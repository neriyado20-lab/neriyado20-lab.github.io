﻿# -*- coding: utf-8 -*-
"""
גל עיני V283 Safe Development
-------------------
עקרון יסוד:
1. torah_clean.txt = מקור החיפוש היחיד. חייב להיות 304,805 אותיות.
2. torah.txt = מקור תצוגה/ספ״פ בלבד, אם קיים.
3. אין שינוי בקבצי המקור.
4. חיפוש דילוג אמיתי: start + i * skip.
5. רשת דמיונית: אין קווי משבצות, רק אותיות ורקעים.
"""

import os
import base64
import re
import random
import json
import threading
import time
import hashlib
import ctypes
import math
import sys
import subprocess
import struct
import tempfile
import textwrap
import urllib.error
import urllib.request
import webbrowser
import zlib
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk, messagebox, filedialog, colorchooser, simpledialog
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Tuple, Optional

TARGET_COUNT = 304805
HEBREW = set("אבגדהוזחטיכלמנסעפצקרשתךםןףץ")
FINAL_TO_REGULAR = str.maketrans({"ך": "כ", "ם": "מ", "ן": "נ", "ף": "פ", "ץ": "צ"})
ENGLISH_TO_HEBREW_KEYS = str.maketrans({
    "q": "/", "w": "'", "e": "ק", "r": "ר", "t": "א", "y": "ט", "u": "ו", "i": "ן", "o": "ם", "p": "פ",
    "a": "ש", "s": "ד", "d": "ג", "f": "כ", "g": "ע", "h": "י", "j": "ח", "k": "ל", "l": "ך",
    "z": "ז", "x": "ס", "c": "ב", "v": "ה", "b": "נ", "n": "מ", "m": "צ",
    "Q": "/", "W": "'", "E": "ק", "R": "ר", "T": "א", "Y": "ט", "U": "ו", "I": "ן", "O": "ם", "P": "פ",
    "A": "ש", "S": "ד", "D": "ג", "F": "כ", "G": "ע", "H": "י", "J": "ח", "K": "ל", "L": "ך",
    "Z": "ז", "X": "ס", "C": "ב", "V": "ה", "B": "נ", "N": "מ", "M": "צ",
})
TORAH_SEARCH_FILE = "torah_clean.txt"
TORAH_DISPLAY_FILE = "torah.txt"
SCAN_WORDS_FILE = "scan_words.txt"
DATE_WORDS_FILE = "date_words.json"
WORD_CATEGORY_FILES = {
    "שמות אנשים/אישים": "scan_words_people.txt",
    "ארצות ויבשות": "scan_words_places.txt",
    "תארים ותכונות": "scan_words_titles_traits.txt",
    "סוגי ארועים": "scan_words_events.txt",
    "מילות גאלה": "scan_words_redemption.txt",
    "שונות": "scan_words_misc.txt",
}
SEARCH_STATE_FILE = "gal_einai_search_state.json"
APP_SETTINGS_FILE = "gal_einai_settings.json"
INFO_DOC_FILE = "פירוט_התוכנה_גל_עיני.md"
SKIP_TECH_DOC_FILE = "מסמך_טכני_דילוגים_גל_עיני.md"
APP_ICON_ICO = "gal_einai_icon.ico"
APP_ICON_PNG = "gal_einai_icon.png"
MAX_SEARCH_SECONDS = 0.0
MAX_SKIP_VALUES = 2000
FREE_SKIP_LIMIT = 5000
MAX_AUTO_EXTENDED_SKIP = FREE_SKIP_LIMIT
MAX_SCAN_WORDS = 6000
MAX_SCAN_RESULTS = 300
MAX_GRID_COLS = 1200
CLUSTER_BOX_ROWS = 10
CLUSTER_BOX_COLS = 10
APP_VERSION = "V382"
GAL_EINAI_PURCHASE_URL = "https://neriyado20-lab.github.io/purchase.html?source=ai_decode&reason=quota"
AI_FEATURES_ENABLED = True
APP_EDITION_LABEL = "עם AI" if AI_FEATURES_ENABLED else "ללא AI"
APP_WINDOW_TITLE = f"גל עיני {APP_VERSION} {APP_EDITION_LABEL} - תוכנה לחיפוש צפנים בתורה"
DEFAULT_WINDOW_GEOMETRY = "1280x760"
MIN_WINDOW_WIDTH = 980
MIN_WINDOW_HEIGHT = 620
MIN_FREE_RAM_MB = 512
MAX_MEMORY_LOAD_PERCENT = 94
MAX_PROCESS_RAM_MB = 2048
MEMORY_CHECK_INTERVAL = 0.5
PARCHMENT_BG = "#f6ecd9"
OUTSIDE_TORAH_BG = "#ddd7cc"
WORD_COLOR_PALETTE = (
    "#ffd400", "#00d084", "#00b0f0", "#ff8c00",
    "#c000ff", "#00c2a8", "#ff66a3", "#a6ff00",
    "#ffbf00", "#4da3ff", "#7ed957", "#ff7b7b",
)
RTL_MARK = "\u200f"
RTL_START = "\u202b"
RTL_END = "\u202c"
AVOT_TICKER_FILE = "pirkei_avot_mishnayot.json"
DEFAULT_AVOT_TICKER_LINES = (
    "פרקי אבות: הוי דן את כל האדם לכף זכות.",
    "פרקי אבות: איזהו חכם? הלומד מכל אדם.",
    "פרקי אבות: איזהו גיבור? הכובש את יצרו.",
    "פרקי אבות: איזהו עשיר? השמח בחלקו.",
    "פרקי אבות: לא עליך המלאכה לגמור, ולא אתה בן חורין ליבטל ממנה.",
    "פרקי אבות: אם אין אני לי, מי לי? וכשאני לעצמי, מה אני?",
    "פרקי אבות: על שלושה דברים העולם עומד: על התורה, ועל העבודה, ועל גמילות חסדים.",
    "פרקי אבות: סייג לחכמה שתיקה.",
    "פרקי אבות: במקום שאין אנשים, השתדל להיות איש.",
    "פרקי אבות: כל מעשיך יהיו לשם שמים.",
)


def load_avot_ticker_lines() -> Tuple[str, ...]:
    try:
        path = Path(__file__).resolve().with_name(AVOT_TICKER_FILE)
        raw = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(raw, list):
            lines = [str(item).strip() for item in raw if str(item).strip()]
            if lines:
                return tuple(lines)
    except Exception:
        pass
    return DEFAULT_AVOT_TICKER_LINES


AVOT_TICKER_LINES = load_avot_ticker_lines()

def force_hebrew_keyboard_text(text: str) -> str:
    return str(text).translate(ENGLISH_TO_HEBREW_KEYS)


def rtl_display(text) -> str:
    value = str(text or "")
    if not value:
        return ""
    return "\n".join(f"{RTL_START}{RTL_MARK}{line}{RTL_MARK}{RTL_END}" if line else "" for line in value.splitlines())


def format_avot_ticker_text(text: str, line_chars: int = 115) -> str:
    value = " ".join(str(text or "").split())
    if not value:
        return ""
    match = re.match(r"^(אבות פ' [^']+' מש' [^']+':)\s*(.*)$", value)
    if not match:
        return "\n".join(textwrap.wrap(value, width=line_chars, break_long_words=False, break_on_hyphens=False))
    ref, body = match.groups()
    lines = []
    current = ref
    for word in body.split():
        addition = f" {word}"
        if len(current) + len(addition) > line_chars:
            lines.append(current)
            current = word
        else:
            current += addition
    if current:
        lines.append(current)
    return "\n".join(lines)


def rtl_showinfo(title, message, **kwargs):
    return messagebox.showinfo(rtl_display(title), rtl_display(message), **kwargs)


def rtl_showerror(title, message, **kwargs):
    return messagebox.showerror(rtl_display(title), rtl_display(message), **kwargs)


def rtl_showwarning(title, message, **kwargs):
    return messagebox.showwarning(rtl_display(title), rtl_display(message), **kwargs)


def rtl_askyesno(title, message, **kwargs):
    return messagebox.askyesno(rtl_display(title), rtl_display(message), **kwargs)


def app_dir() -> str:
    return os.path.dirname(os.path.abspath(__file__))


def app_asset_path(filename: str) -> str:
    return os.path.join(app_dir(), filename)


def set_windows_app_id():
    if os.name != "nt":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(f"NeriyaDeutsch.GalEinai.{APP_VERSION}")
    except Exception:
        pass


def apply_window_icon(root: tk.Tk):
    set_windows_app_id()
    ico_path = app_asset_path(APP_ICON_ICO)
    png_path = app_asset_path(APP_ICON_PNG)
    try:
        if os.path.exists(ico_path):
            root.iconbitmap(ico_path)
    except Exception:
        pass
    try:
        if os.path.exists(png_path):
            icon_photo = tk.PhotoImage(file=png_path)
            root.iconphoto(True, icon_photo)
            root._gal_einai_icon_photo = icon_photo
    except Exception:
        pass
    try:
        root.after(120, lambda r=root: apply_windows_taskbar_icon(r))
    except Exception:
        apply_windows_taskbar_icon(root)


def apply_windows_taskbar_icon(root: tk.Tk):
    if os.name != "nt":
        return
    ico_path = app_asset_path(APP_ICON_ICO)
    if not os.path.exists(ico_path):
        return
    try:
        root.update_idletasks()
        hwnd = root.winfo_id()
        user32 = ctypes.windll.user32
        image_icon = 1
        lr_loadfromfile = 0x00000010
        wm_seticon = 0x0080
        icon_small = 0
        icon_big = 1
        big_icon = user32.LoadImageW(None, ico_path, image_icon, 256, 256, lr_loadfromfile)
        small_icon = user32.LoadImageW(None, ico_path, image_icon, 32, 32, lr_loadfromfile)
        handles = []
        if big_icon:
            user32.SendMessageW(hwnd, wm_seticon, icon_big, big_icon)
            handles.append(big_icon)
        if small_icon:
            user32.SendMessageW(hwnd, wm_seticon, icon_small, small_icon)
            handles.append(small_icon)
        if handles:
            root._gal_einai_windows_icon_handles = handles
    except Exception:
        pass

ALIA_WORDS = (
    "ראשון", "שני", "שלישי", "רביעי",
    "חמישי", "שישי", "ששי", "שביעי",
    "מפטיר", "במחוברין", "במחוברות",
)

BOOKS = ("בראשית", "שמות", "ויקרא", "במדבר", "דברים")
HEBREW_MONTHS = ("ניסן", "אייר", "סיון", "תמוז", "אב", "אלול", "תשרי", "חשון", "כסלו", "טבת", "שבט", "אדר", "אדר א", "אדר ב")

BOOK_SOURCE_FILES = (
    ("בראשית", "book_01_genesis_source.txt"),
    ("שמות", "book_02_exodus_source.txt"),
    ("ויקרא", "book_03_leviticus_source.txt"),
    ("במדבר", "book_04_numbers_source.txt"),
    ("דברים", "book_05_deuteronomy_source.txt"),
)
BUNDLED_ASHURI_FONT_FILES = (
    "StamAshkenazCLM.ttf",
    "StamSefaradCLM.ttf",
    "KeterYG.ttf",
    "EzraSIL.ttf",
    "SBL_Hbrw.ttf",
    "ashuri.ttf",
    "stam.ttf",
)


def stable_word_color(word: str) -> str:
    clean = TorahLoader.hebrew_only(TorahLoader.strip_marks(word)) if "TorahLoader" in globals() else word
    if not clean:
        clean = word or ""
    digest = hashlib.sha256(clean.encode("utf-8")).digest()
    return WORD_COLOR_PALETTE[digest[0] % len(WORD_COLOR_PALETTE)]


def readable_text_on_bg(bg_color: str, fallback: str) -> str:
    if not bg_color or not bg_color.startswith("#") or len(bg_color) != 7:
        return fallback
    try:
        r = int(bg_color[1:3], 16)
        g = int(bg_color[3:5], 16)
        b = int(bg_color[5:7], 16)
    except ValueError:
        return fallback

    def rel_luminance(rgb):
        vals = []
        for channel in rgb:
            c = channel / 255.0
            vals.append(c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4)
        return 0.2126 * vals[0] + 0.7152 * vals[1] + 0.0722 * vals[2]

    bg_lum = rel_luminance((r, g, b))

    def contrast(candidate: str) -> float:
        cr = int(candidate[1:3], 16)
        cg = int(candidate[3:5], 16)
        cb = int(candidate[5:7], 16)
        fg_lum = rel_luminance((cr, cg, cb))
        light = max(bg_lum, fg_lum)
        dark = min(bg_lum, fg_lum)
        return (light + 0.05) / (dark + 0.05)

    return max(("#111111", "#ffffff", "#ffe600"), key=contrast)


def is_primary_red(color: str) -> bool:
    if not color or not color.startswith("#") or len(color) != 7:
        return False
    try:
        r = int(color[1:3], 16)
        g = int(color[3:5], 16)
        b = int(color[5:7], 16)
    except ValueError:
        return False
    return r >= 180 and g <= 95 and b <= 95


def hebrew_number(n: int) -> str:
    if n <= 0:
        return ""
    thousands = n // 1000
    n = n % 1000
    hundreds_map = ["", "ק", "ר", "ש", "ת"]
    tens_map = ["", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ", "צ"]
    ones_map = ["", "א", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט"]
    parts = []
    if thousands and n == 0:
        parts.append(ones_map[thousands] if thousands < len(ones_map) else hebrew_number(thousands))
    while n >= 400:
        parts.append("ת")
        n -= 400
    if n >= 100:
        h = n // 100
        parts.append(hundreds_map[h])
        n %= 100
    if n == 15:
        parts.append("טו")
        n = 0
    elif n == 16:
        parts.append("טז")
        n = 0
    if n >= 10:
        parts.append(tens_map[n // 10])
        n %= 10
    if n:
        parts.append(ones_map[n])
    return "".join(parts)


def canonical_hebrew(text: str) -> str:
    """Search form: final and regular מנצפ״ך letters are treated as equal."""
    return text.translate(FINAL_TO_REGULAR)


def search_pattern(text: str) -> str:
    clean = TorahLoader.strip_marks(text) if "TorahLoader" in globals() else text
    return "".join(ch for ch in clean if ch in HEBREW or ch == "?")


@dataclass
class VerseInfo:
    book: str
    chapter: str
    verse: str
    start: int
    end: int


@dataclass
class Match:
    word: str
    start: int
    skip: int
    kind: str = "primary"
    color: str = ""
    positions: List[int] = field(default_factory=list)

    def calc_positions(self) -> List[int]:
        if not self.positions:
            self.positions = [self.start + i * self.skip for i in range(len(self.word))]
        return self.positions


def match_to_dict(match: Match) -> dict:
    return {
        "word": match.word,
        "start": match.start,
        "skip": match.skip,
        "kind": match.kind,
        "color": match.color,
        "positions": list(match.calc_positions()),
    }


def match_from_dict(data: dict) -> Match:
    return Match(
        str(data.get("word", "")),
        int(data.get("start", 0)),
        int(data.get("skip", 1) or 1),
        str(data.get("kind", "primary")),
        str(data.get("color", "")),
        [int(p) for p in data.get("positions", []) if isinstance(p, int) or str(p).lstrip("-").isdigit()],
    )


class TorahLoader:
    @staticmethod
    def read_file(path: str) -> str:
        last_err = None
        for enc in ("utf-8", "utf-8-sig", "cp1255", "windows-1255"):
            try:
                with open(path, "r", encoding=enc) as f:
                    return f.read()
            except UnicodeDecodeError as e:
                last_err = e
        raise last_err or UnicodeError("לא הצלחתי לקרוא קובץ")

    @staticmethod
    def strip_marks(s: str) -> str:
        # Keep Hebrew maqaf (U+05BE) as a word separator for display/parity.
        return re.sub(r"[\u0591-\u05BD\u05BF-\u05C7]", "", s)

    @staticmethod
    def hebrew_only(s: str) -> str:
        return "".join(ch for ch in s if ch in HEBREW)

    @staticmethod
    def hebrew_words(s: str) -> List[str]:
        return re.findall(r"[אבגדהוזחטיכלמנסעפצקרשתךםןףץ]+", s)

    @staticmethod
    def is_header_line(line: str) -> bool:
        line = line.strip()
        if not line:
            return True
        if line.startswith(("פרשת ", "ספר ", "פרק ", "פסוק ", "הפטרה ", "מפטיר ")):
            return True
        if "פרק-" in line:
            return True
        if "תורת אמת" in line:
            return True
        # separator rows
        if set(line) <= {"-", " "}:
            return True
        return False

    @staticmethod
    def clean_display_line_for_letters(line: str) -> str:
        # This mirrors the successful cleaning logic that produced 304805.
        line = TorahLoader.strip_marks(line)

        # Aliyah words only immediately after verse marker: {א} שני ...
        alia_alt = "|".join(ALIA_WORDS)
        line = re.sub(rf"(\{{[א-ת]+\}})\s+(?:(?:{alia_alt})|\s|-)+\s+", r"\1 ", line)

        # (פ), (ס), (פפפ), (חזק)
        line = re.sub(r"\(([פססרפחזק]+)\)", "", line)

        # Kri/Ktiv: (כתיב) קרי -> כתיב
        line = re.sub(r"\(([^)]+)\)\s*[א-תךםןףץ]+", r"\1", line)

        # verse markers and bracketed items
        line = re.sub(r"\{[^}]*\}", "", line)
        line = re.sub(r"\[[^\]]*\]", "", line)

        line = line.replace(":", " ")
        return line

    @staticmethod
    def chapter_from_header(line: str) -> Optional[Tuple[str, str]]:
        # Example: בראשית פרק-א
        m = re.match(r"^\s*([א-ת]+)\s+פרק-([א-ת]+)\s*$", line.strip())
        if m and m.group(1) in BOOKS:
            return m.group(1), m.group(2)
        return None

    @staticmethod
    def extract_verses_from_display(path: str, expected_letters: str) -> Tuple[List[VerseInfo], List[int]]:
        """Build SPP mapping from original torah.txt without using it for search.
        Returns (verses, word_parity_by_pos).
        """
        if not os.path.exists(path):
            return TorahLoader.extract_verses_from_book_sources(expected_letters)

        raw = TorahLoader.read_file(path)
        lines = raw.splitlines()
        verses: List[VerseInfo] = []
        parity_by_pos: List[int] = []
        built_letters = []
        current_book = "?"
        current_chapter = "?"
        word_parity = 0
        pos = 0

        for raw_line in lines:
            line = raw_line.strip()
            ch = TorahLoader.chapter_from_header(line)
            if ch:
                current_book, current_chapter = ch
                continue
            if TorahLoader.is_header_line(line):
                continue

            # split at verse markers, keeping marker
            parts = re.split(r"(\{[א-ת]+\})", line)
            cur_verse = None
            buf = ""
            for part in parts:
                if not part:
                    continue
                vm = re.fullmatch(r"\{([א-ת]+)\}", part.strip())
                if vm:
                    if cur_verse is not None and buf.strip():
                        pos, word_parity = TorahLoader._append_verse(
                            verses, parity_by_pos, built_letters, current_book, current_chapter, cur_verse, buf, pos, word_parity
                        )
                    cur_verse = vm.group(1)
                    buf = ""
                else:
                    buf += " " + part
            if cur_verse is not None and buf.strip():
                pos, word_parity = TorahLoader._append_verse(
                    verses, parity_by_pos, built_letters, current_book, current_chapter, cur_verse, buf, pos, word_parity
                )

        display_letters = "".join(built_letters)
        if display_letters != expected_letters:
            # If mapping source is not perfectly aligned, do not risk wrong SPP.
            return TorahLoader.extract_verses_from_book_sources(expected_letters)

        if len(parity_by_pos) != len(expected_letters):
            parity_by_pos = [0] * len(expected_letters)

        return verses, parity_by_pos

    @staticmethod
    def extract_verses_from_book_sources(expected_letters: str) -> Tuple[List[VerseInfo], List[int]]:
        """Build exact SPP and alternating word colors from the five source book files."""
        verses: List[VerseInfo] = []
        parity_by_pos: List[int] = []
        built_letters: List[str] = []
        pos = 0
        word_parity = 0

        def clean_ref(ref: str) -> str:
            return ref.strip().strip("'\"׳״")

        def flush(book: str, chapter: str, verse: str, lines: List[str]):
            nonlocal pos, word_parity
            text = " ".join(lines).strip()
            if not text:
                return
            cleaned_text = TorahLoader.strip_marks(text)
            words = TorahLoader.hebrew_words(cleaned_text)
            verse_letters = "".join(words)
            if not verse_letters:
                return
            start = pos
            built_letters.append(verse_letters)
            for word in words:
                parity_by_pos.extend([word_parity] * len(word))
                word_parity = 1 - word_parity
            pos += len(verse_letters)
            verses.append(VerseInfo(book, chapter, verse, start, pos - 1))

        for book, filename in BOOK_SOURCE_FILES:
            if not os.path.exists(filename):
                return [VerseInfo("", "", "", 0, max(0, len(expected_letters)-1))], [0] * len(expected_letters)

            chapter = ""
            verse = ""
            verse_lines: List[str] = []
            raw = TorahLoader.read_file(filename)
            for raw_line in raw.splitlines():
                line = raw_line.strip()
                if not line or line in ("ראש_ספר", "פתוחה", "סתומה"):
                    continue
                ch_match = re.match(r"^פרק\s+(.+)$", TorahLoader.strip_marks(line))
                if ch_match:
                    if verse and verse_lines:
                        flush(book, chapter, verse, verse_lines)
                    chapter = clean_ref(ch_match.group(1))
                    verse = ""
                    verse_lines = []
                    continue
                verse_match = re.match(r"^פסוק\s+(.+)$", TorahLoader.strip_marks(line))
                if verse_match:
                    if verse and verse_lines:
                        flush(book, chapter, verse, verse_lines)
                    verse = clean_ref(verse_match.group(1))
                    verse_lines = []
                    continue
                if verse:
                    verse_lines.append(line)

            if verse and verse_lines:
                flush(book, chapter, verse, verse_lines)

        if "".join(built_letters) != expected_letters or len(parity_by_pos) != len(expected_letters):
            return [VerseInfo("", "", "", 0, max(0, len(expected_letters)-1))], [0] * len(expected_letters)

        return verses, parity_by_pos

    @staticmethod
    def _append_verse(verses, parity_by_pos, built_letters, book, chapter, verse, text, pos, word_parity):
        cleaned_text = TorahLoader.clean_display_line_for_letters(text)
        words = TorahLoader.hebrew_words(cleaned_text)
        verse_letters = "".join(words)
        if not verse_letters:
            return pos, word_parity

        start = pos
        built_letters.append(verse_letters)
        for w in words:
            parity_by_pos.extend([word_parity] * len(w))
            word_parity = 1 - word_parity
        pos += len(verse_letters)
        verses.append(VerseInfo(book, chapter, verse, start, pos - 1))
        return pos, word_parity


class TorahModel:
    def __init__(self):
        self.search_text = ""
        self.verses: List[VerseInfo] = []
        self.word_parity: List[int] = []
        self.search_path = TORAH_SEARCH_FILE
        self.display_path = TORAH_DISPLAY_FILE
        self.info: dict = {}

    def load(self, search_path=TORAH_SEARCH_FILE, display_path=TORAH_DISPLAY_FILE) -> dict:
        self.search_path = search_path
        self.display_path = display_path
        if not os.path.exists(search_path):
            raise FileNotFoundError(f"לא נמצא {search_path}. צריך לשים ליד התוכנה את torah_clean.txt המאומת.")

        raw = TorahLoader.read_file(search_path)
        letters = TorahLoader.hebrew_only(TorahLoader.strip_marks(raw))
        self.search_text = letters

        self.verses, self.word_parity = TorahLoader.extract_verses_from_display(display_path, self.search_text)

        self.info = {
            "path": os.path.abspath(search_path),
            "count": len(self.search_text),
            "raw_chars": len(raw),
            "count_ok": len(self.search_text) == TARGET_COUNT,
            "start": self.search_text[:30],
            "end": self.search_text[-30:] if self.search_text else "",
            "start_ok": self.search_text.startswith("בראשיתבראאלהים"),
            "end_ok": self.search_text.endswith("לעיניכלישראל"),
            "sha256": hashlib.sha256(self.search_text.encode("utf-8")).hexdigest(),
            "mapping_ok": bool(self.verses and self.verses[0].book != "?"),
            "display_file": display_path if os.path.exists(display_path) else "לא נמצא",
        }
        return self.info

    def spp_at(self, idx: int) -> str:
        lo, hi = 0, len(self.verses) - 1
        while lo <= hi:
            mid = (lo + hi) // 2
            v = self.verses[mid]
            if idx < v.start:
                hi = mid - 1
            elif idx > v.end:
                lo = mid + 1
            else:
                if not (v.book and v.chapter and v.verse) or "?" in (v.book, v.chapter, v.verse):
                    return ""
                return f"{v.book} {v.chapter}:{v.verse}"
        return ""


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_ulong),
        ("PageFaultCount", ctypes.c_ulong),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


class MemoryGuard:
    def __init__(
        self,
        min_free_mb: int = MIN_FREE_RAM_MB,
        max_load_percent: int = MAX_MEMORY_LOAD_PERCENT,
        max_process_mb: int = MAX_PROCESS_RAM_MB,
        check_interval: float = MEMORY_CHECK_INTERVAL,
    ):
        self.min_free_mb = min_free_mb
        self.max_load_percent = max_load_percent
        self.max_process_mb = max_process_mb
        self.check_interval = check_interval
        self.next_check = 0.0
        self.last_reason = ""

    def reset(self):
        self.next_check = 0.0
        self.last_reason = ""

    @staticmethod
    def _system_memory():
        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return stat.dwMemoryLoad, stat.ullAvailPhys / (1024 * 1024)
        return None, None

    @staticmethod
    def _process_memory_mb():
        try:
            counters = PROCESS_MEMORY_COUNTERS()
            counters.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS)
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            psapi = ctypes.WinDLL("psapi", use_last_error=True)
            kernel32.GetCurrentProcess.restype = ctypes.c_void_p
            psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong]
            psapi.GetProcessMemoryInfo.restype = ctypes.c_int
            handle = kernel32.GetCurrentProcess()
            ok = psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb)
            if ok:
                return counters.WorkingSetSize / (1024 * 1024)
        except Exception:
            return None
        return None

    def should_stop(self) -> bool:
        now = time.monotonic()
        if now < self.next_check:
            return False
        self.next_check = now + self.check_interval

        load_percent, free_mb = self._system_memory()
        if free_mb is not None and free_mb < self.min_free_mb:
            self.last_reason = f"החיפוש נעצר אוטומטית: נשארו רק {free_mb:.0f}MB RAM פנויים"
            return True
        if load_percent is not None and load_percent >= self.max_load_percent:
            self.last_reason = f"החיפוש נעצר אוטומטית: עומס RAM כללי {load_percent:.0f}%"
            return True

        process_mb = self._process_memory_mb()
        if process_mb is not None and process_mb >= self.max_process_mb:
            self.last_reason = f"החיפוש נעצר אוטומטית: התוכנה משתמשת בכ-{process_mb:.0f}MB RAM"
            return True

        return False


class SearchEngine:
    def __init__(self, model: TorahModel):
        self.model = model
        self.index: Dict[str, List[int]] = {}
        self.canonical_text = ""
        self.stop_flag = False
        self.deadline: Optional[float] = None
        self.stop_reason = ""
        self.memory_guard = MemoryGuard()
        self.max_seconds = MAX_SEARCH_SECONDS
        self.next_ui_yield = 0.0
        self.ui_yield_interval = 0.035

    def begin_search(self, max_seconds: float = MAX_SEARCH_SECONDS):
        self.stop_flag = False
        self.stop_reason = ""
        self.max_seconds = float(max_seconds)
        self.deadline = time.monotonic() + self.max_seconds if self.max_seconds > 0 else None
        self.memory_guard.reset()
        self.next_ui_yield = time.monotonic() + self.ui_yield_interval

    def breathe(self):
        """Give Tk/Windows a tiny scheduling gap during CPU-heavy searches."""
        now = time.monotonic()
        if now >= self.next_ui_yield:
            time.sleep(0.001)
            self.next_ui_yield = now + self.ui_yield_interval

    def should_stop(self) -> bool:
        self.breathe()
        if self.stop_flag:
            if not self.stop_reason:
                self.stop_reason = "החיפוש נעצר ידנית"
            return True
        if self.deadline is not None and time.monotonic() >= self.deadline:
            self.stop_flag = True
            self.stop_reason = f"החיפוש נעצר אוטומטית אחרי {self.max_seconds:g} שניות"
            return True
        if self.memory_guard.should_stop():
            self.stop_flag = True
            self.stop_reason = self.memory_guard.last_reason
            return True
        return False

    @staticmethod
    def normalize_word(word: str) -> str:
        return search_pattern(word)

    def build_index(self):
        self.index = {}
        self.canonical_text = canonical_hebrew(self.model.search_text)
        for i, ch in enumerate(self.canonical_text):
            self.index.setdefault(ch, []).append(i)

    @staticmethod
    def build_skip_list(skip_from: int, skip_to: int, include_plain: bool = True) -> List[int]:
        a, b = int(skip_from), int(skip_to)
        if a > b:
            a, b = b, a
        a, b = max(1, abs(a)), max(1, abs(b))
        if a > b:
            a, b = b, a

        values = []
        seen = set()
        for s in range(a, b + 1):
            for k in (s, -s):
                if k not in seen:
                    values.append(k)
                    seen.add(k)

        if include_plain:
            plain = []
            for k in (1, -1):
                if k not in seen:
                    plain.append(k)
                    seen.add(k)
            values = plain + values

        return values

    @staticmethod
    def minimal_skip_pairs(skip_from: int, skip_to: int):
        a, b = int(skip_from), int(skip_to)
        if a > b:
            a, b = b, a
        a, b = max(1, abs(a)), max(1, abs(b))
        if a > b:
            a, b = b, a
        for s in range(a, b + 1):
            yield s, [s, -s]

    def check_word_at(self, word: str, start: int, skip: int) -> bool:
        if skip == 0:
            return False
        word = canonical_hebrew(word)
        text = self.canonical_text or canonical_hebrew(self.model.search_text)
        n = len(self.model.search_text)
        for i, ch in enumerate(word):
            pos = start + i * skip
            if pos < 0 or pos >= n or (ch != "?" and text[pos] != ch):
                return False
        return True

    def letters_at(self, start: int, skip: int, length: int) -> str:
        out = []
        n = len(self.model.search_text)
        for i in range(length):
            p = start + i * skip
            out.append(self.model.search_text[p] if 0 <= p < n else "∅")
        return "".join(out)

    def report_progress(self, progress, done: int, total: int, skip: Optional[int] = None, found_count: Optional[int] = None):
        if not progress:
            return
        try:
            progress(done, total, skip, found_count)
        except TypeError:
            try:
                progress(done, total, skip)
            except TypeError:
                progress(done, total)

    def find_word(self, word: str, skips: List[int], limit: Optional[int] = None, progress=None) -> List[Match]:
        word = self.normalize_word(word)
        if not word:
            return []
        lookup_word = canonical_hebrew(word)
        if not self.index:
            self.build_index()
        n = len(self.model.search_text)
        anchor_options = [(i, ch) for i, ch in enumerate(lookup_word) if ch != "?"]
        if anchor_options:
            anchor_i, anchor_ch = min(
                anchor_options,
                key=lambda item: len(self.index.get(item[1], [])),
            )
            anchor_positions = self.index.get(anchor_ch, [])
        else:
            anchor_i = 0
            anchor_positions = range(n)
        results = []
        total = max(1, len(skips) * len(anchor_positions))
        done = 0

        for skip in skips:
            if skip == 0:
                continue
            for anchor_pos in anchor_positions:
                if self.should_stop():
                    return results
                done += 1
                if progress and done % 3000 == 0:
                    self.report_progress(progress, done, total, skip, len(results))

                start = anchor_pos - anchor_i * skip
                end = start + (len(word) - 1) * skip
                if start < 0 or start >= n or end < 0 or end >= n:
                    continue

                if self.check_word_at(word, start, skip):
                    display_word = self.letters_at(start, skip, len(word)) if "?" in word else word
                    m = Match(word=display_word, start=start, skip=skip, kind="primary")
                    m.calc_positions()
                    results.append(m)
                    self.report_progress(progress, done, total, skip, len(results))
                    if limit and len(results) >= limit:
                        self.report_progress(progress, done, total, skip, len(results))
                        return results
        self.report_progress(progress, total, total, skips[-1] if skips else None, len(results))
        return results

    def find_minimal_word(self, word: str, skip_from: int, skip_to: int, progress=None) -> List[Match]:
        """חיפוש מינימלי אמיתי לפי הטווח שהוגדר, ומחזיר את כל הממצאים בדילוג הקטן ביותר."""
        word = self.normalize_word(word)
        if not word:
            return []
        pairs = list(self.minimal_skip_pairs(skip_from, skip_to))
        total = len(pairs) or 1
        for idx, (s, skips) in enumerate(pairs, 1):
            if self.should_stop():
                return []
            if progress and (idx == 1 or idx % 10 == 0):
                self.report_progress(progress, idx, total, s)
            found = self.find_word(word, skips, limit=None)
            if found:
                self.report_progress(progress, total, total, s)
                return found
        self.report_progress(progress, total, total, pairs[-1][0] if pairs else None)
        return []

    def find_text(self, phrase: str) -> List[Match]:
        phrase = self.normalize_word(phrase)
        lookup_phrase = canonical_hebrew(phrase)
        if not self.canonical_text:
            self.build_index()
        res = []
        i = 0
        while phrase:
            if self.should_stop():
                break
            if "?" in lookup_phrase:
                found_at = -1
                limit = len(self.canonical_text) - len(lookup_phrase) + 1
                for pos in range(i, max(0, limit)):
                    if all(ch == "?" or self.canonical_text[pos + j] == ch for j, ch in enumerate(lookup_phrase)):
                        found_at = pos
                        break
                i = found_at
            else:
                i = self.canonical_text.find(lookup_phrase, i)
            if i == -1:
                break
            actual = self.model.search_text[i:i + len(phrase)]
            m = Match(actual if "?" in phrase else phrase, i, 1, "text")
            m.calc_positions()
            res.append(m)
            i += 1
            if len(res) >= 500:
                break
        return res

    def find_in_window(self, word: str, positions: set, skips: List[int], kind="secondary") -> List[Match]:
        word = self.normalize_word(word)
        if not word:
            return []
        lookup_word = canonical_hebrew(word)
        if not self.canonical_text:
            self.build_index()
        results = []
        anchor_options = [(i, ch) for i, ch in enumerate(lookup_word) if ch != "?"]
        if anchor_options:
            anchor_i, anchor_ch = min(
                anchor_options,
                key=lambda item: sum(1 for p in positions if self.canonical_text[p] == item[1]),
            )
            anchor_positions = [p for p in positions if self.canonical_text[p] == anchor_ch]
        else:
            anchor_i = 0
            anchor_positions = list(positions)
        for skip in skips:
            if skip == 0:
                continue
            for anchor_pos in anchor_positions:
                if self.should_stop():
                    return results
                start = anchor_pos - anchor_i * skip
                ps = [start + i * skip for i in range(len(word))]
                if all(p in positions for p in ps) and self.check_word_at(word, start, skip):
                    display_word = self.letters_at(start, skip, len(word)) if "?" in word else word
                    results.append(Match(display_word, start, skip, kind, positions=ps))
        return results


DEFAULT_TOOLTIP_DELAY_MS = 300
MIN_TOOLTIP_VISIBLE_MS = 1300
MAX_TOOLTIP_VISIBLE_MS = 3600
HELP_HINT_TOOLTIP = "קליק ימני לעזרה"
LONG_TOOLTIP_CHARS = 95


def tooltip_visible_time(text) -> int:
    try:
        raw = text() if callable(text) else str(text or "")
    except Exception:
        raw = ""
    length = len(re.sub(r"\s+", "", raw))
    return max(MIN_TOOLTIP_VISIBLE_MS, min(MAX_TOOLTIP_VISIBLE_MS, 900 + length * 22))


def tooltip_is_long(text: str) -> bool:
    text = str(text or "").strip()
    return "\n" in text or len(text) > LONG_TOOLTIP_CHARS

def widget_should_have_right_click_help(widget) -> bool:
    try:
        cls = str(widget.winfo_class())
    except Exception:
        cls = ""
    return cls in {
        "Button",
        "TButton",
        "Checkbutton",
        "TCheckbutton",
        "Radiobutton",
        "TRadiobutton",
    }


def tooltip_summary(text: str) -> str:
    text = re.sub(r"\s+", " ", str(text or "").strip())
    if not text:
        return ""
    for sep in (".", ":", "?", "!"):
        idx = text.find(sep)
        if 18 <= idx <= LONG_TOOLTIP_CHARS:
            return text[:idx + 1]
    if len(text) <= LONG_TOOLTIP_CHARS:
        return text
    return text[:LONG_TOOLTIP_CHARS - 1].rstrip() + "..."


class ToolTip:
    def __init__(self, widget, text: str, delay: int = 450, visible_ms: Optional[int] = None):
        self.widget = widget
        self.text = text
        self.delay = delay
        self.visible_ms = visible_ms
        self.tip = None
        self.after_id = None
        self.hide_after_id = None
        initial_text = self.text_value()
        self.has_help_window = bool(initial_text) and (tooltip_is_long(initial_text) or widget_should_have_right_click_help(widget)) and not widget.bind("<Button-3>")
        widget.bind("<Enter>", self.schedule, add="+")
        widget.bind("<Leave>", self.hide, add="+")
        widget.bind("<ButtonPress>", self.hide, add="+")
        if self.has_help_window:
            widget.bind("<Button-3>", self.show_help, add="+")

    def text_value(self) -> str:
        try:
            return self.text() if callable(self.text) else str(self.text or "")
        except Exception:
            return ""

    def schedule(self, _event=None):
        self.cancel()
        self.after_id = self.widget.after(self.delay, self.show)

    def cancel(self):
        if self.after_id:
            self.widget.after_cancel(self.after_id)
            self.after_id = None
        if self.hide_after_id:
            self.widget.after_cancel(self.hide_after_id)
            self.hide_after_id = None

    def show(self):
        full_text = self.text_value()
        if tooltip_is_long(full_text):
            text = tooltip_summary(full_text)
            if self.has_help_window:
                text = f"{text}\n{HELP_HINT_TOOLTIP}"
        else:
            text = full_text
            if self.has_help_window and widget_should_have_right_click_help(self.widget):
                text = f"{text}\n{HELP_HINT_TOOLTIP}"
        if self.tip or not text:
            return
        x = self.widget.winfo_rootx() + 18
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 8
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        label = tk.Label(
            self.tip,
            text=rtl_display(text),
            anchor="e",
            justify="right",
            bg="#fff8dc",
            fg="#111111",
            relief="solid",
            borderwidth=1,
            padx=8,
            pady=5,
            font=("Arial", 10),
            wraplength=330,
        )
        label.pack()
        self.tip.update_idletasks()
        tip_w = self.tip.winfo_width()
        tip_h = self.tip.winfo_height()
        screen_w = self.widget.winfo_screenwidth()
        screen_h = self.widget.winfo_screenheight()
        x = max(4, min(x, screen_w - tip_w - 8))
        if y + tip_h > screen_h - 8:
            y = self.widget.winfo_rooty() - tip_h - 8
        y = max(4, min(y, screen_h - tip_h - 8))
        self.tip.wm_geometry(f"+{x}+{y}")
        if self.visible_ms:
            self.hide_after_id = self.widget.after(int(self.visible_ms), self.hide)

    def show_help(self, event=None):
        text = self.text_value()
        if not text:
            return None
        self.hide()
        win = tk.Toplevel(self.widget)
        win.title("עזרה קצרה")
        win.transient(self.widget.winfo_toplevel())
        win.resizable(True, True)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        msg = tk.Message(
            frame,
            text=rtl_display(text),
            width=420,
            anchor="e",
            justify="right",
            font=("Arial", 11),
            bg="#fff8dc",
            relief="solid",
            borderwidth=1,
            padx=10,
            pady=8,
        )
        msg.grid(row=0, column=0, sticky="nsew")
        ttk.Button(frame, text="סגור", command=win.destroy).grid(row=1, column=0, sticky="ew", pady=(8, 0))
        x = event.x_root + 12 if event else self.widget.winfo_rootx() + 20
        y = event.y_root + 12 if event else self.widget.winfo_rooty() + 20
        win.update_idletasks()
        screen_w = win.winfo_screenwidth()
        screen_h = win.winfo_screenheight()
        x = max(4, min(x, screen_w - win.winfo_width() - 8))
        y = max(4, min(y, screen_h - win.winfo_height() - 8))
        win.geometry(f"+{x}+{y}")
        return "break"

    def hide(self, _event=None):
        self.cancel()
        if self.tip:
            self.tip.destroy()
        self.tip = None


class HebrewWordField(tk.Text):
    """Single-line Hebrew text field with stable mouse selection."""

    def __init__(self, master, textvariable: tk.StringVar, width=24, font=("Arial", 11), **kwargs):
        super().__init__(
            master,
            height=1,
            width=width,
            font=font,
            wrap="none",
            undo=True,
            exportselection=False,
            padx=4,
            pady=2,
            bd=1,
            relief="sunken",
            **kwargs,
        )
        self.textvariable = textvariable
        self._syncing = False
        self._drag_anchor = None
        self.tag_configure("rtl", justify="right")
        self._replace_all(textvariable.get())
        self.bind("<<Modified>>", self._on_modified)
        self._trace_id = textvariable.trace_add("write", self._on_variable_changed)
        self.bind("<Return>", lambda _event: "break")
        self.bind("<Control-a>", self._select_all)
        self.bind("<Control-A>", self._select_all)
        self.bind("<Tab>", self._focus_next)
        self.bind("<Button-1>", self._mouse_down)
        self.bind("<B1-Motion>", self._mouse_drag)
        self.bind("<ButtonRelease-1>", self._mouse_up)
        self.bind("<Button-3>", self._context_menu)
        self.bind("<<Paste>>", self._paste_clean)
        self.bind("<KeyRelease>", lambda _event: self.see("insert"))

    def value(self) -> str:
        return tk.Text.get(self, "1.0", "end-1c").replace("\n", " ")

    def _replace_all(self, text: str):
        self._syncing = True
        try:
            tk.Text.delete(self, "1.0", "end")
            tk.Text.insert(self, "1.0", str(text).replace("\n", " "))
            self.tag_add("rtl", "1.0", "end")
            self.mark_set("insert", "end-1c")
            self.edit_modified(False)
        finally:
            self._syncing = False

    def _on_modified(self, _event=None):
        if self._syncing or not self.edit_modified():
            return
        value = self.value()
        if self.textvariable.get() != value:
            self._syncing = True
            try:
                self.textvariable.set(value)
            finally:
                self._syncing = False
        self.tag_add("rtl", "1.0", "end")
        self.edit_modified(False)

    def _on_variable_changed(self, *_args):
        if self._syncing:
            return
        if self.value() != self.textvariable.get():
            self._replace_all(self.textvariable.get())

    def _text_index(self, index):
        if isinstance(index, int):
            return f"1.{max(0, index)}"
        if index == "end":
            return "end-1c"
        if index == "insert":
            return "insert"
        if isinstance(index, str) and index.startswith("@"):
            parts = index[1:].split(",")
            x = int(parts[0] or 0)
            y = int(parts[1] or max(1, self.winfo_height() // 2)) if len(parts) > 1 else max(1, self.winfo_height() // 2)
            return tk.Text.index(self, f"@{x},{y}")
        return index

    def _offset(self, index) -> int:
        idx = tk.Text.index(self, self._text_index(index))
        return int(idx.split(".")[1])

    def index(self, index):
        return self._offset(index)

    def icursor(self, index):
        self.mark_set("insert", self._text_index(index))
        self.see("insert")

    def selection_range(self, start, end):
        self.tag_remove("sel", "1.0", "end")
        self.tag_add("sel", self._text_index(start), self._text_index(end))

    def selection_clear(self):
        self.tag_remove("sel", "1.0", "end")

    def delete(self, start, end=None):
        tk.Text.delete(self, self._text_index(start), self._text_index(end) if end is not None else None)
        self.tag_add("rtl", "1.0", "end")

    def insert(self, index, chars, *args):
        tk.Text.insert(self, self._text_index(index), str(chars).replace("\n", " "), *args)
        self.tag_add("rtl", "1.0", "end")

    def _mouse_index(self, event):
        return self._text_index(f"@{event.x},{event.y}")

    def _mouse_down(self, event):
        self.focus_set()
        idx = self._mouse_index(event)
        self._drag_anchor = idx
        self.tag_remove("sel", "1.0", "end")
        self.mark_set("insert", idx)
        return "break"

    def _mouse_drag(self, event):
        idx = self._mouse_index(event)
        anchor = self._drag_anchor or self.index("insert")
        self.tag_remove("sel", "1.0", "end")
        if tk.Text.compare(self, anchor, "<", idx):
            self.tag_add("sel", anchor, idx)
        elif tk.Text.compare(self, idx, "<", anchor):
            self.tag_add("sel", idx, anchor)
        self.mark_set("insert", idx)
        self.see("insert")
        return "break"

    def _mouse_up(self, event):
        idx = self._mouse_index(event)
        if self._drag_anchor and tk.Text.compare(self, self._drag_anchor, "==", idx):
            self.tag_remove("sel", "1.0", "end")
            self.mark_set("insert", idx)
        self._drag_anchor = None
        return "break"

    def _select_all(self, _event=None):
        self.tag_add("sel", "1.0", "end-1c")
        self.mark_set("insert", "end-1c")
        return "break"

    def _focus_next(self, _event=None):
        self.tk_focusNext().focus_set()
        return "break"

    def _paste_clean(self, _event=None):
        try:
            text = self.clipboard_get().replace("\r", " ").replace("\n", " ")
        except tk.TclError:
            return "break"
        try:
            tk.Text.delete(self, "sel.first", "sel.last")
        except tk.TclError:
            pass
        tk.Text.insert(self, "insert", text)
        self.tag_add("rtl", "1.0", "end")
        self.event_generate("<<Modified>>")
        return "break"

    def _context_menu(self, event):
        def delete_selection():
            try:
                tk.Text.delete(self, "sel.first", "sel.last")
            except tk.TclError:
                pass

        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="גזור", command=lambda: self.event_generate("<<Cut>>"))
        menu.add_command(label="העתק", command=lambda: self.event_generate("<<Copy>>"))
        menu.add_command(label="הדבק", command=lambda: self.event_generate("<<Paste>>"))
        menu.add_command(label="מחק", command=delete_selection)
        menu.add_separator()
        menu.add_command(label="בחר הכל", command=self._select_all)
        menu.tk_popup(event.x_root, event.y_root)
        return "break"


class PlainWordTextField(tk.Text):
    """Native Tk text field with no wrapping, so selection never reflows letters."""

    def __init__(self, master, textvariable: tk.StringVar, height=1, width=30, font=("Arial", 11), single_line=False, **kwargs):
        super().__init__(
            master,
            height=height,
            width=width,
            font=font,
            wrap="none",
            undo=True,
            exportselection=False,
            padx=4,
            pady=2,
            bd=1,
            relief="sunken",
            **kwargs,
        )
        self.textvariable = textvariable
        self.single_line = single_line
        self._syncing = False
        self._replace_all(textvariable.get())
        self.bind("<<Modified>>", self._on_modified)
        self._trace_id = textvariable.trace_add("write", self._on_variable_changed)
        self.bind("<Control-a>", self.select_all)
        self.bind("<Control-A>", self.select_all)
        self.bind("<Button-3>", self.show_context_menu)
        self.bind("<<Paste>>", self.paste_clean)
        self.bind("<Delete>", self.delete_key)
        self.bind("<BackSpace>", self.backspace_key)
        if single_line:
            self.bind("<Return>", lambda _event: "break")
        self.bind("<Tab>", self.focus_next)

    def get_value(self) -> str:
        text = tk.Text.get(self, "1.0", "end-1c")
        return text.replace("\n", " ") if self.single_line else text

    def _replace_all(self, value: str):
        self._syncing = True
        try:
            text = str(value)
            if self.single_line:
                text = text.replace("\r", " ").replace("\n", " ")
            tk.Text.delete(self, "1.0", "end")
            tk.Text.insert(self, "1.0", text)
            self.mark_set("insert", "end-1c")
            self.edit_modified(False)
        finally:
            self._syncing = False

    def _on_modified(self, _event=None):
        if self._syncing or not self.edit_modified():
            return
        value = self.get_value()
        if self.textvariable.get() != value:
            self._syncing = True
            try:
                self.textvariable.set(value)
            finally:
                self._syncing = False
        self.edit_modified(False)

    def _on_variable_changed(self, *_args):
        if not self._syncing and self.get_value() != self.textvariable.get():
            self._replace_all(self.textvariable.get())

    def icursor(self, index):
        target = "end-1c" if index == "end" else index
        self.mark_set("insert", target)
        self.see("insert")

    def selection_range(self, start, end):
        self.tag_remove("sel", "1.0", "end")
        s = f"1.{start}" if isinstance(start, int) else start
        e = "end-1c" if end == "end" else (f"1.{end}" if isinstance(end, int) else end)
        self.tag_add("sel", s, e)

    def select_all(self, _event=None):
        self.tag_add("sel", "1.0", "end-1c")
        self.mark_set("insert", "end-1c")
        return "break"

    def delete_selection(self) -> bool:
        try:
            tk.Text.delete(self, "sel.first", "sel.last")
            self.edit_modified(True)
            self.event_generate("<<Modified>>")
            return True
        except tk.TclError:
            return False

    def delete_key(self, _event=None):
        if self.delete_selection():
            return "break"
        if tk.Text.compare(self, "insert", "<", "end-1c"):
            tk.Text.delete(self, "insert", "insert+1c")
            self.edit_modified(True)
            self.event_generate("<<Modified>>")
        return "break"

    def backspace_key(self, _event=None):
        if self.delete_selection():
            return "break"
        if tk.Text.compare(self, "insert", ">", "1.0"):
            tk.Text.delete(self, "insert-1c", "insert")
            self.edit_modified(True)
            self.event_generate("<<Modified>>")
        return "break"

    def focus_next(self, _event=None):
        self.tk_focusNext().focus_set()
        return "break"

    def paste_clean(self, _event=None):
        try:
            text = self.clipboard_get()
        except tk.TclError:
            return "break"
        if self.single_line:
            text = text.replace("\r", " ").replace("\n", " ")
        try:
            tk.Text.delete(self, "sel.first", "sel.last")
        except tk.TclError:
            pass
        tk.Text.insert(self, "insert", text)
        self.edit_modified(True)
        self.event_generate("<<Modified>>")
        return "break"

    def show_context_menu(self, event):
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="גזור", command=lambda: self.event_generate("<<Cut>>"))
        menu.add_command(label="העתק", command=lambda: self.event_generate("<<Copy>>"))
        menu.add_command(label="הדבק", command=lambda: self.event_generate("<<Paste>>"))
        menu.add_command(label="מחק", command=self.delete_selection)
        menu.add_separator()
        menu.add_command(label="בחר הכל", command=self.select_all)
        menu.tk_popup(event.x_root, event.y_root)
        return "break"


class FixedHebrewField(ttk.Frame):
    """Canvas-drawn input: every character sits in a fixed cell, bypassing BiDi reflow."""

    def __init__(self, master, textvariable: tk.StringVar, height=1, width=30, font=("Arial", 11), **kwargs):
        super().__init__(master, **kwargs)
        self.textvariable = textvariable
        self.font = tkfont.Font(font=font)
        compact_sample = "אבגדהוזחטיכלמנסעפצקרשתךםןףץ"
        avg_char_w = round(self.font.measure(compact_sample) / max(1, len(compact_sample)))
        self.char_w = max(8, avg_char_w + 1)
        self.line_h = max(22, self.font.metrics("linespace") + 5)
        self.requested_chars = max(1, int(width))
        self.rows = max(1, int(height))
        self.value = force_hebrew_keyboard_text(str(textvariable.get()))
        if self.value != textvariable.get():
            textvariable.set(self.value)
        self.cursor = len(self.value)
        self.sel_anchor: Optional[int] = None
        self.sel_start: Optional[int] = None
        self.sel_end: Optional[int] = None
        self.scroll = 0
        self.syncing = False
        self.undo_stack = []
        self.redo_stack = []
        self.undo_labels = []
        self.redo_labels = []
        self.max_history = 100
        self.cursor_visible = True
        self.cursor_blink_after = None
        self.return_command = None
        self.drag_peer = None
        self.drag_target_mode = "append"
        self.drag_status_callback = None
        self._drag_transfer_range = None
        self._drag_existing_selection = False

        self.canvas = tk.Canvas(self, height=self.rows * self.line_h + 2, bg="white", highlightthickness=1, highlightbackground="#9e9e9e")
        self.canvas.pack(fill="x", expand=True)
        self.canvas.configure(takefocus=True)
        self.canvas.bind("<Button-1>", self.on_mouse_down)
        self.canvas.bind("<B1-Motion>", self.on_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
        self.canvas.bind("<Key>", self.on_key)
        self.canvas.bind("<Control-a>", self.select_all)
        self.canvas.bind("<Control-A>", self.select_all)
        self.canvas.bind("<Button-3>", self.show_context_menu)
        self.canvas.bind("<Configure>", lambda _event: self.render())
        self.canvas.bind("<FocusIn>", self.on_focus_in)
        self.canvas.bind("<FocusOut>", self.on_focus_out)
        self._trace_id = textvariable.trace_add("write", self.on_variable_changed)
        self.render()

    def set_drag_transfer(self, peer, target_mode: str = "append", status_callback=None):
        self.drag_peer = peer
        self.drag_target_mode = target_mode if target_mode in ("append", "replace") else "append"
        self.drag_status_callback = status_callback

    def focus_set(self):
        self.canvas.focus_set()

    def on_focus_in(self, _event=None):
        self.cursor_visible = True
        self.start_cursor_blink()
        self.render()

    def on_focus_out(self, _event=None):
        if self.cursor_blink_after:
            self.after_cancel(self.cursor_blink_after)
            self.cursor_blink_after = None
        self.cursor_visible = False
        self.render()

    def start_cursor_blink(self):
        if self.cursor_blink_after:
            self.after_cancel(self.cursor_blink_after)
        self.cursor_blink_after = self.after(530, self.blink_cursor)

    def blink_cursor(self):
        if self.canvas.focus_get() != self.canvas:
            self.cursor_blink_after = None
            return
        self.cursor_visible = not self.cursor_visible
        self.render()
        self.cursor_blink_after = self.after(530, self.blink_cursor)

    def show_cursor_now(self):
        self.cursor_visible = True
        if self.canvas.focus_get() == self.canvas:
            self.start_cursor_blink()

    def icursor(self, index):
        self.cursor = len(self.value) if index == "end" else max(0, min(int(index), len(self.value)))
        self.ensure_cursor_visible()
        self.show_cursor_now()
        self.render()

    def selection_range(self, start, end):
        self.sel_start = max(0, min(int(start), len(self.value)))
        self.sel_end = len(self.value) if end == "end" else max(0, min(int(end), len(self.value)))
        if self.sel_start == self.sel_end:
            self.clear_selection()
        else:
            self.cursor = self.sel_end
            self.ensure_cursor_visible()
            self.render()

    def selection_clear(self):
        self.clear_selection()

    def delete(self, start, end=None):
        s = self.resolve_index(start)
        e = s + 1 if end is None else self.resolve_index(end)
        self.replace_range(s, e, "")

    def insert(self, index, chars, *args):
        idx = self.resolve_index(index)
        self.replace_range(idx, idx, force_hebrew_keyboard_text(str(chars).replace("\r", " ").replace("\n", " ")))

    def resolve_index(self, index) -> int:
        if index == "end":
            return len(self.value)
        if index == "insert":
            return self.cursor
        if index == "sel.first":
            if self.has_selection():
                return min(self.sel_start, self.sel_end)
            raise tk.TclError("selection is empty")
        if index == "sel.last":
            if self.has_selection():
                return max(self.sel_start, self.sel_end)
            raise tk.TclError("selection is empty")
        return max(0, min(int(index), len(self.value)))

    def has_selection(self) -> bool:
        return self.sel_start is not None and self.sel_end is not None and self.sel_start != self.sel_end

    def clear_selection(self):
        self.sel_anchor = None
        self.sel_start = None
        self.sel_end = None
        self.render()

    def selected_range(self) -> Tuple[int, int]:
        if not self.has_selection():
            return self.cursor, self.cursor
        return min(self.sel_start, self.sel_end), max(self.sel_start, self.sel_end)

    def selected_text(self) -> str:
        s, e = self.selected_range()
        return self.value[s:e] if e > s else ""

    def word_range_at(self, idx: int):
        text = self.value
        if not text:
            return None
        idx = max(0, min(idx, len(text) - 1))
        separators = set(" \t\r\n,.;:|/\\()[]{}\"'׳״־-–—")
        if text[idx] in separators:
            return None
        start = idx
        end = idx + 1
        while start > 0 and text[start - 1] not in separators:
            start -= 1
        while end < len(text) and text[end] not in separators:
            end += 1
        return (start, end) if end > start else None

    def event_is_over_peer(self, event) -> bool:
        peer = getattr(self, "drag_peer", None)
        peer_canvas = getattr(peer, "canvas", None)
        if peer_canvas is None:
            return False
        x = int(getattr(event, "x_root", 0) or 0)
        y = int(getattr(event, "y_root", 0) or 0)
        left = peer_canvas.winfo_rootx()
        top = peer_canvas.winfo_rooty()
        right = left + peer_canvas.winfo_width()
        bottom = top + peer_canvas.winfo_height()
        return left <= x <= right and top <= y <= bottom

    def transfer_drag_text_to_peer(self, event) -> bool:
        peer = getattr(self, "drag_peer", None)
        if peer is None or not self.event_is_over_peer(event):
            return False
        if self._drag_existing_selection and self.has_selection():
            move_range = self.selected_range()
        else:
            move_range = self._drag_transfer_range
        if not move_range:
            return False
        s, e = move_range
        text = self.value[s:e].strip()
        if not text:
            return False
        self.replace_range(s, e, "")
        if getattr(self, "drag_target_mode", "append") == "replace":
            peer.replace_range(0, len(peer.value), text)
        else:
            current = peer.value.strip()
            addition = text if not current else f"{current} {text}"
            peer.replace_range(0, len(peer.value), addition)
        peer.focus_set()
        peer.icursor("end")
        callback = getattr(self, "drag_status_callback", None)
        if callable(callback):
            callback(text, self, peer)
        self._drag_transfer_range = None
        self._drag_existing_selection = False
        return True

    def replace_range(self, start: int, end: int, text: str):
        start = max(0, min(start, len(self.value)))
        end = max(start, min(end, len(self.value)))
        text = force_hebrew_keyboard_text(str(text))
        label = self.describe_edit(start, end, text)
        self.push_undo_state(label)
        self.value = self.value[:start] + text + self.value[end:]
        self.cursor = start + len(text)
        self.sel_anchor = None
        self.sel_start = None
        self.sel_end = None
        self.sync_to_var()
        self.ensure_cursor_visible()
        self.show_cursor_now()
        self.render()

    def state_snapshot(self) -> dict:
        return {
            "value": self.value,
            "cursor": self.cursor,
            "sel_start": self.sel_start,
            "sel_end": self.sel_end,
            "scroll": self.scroll,
        }

    def short_history_text(self, text: str, limit: int = 18) -> str:
        text = " ".join(str(text).split())
        if len(text) <= limit:
            return text
        return text[:limit - 1] + "…"

    def describe_edit(self, start: int, end: int, text: str) -> str:
        old_text = self.value[start:end]
        new_text = str(text)
        old_short = self.short_history_text(old_text)
        new_short = self.short_history_text(new_text)
        if old_text and new_text:
            return f"החלפת \"{old_short}\" ב-\"{new_short}\""
        if old_text:
            return f"מחיקת \"{old_short}\""
        if new_text:
            return f"הוספת \"{new_short}\""
        return "עריכה בשדה"

    def push_undo_state(self, label: str = "עריכה בשדה"):
        snapshot = self.state_snapshot()
        if self.undo_stack and self.undo_stack[-1] == snapshot:
            return
        self.undo_stack.append(snapshot)
        self.undo_labels.append(label or "עריכה בשדה")
        if len(self.undo_stack) > self.max_history:
            self.undo_stack.pop(0)
            if self.undo_labels:
                self.undo_labels.pop(0)
        self.redo_stack.clear()
        self.redo_labels.clear()

    def restore_state(self, snapshot: dict):
        self.value = str(snapshot.get("value", ""))
        self.cursor = max(0, min(int(snapshot.get("cursor", len(self.value)) or 0), len(self.value)))
        self.sel_start = snapshot.get("sel_start")
        self.sel_end = snapshot.get("sel_end")
        if self.sel_start is not None:
            self.sel_start = max(0, min(int(self.sel_start), len(self.value)))
        if self.sel_end is not None:
            self.sel_end = max(0, min(int(self.sel_end), len(self.value)))
        if self.sel_start == self.sel_end:
            self.sel_start = self.sel_end = None
        self.sel_anchor = None
        self.scroll = max(0, int(snapshot.get("scroll", 0) or 0))
        self.sync_to_var()
        self.ensure_cursor_visible()
        self.show_cursor_now()
        self.render()

    def undo(self):
        if self.undo_stack:
            label = self.undo_labels.pop() if self.undo_labels else "פעולה אחרונה"
            self.redo_stack.append(self.state_snapshot())
            self.redo_labels.append(label)
            self.restore_state(self.undo_stack.pop())
        return "break"

    def redo(self):
        if self.redo_stack:
            label = self.redo_labels.pop() if self.redo_labels else "פעולה אחרונה"
            self.undo_stack.append(self.state_snapshot())
            self.undo_labels.append(label)
            self.restore_state(self.redo_stack.pop())
        return "break"

    def sync_to_var(self):
        if self.syncing:
            return
        self.syncing = True
        try:
            self.textvariable.set(self.value)
        finally:
            self.syncing = False

    def on_variable_changed(self, *_args):
        if self.syncing:
            return
        converted = force_hebrew_keyboard_text(str(self.textvariable.get()))
        if converted != self.textvariable.get():
            self.syncing = True
            try:
                self.textvariable.set(converted)
            finally:
                self.syncing = False
        self.value = converted
        self.cursor = min(self.cursor, len(self.value))
        self.clear_selection()
        self.ensure_cursor_visible()
        self.render()

    def visible_capacity(self) -> int:
        canvas_width = self.canvas.winfo_width()
        if canvas_width <= 1:
            canvas_width = max(self.canvas.winfo_reqwidth(), self.requested_chars * self.char_w)
        width = max(1, canvas_width - 4)
        return max(1, width // self.char_w)

    def ensure_cursor_visible(self):
        cap = self.visible_capacity()
        if self.cursor < self.scroll:
            self.scroll = self.cursor
        elif self.cursor > self.scroll + cap:
            self.scroll = max(0, self.cursor - cap)
        self.scroll = max(0, min(self.scroll, max(0, len(self.value) - cap)))

    def index_from_x(self, x: int) -> int:
        cap = self.visible_capacity()
        visible_len = min(cap, max(1, len(self.value) - self.scroll + 1))
        right = self.canvas.winfo_width() - 3
        offset_from_right = max(0, int((right - x) // self.char_w))
        idx = self.scroll + max(0, min(visible_len, offset_from_right))
        return max(0, min(idx, len(self.value)))

    def on_mouse_down(self, event):
        self.focus_set()
        self.show_cursor_now()
        idx = self.index_from_x(event.x)
        self._drag_existing_selection = False
        self._drag_transfer_range = self.word_range_at(idx)
        if self.has_selection():
            s, e = self.selected_range()
            if s <= idx <= e:
                self.cursor = idx
                self.sel_anchor = None
                self._drag_existing_selection = True
                self._drag_transfer_range = (s, e)
                self.render()
                return "break"
        self.cursor = idx
        self.sel_anchor = idx
        self.sel_start = None
        self.sel_end = None
        self.render()
        return "break"

    def on_mouse_drag(self, event):
        self.show_cursor_now()
        if self._drag_existing_selection and self.event_is_over_peer(event):
            return "break"
        if self.sel_anchor is None:
            self.sel_anchor = self.cursor
        idx = self.index_from_x(event.x)
        self.cursor = idx
        self.sel_start = self.sel_anchor
        self.sel_end = idx
        if self.sel_start == self.sel_end:
            self.sel_start = self.sel_end = None
        self.render()
        return "break"

    def on_mouse_up(self, event):
        if self.transfer_drag_text_to_peer(event):
            self.sel_anchor = None
            return "break"
        self.sel_anchor = None
        self._drag_transfer_range = None
        self._drag_existing_selection = False
        return "break"

    def select_all(self, _event=None):
        self.sel_start = 0
        self.sel_end = len(self.value)
        self.cursor = len(self.value)
        self.ensure_cursor_visible()
        self.show_cursor_now()
        self.render()
        return "break"

    def delete_selection(self) -> bool:
        if not self.has_selection():
            return False
        s, e = self.selected_range()
        self.replace_range(s, e, "")
        return True

    def on_key(self, event):
        key = event.keysym
        ctrl = bool(event.state & 0x4)
        if ctrl:
            if key.lower() == "a":
                return self.select_all()
            if key.lower() == "c":
                self.copy()
                return "break"
            if key.lower() == "x":
                self.cut()
                return "break"
            if key.lower() == "v":
                self.paste()
                return "break"
            if key.lower() == "z":
                return self.undo()
            if key.lower() == "y":
                return self.redo()
            return None
        if key in ("Left", "Right"):
            self.clear_selection()
            self.cursor += 1 if key == "Left" else -1
            self.cursor = max(0, min(self.cursor, len(self.value)))
            self.ensure_cursor_visible()
            self.render()
            return "break"
        if key == "Home":
            self.clear_selection()
            self.cursor = 0
            self.ensure_cursor_visible()
            self.render()
            return "break"
        if key == "End":
            self.clear_selection()
            self.cursor = len(self.value)
            self.ensure_cursor_visible()
            self.render()
            return "break"
        if key in ("BackSpace", "Delete"):
            if self.delete_selection():
                return "break"
            if key == "BackSpace" and self.cursor > 0:
                self.replace_range(self.cursor - 1, self.cursor, "")
            elif key == "Delete" and self.cursor < len(self.value):
                self.replace_range(self.cursor, self.cursor + 1, "")
            return "break"
        if key == "Return":
            if callable(self.return_command):
                self.return_command()
            return "break"
        if key in ("Tab", "Escape"):
            return "break"
        if event.char:
            s, e = self.selected_range()
            self.replace_range(s, e, force_hebrew_keyboard_text(event.char.replace("\r", " ").replace("\n", " ")))
            return "break"
        return None

    def copy(self):
        if not self.has_selection():
            return
        s, e = self.selected_range()
        self.clipboard_clear()
        self.clipboard_append(self.value[s:e])

    def cut(self):
        if self.has_selection():
            self.copy()
            self.delete_selection()

    def paste(self):
        try:
            text = force_hebrew_keyboard_text(self.clipboard_get().replace("\r", " ").replace("\n", " "))
        except tk.TclError:
            return
        s, e = self.selected_range()
        self.replace_range(s, e, text)

    def show_context_menu(self, event):
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="גזור", command=self.cut)
        menu.add_command(label="העתק", command=self.copy)
        menu.add_command(label="הדבק", command=self.paste)
        menu.add_command(label="מחק", command=self.delete_selection)
        menu.add_separator()
        menu.add_command(label="בחר הכל", command=self.select_all)
        menu.tk_popup(event.x_root, event.y_root)
        return "break"

    def render(self):
        self.canvas.delete("all")
        width = max(1, self.canvas.winfo_width())
        height = max(1, self.canvas.winfo_height())
        cap = self.visible_capacity()
        start = self.scroll
        end = min(len(self.value), start + cap)
        sel_s, sel_e = self.selected_range()
        y = height / 2
        right = width - 3
        for idx in range(start, end):
            col = idx - start
            x_right = right - col * self.char_w
            x_left = x_right - self.char_w
            if sel_s <= idx < sel_e:
                self.canvas.create_rectangle(x_left, 2, x_right, height - 2, fill="#9fc5e8", outline="")
            self.canvas.create_text((x_left + x_right) / 2, y, text=self.value[idx], font=self.font, fill="#111111")
        if self.canvas.focus_get() == self.canvas and self.cursor_visible:
            cur_col = self.cursor - start
            if 0 <= cur_col <= cap:
                x = right - cur_col * self.char_w
                self.canvas.create_line(x, 4, x, height - 4, fill="#111111", width=2)


def add_tooltip(widget, text: str, *, visible_ms: Optional[int] = None):
    try:
        raw_text = text() if callable(text) else str(text or "")
    except Exception:
        raw_text = ""
    hover_text = tooltip_summary(raw_text) if tooltip_is_long(raw_text) else raw_text
    if raw_text and (tooltip_is_long(raw_text) or widget_should_have_right_click_help(widget)) and not widget.bind("<Button-3>"):
        hover_text = f"{hover_text}\n{HELP_HINT_TOOLTIP}"
    ToolTip(widget, text, delay=DEFAULT_TOOLTIP_DELAY_MS, visible_ms=visible_ms or tooltip_visible_time(hover_text))
    return widget


class TorahCanvas(ttk.Frame):
    def __init__(self, master, model: TorahModel):
        super().__init__(master)
        self.model = model
        self.cell_w = 22
        self.cell_h = 28
        self.font_size = 23
        self.spp_w = 150
        self.cols = 46
        self.rows = 24
        self.grid: List[List[Optional[int]]] = []
        self.pos_to_cell: Dict[int, Tuple[int, int]] = {}
        self.matches: List[Match] = []
        self.manual_marks: List[Match] = []
        self.hidden_match_frames = set()
        self.top_connector_lines: List[dict] = []
        self.selected_positions: List[int] = []
        self.drag_start: Optional[int] = None
        self.selection_preview_start: Optional[int] = None
        self.selection_preview_end: Optional[int] = None
        self.selection_preview_line: Optional[Tuple[float, float, float, float]] = None
        self._last_drag_preview_pos: Optional[int] = None
        self.context_line_anchor: Optional[int] = None
        self.pan_last_x: Optional[int] = None
        self.pan_last_y: Optional[int] = None
        self.pan_accum_x = 0
        self.pan_accum_y = 0
        self.selection_enabled = False
        self.view_mode = "linear"
        self.linear_start = 0
        self.skip_primary: Optional[Match] = None
        self.skip_view_anchor = 0
        self.lock_to_primary_anchor = False
        self.on_view_change = None
        self._resize_after = None
        self.show_mark_borders = True
        self.show_spp_labels = True
        self.alternate_word_colors = True
        self.show_word_spaces = False
        self.view_cols_extra = 0
        self.view_rows_extra = 0
        self.view_col_offset = 0
        self.draw_x_offset = 0
        self.draw_y_offset = 0
        self.render_col_start = 0
        self.render_col_end = self.cols
        self.ashuri_mode = False
        self.regular_font_family = "Arial"
        self.loaded_ashuri_font_files: List[str] = []
        self.load_bundled_ashuri_fonts()
        self.ashuri_font_family = self.detect_ashuri_font()
        self.ashuri_ashkenaz_family = self.detect_font_family(("Stam Ashkenaz CLM", "StamAshkenazCLM"))
        self.ashuri_sefarad_family = self.detect_font_family(("Stam Sefarad CLM", "StamSefaradCLM"))
        self.font_mode = "regular"

        self.custom_yad_image = self.load_custom_yad_cursor()
        self.yad_cursor_item = None
        self.yad_pointer_x = 0.0
        self.yad_pointer_y = 0.0
        self.yad_pointer_inside = False
        self.cursor_mode = "yad" if self.custom_yad_image else "arrow"
        self.canvas = tk.Canvas(self, bg=PARCHMENT_BG, highlightthickness=0, cursor="none" if self.custom_yad_image else "arrow")
        self.vbar = ttk.Scrollbar(self, orient="vertical", command=self.on_vertical_scroll)
        self.position_scale = ttk.Scale(self, orient="vertical", from_=0, to=1000, command=self.on_position_scale)
        self.hbar = ttk.Scrollbar(self, orient="horizontal", command=self.canvas.xview)
        self.updating_position_scale = False
        self.book_marker_canvas = tk.Canvas(self, width=46, bg="#fbfbf8", highlightthickness=1, highlightbackground="#c7c7c7")
        self.marker_hover_y = 0
        self.marker_hover_point = None
        self.marker_point_items = {}
        self.marker_graph_visible = True
        self.findings_provider = None
        self.finding_click_handler = None
        self.canvas.configure(yscrollcommand=self.vbar.set, xscrollcommand=self.hbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.vbar.grid(row=0, column=1, sticky="ns")
        self.position_scale.grid(row=0, column=2, sticky="ns", padx=(1, 0))
        self.book_marker_canvas.grid(row=0, column=3, sticky="ns", padx=(1, 0))
        self.hbar.grid(row=1, column=0, sticky="ew")
        add_tooltip(self.vbar, "גרור את סמן הגלילה כדי לנוע לאורך התורה לפי הערכת מיקום.")
        add_tooltip(self.position_scale, "סמן מיקום בולט: גרור למעלה או למטה כדי לקפוץ לאורך התורה.")
        add_tooltip(self.book_marker_canvas, self.book_marker_tooltip_text)
        add_tooltip(self.hbar, "גרור ימינה או שמאלה. הגלילה זמינה גם כשהדילוג קטן מרוחב המסך; אם אין אותיות נוספות, המסגרת הריקה מסמנת את גבול הדילוג.")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        self.canvas.bind("<Button-1>", self.on_down)
        self.canvas.bind("<Double-Button-1>", self.on_double_click)
        self.canvas.bind("<Button-3>", self.on_right_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
        self.canvas.bind("<Control-MouseWheel>", self.on_zoom_wheel)
        self.canvas.bind("<Control-Button-4>", self.on_zoom_wheel)
        self.canvas.bind("<Control-Button-5>", self.on_zoom_wheel)
        self.canvas.bind("<MouseWheel>", self.on_mouse_wheel)
        self.canvas.bind("<Shift-MouseWheel>", self.on_shift_mouse_wheel)
        self.canvas.bind("<Button-4>", self.on_mouse_wheel)
        self.canvas.bind("<Button-5>", self.on_mouse_wheel)
        self.canvas.bind("<Enter>", lambda event: self.canvas.focus_set())
        self.canvas.bind("<Motion>", self.on_pointer_motion)
        self.canvas.bind("<Leave>", self.on_pointer_leave)
        self.canvas.bind("<Key>", self.on_key)
        self.canvas.bind("<KeyPress>", self.on_key)
        self.canvas.bind("<Configure>", self.on_canvas_configure)
        self.canvas.configure(takefocus=True)
        self.book_marker_canvas.bind("<Configure>", lambda _event: self.draw_book_markers())
        self.book_marker_canvas.bind("<Motion>", self.on_book_marker_motion)
        self.book_marker_canvas.bind("<Button-1>", self.on_book_marker_click)
        self.book_marker_canvas.bind("<B1-Motion>", self.on_book_marker_click)

    def marker_graph_is_visible(self) -> bool:
        return bool(getattr(self, "marker_graph_visible", True))

    def set_marker_graph_visible(self, visible: bool):
        self.marker_graph_visible = bool(visible)
        if self.marker_graph_visible:
            if not self.book_marker_canvas.winfo_manager():
                self.book_marker_canvas.grid(row=0, column=3, sticky="ns", padx=(1, 0))
            self.draw_book_markers()
        else:
            self.book_marker_canvas.grid_remove()

    def on_pointer_motion(self, event):
        self.yad_pointer_inside = True
        self.yad_pointer_x = self.canvas.canvasx(event.x)
        self.yad_pointer_y = self.canvas.canvasy(event.y)
        if self.cursor_mode == "yad" and self.custom_yad_image:
            self.draw_yad_cursor(self.yad_pointer_x, self.yad_pointer_y)

    def on_pointer_leave(self, _event=None):
        self.yad_pointer_inside = False
        self.canvas.delete("yad_cursor")
        self.yad_cursor_item = None

    def set_cursor_mode(self, mode: str):
        if mode == "hand":
            mode = "yad"
        mode = mode if mode in ("yad", "arrow") else "yad"
        if mode == "yad" and not self.custom_yad_image:
            mode = "arrow"
        self.cursor_mode = mode
        self.canvas.delete("yad_cursor")
        self.yad_cursor_item = None
        cursor = "none" if mode == "yad" else "arrow"
        self.canvas.configure(cursor=cursor)

    def load_custom_yad_cursor(self):
        here = os.path.dirname(os.path.abspath(__file__))
        base = os.path.dirname(here)
        folders = [
            here,
            os.path.join(base, "גל_עיני_V124_להפצה_קובץ_תורה_אחד"),
            os.path.join(base, "גל_עיני_V124_GMAIL_SAFE"),
            os.path.join(base, "Codex", "gal_einai_extracted"),
        ]
        for folder in folders:
            for filename in ("yad_cursor.png", "yad_cursor.gif"):
                path = os.path.join(folder, filename)
                if not os.path.exists(path):
                    continue
                try:
                    image = tk.PhotoImage(file=path)
                    factor = max(1, math.ceil(max(image.width(), image.height()) / 52))
                    return image.subsample(factor, factor) if factor > 1 else image
                except tk.TclError:
                    continue
        return None

    def draw_yad_cursor(self, x: float, y: float):
        if not self.custom_yad_image:
            return
        # The supplied image points upward; anchor the top-center as the pointer tip.
        if self.yad_cursor_item is None:
            self.yad_cursor_item = self.canvas.create_image(x, y, image=self.custom_yad_image, anchor="n", tags="yad_cursor")
        else:
            self.canvas.coords(self.yad_cursor_item, x, y)
        self.canvas.tag_raise("yad_cursor")

    def restore_yad_cursor_after_render(self):
        if self.cursor_mode == "yad" and self.custom_yad_image and self.yad_pointer_inside:
            self.draw_yad_cursor(self.yad_pointer_x, self.yad_pointer_y)

    def load_bundled_ashuri_fonts(self):
        if os.name != "nt":
            return
        font_dir = os.path.dirname(os.path.abspath(__file__))
        try:
            add_font = ctypes.windll.gdi32.AddFontResourceExW
        except Exception:
            return
        FR_PRIVATE = 0x10
        for filename in BUNDLED_ASHURI_FONT_FILES:
            path = os.path.join(font_dir, filename)
            if not os.path.exists(path):
                continue
            try:
                loaded = add_font(path, FR_PRIVATE, 0)
                if loaded:
                    self.loaded_ashuri_font_files.append(filename)
            except Exception:
                pass

    def detect_font_family(self, names: Tuple[str, ...]) -> str:
        available = {name.lower(): name for name in tkfont.families()}
        for name in names:
            if name.lower() in available:
                return available[name.lower()]
        return ""

    def detect_ashuri_font(self) -> str:
        preferred = (
            "Stam Ashkenaz CLM",
            "Stam Sefarad CLM",
            "Keter YG",
            "Ezra SIL",
            "SBL Hebrew",
            "FrankRuehl",
            "David",
            "Narkisim",
        )
        family = self.detect_font_family(preferred)
        if family:
            return family
        return "Arial"

    def current_letter_font(self):
        family = self.font_family_for_mode(self.font_mode)
        size = self.font_size
        if self.show_word_spaces:
            size = max(10, int(self.font_size * 0.88))
        return (family, size, "bold")

    def font_family_for_mode(self, mode: str) -> str:
        if mode == "ashkenaz":
            return self.ashuri_ashkenaz_family or self.regular_font_family
        if mode == "sefarad":
            return self.ashuri_sefarad_family or self.regular_font_family
        return self.regular_font_family

    def is_real_ashuri_font(self, mode: Optional[str] = None) -> bool:
        family = self.font_family_for_mode(mode or self.font_mode)
        return family.lower().startswith("stam ")

    def alternate_font_label(self) -> str:
        return self.font_mode_label(self.font_mode)

    def font_mode_label(self, mode: str) -> str:
        family = self.font_family_for_mode(mode)
        if mode == "ashkenaz":
            return f"אשורי אשכנז ({family})" if self.is_real_ashuri_font(mode) else f"אשכנז לא זמין - מוצג {family}"
        if mode == "sefarad":
            return f"אשורי ספרדי ({family})" if self.is_real_ashuri_font(mode) else f"ספרדי לא זמין - מוצג {family}"
        return f"כתב רגיל ({family})"

    def bundled_font_status(self) -> str:
        if self.loaded_ashuri_font_files:
            return "נטען מהתיקייה: " + ", ".join(self.loaded_ashuri_font_files)
        return "לא נמצא קובץ פונט אשורי בתיקיית התוכנה"

    def visual_gap_after(self, pos: int) -> int:
        if not self.show_word_spaces:
            return 0
        if pos < 0 or pos + 1 >= len(self.model.word_parity):
            return 0
        return max(8, int(self.cell_w * 0.82)) if self.model.word_parity[pos] != self.model.word_parity[pos + 1] else 0

    def visual_cell_width(self) -> int:
        if not self.show_word_spaces:
            return self.cell_w
        return max(6, int(self.cell_w * 0.86))

    def row_visual_width(self, row, start_col: int, end_col: int) -> int:
        width = 0
        letter_w = self.visual_cell_width()
        for c in range(start_col, end_col):
            width += letter_w
            pos = row[c] if 0 <= c < len(row) else None
            if pos is not None:
                width += self.visual_gap_after(pos)
        return width

    def set_ashuri_mode(self, enabled: bool):
        self.set_font_mode("ashkenaz" if enabled else "regular")

    def set_font_mode(self, mode: str):
        self.font_mode = mode if mode in ("regular", "ashkenaz", "sefarad") else "regular"
        self.ashuri_mode = self.font_mode != "regular"
        self.render()

    def set_zoom(self, delta: int = 0, reset: bool = False, dense: bool = False):
        if reset:
            self.cell_w, self.cell_h, self.font_size = 22, 28, 23
        elif dense:
            self.cell_w, self.cell_h, self.font_size = 8, 13, 13
        else:
            self.cell_w = max(7, min(42, self.cell_w + delta))
            self.cell_h = max(12, min(50, self.cell_h + delta))
            self.font_size = max(11, min(38, self.font_size + delta))
        if self.view_mode == "skip" and self.skip_primary:
            self.build_skip_grid(self.skip_primary)
        else:
            self.build_linear(self.linear_start)

    def set_display_height(self, delta: int = 0, reset: bool = False):
        if reset:
            self.cell_h, self.font_size = 28, 23
        else:
            step = 1 if delta > 0 else -1 if delta < 0 else 0
            self.cell_h = max(13, min(56, self.cell_h + delta))
            self.font_size = max(11, min(38, self.font_size + step))
        if self.view_mode == "skip" and self.skip_primary:
            self.build_skip_grid(self.skip_primary)
        else:
            self.build_linear(self.linear_start)

    def set_selection_enabled(self, enabled: bool):
        self.selection_enabled = bool(enabled)
        if not self.selection_enabled:
            self.selected_positions.clear()
            self.selection_preview_start = None
            self.selection_preview_end = None
            self.selection_preview_line = None
            self.render()

    def fitted_linear_cols(self) -> int:
        width = self.canvas.winfo_width()
        if width <= 1:
            width = self.canvas.winfo_reqwidth()
        usable = max(self.cell_w, width - self.spp_w - 12)
        return max(1, min(MAX_GRID_COLS, int(usable // self.cell_w) + int(self.view_cols_extra)))

    def fitted_base_cols(self) -> int:
        width = self.canvas.winfo_width()
        if width <= 1:
            width = self.canvas.winfo_reqwidth()
        usable = max(self.cell_w, width - self.spp_w - 12)
        return max(1, int(usable // self.cell_w))

    def fitted_linear_rows(self) -> int:
        height = self.canvas.winfo_height()
        if height <= 1:
            height = self.canvas.winfo_reqheight()
        natural_rows = int(max(self.cell_h, height - 20) // self.cell_h)
        return max(8, min(260, natural_rows + int(self.view_rows_extra)))

    def displayed_cols_for_skip(self, skip: int, min_cols: int = 1) -> int:
        natural_cols = max(1, abs(int(skip or 1)))
        requested_cols = natural_cols + max(0, int(self.view_cols_extra))
        return max(1, min(max(natural_cols, requested_cols), MAX_GRID_COLS))

    def natural_col_bounds_for_skip(self, skip: int, cols: Optional[int] = None, center_col: Optional[int] = None) -> Tuple[int, int]:
        cols = int(cols if cols is not None else self.cols)
        center_col = int(center_col if center_col is not None else cols // 2)
        natural_cols = max(1, min(abs(int(skip or 1)), cols))
        start = max(0, min(max(0, cols - natural_cols), center_col - natural_cols // 2))
        return start, min(cols, start + natural_cols)

    def visible_col_bounds(self) -> Tuple[int, int]:
        if self.view_mode != "skip":
            return 0, self.cols
        visible_cols = max(1, min(self.cols, self.fitted_base_cols() + int(self.view_cols_extra)))
        center_col = self.cols // 2
        max_start = max(0, self.cols - visible_cols)
        centered_start = max(0, min(max_start, center_col - visible_cols // 2))
        start = max(0, min(max_start, centered_start + int(self.view_col_offset)))
        return start, min(self.cols, start + visible_cols)

    def skip_width_domain_edge_visible(self) -> bool:
        if self.view_mode != "skip" or not self.skip_primary:
            return False
        start_col, end_col = self.visible_col_bounds()
        domain_start, domain_end = self.natural_col_bounds_for_skip(self.skip_primary.skip)
        return start_col < domain_start or end_col > domain_end or max(1, end_col - start_col) >= max(1, self.cols)

    def position_near_canvas_center(self) -> Optional[int]:
        self.update_idletasks()
        view_w = max(1, self.canvas.winfo_width())
        view_h = max(1, self.canvas.winfo_height())
        x = self.canvas.canvasx(view_w / 2)
        y = self.canvas.canvasy(view_h / 2)
        pos = self.cell_at(x, y)
        if pos is not None:
            return pos
        if self.view_mode == "linear":
            center_row = max(0, min(self.rows - 1, self.rows // 2))
            center_col = max(0, min(self.cols - 1, self.cols // 2))
            pos = self.linear_start + center_row * max(1, self.cols) + center_col
            if 0 <= pos < len(self.model.search_text):
                return pos
        return None

    def center_position_in_view(self, pos: Optional[int]):
        if pos is None or pos not in self.pos_to_cell:
            return
        self.update_idletasks()
        row, col = self.pos_to_cell[pos]
        start_col, end_col = self.visible_col_bounds()
        visible_cols = max(1, end_col - start_col)
        if not (start_col <= col < end_col):
            return
        content_w = self.spp_w + visible_cols * self.cell_w
        visible_col = col - start_col
        x = self.draw_x_offset + content_w - self.spp_w - (visible_col + 0.5) * self.cell_w
        y = self.draw_y_offset + row * self.cell_h
        region = self.canvas.cget("scrollregion").split()
        if len(region) != 4:
            return
        total_w = max(1, float(region[2]))
        total_h = max(1, float(region[3]))
        view_w = max(1, self.canvas.winfo_width())
        view_h = max(1, self.canvas.winfo_height())
        max_x = max(1, total_w - view_w)
        max_y = max(1, total_h - view_h)
        self.canvas.xview_moveto(max(0.0, min(1.0, (x - view_w / 2) / max_x)))
        self.canvas.yview_moveto(max(0.0, min(1.0, (y - view_h / 2) / max_y)))

    def adjust_display_width(self, delta_cols: int = 0, reset: bool = False):
        self.lock_to_primary_anchor = False
        center_pos = self.position_near_canvas_center()
        current_skip = self.skip_primary.skip if self.view_mode == "skip" and self.skip_primary else None
        current_primary = self.skip_primary
        primary_anchor = None
        if current_primary:
            positions = current_primary.calc_positions()
            primary_anchor = min(positions) if positions else current_primary.start
        if reset:
            self.view_cols_extra = 0
            self.view_col_offset = 0
            status_message = None
        else:
            requested_extra = int(self.view_cols_extra) + int(delta_cols)
            if self.view_mode == "skip" and current_primary:
                self.view_cols_extra = max(-80, min(240, requested_extra))
                status_message = None
                if int(delta_cols) > 0 and abs(int(current_skip or 1)) < self.fitted_base_cols():
                    status_message = "התצוגה הורחבה מעבר לרוחב הדילוג; אפשר לגלול אופקית, והמסגרת הריקה מסמנת שאין שם אותיות נוספות בדילוג הזה."
            else:
                self.view_cols_extra = max(-80, min(240, requested_extra))
                status_message = None
        if self.view_mode == "skip" and current_primary:
            current_primary.skip = current_skip
            self.build_skip_grid(current_primary, view_anchor=self.skip_view_anchor)
            if self.skip_primary:
                self.skip_primary.skip = current_skip
            if current_skip is not None and getattr(current_primary, "skip", None) != current_skip:
                current_primary.skip = current_skip
        else:
            cols = self.fitted_linear_cols()
            rows = self.fitted_linear_rows()
            if center_pos is not None:
                start = center_pos - (rows // 2) * cols - cols // 2
            else:
                start = self.linear_start
            self.build_linear(start, cols, rows)
        if self.view_mode != "skip":
            self.center_position_in_view(center_pos)
        return status_message

    def adjust_display_rows(self, delta_rows: int = 0, reset: bool = False):
        self.lock_to_primary_anchor = False
        center_pos = self.position_near_canvas_center()
        current_skip = self.skip_primary.skip if self.view_mode == "skip" and self.skip_primary else None
        current_primary = self.skip_primary
        if reset:
            self.view_rows_extra = 0
        else:
            self.view_rows_extra = max(-40, min(180, int(self.view_rows_extra) + int(delta_rows)))
        if self.view_mode == "skip" and current_primary:
            current_primary.skip = current_skip
            self.build_skip_grid(current_primary, view_anchor=self.skip_view_anchor)
            if self.skip_primary:
                self.skip_primary.skip = current_skip
        else:
            cols = self.fitted_linear_cols()
            rows = self.fitted_linear_rows()
            if center_pos is not None:
                start = center_pos - (rows // 2) * cols - cols // 2
            else:
                start = self.linear_start
            self.build_linear(start, cols, rows)
            self.center_position_in_view(center_pos)

    def skip_grid_metrics(self, primary: Match, extra_rows=7, view_anchor: Optional[int] = None) -> Tuple[int, int, int, int]:
        skip = primary.skip or 1
        row_step = abs(skip)
        rows = max(12, self.fitted_linear_rows(), len(primary.word) + extra_rows * 2)
        cols = self.displayed_cols_for_skip(skip)
        center_col = cols // 2
        positions = primary.calc_positions()
        anchor = int(view_anchor) if view_anchor is not None else (min(positions) if positions else primary.start)
        rows_above = max(0, (rows - len(primary.word)) // 2)
        base = anchor - rows_above * row_step - center_col
        return rows, cols, center_col, base

    def build_linear(self, start=0, cols=None, rows=None):
        self.view_mode = "linear"
        self.skip_primary = None
        self.skip_view_anchor = 0
        self.view_col_offset = 0
        cols = int(cols or self.fitted_linear_cols())
        rows = int(rows or self.fitted_linear_rows())
        self.cols, self.rows = cols, rows
        max_start = max(0, len(self.model.search_text) - cols * rows)
        start = min(max(0, start), max_start)
        self.linear_start = start
        self.grid = []
        p = start
        for _ in range(rows):
            row = []
            for _ in range(cols):
                row.append(p if p < len(self.model.search_text) else None)
                p += 1
            self.grid.append(row)
        self.render()
        if self.on_view_change:
            self.on_view_change()

    def on_canvas_configure(self, _event=None):
        if self.view_mode not in ("linear", "skip"):
            return
        if self._resize_after:
            self.after_cancel(self._resize_after)
        self._resize_after = self.after(80, self.reflow_to_canvas)

    def reflow_to_canvas(self):
        self._resize_after = None
        if self.view_mode == "linear":
            self.reflow_linear_to_canvas()
        elif self.view_mode == "skip":
            self.reflow_skip_to_canvas()

    def reflow_linear_to_canvas(self):
        if self.view_mode != "linear":
            return
        cols = self.fitted_linear_cols()
        rows = self.fitted_linear_rows()
        if cols != self.cols or rows != self.rows:
            self.build_linear(self.linear_start, cols, rows)

    def reflow_skip_to_canvas(self):
        if self.view_mode != "skip" or not self.skip_primary:
            return
        view_anchor = None if self.lock_to_primary_anchor else self.skip_view_anchor
        cols = self.displayed_cols_for_skip(self.skip_primary.skip)
        rows, _, _, _ = self.skip_grid_metrics(self.skip_primary, view_anchor=view_anchor)
        anchor_changed = False
        if self.lock_to_primary_anchor:
            positions = self.skip_primary.calc_positions()
            primary_anchor = min(positions) if positions else self.skip_primary.start
            anchor_changed = self.skip_view_anchor != primary_anchor
        if cols != self.cols or rows != self.rows or anchor_changed:
            self.build_skip_grid(self.skip_primary, view_anchor=view_anchor)

    def build_skip_grid(self, primary: Match, side_cols=None, extra_rows=7, view_anchor: Optional[int] = None):
        if abs(primary.skip or 1) == 1:
            self.build_linear(max(0, primary.start - self.fitted_linear_cols() // 2))
            return
        self.view_mode = "skip"
        self.skip_primary = primary
        skip = primary.skip or 1
        row_step = abs(skip)
        positions = primary.calc_positions()
        default_anchor = min(positions) if positions else primary.start
        self.skip_view_anchor = max(0, min(int(view_anchor if view_anchor is not None else default_anchor), max(0, len(self.model.search_text) - 1)))
        rows, cols, center_col, base = self.skip_grid_metrics(primary, extra_rows, self.skip_view_anchor)
        self.cols, self.rows = cols, rows
        start_col, end_col = self.visible_col_bounds()
        visible_cols = max(1, end_col - start_col)
        max_offset = max(0, self.cols - visible_cols)
        self.view_col_offset = max(-max_offset, min(max_offset, int(self.view_col_offset)))
        self.grid = [[None] * cols for _ in range(rows)]
        used = set()
        domain_start, domain_end = self.natural_col_bounds_for_skip(skip, cols, center_col)

        # First reserve the central ELS column, so neighboring filler letters cannot steal it.
        for r in range(rows):
            p = base + r * row_step + center_col
            if domain_start <= center_col < domain_end and 0 <= p < len(self.model.search_text) and p not in used:
                self.grid[r][center_col] = p
                used.add(p)

        for r in range(rows):
            for offset in range(1, max(center_col + 1, cols - center_col)):
                for c in (center_col + offset, center_col - offset):
                    if not (0 <= c < cols):
                        continue
                    if not (domain_start <= c < domain_end):
                        continue
                    p = base + r * row_step + c
                    if 0 <= p < len(self.model.search_text):
                        if p not in used:
                            self.grid[r][c] = p
                            used.add(p)
        self.render()
        if self.on_view_change:
            self.on_view_change()

    def nearest_unused_position(self, target: int, used: set) -> Optional[int]:
        n = len(self.model.search_text)
        if 0 <= target < n and target not in used:
            return target
        # The visible grid is small; searching nearby keeps the table full without duplicating positions.
        for radius in range(1, max(self.cols * self.rows * 2, 200)):
            right = target + radius
            if 0 <= right < n and right not in used:
                return right
            left = target - radius
            if 0 <= left < n and left not in used:
                return left
        return None

    def visible_positions(self) -> set:
        start_col, end_col = self.visible_col_bounds()
        visible = set()
        for row in self.grid:
            for c in range(start_col, min(end_col, len(row))):
                p = row[c]
                if p is not None:
                    visible.add(p)
        return visible

    def screen_word_paths(self, words: List[str], max_results: int = MAX_SCAN_RESULTS, grid=None, should_stop=None, progress=None) -> List[Match]:
        grid = grid if grid is not None else self.grid
        patterns = []
        exact_word_map = {}
        for word in words:
            clean = canonical_hebrew(word)
            if len(clean) >= 2 and clean not in exact_word_map:
                exact_word_map[clean] = word
                patterns.append((clean, word))
        if not patterns:
            return []
        max_len = max(len(pattern) for pattern, _display in patterns)
        exact_word_set = {pattern for pattern, _display in patterns if "?" not in pattern}
        exact_prefixes = set()
        wildcard_patterns = []
        for pattern, display_word in patterns:
            if "?" in pattern:
                wildcard_patterns.append((pattern, display_word))
            else:
                for i in range(1, len(pattern)):
                    exact_prefixes.add(pattern[:i])

        directions = (
            (0, 1), (0, -1),
            (1, 0), (-1, 0),
            (1, 1), (1, -1),
            (-1, 1), (-1, -1),
        )
        found: List[Match] = []
        seen = set()
        cells_total = max(1, sum(1 for row in grid for p in row if p is not None))
        cells_done = 0
        visible_positions = {p for row in grid for p in row if p is not None}

        def add_visible_linear_text_matches():
            if not visible_positions:
                return
            text = self.model.search_text
            canonical_text = "".join(canonical_hebrew(ch) for ch in text)
            for pattern, display_word in patterns:
                if "?" in pattern:
                    continue
                start = canonical_text.find(pattern)
                while start != -1:
                    positions = list(range(start, start + len(pattern)))
                    if all(p in visible_positions for p in positions):
                        key = (display_word, tuple(positions))
                        if key not in seen:
                            seen.add(key)
                            found.append(Match(display_word, positions[0], 1, "scan", positions=positions))
                            if len(found) >= max_results:
                                return
                    start = canonical_text.find(pattern, start + 1)

                reverse_pattern = pattern[::-1]
                if reverse_pattern == pattern:
                    continue
                start = canonical_text.find(reverse_pattern)
                while start != -1:
                    positions = list(range(start + len(pattern) - 1, start - 1, -1))
                    if all(p in visible_positions for p in positions):
                        key = (display_word, tuple(positions))
                        if key not in seen:
                            seen.add(key)
                            found.append(Match(display_word, positions[0], -1, "scan", positions=positions))
                            if len(found) >= max_results:
                                return
                    start = canonical_text.find(reverse_pattern, start + 1)

        def add_visible_skip_matches():
            if len(visible_positions) < 2:
                return
            text = self.model.search_text
            canonical_text = "".join(canonical_hebrew(ch) for ch in text)
            visible_sorted = sorted(p for p in visible_positions if 0 <= p < len(text))
            positions_by_letter: Dict[str, List[int]] = {}
            for p in visible_sorted:
                positions_by_letter.setdefault(canonical_text[p], []).append(p)
            for pattern, display_word in patterns:
                if "?" in pattern or len(pattern) < 2:
                    continue
                pattern_variants = [(pattern, display_word)]
                reverse_pattern = pattern[::-1]
                if reverse_pattern != pattern:
                    pattern_variants.append((reverse_pattern, display_word))
                for candidate_pattern, result_word in pattern_variants:
                    first_positions = positions_by_letter.get(candidate_pattern[0], [])
                    second_positions = positions_by_letter.get(candidate_pattern[1], [])
                    if not first_positions or not second_positions:
                        continue
                    for start in first_positions:
                        if should_stop and should_stop():
                            return
                        for second in second_positions:
                            skip = second - start
                            if skip == 0:
                                continue
                            end_pos = start + skip * (len(candidate_pattern) - 1)
                            if not (0 <= end_pos < len(text)):
                                continue
                            positions = [start + skip * i for i in range(len(candidate_pattern))]
                            if not all(p in visible_positions for p in positions):
                                continue
                            if "".join(canonical_text[p] for p in positions) != candidate_pattern:
                                continue
                            stored_positions = positions[:] if candidate_pattern == pattern else list(reversed(positions))
                            stored_skip = skip if candidate_pattern == pattern else -skip
                            key = (result_word, tuple(stored_positions))
                            if key in seen:
                                continue
                            seen.add(key)
                            found.append(Match(result_word, stored_positions[0], stored_skip, "scan", positions=stored_positions))
                            if len(found) >= max_results:
                                return

        add_visible_linear_text_matches()
        if len(found) < max_results:
            add_visible_skip_matches()
        if len(found) >= max_results:
            return self.drop_matches_inside_longer(found)[:max_results]

        for r, row in enumerate(grid):
            for c, pos in enumerate(row):
                if should_stop and should_stop():
                    return found
                if pos is None:
                    continue
                cells_done += 1
                if progress and (cells_done == 1 or cells_done % 80 == 0):
                    progress(cells_done, cells_total)
                for dr, dc in directions:
                    letters = []
                    positions = []
                    rr, cc = r, c
                    for _ in range(max_len):
                        if not (0 <= rr < len(grid) and 0 <= cc < len(grid[rr])):
                            break
                        p = grid[rr][cc]
                        if p is None:
                            break
                        letters.append(canonical_hebrew(self.model.search_text[p]))
                        positions.append(p)
                        text = "".join(letters)
                        if text in exact_word_set:
                            display_word = exact_word_map[text]
                            key = (display_word, tuple(positions))
                            if key not in seen:
                                seen.add(key)
                                skip = positions[1] - positions[0] if len(positions) > 1 else 1
                                found.append(Match(display_word, positions[0], skip, "scan", positions=positions[:]))
                                if len(found) >= max_results:
                                    return found
                        for pattern, _display_word in wildcard_patterns:
                            if len(pattern) == len(text) and all(pc == "?" or pc == tc for pc, tc in zip(pattern, text)):
                                actual_word = "".join(self.model.search_text[p0] for p0 in positions)
                                key = (actual_word, tuple(positions))
                                if key not in seen:
                                    seen.add(key)
                                    skip = positions[1] - positions[0] if len(positions) > 1 else 1
                                    found.append(Match(actual_word, positions[0], skip, "scan", positions=positions[:]))
                                    if len(found) >= max_results:
                                        return found
                        can_continue = text in exact_prefixes or any(
                            len(text) < len(pattern) and all(pc == "?" or pc == tc for pc, tc in zip(pattern[:len(text)], text))
                            for pattern, _display_word in wildcard_patterns
                        )
                        if not can_continue:
                            break
                        rr += dr
                        cc += dc
        found.sort(key=lambda m: (-len(m.word), m.word, m.start, m.skip))
        if progress:
            progress(cells_total, cells_total)
        return self.drop_matches_inside_longer(found)[:max_results]

    @staticmethod
    def drop_matches_inside_longer(matches: List[Match]) -> List[Match]:
        ordered = sorted(matches, key=lambda m: (-len(m.calc_positions()), m.word, m.start, m.skip))
        kept: List[Match] = []
        kept_sets: List[set] = []
        for match in ordered:
            positions = set(match.calc_positions())
            if not positions:
                continue
            preserve_nested = match.kind in {
                "secondary",
                "scan",
                "text",
                "date",
                "date_day",
                "date_month",
                "cluster",
                "stacked",
                "repeat_text",
                "manual",
            }
            if not preserve_nested and any(len(positions) < len(kept_set) and positions <= kept_set for kept_set in kept_sets):
                continue
            kept.append(match)
            kept_sets.append(positions)
        return sorted(kept, key=lambda m: (-len(m.word), m.word, m.start, m.skip))

    def stacked_field_words(self, words: List[str], max_results: int = MAX_SCAN_RESULTS, grid=None) -> List[Match]:
        grid = grid if grid is not None else self.grid
        pos_to_cell = {p: (r, c) for r, row in enumerate(grid) for c, p in enumerate(row) if p is not None}
        candidates = self.screen_word_paths(words, max_results * 3, grid)
        horizontal = []
        for match in candidates:
            cells = [pos_to_cell.get(p) for p in match.calc_positions()]
            if cells and all(cell is not None for cell in cells):
                rows = {cell[0] for cell in cells}
                cols = [cell[1] for cell in cells]
                if len(rows) == 1 and len(cols) == len(set(cols)):
                    horizontal.append((match, rows.pop(), min(cols), max(cols), set(cols)))

        found = []
        seen = set()
        for i, (upper, row_a, left_a, right_a, cols_a) in enumerate(horizontal):
            for lower, row_b, left_b, right_b, cols_b in horizontal[i + 1:]:
                if upper.word == lower.word:
                    continue
                if row_a == row_b:
                    continue
                if not (cols_a & cols_b):
                    continue
                first, second = (upper, lower) if row_a < row_b else (lower, upper)
                pair_positions = tuple(first.calc_positions() + second.calc_positions())
                key = (first.word, second.word, pair_positions)
                if key in seen:
                    continue
                seen.add(key)
                found.append(Match(f"{first.word}/{second.word}", first.start, second.start - first.start, "stacked", positions=list(pair_positions)))
                if len(found) >= max_results:
                    return found
        return found

    def set_matches(self, matches: List[Match]):
        self.matches = matches or []
        self.render()

    def matches_at_position(self, pos: int) -> List[Match]:
        hits = []
        for match in (self.matches or []) + self.manual_marks:
            if pos in match.calc_positions():
                hits.append(match)
        return hits

    def best_match_at_position(self, pos: int) -> Optional[Match]:
        hits = self.matches_at_position(pos)
        if not hits:
            return None
        priority = {
            "secondary": 0,
            "text": 0,
            "scan": 0,
            "cluster": 0,
            "stacked": 0,
            "repeat_text": 0,
            "date": 0,
            "date_day": 0,
            "date_month": 0,
            "primary": 1,
            "manual": 2,
        }
        return sorted(hits, key=lambda m: (priority.get(m.kind, 1), len(m.calc_positions()), abs(m.skip or 1)))[0]

    def cell_at(self, x, y) -> Optional[int]:
        local_y = y - self.draw_y_offset
        row = int(local_y // self.cell_h)
        start_col, end_col = self.visible_col_bounds()
        visible_cols = max(1, end_col - start_col)
        content_w = self.spp_w + visible_cols * self.cell_w
        local_x = x - self.draw_x_offset
        col = start_col + int((content_w - self.spp_w - local_x) // self.cell_w)
        if 0 <= row < len(self.grid) and 0 <= col < len(self.grid[row]):
            return self.grid[row][col]
        return None

    def on_down(self, event):
        self.canvas.focus_set()
        if not self.selection_enabled:
            self.pan_last_x = event.x
            self.pan_last_y = event.y
            self.pan_accum_x = 0
            self.pan_accum_y = 0
            return "break"
        x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        p = self.cell_at(x, y)
        self.drag_start = p
        self.selection_preview_start = p
        self.selection_preview_end = p
        self.selection_preview_line = None
        self._last_drag_preview_pos = p
        if p is not None:
            self.selected_positions = []
        else:
            self.selected_positions = []
        self.render()
        return "break"

    def on_double_click(self, event):
        self.canvas.focus_set()
        x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        pos = self.cell_at(x, y)
        if pos is None:
            return "break"
        match = self.best_match_at_position(pos)
        if match is not None and hasattr(self, "app_center_match"):
            self.app_center_match(match)
            return "break"
        return "break"

    def on_right_click(self, event):
        x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        pos = self.cell_at(x, y)
        if pos is None:
            return "break"
        matches = self.matches_at_position(pos)
        if matches and not self.selected_positions and hasattr(self, "app_show_canvas_context_menu"):
            self.app_show_canvas_context_menu(self.canvas, event.x_root, event.y_root, pos, matches)
            return "break"
        menu = tk.Menu(self.canvas, tearoff=0)
        if matches:
            for match in matches[:8]:
                label = f"{match.word} | דילוג {abs(match.skip or 1)}"
                menu.add_command(label=f"שינוי צבע: {label}", command=lambda m=match: self.change_match_color(m))
                menu.add_command(label=f"הסרה: {label}", command=lambda m=match: self.remove_match(m))
                framed_match = self.builtin_frame_visible_for_overlapping_match(match)
                target = framed_match or match
                if self.match_line_exists(target):
                    menu.add_command(label=f"הסר מסגרת מאותיות הממצא: {target.word} | דילוג {abs(target.skip or 1)}", command=lambda m=target: self.remove_line_for_match(m))
                else:
                    menu.add_command(label=f"הוסף מסגרת לאותיות הממצא: {label}", command=lambda m=target: self.add_line_for_match(m))
                if hasattr(self, "app_delete_word_from_scan_file"):
                    menu.add_command(label=f"הסרה + מחיקה מקובץ סריקה: {label}", command=lambda m=match: self.remove_match_and_delete_word(m))
            menu.add_separator()
        selected_positions = self.unique_selected_positions()
        if selected_positions:
            selected_text = "".join(self.model.search_text[p] for p in selected_positions)
            menu.add_command(label=f"סמן כל הרצף בצבע אקראי: {selected_text}", command=lambda ps=selected_positions, w=selected_text: self.add_manual_positions_random_color(ps, w))
            menu.add_command(label=f"סמן כל הרצף בבחירת צבע: {selected_text}", command=lambda ps=selected_positions, w=selected_text: self.add_manual_positions_chosen_color(ps, w))
            menu.add_separator()
        word_positions = self.word_positions_at(pos)
        word_text = "".join(self.model.search_text[p] for p in word_positions)
        menu.add_command(label="סמן אות זו", command=lambda p=pos: self.add_manual_positions([p], "סומן ידנית: אות"))
        if word_positions and word_text:
            menu.add_command(label=f"סמן מילה: {word_text}", command=lambda ps=word_positions, w=word_text: self.add_manual_positions(ps, f"סומנה מילה: {w}"))
            if hasattr(self, "app_add_word_to_scan_file"):
                menu.add_command(label=f"הוסף מילה לקובץ סריקה: {word_text}", command=lambda w=word_text: self.app_add_word_to_scan_file(w))
        menu.add_command(label="התחל קו מכאן", command=lambda p=pos: self.set_context_line_anchor(p))
        if self.context_line_anchor is not None:
            menu.add_command(label="סמן קו מהנקודה הקודמת לכאן", command=lambda p=pos: self.add_line_from_context_anchor(p))
        if self.manual_marks or self.selected_positions:
            menu.add_command(label="נקה סימונים ידניים", command=self.clear_manual)
        menu.tk_popup(event.x_root, event.y_root)
        return "break"

    def unique_selected_positions(self) -> List[int]:
        ps = []
        seen = set()
        for p in self.selected_positions:
            if 0 <= p < len(self.model.search_text) and p not in seen:
                seen.add(p)
                ps.append(p)
        return ps

    def word_positions_at(self, pos: int) -> List[int]:
        if pos < 0 or pos >= len(self.model.search_text):
            return []
        if pos >= len(self.model.word_parity):
            return [pos]
        parity = self.model.word_parity[pos]
        start = pos
        while start > 0 and start - 1 < len(self.model.word_parity) and self.model.word_parity[start - 1] == parity:
            start -= 1
        end = pos
        last = len(self.model.search_text) - 1
        while end < last and end + 1 < len(self.model.word_parity) and self.model.word_parity[end + 1] == parity:
            end += 1
        return list(range(start, end + 1))

    def add_manual_positions(self, positions: List[int], status_text: str = "סומן ידנית", color: str = "#ffd966", kind: str = "manual"):
        ps = []
        seen = set()
        for p in positions:
            if 0 <= p < len(self.model.search_text) and p not in seen:
                seen.add(p)
                ps.append(p)
        if not ps:
            return False
        word = "".join(self.model.search_text[p] for p in ps)
        if hasattr(self, "app_push_undo_state"):
            self.app_push_undo_state(status_text or "סימון ידני")
        self.manual_marks.append(Match(word, ps[0], 1, kind or "manual", color or "#ffd966", ps))
        self.selected_positions.clear()
        self.render()
        if hasattr(self, "app_status"):
            self.app_status.set(status_text)
        return True

    def random_manual_color(self) -> str:
        palette = ["#ffd966", "#93c47d", "#6fa8dc", "#c27ba0", "#f6b26b", "#76a5af", "#b4a7d6", "#e06666"]
        return random.choice(palette)

    def add_manual_positions_random_color(self, positions: List[int], word: str):
        return self.add_manual_positions(positions, f"סומן רצף ידני בצבע אקראי: {word}", self.random_manual_color())

    def add_manual_positions_chosen_color(self, positions: List[int], word: str):
        color = colorchooser.askcolor(color=self.random_manual_color(), title=f"צבע עבור {word}")[1]
        if not color:
            return False
        return self.add_manual_positions(positions, f"סומן רצף ידני בצבע נבחר: {word}", color)

    def set_context_line_anchor(self, pos: int):
        self.context_line_anchor = pos
        self.selected_positions = [pos]
        self.render()
        if hasattr(self, "app_status"):
            self.app_status.set("נבחרה נקודת התחלה לקו. קליק ימני על אות נוספת יסמן קו.")

    def add_line_from_context_anchor(self, pos: int):
        anchor = self.context_line_anchor
        if anchor is None:
            return False
        c1 = self.pos_to_cell.get(anchor)
        c2 = self.pos_to_cell.get(pos)
        if not c1 or not c2:
            return False
        ps = self.cell_line_positions(c1[0], c1[1], c2[0], c2[1])
        self.context_line_anchor = None
        return self.add_manual_positions(ps, "סומן קו ידני בין שתי נקודות")

    def representative_visible_position(self, match: Match) -> Optional[int]:
        positions = [p for p in match.calc_positions() if p in self.pos_to_cell]
        if not positions:
            return None
        return positions[len(positions) // 2]

    def add_line_between_positions(self, start_pos: Optional[int], end_pos: Optional[int], status_text: str, kind: str = "manual") -> bool:
        if start_pos is None or end_pos is None:
            if hasattr(self, "app_status"):
                self.app_status.set("לא ניתן למתוח קו: אחד הממצאים אינו נראה בתצוגה")
            return False
        c1 = self.pos_to_cell.get(start_pos)
        c2 = self.pos_to_cell.get(end_pos)
        if not c1 or not c2:
            if hasattr(self, "app_status"):
                self.app_status.set("לא ניתן למתוח קו: אחד הממצאים אינו נראה בתצוגה")
            return False
        ps = self.cell_line_positions(c1[0], c1[1], c2[0], c2[1])
        return self.add_manual_positions(ps, status_text, kind=kind)

    def line_positions_for_match(self, match: Match) -> List[int]:
        positions = [p for p in match.calc_positions() if p in self.pos_to_cell]
        if getattr(match, "kind", "") == "frame":
            return positions
        if len(positions) < 2:
            p = self.representative_visible_position(match)
            return [p] if p is not None else []
        c1 = self.pos_to_cell.get(positions[0])
        c2 = self.pos_to_cell.get(positions[-1])
        if not c1 or not c2:
            return []
        return self.cell_line_positions(c1[0], c1[1], c2[0], c2[1])

    def match_frame_key(self, match: Match):
        return (canonical_hebrew(match.word), tuple(match.calc_positions()))

    def builtin_frame_visible_for_match(self, match: Match) -> bool:
        if not getattr(self, "show_mark_borders", True):
            return False
        if match.kind == "manual":
            return False
        if self.match_frame_key(match) in self.hidden_match_frames:
            return False
        return any(p in self.pos_to_cell for p in match.calc_positions())

    def builtin_frame_visible_for_overlapping_match(self, match: Match) -> Optional[Match]:
        if not getattr(self, "show_mark_borders", True):
            return None
        positions = set(p for p in match.calc_positions() if p in self.pos_to_cell)
        if not positions:
            return None
        for candidate in self.matches or []:
            if candidate.kind == "manual":
                continue
            candidate_positions = set(p for p in candidate.calc_positions() if p in self.pos_to_cell)
            if not candidate_positions or not (positions & candidate_positions):
                continue
            if self.match_frame_key(candidate) in self.hidden_match_frames:
                continue
            return candidate
        return None

    def hidden_frame_for_overlapping_match(self, match: Match) -> Optional[Match]:
        positions = set(p for p in match.calc_positions() if p in self.pos_to_cell)
        if not positions:
            return None
        for candidate in self.matches or []:
            candidate_positions = set(p for p in candidate.calc_positions() if p in self.pos_to_cell)
            if candidate_positions and positions & candidate_positions and self.match_frame_key(candidate) in self.hidden_match_frames:
                return candidate
        return None

    def manual_line_mark_for_match(self, match: Match) -> Optional[Match]:
        target = set(self.line_positions_for_match(match))
        if not target:
            return None
        match_positions = set(p for p in match.calc_positions() if p in self.pos_to_cell)
        for manual in self.manual_marks:
            if manual.kind != "frame":
                continue
            manual_positions = set(manual.calc_positions())
            if manual_positions == target:
                return manual
            if match_positions and manual_positions & match_positions:
                return manual
            if match_positions and match_positions <= manual_positions:
                return manual
            if target and len(target & manual_positions) >= max(1, min(len(target), len(manual_positions)) - 1):
                return manual
        return None

    def match_line_exists(self, match: Match) -> bool:
        return (
            self.manual_line_mark_for_match(match) is not None
            or self.builtin_frame_visible_for_match(match)
            or self.builtin_frame_visible_for_overlapping_match(match) is not None
        )

    def remove_line_for_match(self, match: Match) -> bool:
        manual = self.manual_line_mark_for_match(match)
        if manual is not None:
            if hasattr(self, "app_push_undo_state"):
                self.app_push_undo_state(f"הסרת מסגרת {match.word}")
            self.manual_marks.remove(manual)
            self.render()
            if hasattr(self, "app_status"):
                self.app_status.set(f"הוסרה מסגרת לאותיות הממצא: {match.word}")
            return True
        if self.builtin_frame_visible_for_match(match):
            if hasattr(self, "app_push_undo_state"):
                self.app_push_undo_state(f"הסתרת מסגרת {match.word}")
            self.hidden_match_frames.add(self.match_frame_key(match))
            self.render()
            if hasattr(self, "app_status"):
                self.app_status.set(f"הוסרה מסגרת מאותיות הממצא: {match.word}")
            return True
        overlap = self.builtin_frame_visible_for_overlapping_match(match)
        if overlap is not None:
            if hasattr(self, "app_push_undo_state"):
                self.app_push_undo_state(f"הסתרת מסגרת {overlap.word}")
            self.hidden_match_frames.add(self.match_frame_key(overlap))
            self.render()
            if hasattr(self, "app_status"):
                self.app_status.set(f"הוסרה מסגרת מאותיות הממצא: {match.word}")
            return True
        return False

    def add_line_for_match(self, match: Match) -> bool:
        if self.match_line_exists(match):
            return self.remove_line_for_match(match)
        key = self.match_frame_key(match)
        if key in self.hidden_match_frames:
            if hasattr(self, "app_push_undo_state"):
                self.app_push_undo_state(f"החזרת מסגרת {match.word}")
            self.hidden_match_frames.remove(key)
            self.render()
            if hasattr(self, "app_status"):
                self.app_status.set(f"הוחזרה מסגרת לאותיות הממצא: {match.word}")
            return True
        hidden_overlap = self.hidden_frame_for_overlapping_match(match)
        if hidden_overlap is not None:
            if hasattr(self, "app_push_undo_state"):
                self.app_push_undo_state(f"החזרת מסגרת {hidden_overlap.word}")
            self.hidden_match_frames.remove(self.match_frame_key(hidden_overlap))
            self.render()
            if hasattr(self, "app_status"):
                self.app_status.set(f"הוחזרה מסגרת לאותיות הממצא: {hidden_overlap.word}")
            return True
        positions = [p for p in match.calc_positions() if p in self.pos_to_cell]
        if not positions:
            p = self.representative_visible_position(match)
            positions = [p] if p is not None else []
        if not positions:
            if hasattr(self, "app_status"):
                self.app_status.set("לא ניתן להוסיף מסגרת: הממצא אינו נראה בתצוגה")
            return False
        if hasattr(self, "app_push_undo_state"):
            self.app_push_undo_state(f"הוספת מסגרת {match.word}")
        self.manual_marks.append(Match(match.word, positions[0], match.skip or 1, "frame", match.color or "#2f80ed", positions))
        self.render()
        if hasattr(self, "app_status"):
            self.app_status.set(f"הוספה מסגרת לכל אות מהממצא: {match.word}")
        return True

    def add_line_to_display_match(self, match: Match) -> bool:
        target = self.app_current_display_match() if hasattr(self, "app_current_display_match") else None
        if target is None:
            if hasattr(self, "app_status"):
                self.app_status.set("אין ממצא תצוגה מרכזי למתיחת קו אליו")
            return False
        return self.add_line_between_positions(
            self.representative_visible_position(match),
            self.representative_visible_position(target),
            f"סומן קו בין {match.word} לבין התצוגה",
        )

    def add_top_connector_to_match(self, source_widget, match: Match) -> bool:
        if self.top_connector_exists_for_match(match):
            return self.remove_top_connector_for_match(match)
        try:
            source_widget.update_idletasks()
            self.canvas.update_idletasks()
            widget_center_root_x = source_widget.winfo_rootx() + source_widget.winfo_width() / 2
            canvas_root_x = self.canvas.winfo_rootx()
            canvas_x = self.canvas.canvasx(widget_center_root_x - canvas_root_x)
        except Exception:
            canvas_x = self.canvas.canvasx(self.canvas.winfo_width() / 2)
        if hasattr(self, "app_push_undo_state"):
            self.app_push_undo_state(f"סימון קו לתצוגה {match.word}")
        self.top_connector_lines.append({"x": canvas_x, "match": match})
        self.render()
        if hasattr(self, "app_top_connectors_changed"):
            self.app_top_connectors_changed()
        if hasattr(self, "app_status"):
            self.app_status.set(f"נמתח קו מהמילה למעלה אל {match.word} בתצוגה")
        return True

    def add_top_connector_at_x(self, canvas_x: float, match: Match) -> bool:
        if self.top_connector_exists_for_match(match):
            return False
        self.top_connector_lines.append({"x": canvas_x, "match": match})
        return True

    def add_top_connectors_for_groups(self, group_widgets: List[Tuple[dict, object]]) -> int:
        added = 0
        pushed_undo = False
        try:
            self.canvas.update_idletasks()
            canvas_root_x = self.canvas.winfo_rootx()
            fallback_x = self.canvas.canvasx(self.canvas.winfo_width() / 2)
        except Exception:
            canvas_root_x = 0
            fallback_x = 0
        for group, widget in group_widgets:
            try:
                widget.update_idletasks()
                source_x = self.canvas.canvasx(widget.winfo_rootx() + widget.winfo_width() / 2 - canvas_root_x)
            except Exception:
                source_x = fallback_x
            for match in group.get("matches", []) or []:
                if self.add_top_connector_at_x(source_x, match):
                    if not pushed_undo and hasattr(self, "app_push_undo_state"):
                        self.app_push_undo_state("שליחת קווים מהמילים למעלה")
                        pushed_undo = True
                    added += 1
        if added:
            self.render()
            if hasattr(self, "app_top_connectors_changed"):
                self.app_top_connectors_changed()
            if hasattr(self, "app_status"):
                self.app_status.set(f"נמתחו {added} קווים מהמילים למעלה אל הממצאים בצופן")
        return added

    def top_connector_key(self, match: Match):
        return (canonical_hebrew(match.word), match.start, match.skip, match.kind, tuple(match.calc_positions()))

    def top_connector_exists_for_match(self, match: Match) -> bool:
        target = self.top_connector_key(match)
        for item in self.top_connector_lines:
            item_match = item.get("match") if isinstance(item, dict) else None
            if item_match is not None and self.top_connector_key(item_match) == target:
                return True
        return False

    def remove_top_connector_for_match(self, match: Match) -> bool:
        target = self.top_connector_key(match)
        kept = []
        removed = 0
        for item in self.top_connector_lines:
            item_match = item.get("match") if isinstance(item, dict) else None
            if item_match is not None and self.top_connector_key(item_match) == target:
                removed += 1
                continue
            kept.append(item)
        if not removed:
            return False
        if hasattr(self, "app_push_undo_state"):
            self.app_push_undo_state(f"הסרת קו לתצוגה {match.word}")
        self.top_connector_lines = kept
        self.render()
        if hasattr(self, "app_top_connectors_changed"):
            self.app_top_connectors_changed()
        if hasattr(self, "app_status"):
            self.app_status.set(f"הוסר קו לתצוגה עבור {match.word}")
        return True

    def remove_top_connectors_for_word(self, word: str) -> int:
        target = canonical_hebrew(word)
        kept = []
        removed = 0
        for item in self.top_connector_lines:
            item_match = item.get("match") if isinstance(item, dict) else None
            if item_match is not None and canonical_hebrew(item_match.word) == target:
                removed += 1
                continue
            kept.append(item)
        if not removed:
            return 0
        if hasattr(self, "app_push_undo_state"):
            self.app_push_undo_state(f"הסרת קווי תצוגה {word}")
        self.top_connector_lines = kept
        self.render()
        if hasattr(self, "app_top_connectors_changed"):
            self.app_top_connectors_changed()
        if hasattr(self, "app_status"):
            self.app_status.set(f"הוסרו {removed} קווים מממצאי המילה {word}")
        return removed

    def clear_top_connectors(self) -> int:
        removed = len(self.top_connector_lines)
        if not removed:
            return 0
        if hasattr(self, "app_push_undo_state"):
            self.app_push_undo_state("ניקוי קווי תצוגה")
        self.top_connector_lines.clear()
        self.render()
        if hasattr(self, "app_top_connectors_changed"):
            self.app_top_connectors_changed()
        if hasattr(self, "app_status"):
            self.app_status.set(f"הוסרו {removed} קווים מהצופן")
        return removed

    def change_match_color(self, match: Match):
        color = colorchooser.askcolor(color=match.color or stable_word_color(match.word), title=f"צבע עבור {match.word}")[1]
        if color:
            match.color = color
            self.render()

    def remove_match(self, match: Match):
        if match in self.matches:
            self.matches.remove(match)
        if match in self.manual_marks:
            self.manual_marks.remove(match)
        if hasattr(self, "app_remove_match"):
            self.app_remove_match(match)
        if hasattr(self, "app_status"):
            self.app_status.set("הוסר סימון")
        self.render()

    def remove_match_and_delete_word(self, match: Match):
        self.remove_match(match)
        if hasattr(self, "app_delete_word_from_scan_file"):
            self.app_delete_word_from_scan_file(match.word)

    def on_drag(self, event):
        self.yad_pointer_inside = True
        self.yad_pointer_x = self.canvas.canvasx(event.x)
        self.yad_pointer_y = self.canvas.canvasy(event.y)
        if self.cursor_mode == "yad" and self.custom_yad_image:
            self.draw_yad_cursor(self.yad_pointer_x, self.yad_pointer_y)
        if not self.selection_enabled:
            self.pan_text_by_mouse(event)
            return "break"
        if self.drag_start is None:
            return "break"
        x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        p2 = self.cell_at(x, y)
        if p2 is None:
            return "break"
        if p2 == self._last_drag_preview_pos:
            return "break"
        c1 = self.pos_to_cell.get(self.drag_start)
        c2 = self.pos_to_cell.get(p2)
        if not c1 or not c2:
            return "break"
        r1, col1 = c1
        r2, col2 = c2
        self.selection_preview_start = self.drag_start
        self.selection_preview_end = p2
        self._last_drag_preview_pos = p2
        self.selection_preview_line = (*self.cell_center(r1, col1), *self.cell_center(r2, col2))
        self.draw_selection_preview()
        return "break"

    def on_mouse_up(self, event):
        if not self.selection_enabled:
            return "break"
        if self.drag_start is None:
            return "break"
        x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        p2 = self.cell_at(x, y) or self.selection_preview_end or self.drag_start
        c1 = self.pos_to_cell.get(self.drag_start)
        c2 = self.pos_to_cell.get(p2)
        if c1 and c2:
            self.selected_positions = self.cell_line_positions(c1[0], c1[1], c2[0], c2[1])
        self.drag_start = None
        self.selection_preview_start = None
        self.selection_preview_end = None
        self.selection_preview_line = None
        self._last_drag_preview_pos = None
        self.render()
        return "break"

    def pan_text_by_mouse(self, event):
        if self.pan_last_x is None or self.pan_last_y is None:
            self.pan_last_x = event.x
            self.pan_last_y = event.y
            return
        dx = event.x - self.pan_last_x
        dy = event.y - self.pan_last_y
        self.pan_last_x = event.x
        self.pan_last_y = event.y
        self.pan_accum_x += dx
        self.pan_accum_y += dy

        horizontal_unit = max(8, self.visual_cell_width())
        if abs(self.pan_accum_x) >= horizontal_unit:
            units = int(self.pan_accum_x / horizontal_unit)
            self.move_horizontal(units, units=1)
            self.pan_accum_x -= units * horizontal_unit

        vertical_unit = max(8, self.cell_h)
        if abs(self.pan_accum_y) >= vertical_unit:
            rows = int(self.pan_accum_y / vertical_unit)
            self.move_linear_rows(-rows)
            self.pan_accum_y -= rows * vertical_unit

    def cell_line_positions(self, r1: int, c1: int, r2: int, c2: int) -> List[int]:
        positions = []
        dr = r2 - r1
        dc = c2 - c1
        steps = max(abs(dr), abs(dc), 1)
        seen = set()
        for i in range(steps + 1):
            r = round(r1 + dr * i / steps)
            c = round(c1 + dc * i / steps)
            if 0 <= r < len(self.grid) and 0 <= c < len(self.grid[r]):
                p = self.grid[r][c]
                if p is not None and p not in seen:
                    seen.add(p)
                    positions.append(p)
        return positions

    def cell_center(self, row: int, col: int) -> Tuple[float, float]:
        start_col, end_col = self.visible_col_bounds()
        visible_col = col - start_col
        visible_cols = max(1, end_col - start_col)
        content_w = self.spp_w + visible_cols * self.cell_w
        letter_w = self.visual_cell_width()
        x = self.draw_x_offset + content_w - self.spp_w - (visible_col + 0.5) * letter_w
        y = self.draw_y_offset + row * self.cell_h + self.cell_h / 2
        return x, y

    def cell_rect(self, row: int, col: int) -> Tuple[float, float, float, float]:
        cx, cy = self.cell_center(row, col)
        letter_w = self.visual_cell_width()
        return (
            cx - letter_w / 2 + 1,
            self.draw_y_offset + row * self.cell_h + 1,
            cx + letter_w / 2 - 1,
            self.draw_y_offset + (row + 1) * self.cell_h - 1,
        )

    def nearest_cell_border_point(self, row: int, col: int, from_x: float, from_y: float) -> Tuple[float, float]:
        left, top, right, bottom = self.cell_rect(row, col)
        cx, cy = self.cell_center(row, col)
        dx = cx - from_x
        dy = cy - from_y
        if abs(dx) < 0.001 and abs(dy) < 0.001:
            return cx, top
        half_w = max(1.0, (right - left) / 2)
        half_h = max(1.0, (bottom - top) / 2)
        scale = max(abs(dx) / half_w, abs(dy) / half_h, 0.001)
        return cx - dx / scale, cy - dy / scale

    def match_visible_rect(self, match: Match) -> Optional[Tuple[float, float, float, float]]:
        cells = [self.pos_to_cell[p] for p in match.calc_positions() if p in self.pos_to_cell]
        if not cells:
            return None
        rects = [self.cell_rect(row, col) for row, col in cells]
        return (
            min(rect[0] for rect in rects),
            min(rect[1] for rect in rects),
            max(rect[2] for rect in rects),
            max(rect[3] for rect in rects),
        )

    def nearest_match_border_point(self, match: Match, from_x: float, from_y: float) -> Optional[Tuple[float, float]]:
        rect = self.match_visible_rect(match)
        if not rect:
            pos = self.representative_visible_position(match)
            cell = self.pos_to_cell.get(pos) if pos is not None else None
            if not cell:
                return None
            return self.nearest_cell_border_point(cell[0], cell[1], from_x, from_y)
        left, top, right, bottom = rect
        cx = (left + right) / 2
        cy = (top + bottom) / 2
        # Top connectors should meet the visible word at the closest point on its top edge.
        if from_y <= top:
            return max(left, min(right, from_x)), top
        if from_y >= bottom:
            return max(left, min(right, from_x)), bottom
        if from_x <= left:
            return left, max(top, min(bottom, from_y))
        if from_x >= right:
            return right, max(top, min(bottom, from_y))
        return cx, cy

    def move_linear_rows(self, rows_delta: int):
        self.lock_to_primary_anchor = False
        if self.view_mode != "linear":
            self.move_skip_rows(rows_delta)
            return
        step = self.cols * rows_delta
        if step:
            self.build_linear(self.linear_start + step, self.cols, self.rows)
            self.flush_scroll_redraw()

    def move_linear_pages(self, pages_delta: int):
        if self.view_mode != "linear":
            self.move_skip_rows(pages_delta * max(1, self.rows - 2))
            return
        self.move_linear_rows(pages_delta * max(1, self.rows - 2))

    def move_linear_home_end(self, end: bool = False):
        self.lock_to_primary_anchor = False
        if self.view_mode != "linear":
            self.move_skip_to_fraction(1.0 if end else 0.0)
            return
        if end:
            self.build_linear(len(self.model.search_text) - self.cols * self.rows, self.cols, self.rows)
        else:
            self.build_linear(0, self.cols, self.rows)
        self.flush_scroll_redraw()

    def move_skip_rows(self, rows_delta: int):
        if self.view_mode != "skip" or not self.skip_primary:
            return
        self.lock_to_primary_anchor = False
        step = max(1, abs(self.skip_primary.skip or 1)) * int(rows_delta)
        if step:
            self.build_skip_grid(self.skip_primary, view_anchor=self.skip_view_anchor + step)
            if self.on_view_change:
                self.on_view_change()
            self.flush_scroll_redraw()

    def move_skip_to_fraction(self, fraction: float):
        if self.view_mode != "skip" or not self.skip_primary:
            return
        self.lock_to_primary_anchor = False
        max_anchor = max(0, len(self.model.search_text) - 1)
        anchor = int(max_anchor * max(0.0, min(1.0, fraction)))
        row_step = max(1, abs(self.skip_primary.skip or 1))
        anchor = (anchor // row_step) * row_step
        self.build_skip_grid(self.skip_primary, view_anchor=anchor)
        if self.on_view_change:
            self.on_view_change()
        self.flush_scroll_redraw()

    def on_mouse_wheel(self, event):
        if getattr(event, "num", None) == 4:
            delta = -1
        elif getattr(event, "num", None) == 5:
            delta = 1
        else:
            delta = -1 if event.delta > 0 else 1
        self.move_linear_rows(delta * 3)
        return "break"

    def on_zoom_wheel(self, event):
        if getattr(event, "num", None) == 4:
            delta = 2
        elif getattr(event, "num", None) == 5:
            delta = -2
        else:
            delta = 2 if getattr(event, "delta", 0) > 0 else -2
        self.set_zoom(delta)
        self.flush_scroll_redraw()
        return "break"

    def on_shift_mouse_wheel(self, event):
        direction = -1 if event.delta > 0 else 1
        self.move_horizontal(direction, units=1)
        return "break"

    def move_horizontal(self, direction: int, units: int = 1):
        direction = int(direction)
        units = 1
        if self.view_mode == "skip":
            start_before, end_before = self.visible_col_bounds()
            visible_cols = max(1, end_before - start_before)
            center_col = self.cols // 2
            max_start = max(0, self.cols - visible_cols)
            centered_start = max(0, min(max_start, center_col - visible_cols // 2))
            current_start = max(0, min(max_start, centered_start + int(self.view_col_offset)))
            target_start = max(0, min(max_start, current_start + direction * units))
            self.view_col_offset = target_start - centered_start
            if target_start != current_start:
                self.render()
                self.flush_scroll_redraw()
            else:
                if self.move_wrapped_text_horizontally(direction, units):
                    self.flush_scroll_redraw()
            return
        before = self.canvas.xview()
        self.canvas.xview_scroll(direction * units, "units")
        after = self.canvas.xview()
        if before == after:
            moved = self.move_wrapped_text_horizontally(direction, units)
            if not moved:
                delta = 0.005 * direction
                self.canvas.xview_moveto(max(0.0, min(1.0, before[0] + delta)))
        self.flush_scroll_redraw()

    def flush_scroll_redraw(self):
        try:
            self.canvas.update_idletasks()
            self.update_idletasks()
        except Exception:
            pass

    def move_wrapped_text_horizontally(self, direction: int, units: int = 1) -> bool:
        if not self.model.search_text:
            return False
        shift = -int(direction) * max(1, int(units))
        if self.view_mode == "skip" and self.skip_primary:
            max_anchor = max(0, len(self.model.search_text) - 1)
            current_anchor = int(getattr(self, "skip_view_anchor", self.skip_primary.start) or 0)
            new_anchor = max(0, min(max_anchor, current_anchor + shift))
            if new_anchor == current_anchor:
                return False
            self.lock_to_primary_anchor = False
            self.build_skip_grid(self.skip_primary, view_anchor=new_anchor)
            return True
        if self.view_mode == "linear":
            max_start = max(0, len(self.model.search_text) - max(1, self.cols * self.rows))
            new_start = max(0, min(max_start, int(self.linear_start) + shift))
            if new_start == self.linear_start:
                return False
            self.build_linear(new_start, self.cols, self.rows)
            return True
        return False

    def on_key(self, event):
        key = event.keysym
        if key == "Down":
            self.move_linear_rows(1)
        elif key == "Up":
            self.move_linear_rows(-1)
        elif key == "Next":
            self.move_linear_pages(1)
        elif key == "Prior":
            self.move_linear_pages(-1)
        elif key == "Home":
            self.move_linear_home_end(False)
        elif key == "End":
            self.move_linear_home_end(True)
        elif key == "Right":
            self.move_horizontal(-1)
        elif key == "Left":
            self.move_horizontal(1)
        else:
            return
        return "break"

    def on_vertical_scroll(self, *args):
        if not args:
            return
        action = args[0]
        if action == "scroll" and len(args) >= 3:
            units = int(args[1])
            what = args[2]
            if self.view_mode == "skip":
                if what == "pages":
                    self.move_skip_rows(units * max(1, self.rows - 2))
                else:
                    self.move_skip_rows(units)
            else:
                if what == "pages":
                    self.move_linear_pages(units)
                else:
                    self.move_linear_rows(units)
        elif action == "moveto" and len(args) >= 2:
            fraction = max(0.0, min(1.0, float(args[1])))
            if self.view_mode == "skip":
                self.move_skip_to_fraction(fraction)
            else:
                max_start = max(0, len(self.model.search_text) - self.cols * self.rows)
                row_start = int((max_start * fraction) // max(1, self.cols)) * self.cols
                self.build_linear(row_start, self.cols, self.rows)

    def on_position_scale(self, value):
        if getattr(self, "updating_position_scale", False):
            return
        try:
            fraction = max(0.0, min(1.0, float(value) / 1000.0))
        except (TypeError, ValueError):
            return
        self.jump_to_fraction(fraction)

    def update_position_scale(self, fraction: float):
        if not hasattr(self, "position_scale"):
            return
        self.updating_position_scale = True
        try:
            self.position_scale.set(max(0.0, min(1.0, float(fraction))) * 1000.0)
        finally:
            self.updating_position_scale = False
        self.draw_book_markers()

    def jump_to_fraction(self, fraction: float):
        fraction = max(0.0, min(1.0, float(fraction)))
        if self.view_mode == "skip":
            self.move_skip_to_fraction(fraction)
        else:
            max_start = max(0, len(self.model.search_text) - self.cols * self.rows)
            row_start = int((max_start * fraction) // max(1, self.cols)) * self.cols
            self.build_linear(row_start, self.cols, self.rows)

    def current_scroll_fraction(self) -> float:
        total = max(1, len(self.model.search_text))
        if self.view_mode == "skip":
            return max(0.0, min(1.0, self.skip_view_anchor / total))
        return max(0.0, min(1.0, self.linear_start / total))

    def position_for_fraction(self, fraction: float) -> int:
        total = max(1, len(self.model.search_text))
        return max(0, min(total - 1, int(max(0.0, min(1.0, fraction)) * (total - 1))))

    def book_starts(self) -> List[Tuple[str, int]]:
        starts = []
        seen = set()
        for verse in getattr(self.model, "verses", []):
            if verse.book and verse.book not in seen and "?" not in verse.book:
                seen.add(verse.book)
                starts.append((verse.book, verse.start))
        return starts

    def draw_book_markers(self):
        if not hasattr(self, "book_marker_canvas"):
            return
        if not self.marker_graph_is_visible():
            return
        c = self.book_marker_canvas
        c.delete("all")
        self.marker_point_items = {}
        h = max(1, c.winfo_height())
        w = max(1, c.winfo_width())
        total = max(1, len(self.model.search_text))
        c.create_line(w - 10, 4, w - 10, h - 4, fill="#9aa6b2", width=2)
        for book, start in self.book_starts():
            y = max(5, min(h - 5, int((start / total) * h)))
            c.create_line(2, y, w - 3, y, fill="#0b63ce", width=2)
            c.create_text(w - 16, y - 7, text=book[:2], anchor="e", fill="#1a3d7c", font=("Arial", 7, "bold"))
        points = []
        if callable(self.findings_provider):
            try:
                points = self.findings_provider() or []
            except Exception:
                points = []
        lanes = [w - 24, w - 32, w - 40]
        lane_counts = {}
        for point in sorted(points, key=lambda p: (p.get("center", 0), p.get("match").kind if p.get("match") else "")):
            match = point.get("match")
            if not match:
                continue
            y = max(5, min(h - 5, int((float(point.get("center", 0)) / total) * h)))
            is_primary = match.kind == "primary"
            lane = 0 if is_primary else 1 + (lane_counts.get(y // 8, 0) % 2)
            lane_counts[y // 8] = lane_counts.get(y // 8, 0) + (0 if is_primary else 1)
            x = lanes[min(lane, len(lanes) - 1)]
            half_len = 7 if is_primary else 5
            line_width = 3 if is_primary else 2
            item = c.create_line(
                x - half_len,
                y,
                x + half_len,
                y,
                fill=point.get("color", "#ffbf00"),
                width=line_width,
                capstyle="round",
            )
            self.marker_point_items[item] = point
        pos_y = max(5, min(h - 5, int(self.current_scroll_fraction() * h)))
        c.create_oval(w - 18, pos_y - 5, w - 3, pos_y + 5, fill="#ffbf00", outline="#7a5a00", width=1)

    def on_book_marker_motion(self, event):
        self.marker_hover_y = event.y
        self.marker_hover_point = self.book_marker_point_at(event.x, event.y)

    def on_book_marker_click(self, event):
        h = max(1, self.book_marker_canvas.winfo_height())
        self.marker_hover_y = event.y
        point = self.book_marker_point_at(event.x, event.y)
        if point and callable(self.finding_click_handler):
            self.finding_click_handler(point)
            return "break"
        self.jump_to_fraction(max(0.0, min(1.0, event.y / h)))
        return "break"

    def book_marker_point_at(self, x: int, y: int):
        if not hasattr(self, "book_marker_canvas"):
            return None
        hits = self.book_marker_canvas.find_overlapping(x - 5, y - 5, x + 5, y + 5)
        for item in reversed(hits):
            if item in self.marker_point_items:
                return self.marker_point_items[item]
        return None

    def book_marker_tooltip_text(self):
        point = getattr(self, "marker_hover_point", None)
        if point:
            match = point.get("match")
            if match:
                center = int(point.get("center", match.start))
                kind = "ראשית" if match.kind == "primary" else "משנית"
                return f"{kind}: {match.word}\nדילוג {abs(match.skip or 1)} | מיקום {center + 1:,}\n{self.model.spp_at(center)}"
        h = max(1, self.book_marker_canvas.winfo_height()) if hasattr(self, "book_marker_canvas") else 1
        y = max(0, min(h, int(getattr(self, "marker_hover_y", 0) or 0)))
        pos = self.position_for_fraction(y / h)
        spp = self.model.spp_at(pos)
        nearest = ""
        starts = self.book_starts()
        if starts:
            book, start = min(starts, key=lambda item: abs(item[1] - pos))
            nearest = f"\nתחילת ספר קרובה: {book} | מיקום {start + 1:,}"
        return f"מיקום משוער {pos + 1:,}\n{spp}{nearest}\nנקודות צבעוניות: ממצאי ראשית ומשניות"

    def selected_word(self) -> str:
        seen = set()
        ordered = []
        for p in self.selected_positions:
            if p not in seen:
                seen.add(p)
                ordered.append(p)
        return "".join(self.model.search_text[p] for p in ordered)

    def add_manual_mark(self):
        if not self.selected_positions:
            return False
        ps = []
        seen = set()
        for p in self.selected_positions:
            if p not in seen:
                seen.add(p)
                ps.append(p)
        self.manual_marks.append(Match(self.selected_word(), ps[0], 1, "manual", "#ffd966", ps))
        self.selected_positions.clear()
        self.render()
        return True

    def clear_manual(self):
        had_marks = bool(self.manual_marks or self.selected_positions or self.top_connector_lines)
        self.manual_marks.clear()
        self.selected_positions.clear()
        self.top_connector_lines.clear()
        self.context_line_anchor = None
        self.render()
        return had_marks

    def render(self):
        self.canvas.delete("all")
        self.yad_cursor_item = None
        self.pos_to_cell.clear()
        start_col, end_col = self.visible_col_bounds()
        visible_cols = max(1, end_col - start_col)
        self.render_col_start, self.render_col_end = start_col, end_col
        max_row_w = max((self.row_visual_width(row, start_col, end_col) for row in self.grid), default=visible_cols * self.cell_w)
        content_w = self.spp_w + max_row_w
        content_height = self.rows * self.cell_h
        self.vbar.grid(row=0, column=1, sticky="ns")
        canvas_w = self.canvas.winfo_width()
        if canvas_w <= 1:
            canvas_w = self.canvas.winfo_reqwidth()
        canvas_h = self.canvas.winfo_height()
        if canvas_h <= 1:
            canvas_h = self.canvas.winfo_reqheight()
        self.draw_y_offset = max(0, int((canvas_h - content_height) / 2))
        height = max(canvas_h, content_height + self.draw_y_offset * 2)
        logical_w = content_w + 10
        self.draw_x_offset = max(0, int((canvas_w - logical_w) / 2))
        scroll_w = max(canvas_w, logical_w + self.draw_x_offset)
        self.canvas.configure(scrollregion=(0, 0, scroll_w, height))
        if logical_w > canvas_w:
            self.hbar.grid(row=1, column=0, sticky="ew")
        else:
            self.hbar.grid_remove()
        if self.view_mode == "linear" and self.model.search_text:
            total = len(self.model.search_text)
            first = self.linear_start / total
            last = min(1.0, (self.linear_start + self.cols * self.rows) / total)
            self.vbar.set(first, last)
            self.update_position_scale(first)
        elif self.view_mode == "skip" and self.model.search_text:
            total = len(self.model.search_text)
            span = max(1, abs((self.skip_primary.skip if self.skip_primary else 1) or 1) * max(1, self.rows - 1) + visible_cols)
            first = max(0.0, min(1.0, self.skip_view_anchor / total))
            last = max(first + 0.002, min(1.0, (self.skip_view_anchor + span) / total))
            self.vbar.set(first, last)
            self.update_position_scale(first)

        bg = {}
        outline = {}
        widths = {}
        text_overrides = {}

        for m in self.matches:
            if m.kind == "primary":
                color = m.color or "#ff3b30"
                ol = "#990000"
                width = 2
                text_fill = "#ffe600" if is_primary_red(color) else readable_text_on_bg(color, "#111111")
            elif m.kind == "secondary":
                color = m.color or stable_word_color(m.word)
                ol = "#7a5a00"
                width = 2
                text_fill = None
            elif m.kind in ("scan", "stacked"):
                color = m.color or stable_word_color(m.word)
                ol = "#004c99"
                width = 2
                text_fill = None
            elif m.kind == "text":
                color = m.color or stable_word_color(m.word)
                ol = color
                width = 2
                text_fill = None
            elif m.kind == "repeat_text":
                color = "#ffbf00"
                ol = "#9a6a00"
                width = 2
                text_fill = None
            elif m.kind == "date":
                color = m.color or "#c2185b"
                ol = "#7b2cbf"
                width = 2
                text_fill = None
            elif m.kind == "date_day":
                color = m.color or "#fff176"
                ol = "#7b2cbf"
                width = 2
                text_fill = None
            elif m.kind == "date_month":
                color = m.color or "#ffb74d"
                ol = "#7b2cbf"
                width = 2
                text_fill = None
            else:
                color = m.color or "#ffd966"
                ol = color
                width = 1
                text_fill = None
            hide_frame = self.match_frame_key(m) in self.hidden_match_frames
            for p in m.calc_positions():
                bg[p] = color
                outline[p] = color if hide_frame else ol
                widths[p] = 1 if hide_frame else width
                if text_fill:
                    text_overrides[p] = text_fill

        for m in self.manual_marks:
            color = m.color or "#b6d7a8"
            for p in m.calc_positions():
                if m.kind != "frame":
                    bg[p] = color
                outline[p] = color if m.kind == "frame" else "#5b8f42"
                widths[p] = 2
        for p in self.selected_positions:
            bg[p] = "#9fc5e8"
            outline[p] = "#2f80ed"
            widths[p] = 2

        for r, row in enumerate(self.grid):
            y = self.draw_y_offset + r * self.cell_h
            visible_row = row[start_col:end_col]
            first_pos = next((p for p in visible_row if p is not None), None)
            spp = self.model.spp_at(first_pos) if first_pos is not None else ""
            letter_w = self.visual_cell_width()
            if self.show_spp_labels:
                self.canvas.create_text(self.draw_x_offset + content_w - 6, y + self.cell_h/2, text=spp, anchor="e",
                                        font=("Arial", 12, "bold"), fill="#2f4f7f")
            x_cursor = self.draw_x_offset + content_w - self.spp_w
            for c in range(start_col, end_col):
                pos = row[c]
                visible_col = c - start_col
                x_cursor -= letter_w
                x = x_cursor
                if pos is None:
                    self.canvas.create_rectangle(
                        x + 1,
                        y + 1,
                        x + letter_w - 1,
                        y + self.cell_h - 1,
                        fill=OUTSIDE_TORAH_BG,
                        outline="",
                    )
                    continue
                self.pos_to_cell[pos] = (r, c)

                # virtual grid: no visible cell lines unless highlighted
                if pos in bg:
                    rect_outline = outline.get(pos, bg[pos]) if self.show_mark_borders else bg[pos]
                    rect_width = widths.get(pos, 1) if self.show_mark_borders else 1
                    self.canvas.create_rectangle(x+1, y+1, x+letter_w-1, y+self.cell_h-1,
                                                 fill=bg[pos], outline=rect_outline, width=rect_width)

                parity = self.model.word_parity[pos] if pos < len(self.model.word_parity) else 0
                fill = "#0b3d91" if self.alternate_word_colors and parity else "#111111"
                if pos in bg:
                    fill = text_overrides.get(pos) or readable_text_on_bg(bg[pos], fill)
                self.canvas.create_text(x + letter_w/2, y + self.cell_h/2 + 1,
                                        text=self.model.search_text[pos],
                                        font=self.current_letter_font(),
                                        fill=fill)
                x_cursor -= self.visual_gap_after(pos)
        if self.skip_width_domain_edge_visible():
            grid_right = self.draw_x_offset + content_w - self.spp_w
            grid_left = grid_right - max_row_w
            grid_top = self.draw_y_offset
            grid_bottom = self.draw_y_offset + max(self.cell_h, self.rows * self.cell_h)
            self.canvas.create_rectangle(
                grid_left + 1,
                grid_top + 1,
                grid_right - 1,
                grid_bottom - 1,
                outline="#b08d2f",
                width=1,
                dash=(3, 3),
                tags=("domain_edge",),
            )
            label_y = grid_top + min(max(16, grid_bottom - grid_top - 12), 24)
            self.canvas.create_text(
                grid_left + 8,
                label_y,
                text=rtl_display("קצה תחום הדילוג"),
                anchor="w",
                font=("Arial", 9, "bold"),
                fill="#7a5a00",
                tags=("domain_edge",),
            )
        self.draw_selection_preview()
        self.draw_top_connector_lines()
        self.restore_yad_cursor_after_render()

    def draw_selection_preview(self):
        self.canvas.delete("selection_preview")
        if not self.selection_preview_line:
            return
        x1, y1, x2, y2 = self.selection_preview_line
        self.canvas.create_line(
            x1,
            y1,
            x2,
            y2,
            fill="#2f80ed",
            width=3,
            dash=(5, 3),
            tags=("selection_preview",),
        )
        self.canvas.create_oval(
            x1 - 4,
            y1 - 4,
            x1 + 4,
            y1 + 4,
            fill="#2f80ed",
            outline="",
            tags=("selection_preview",),
        )
        self.canvas.create_oval(
            x2 - 4,
            y2 - 4,
            x2 + 4,
            y2 + 4,
            fill="#2f80ed",
            outline="",
            tags=("selection_preview",),
        )

    def draw_top_connector_lines(self):
        if not self.top_connector_lines:
            return
        canvas_width = max(1, self.canvas.winfo_width())
        kept = []
        lane_counts = {}
        for item in self.top_connector_lines:
            match = item.get("match")
            if not match:
                continue
            pos = self.representative_visible_position(match)
            if pos is None:
                kept.append(item)
                continue
            x1 = max(4, min(canvas_width - 4, float(item.get("x", canvas_width / 2))))
            lane_key = round(x1 / 18)
            lane = lane_counts.get(lane_key, 0)
            lane_counts[lane_key] = lane + 1
            x1 = max(4, min(canvas_width - 4, x1 + ((lane % 5) - 2) * 4))
            y1 = 3 + min(4, lane) * 4
            target = self.nearest_match_border_point(match, x1, y1)
            if not target:
                kept.append(item)
                continue
            x2, y2 = target
            color = match.color or ("#ff3b30" if match.kind == "primary" else stable_word_color(match.word))
            self.canvas.create_line(
                x1,
                y1,
                x2,
                y2,
                fill=color,
                width=4,
                dash=(6, 3),
                arrow="last",
                arrowshape=(13, 15, 6),
                tags=("top_connector",),
            )
            kept.append(item)
        self.top_connector_lines = kept


class ResultsTable(ttk.Frame):
    def __init__(self, master, height=12, width=36, font=("Arial", 12), **kwargs):
        super().__init__(master)
        self.display_font = font
        self.items: List[str] = []
        self.row_texts: List[str] = []
        self.columns: List[str] = []
        self.sort_keys: Dict[str, str] = {}
        self.sort_command = None
        self.fill_first_column = False
        style = ttk.Style()
        try:
            row_height = max(22, tkfont.Font(font=font).metrics("linespace") + 6)
            style.configure("GalEinai.Results.Treeview", font=font, rowheight=row_height)
            style.configure("GalEinai.Results.Treeview.Heading", font=("Arial", 12, "bold"))
        except tk.TclError:
            pass
        self.tree = ttk.Treeview(self, selectmode="browse", height=height, show="headings", style="GalEinai.Results.Treeview", **kwargs)
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.tree.bind("<Button-1>", self.on_tree_button_1, add="+")
        self.tree.bind("<Configure>", self.on_tree_configure, add="+")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.clear_columns()

    def set_columns(self, headers: List[str], widths_px: List[int], sort_command=None, active_sort_key: str = "", reverse: bool = False, fill_first: bool = False):
        self.columns = [f"c{i}" for i in range(len(headers))]
        self.sort_command = sort_command
        self.sort_keys = {}
        self.fill_first_column = bool(fill_first)
        self.tree.configure(columns=self.columns, show="headings")
        for index, (column, header) in enumerate(zip(self.columns, headers)):
            key = {"דילוג": "skip", "משניות": "secondary", "איכות": "quality"}.get(header)
            if key and sort_command:
                self.sort_keys[column] = key
            command = (lambda k=key: sort_command(k)) if key and sort_command else ""
            heading_text = header
            if key and key == active_sort_key:
                heading_text = f"{header} {'▼' if reverse else '▲'}"
            self.tree.heading(column, text=heading_text, anchor="e", command=command)
            if fill_first and index == 0:
                width = max(140, int(widths_px[index]) + 18 if index < len(widths_px) else 160)
                minwidth = 100
                stretch = True
            else:
                width = max(42, int(widths_px[index]) + 18 if index < len(widths_px) else 80)
                minwidth = 36
                stretch = bool(index == 0)
            self.tree.column(column, width=width, minwidth=minwidth, anchor="e", stretch=stretch)
        self.after_idle(self.adjust_fill_first_column)

    def on_tree_configure(self, _event=None):
        self.adjust_fill_first_column()

    def adjust_fill_first_column(self):
        if not self.fill_first_column or len(self.columns) < 2:
            return
        try:
            total_width = max(1, self.tree.winfo_width(), self.winfo_width(), self.master.winfo_width())
            fixed_width = sum(int(self.tree.column(column, "width")) for column in self.columns[1:])
            first_width = max(120, total_width - fixed_width - 8)
            self.tree.column(self.columns[0], width=first_width, stretch=True)
        except tk.TclError:
            return

    def clear_columns(self):
        self.columns = ["text"]
        self.fill_first_column = False
        self.tree.configure(columns=self.columns, show="headings")
        self.tree.heading("text", text="", anchor="e")
        self.tree.column("text", width=260, minwidth=120, anchor="e", stretch=True)
        self.sort_keys = {}
        self.sort_command = None

    def on_tree_button_1(self, event):
        if self.tree.identify_region(event.x, event.y) != "heading":
            return None
        column = self.tree.identify_column(event.x)
        try:
            index = int(str(column).lstrip("#")) - 1
        except ValueError:
            return None
        if 0 <= index < len(self.columns):
            key = self.sort_keys.get(self.columns[index])
            if key and self.sort_command:
                self.sort_command(key)
                return "break"
        return None

    def configure(self, cnf=None, **kwargs):
        height = kwargs.pop("height", None)
        ycmd = kwargs.pop("yscrollcommand", None)
        xcmd = kwargs.pop("xscrollcommand", None)
        if height is not None:
            try:
                self.tree.configure(height=int(height))
            except (TypeError, tk.TclError, ValueError):
                pass
        tree_kwargs = {}
        if ycmd is not None:
            tree_kwargs["yscrollcommand"] = ycmd
        if xcmd is not None:
            tree_kwargs["xscrollcommand"] = xcmd
        if tree_kwargs:
            self.tree.configure(**tree_kwargs)
        if kwargs:
            return super().configure(cnf, **kwargs)
        return None

    config = configure

    def cget(self, key):
        if key == "font":
            return self.display_font
        return super().cget(key)

    def yview(self, *args):
        return self.tree.yview(*args)

    def xview(self, *args):
        return self.tree.xview(*args)

    def bind(self, sequence=None, func=None, add=None):
        return self.tree.bind(sequence, func, add)

    def focus_set(self):
        return self.tree.focus_set()

    def delete(self, first, last=None):
        for item in list(self.items):
            self.tree.delete(item)
        self.items = []
        self.row_texts = []

    def insert(self, index, value):
        if isinstance(value, (list, tuple)):
            values = [str(v) for v in value]
            text = " | ".join(values)
        else:
            values = [str(value)] + [""] * max(0, len(self.columns) - 1)
            text = str(value)
        item = self.tree.insert("", "end", values=values)
        self.items.append(item)
        self.row_texts.append(text)
        return item

    def size(self):
        return len(self.items)

    def _index_for(self, index):
        if index == "end":
            return len(self.items) - 1
        try:
            return int(index)
        except (TypeError, ValueError):
            return -1

    def itemconfig(self, index, **kwargs):
        idx = self._index_for(index)
        if not (0 <= idx < len(self.items)):
            return
        tag = f"row{idx}"
        options = {}
        if "background" in kwargs:
            options["background"] = kwargs["background"]
        if "foreground" in kwargs:
            options["foreground"] = kwargs["foreground"]
        if options:
            self.tree.tag_configure(tag, **options)
            self.tree.item(self.items[idx], tags=(tag,))

    def selection_clear(self, first, last=None):
        self.tree.selection_remove(self.tree.selection())

    def selection_set(self, index):
        idx = self._index_for(index)
        if 0 <= idx < len(self.items):
            item = self.items[idx]
            self.tree.selection_set(item)
            self.tree.focus(item)

    def activate(self, index):
        idx = self._index_for(index)
        if 0 <= idx < len(self.items):
            self.tree.focus(self.items[idx])

    def see(self, index):
        idx = self._index_for(index)
        if 0 <= idx < len(self.items):
            self.tree.see(self.items[idx])

    def curselection(self):
        selection = self.tree.selection()
        if not selection:
            focus = self.tree.focus()
            selection = (focus,) if focus else ()
        for item in selection:
            if item in self.items:
                return (self.items.index(item),)
        return ()

    def bbox(self, index):
        idx = self._index_for(index)
        if 0 <= idx < len(self.items):
            return self.tree.bbox(self.items[idx])
        return None

    def get(self, index):
        idx = self._index_for(index)
        if 0 <= idx < len(self.row_texts):
            return self.row_texts[idx]
        raise tk.TclError("bad results row index")

    def identify_row_index(self, y: int) -> Optional[int]:
        item = self.tree.identify_row(y)
        if item and item in self.items:
            return self.items.index(item)
        return None


class App:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_WINDOW_TITLE)
        self.model = TorahModel()
        self.engine = SearchEngine(self.model)
        self.saved: List[Tuple[Match, List[Match]]] = []
        self.result_rows: List[Tuple[str, Optional[Match]]] = []
        self.results_mode = "ciphers"
        self.updating_result_selection = False
        self.result_selection_highlight = False
        self.cipher_sort_key = ""
        self.cipher_sort_reverse = False
        self.detail_sort_key = ""
        self.detail_sort_reverse = False
        self.settings_state = self.load_app_settings()
        self.openai_api_key = str(self.settings_state.get("openai_api_key", "") or "")
        self.last_normal_geometry = str(self.settings_state.get("window_geometry", DEFAULT_WINDOW_GEOMETRY) or DEFAULT_WINDOW_GEOMETRY)
        self.apply_saved_window_state()
        self.results_height = int(self.settings_state.get("results_height", 8) or 8)
        self.results_panel_height = int(self.settings_state.get("results_panel_height", 280) or 280)
        self.recent_search_limit = max(1, int(self.settings_state.get("recent_search_limit", 20) or 20))
        self.recent_searches = self.clean_recent_searches(self.settings_state.get("recent_searches", []))
        self.current = 0
        self.current_display_match: Optional[Match] = None
        self.side_visible = bool(self.settings_state.get("side_visible", True))
        self.bottom_controls_visible = True
        self.results_visible = bool(self.settings_state.get("results_visible", False))
        self.results_expanded = False
        self.results_overlay_hidden_widgets = []
        self.search_thread: Optional[threading.Thread] = None
        self.scan_thread: Optional[threading.Thread] = None
        self.scan_stop = False
        self.cluster_fraction_mode = 1
        self.live_skip_after = None
        self.applying_live_skip = False
        self.startup_notice_window = None
        self.close_startup_notice = None
        self.ignore_enter_until = 0.0
        self.hold_scroll_after = None
        self.hold_scroll_active = False
        self.hold_scroll_delta = 0
        self.hold_scroll_updating = False
        self.hold_scroll_button = None
        self.keyboard_scroll_after = None
        self.keyboard_scroll_key = ""
        self.keyboard_scroll_action = None
        self.keyboard_scroll_last_event = 0.0
        self.status_lock_text: Optional[str] = None
        self.restoring_locked_status = False
        self.last_no_results_status_text = ""
        self.primary_found_count = 0
        self.primary_found_var = tk.StringVar(value="")
        self.search_reached_skip_var = tk.StringVar(value="")
        self.cached_primary_key = None
        self.cached_primary_matches: List[Match] = []
        self.preserve_saved_on_next_results = False
        self.app_undo_stack: List[dict] = []
        self.app_redo_stack: List[dict] = []
        self.app_undo_labels: List[str] = []
        self.app_redo_labels: List[str] = []
        self.max_app_history = 50
        self.restoring_app_state = False
        self.auto_undo_ready = False
        self.auto_undo_trace_ids = []
        self.auto_undo_last_snapshot = None
        self.pointer_keyboard_zone = ""
        self.ctrl_shortcuts = {}
        self.ctrl_shortcut_labels = {}
        self.shortcut_conflicts = []
        self.search_state = self.load_search_state()
        self.opt_mark_borders = tk.BooleanVar(value=bool(self.settings_state.get("mark_borders", True)))
        self.opt_spp_labels = tk.BooleanVar(value=bool(self.settings_state.get("spp_labels", True)))
        self.opt_word_colors = tk.BooleanVar(value=bool(self.settings_state.get("word_colors", True)))
        self.opt_word_spaces = tk.BooleanVar(value=bool(self.settings_state.get("word_spaces", False)))
        self.opt_avot_ticker = tk.BooleanVar(value=bool(self.settings_state.get("avot_ticker", True)))
        self.avot_ticker_speed_var = tk.IntVar(value=max(1, min(10, int(self.settings_state.get("avot_ticker_speed", 4) or 4))))
        saved_avot_order = str(self.settings_state.get("avot_ticker_order", "ordered") or "ordered")
        if saved_avot_order not in ("ordered", "random"):
            saved_avot_order = "ordered"
        self.avot_ticker_order_var = tk.StringVar(value=saved_avot_order)
        self.opt_start_maximized = tk.BooleanVar(value=bool(self.settings_state.get("start_maximized", False)))
        self.opt_include_av_dates = tk.BooleanVar(value=bool(self.settings_state.get("include_av_dates", False)))
        self.opt_auto_advance_skip = tk.BooleanVar(value=bool(self.settings_state.get("extend_beyond_skip_range", False)))
        self.opt_primary_text_mark = tk.BooleanVar(value=bool(self.settings_state.get("primary_text_mark", True)))
        self.opt_secondary_text_mark = tk.BooleanVar(value=bool(self.settings_state.get("secondary_text_mark", True)))
        self.opt_try_long_secondary_primary = tk.BooleanVar(value=bool(self.settings_state.get("try_long_secondary_primary", False)))
        self.opt_min_secondary_all = tk.BooleanVar(value=bool(self.settings_state.get("min_secondary_all", False)))
        self.opt_current_view_only = tk.BooleanVar(value=bool(self.settings_state.get("current_view_only", False)))
        self.opt_minimal_search = tk.BooleanVar(value=bool(self.settings_state.get("minimal_search", False)))
        saved_font_mode = str(self.settings_state.get("font_mode", "") or "")
        if not saved_font_mode:
            saved_font_mode = "ashkenaz" if bool(self.settings_state.get("ashuri_font", False)) else "regular"
        self.font_mode_var = tk.StringVar(value=saved_font_mode if saved_font_mode in ("regular", "ashkenaz", "sefarad") else "regular")
        saved_cursor_mode = str(self.settings_state.get("cursor_mode", "yad") or "yad")
        if saved_cursor_mode == "hand":
            saved_cursor_mode = "yad"
        self.cursor_mode_var = tk.StringVar(value=saved_cursor_mode if saved_cursor_mode in ("yad", "arrow") else "yad")
        self.opt_word_spaces.trace_add("write", lambda *_args: self.apply_display_options() if hasattr(self, "canvas") else None)
        self.font_mode_label_var = tk.StringVar(value="כתב תצוגה")
        self.opt_date_fraction_fallback = tk.BooleanVar(value=bool(self.settings_state.get("date_fraction_fallback", True)))
        self.date_fraction_words = set()
        self.pending_auto_advance_search = False
        self.auto_advance_chain_active = False
        self.auto_advance_launching = False
        self.display_fraction_original_skip: Optional[int] = None
        self.active_display_fraction_divisor: Optional[int] = None
        self.skip_chunk_queue: List[Tuple[int, int]] = []
        self.skip_chunk_original_range: Optional[Tuple[int, int]] = None
        self.skip_chunk_active = False
        self.active_search_runner = "search"
        self.avot_ticker_index = 0
        self.avot_ticker_after = None
        self.avot_ticker_paused = False
        self.avot_ticker_x = 0.0
        self.avot_ticker_item = None
        self.avot_ticker_groups = []
        self.avot_ticker_group_serial = 0
        self.register_core_ctrl_shortcuts()
        self.build_ui()
        self.load_auto()
        self.install_auto_undo_watchers()
        self.root.bind("<Configure>", self.remember_normal_window_geometry, add="+")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.after_idle(self.show_startup_notice)

    def ctrl_shortcut_for_label(self, label: str) -> str:
        for key, registered_label in self.ctrl_shortcut_labels.items():
            if registered_label == label:
                return f"Ctrl+{key}"
        return ""

    def tooltip_with_shortcut(self, text: str, shortcut_label: str = "") -> str:
        shortcut = self.ctrl_shortcut_for_label(shortcut_label)
        if not shortcut:
            return text
        if shortcut in text:
            return text
        return f"{text}\nקיצור: {shortcut}"

    def add_shortcut_tooltip(self, widget, text: str, shortcut_label: str):
        add_tooltip(widget, self.tooltip_with_shortcut(text, shortcut_label))

    def build_menu(self):
        menu_bar = tk.Menu(self.root)

        file_menu = tk.Menu(menu_bar, tearoff=0)
        file_menu.add_command(label="טען תורה...", command=self.load_dialog)
        file_menu.add_command(label="השווה קבצי תורה...", command=self.compare_torah_files)
        file_menu.add_separator()
        file_menu.add_command(label="פתח פרויקט...", command=self.open_project)
        file_menu.add_command(label="שמור פרויקט...", command=self.save_project)
        if AI_FEATURES_ENABLED:
            file_menu.add_command(label="פענוח AI לצופן...", command=self.open_ai_decode_tool)
            file_menu.add_command(label="ייבא מילות AI לחיפוש...", command=self.import_ai_keywords)
        file_menu.add_separator()
        file_menu.add_command(label="שמור דו״ח ממצא...", command=self.save_current_report)
        file_menu.add_command(label="שמור תצוגה PNG/PDF...", command=self.export_current_view)
        file_menu.add_command(label="הדפס תצוגה...", command=self.print_current_view)
        file_menu.add_separator()
        file_menu.add_command(label="התקן קיצורי דרך להפעלה...", command=self.create_app_shortcuts)
        file_menu.add_separator()
        file_menu.add_command(label="יציאה", command=self.root.quit)
        menu_bar.add_cascade(label="קובץ", menu=file_menu)

        tools_menu = tk.Menu(menu_bar, tearoff=0)
        tools_menu.add_command(label="אפשרויות תצוגה וסמן...", command=self.open_options_table)
        tools_menu.add_command(label="מספר חיפושים אחרונים...", command=self.set_recent_search_limit)
        tools_menu.add_separator()
        tools_menu.add_command(label="אימות קובץ התורה...", command=self.validate_torah)
        tools_menu.add_command(label="דוח קיצורי Ctrl...", command=self.open_shortcuts_report)
        menu_bar.add_cascade(label="כלים", menu=tools_menu)

        help_menu = tk.Menu(menu_bar, tearoff=0)
        help_menu.add_command(label="הדרכה ראשונית...", command=self.open_quick_start)
        help_menu.add_command(label="עזרה והוראות...", command=lambda: self.open_general_info("search"))
        help_menu.add_command(label="מסמך טכני על דילוגים...", command=self.open_skip_technical_doc)
        menu_bar.add_cascade(label="עזרה", menu=help_menu)

        menu_bar.add_command(label="מידע", command=self.open_credits_rights_window)

        self.root.config(menu=menu_bar)

    def prepare_child_window(self, win: tk.Toplevel, min_width: int = 520, min_height: int = 360):
        apply_window_icon(win)
        win.resizable(True, True)
        try:
            win.minsize(min_width, min_height)
        except tk.TclError:
            pass

    def center_child_window(self, win: tk.Toplevel, width: int, height: int):
        win.update_idletasks()
        self.center_child_window(win, width, height)

    def open_quick_start(self, startup_prompt: bool = False):
        win = tk.Toplevel(self.root)
        win.title(rtl_display("הדרכה ראשונית"))
        win.transient(self.root)
        self.prepare_child_window(win, 620, 500)
        frame = ttk.Frame(win, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(
            frame,
            text=rtl_display("התחלת שימוש בגל עיני"),
            anchor="center",
            justify="center",
            font=("Segoe UI", 16, "bold"),
        ).pack(fill="x", pady=(0, 10))
        guide = (
            "1. בשדה ראשית כתוב את המילה או הביטוי העיקרי שאתה רוצה למצוא בתורה. "
            "הראשית היא העוגן: סביב הממצא שלה נבנית טבלת הצופן.\n\n"
            "2. בשדה משניות כתוב מילים נוספות שתרצה לבדוק ליד הראשית, מופרדות ברווח. "
            "לדוגמה: אם הראשית היא שם או נושא, המשניות יכולות להיות מילים קשורות לנושא.\n\n"
            "3. מצב צופן מחפש את הראשית בדילוגים, ואז בודק את המשניות במסך שנפתח סביב הראשית. "
            "מצב רגיל מחפש רק את הראשית, בלי תנאי משניות.\n\n"
            "4. דילוג הוא המרחק בין אות לאות במילה הנמצאת. אפשר להזין דילוג מדויק, או טווח דילוגים מ־עד, ואז ללחוץ חפש.\n\n"
            "5. אחרי שנמצא צופן, פתח אותו מהרשימה. משם אפשר להוסיף סריקה במסך, חצי/שליש/רבע דילוג, מפגשים, מקבץ, עמודות, שנה או תאריכים.\n\n"
            "המלצה: אל תכתוב בשדות החיפוש מילים בנות פחות מ-4 אותיות, מפני שהן מצויות מאוד ועלולות ליצור עומס וממצאים אקראיים. אפשר להשתמש בהן רק כאשר הן מצטרפות לממצאים קשורים, למשל שנה יחד עם התשפו.\n\n"
            "אפשרות מתקדמת: חיפוש מורחב מנסה עד 5 משניות ארוכות כראשיות חלופיות אם לא נמצא צופן שעומד בתנאים המבוקשים. פעולה זו עלולה להימשך זמן ממושך.\n\n"
            "טיפ: אם מסומן גם כטקסט ליד ראשית או משניות, מילה מהשדה שתופיע במסך כרצף רגיל תסומן גם כממצא.\n\n"
            "הדרכה זו נמצאת תמיד גם בתפריט עזרה > הדרכה ראשונית."
        )
        ttk.Label(
            frame,
            text=rtl_display(guide),
            anchor="e",
            justify="right",
            wraplength=580,
            font=("Segoe UI", 12, "bold"),
        ).pack(fill="x", pady=(0, 12))
        dont_show_var = tk.BooleanVar(value=False)
        if startup_prompt:
            dont_show_check = ttk.Checkbutton(frame, text=rtl_display("אל תציג יותר בפתיחה"), variable=dont_show_var)
            dont_show_check.pack(anchor="e", pady=(0, 8))

        def close_quick_start(_event=None):
            self.ignore_enter_until = time.time() + 0.8
            if startup_prompt and dont_show_var.get():
                self.settings_state["hide_startup_quick_start"] = True
                self.save_app_settings()
            try:
                win.destroy()
            except tk.TclError:
                pass
            return "break"

        close_btn = ttk.Button(frame, text=rtl_display("הבנתי"), command=close_quick_start)
        close_btn.pack(anchor="center", ipadx=12, ipady=2)
        win.bind("<Return>", close_quick_start)
        win.bind("<KP_Enter>", close_quick_start)
        win.protocol("WM_DELETE_WINDOW", close_quick_start)
        win.update_idletasks()
        width = max(win.winfo_reqwidth(), 620)
        height = max(win.winfo_reqheight(), 500)
        root_w = self.root.winfo_width()
        root_h = self.root.winfo_height()
        if root_w > 100 and root_h > 100:
            x = self.root.winfo_rootx() + (root_w - width) // 2
            y = self.root.winfo_rooty() + (root_h - height) // 2
        else:
            x = (win.winfo_screenwidth() - width) // 2
            y = (win.winfo_screenheight() - height) // 2
        win.geometry(f"{width}x{height}+{max(0, x)}+{max(0, y)}")
        close_btn.focus_set()
        win.lift()

    def should_show_startup_quick_start(self) -> bool:
        return not bool(self.settings_state.get("hide_startup_quick_start", False))

    def show_startup_notice(self):
        win = tk.Toplevel(self.root)
        self.startup_notice_window = win
        win.withdraw()
        win.title(rtl_display("ברוכים הבאים לגל עיני"))
        win.transient(self.root)
        self.prepare_child_window(win, 520, 360)
        win.configure(bg="#f7f7f3")
        frame = ttk.Frame(win, padding=18)
        frame.pack(fill="both", expand=True)
        ttk.Label(
            frame,
            text=rtl_display("גל עיני"),
            anchor="center",
            justify="center",
            font=("Segoe UI", 20, "bold"),
        ).pack(fill="x", pady=(0, 8))
        ttk.Label(
            frame,
            text=rtl_display("תזכורת קצרה לפני תחילת העבודה"),
            anchor="center",
            justify="center",
            font=("Segoe UI", 13, "bold"),
        ).pack(fill="x", pady=(0, 10))
        body = (
            "השימוש בתוכנה באחריות המשתמש בלבד.\n\n"
            "הממצאים מיועדים לעיון ולחקירה, ואין להסיק מהם מסקנות ודאיות "
            "או החלטות מעשיות.\n\n"
            "אין להשתמש בתוכנה לחיפוש דברים אישיים על אנשים פרטיים.\n\n"
            "יש לנהוג בזהירות ובענווה, בבחינת:\n"
            "\"תמים תהיה עם ה' אלוקיך\"."
        )
        ttk.Label(
            frame,
            text=rtl_display(body),
            anchor="center",
            justify="center",
            wraplength=500,
            font=("Segoe UI", 12, "bold"),
        ).pack(fill="x", pady=(0, 14))
        def close_notice(_event=None, show_quick_start: bool = True):
            self.ignore_enter_until = time.time() + 0.8
            try:
                for sequence in ("<Return>", "<KP_Enter>", "<KeyRelease-Return>", "<KeyRelease-KP_Enter>"):
                    win.unbind_all(sequence)
            except Exception:
                pass
            try:
                win.destroy()
            except tk.TclError:
                pass
            self.startup_notice_window = None
            self.close_startup_notice = None
            try:
                self.primary_text.focus_set()
            except Exception:
                self.root.focus_set()
            if show_quick_start and self.should_show_startup_quick_start():
                self.root.after(120, lambda: self.open_quick_start(startup_prompt=True))
            return "break"

        self.close_startup_notice = close_notice
        button_row = ttk.Frame(frame)
        button_row.pack(anchor="center")
        ok_btn = ttk.Button(button_row, text=rtl_display("הבנתי, המשך"), command=close_notice)
        ok_btn.pack(side="right", padx=4, ipadx=12, ipady=2)

        def bind_enter_recursive(widget):
            for sequence in ("<Return>", "<KP_Enter>", "<KeyRelease-Return>", "<KeyRelease-KP_Enter>"):
                widget.bind(sequence, close_notice, add="+")
            for child in widget.winfo_children():
                bind_enter_recursive(child)

        bind_enter_recursive(win)
        for sequence in ("<Return>", "<KP_Enter>", "<KeyRelease-Return>", "<KeyRelease-KP_Enter>"):
            win.bind_all(sequence, close_notice, add="+")
        win.protocol("WM_DELETE_WINDOW", close_notice)

        def center_startup_notice():
            if not win.winfo_exists():
                return
            win.update_idletasks()
            self.root.update_idletasks()
            width = max(win.winfo_reqwidth(), win.winfo_width(), 520)
            height = max(win.winfo_reqheight(), win.winfo_height(), 340)
            root_w = self.root.winfo_width()
            root_h = self.root.winfo_height()
            if root_w > 100 and root_h > 100:
                x = self.root.winfo_rootx() + (root_w - width) // 2
                y = self.root.winfo_rooty() + (root_h - height) // 2
            else:
                screen_w = win.winfo_screenwidth()
                screen_h = win.winfo_screenheight()
                x = (screen_w - width) // 2
                y = (screen_h - height) // 2
            win.geometry(f"{width}x{height}+{max(0, x)}+{max(0, y)}")
            win.deiconify()
            win.lift()

        center_startup_notice()
        ok_btn.focus_set()
        win.after(120, center_startup_notice)
        win.after(350, center_startup_notice)
        win.after(400, lambda: (win.lift(), win.focus_force(), ok_btn.focus_force()) if win.winfo_exists() else None)
        try:
            ok_btn.configure(default="active")
        except tk.TclError:
            pass
        win.grab_set()

    def on_global_enter(self, event=None):
        if time.time() < getattr(self, "ignore_enter_until", 0.0):
            return "break"
        notice = getattr(self, "startup_notice_window", None)
        if notice is not None and notice.winfo_exists():
            close_notice = getattr(self, "close_startup_notice", None)
            if callable(close_notice):
                return close_notice(event)
            return "break"
        if self.operation_is_running():
            self.stop()
            return "break"
        self.search_cipher()
        return "break"

    def on_global_arrow(self, event=None):
        routed = self.route_arrow_key_by_pointer(event) if event is not None and hasattr(self, "canvas") else None
        if routed == "break":
            return routed
        focus = self.root.focus_get()
        if isinstance(focus, (tk.Entry, tk.Text, tk.Listbox, ttk.Entry, ttk.Spinbox)):
            return None
        if hasattr(self, "primary_text") and focus in (getattr(self.primary_text, "canvas", None), getattr(self.secondary, "canvas", None)):
            return None
        if hasattr(self, "canvas") and event is not None:
            return self.start_keyboard_torah_scroll(getattr(event, "keysym", ""))
        return None

    def current_report_text(self) -> str:
        lines = [
            "גל עיני - דו״ח ממצא",
            self.context_title.get() if hasattr(self, "context_title") else "",
            f"סה״כ ממצאים שמורים: {len(self.saved)}",
            "",
        ]
        if self.saved:
            pm, local = self.saved[self.current]
            score, _quality, quality_details = self.cipher_quality(pm, local) if hasattr(self, "canvas") else (0, "לא חושב", "")
            lines.extend([
                f"ממצא נוכחי: {self.current + 1} מתוך {len(self.saved)}",
                f"מילה ראשית: {pm.word}",
                f"דילוג: {abs(pm.skip or 1)}",
                f"מיקום: {pm.start + 1}",
                f"ספ״פ: {self.model.spp_at(pm.start)}",
                f"רמת צופן: {self.short_quality_text(score)} | {quality_details}",
                "",
                "סימונים בתצוגה:",
            ])
            for m in local:
                lines.append(self.report_match_line(m))
            if len(self.saved) > 1:
                lines.extend(["", "כל הממצאים השמורים:"])
                for idx, (saved_pm, saved_local) in enumerate(self.saved, 1):
                    s, _q, qd = self.cipher_quality(saved_pm, saved_local) if hasattr(self, "canvas") else (0, "לא חושב", "")
                    lines.append(f"{idx}. ראשית: {saved_pm.word} | דילוג {abs(saved_pm.skip or 1)} | מיקום {saved_pm.start + 1} | {self.model.spp_at(saved_pm.start)} | רמה {self.short_quality_text(s)} | {qd}")
                    for m in saved_local:
                        if m.kind == "primary" and m.start == saved_pm.start and m.skip == saved_pm.skip and m.word == saved_pm.word:
                            continue
                        lines.append(f"   {self.report_match_line(m)}")
        else:
            lines.append("אין ממצא נוכחי.")
        return "\n".join(lines).strip() + "\n"

    def report_match_line(self, match: Match) -> str:
        color = match.color or ("#ff3b30" if match.kind == "primary" else stable_word_color(match.word))
        return f"- {match.kind}: {match.word} | דילוג {abs(match.skip or 1)} | מיקום {match.start + 1} | {self.model.spp_at(match.start)} | צבע {color}"

    def save_current_report(self):
        path = filedialog.asksaveasfilename(
            title="שמור דו״ח ממצא",
            defaultextension=".txt",
            filetypes=[("Text", "*.txt"), ("All", "*.*")],
        )
        if not path:
            return
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(self.current_report_text())
        self.status.set(f"נשמר דו״ח: {os.path.basename(path)}")

    def capture_widget_pixels(self, widget) -> Tuple[int, int, bytes, bytes, int]:
        if os.name != "nt":
            raise RuntimeError("שמירת PNG/PDF מתצוגה זמינה כרגע ב-Windows בלבד.")
        widget.update_idletasks()
        x = int(widget.winfo_rootx())
        y = int(widget.winfo_rooty())
        width = max(1, int(widget.winfo_width()))
        height = max(1, int(widget.winfo_height()))
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32
        SRCCOPY = 0x00CC0020
        CAPTUREBLT = 0x40000000
        screen_dc = user32.GetDC(0)
        mem_dc = gdi32.CreateCompatibleDC(screen_dc)
        bitmap = gdi32.CreateCompatibleBitmap(screen_dc, width, height)
        old_obj = gdi32.SelectObject(mem_dc, bitmap)
        try:
            if not gdi32.BitBlt(mem_dc, 0, 0, width, height, screen_dc, x, y, SRCCOPY | CAPTUREBLT):
                hwnd = int(widget.winfo_id())
                if not user32.PrintWindow(hwnd, mem_dc, 2):
                    raise RuntimeError("לא הצלחתי לצלם את התצוגה.")
            stride = ((width * 3 + 3) // 4) * 4
            buf = ctypes.create_string_buffer(stride * height)

            class BITMAPINFOHEADER(ctypes.Structure):
                _fields_ = [
                    ("biSize", ctypes.c_uint32),
                    ("biWidth", ctypes.c_int32),
                    ("biHeight", ctypes.c_int32),
                    ("biPlanes", ctypes.c_uint16),
                    ("biBitCount", ctypes.c_uint16),
                    ("biCompression", ctypes.c_uint32),
                    ("biSizeImage", ctypes.c_uint32),
                    ("biXPelsPerMeter", ctypes.c_int32),
                    ("biYPelsPerMeter", ctypes.c_int32),
                    ("biClrUsed", ctypes.c_uint32),
                    ("biClrImportant", ctypes.c_uint32),
                ]

            class BITMAPINFO(ctypes.Structure):
                _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", ctypes.c_uint32 * 3)]

            bmi = BITMAPINFO()
            bmi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bmi.bmiHeader.biWidth = width
            bmi.bmiHeader.biHeight = -height
            bmi.bmiHeader.biPlanes = 1
            bmi.bmiHeader.biBitCount = 24
            bmi.bmiHeader.biCompression = 0
            bmi.bmiHeader.biSizeImage = stride * height
            if not gdi32.GetDIBits(mem_dc, bitmap, 0, height, buf, ctypes.byref(bmi), 0):
                raise RuntimeError("לא הצלחתי לקרוא את תמונת התצוגה.")
            bgr = bytes(buf)
            rgb_rows = []
            for row in range(height):
                start = row * stride
                row_bgr = bgr[start:start + width * 3]
                rgb_rows.append(bytes(
                    channel
                    for pixel in range(0, len(row_bgr), 3)
                    for channel in (row_bgr[pixel + 2], row_bgr[pixel + 1], row_bgr[pixel])
                ))
            return width, height, bgr, b"".join(rgb_rows), stride
        finally:
            gdi32.SelectObject(mem_dc, old_obj)
            gdi32.DeleteObject(bitmap)
            gdi32.DeleteDC(mem_dc)
            user32.ReleaseDC(0, screen_dc)

    def crop_capture_pixels(self, width: int, height: int, bgr: bytes, rgb: bytes, stride: int, left: int, right: int) -> Tuple[int, int, bytes, bytes, int]:
        left = max(0, min(width - 1, int(left)))
        right = max(left + 1, min(width, int(right)))
        new_width = right - left
        new_stride = ((new_width * 3 + 3) // 4) * 4
        cropped_bgr_rows = []
        cropped_rgb_rows = []
        pad = b"\x00" * (new_stride - new_width * 3)
        for row in range(height):
            bgr_start = row * stride + left * 3
            cropped_bgr_rows.append(bgr[bgr_start:bgr_start + new_width * 3] + pad)
            rgb_start = row * width * 3 + left * 3
            cropped_rgb_rows.append(rgb[rgb_start:rgb_start + new_width * 3])
        return new_width, height, b"".join(cropped_bgr_rows), b"".join(cropped_rgb_rows), new_stride

    def print_canvas_right_edge_in_display(self) -> Optional[int]:
        canvas_widget = getattr(getattr(self, "canvas", None), "canvas", None)
        display = getattr(self, "display", None)
        if canvas_widget is None or display is None:
            return None
        try:
            display_root_x = int(display.winfo_rootx())
            canvas_right = int(canvas_widget.winfo_rootx()) + int(canvas_widget.winfo_width())
            return max(1, canvas_right - display_root_x)
        except Exception:
            return None

    def save_png_image(self, path: str, width: int, height: int, rgb: bytes):
        def chunk(kind: bytes, data: bytes) -> bytes:
            return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)

        raw = b"".join(b"\x00" + rgb[row * width * 3:(row + 1) * width * 3] for row in range(height))
        png = (
            b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6))
            + chunk(b"IEND", b"")
        )
        with open(path, "wb") as f:
            f.write(png)

    def add_rgb_border(self, width: int, height: int, rgb: bytes, border_mm: float = 2.0) -> Tuple[int, int, bytes]:
        border_px = max(0, round(float(border_mm or 0.0) * 96.0 / 25.4))
        if border_px <= 0:
            return width, height, rgb
        new_width = width + border_px * 2
        black_row = b"\x00" * (new_width * 3)
        side = b"\x00" * (border_px * 3)
        rows = [black_row] * border_px
        for row in range(height):
            start = row * width * 3
            rows.append(side + rgb[start:start + width * 3] + side)
        rows.extend([black_row] * border_px)
        return new_width, height + border_px * 2, b"".join(rows)

    def save_pdf_image(self, path: str, width: int, height: int, rgb: bytes, border_mm: float = 0.0):
        if height > width:
            page_w, page_h = 595.0, 842.0
        else:
            page_w, page_h = 842.0, 595.0
        margin = 28.0
        scale = min((page_w - margin * 2) / width, (page_h - margin * 2) / height)
        draw_w, draw_h = width * scale, height * scale
        x, y = (page_w - draw_w) / 2, (page_h - draw_h) / 2
        image_data = zlib.compress(rgb, 6)
        border_pt = max(0.0, float(border_mm or 0.0)) * 72.0 / 25.4
        content_parts = [f"q\n{draw_w:.2f} 0 0 {draw_h:.2f} {x:.2f} {y:.2f} cm\n/Im0 Do\nQ\n"]
        if border_pt > 0:
            half = border_pt / 2.0
            content_parts.append(
                f"q\n{border_pt:.2f} w 0 0 0 RG\n"
                f"{x - half:.2f} {y - half:.2f} {draw_w + border_pt:.2f} {draw_h + border_pt:.2f} re S\nQ\n"
            )
        content = "".join(content_parts).encode("ascii")
        objects = [
            b"<< /Type /Catalog /Pages 2 0 R >>",
            b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {page_w:.0f} {page_h:.0f}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>".encode("ascii"),
            f"<< /Type /XObject /Subtype /Image /Width {width} /Height {height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length {len(image_data)} >>\nstream\n".encode("ascii") + image_data + b"\nendstream",
            f"<< /Length {len(content)} >>\nstream\n".encode("ascii") + content + b"endstream",
        ]
        with open(path, "wb") as f:
            f.write(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
            offsets = [0]
            for idx, obj in enumerate(objects, 1):
                offsets.append(f.tell())
                f.write(f"{idx} 0 obj\n".encode("ascii"))
                f.write(obj)
                f.write(b"\nendobj\n")
            xref = f.tell()
            f.write(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
            f.write(b"0000000000 65535 f \n")
            for offset in offsets[1:]:
                f.write(f"{offset:010d} 00000 n \n".encode("ascii"))
            f.write(f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode("ascii"))

    def scaled_rgb_for_preview(self, width: int, height: int, rgb: bytes, max_w: int, max_h: int) -> Tuple[int, int, bytes]:
        scale = min(max_w / max(1, width), max_h / max(1, height), 1.0)
        out_w = max(1, int(width * scale))
        out_h = max(1, int(height * scale))
        if out_w == width and out_h == height:
            return width, height, rgb
        rows = []
        for y in range(out_h):
            src_y = min(height - 1, int(y / scale))
            row_start = src_y * width * 3
            src_row = rgb[row_start:row_start + width * 3]
            out_row = bytearray()
            for x in range(out_w):
                src_x = min(width - 1, int(x / scale))
                src = src_x * 3
                out_row.extend(src_row[src:src + 3])
            rows.append(bytes(out_row))
        return out_w, out_h, b"".join(rows)

    def rgb_photo_image(self, width: int, height: int, rgb: bytes) -> tk.PhotoImage:
        ppm = f"P6\n{width} {height}\n255\n".encode("ascii") + rgb
        return tk.PhotoImage(data=ppm, format="PPM")

    def toolbar_icon_image(self, kind: str, size: int = 28) -> tk.PhotoImage:
        bg = (248, 250, 252)
        aa = 4
        hi_size = size * aa
        data = [list(bg) for _ in range(hi_size * hi_size)]
        base = 22

        def put(x: int, y: int, color):
            if 0 <= x < base and 0 <= y < base:
                x1 = int(x * hi_size / base)
                y1 = int(y * hi_size / base)
                x2 = max(x1, int((x + 1) * hi_size / base) - 1)
                y2 = max(y1, int((y + 1) * hi_size / base) - 1)
                for yy in range(y1, min(hi_size, y2 + 1)):
                    for xx in range(x1, min(hi_size, x2 + 1)):
                        data[yy * hi_size + xx] = list(color)

        def line(x1: int, y1: int, x2: int, y2: int, color, width: int = 1):
            dx = abs(x2 - x1)
            dy = -abs(y2 - y1)
            sx = 1 if x1 < x2 else -1
            sy = 1 if y1 < y2 else -1
            err = dx + dy
            x, y = x1, y1
            while True:
                for ox in range(-(width // 2), width // 2 + 1):
                    for oy in range(-(width // 2), width // 2 + 1):
                        put(x + ox, y + oy, color)
                if x == x2 and y == y2:
                    break
                e2 = 2 * err
                if e2 >= dy:
                    err += dy
                    x += sx
                if e2 <= dx:
                    err += dx
                    y += sy

        def thin_line(x1: int, y1: int, x2: int, y2: int, color):
            line(x1, y1, x2, y2, color, 1)

        def icon_line(x1: int, y1: int, x2: int, y2: int, color):
            thin_line(x1, y1, x2, y2, color)
            if y1 == y2:
                thin_line(x1, y1 + 1, x2, y2 + 1, color)
            elif x1 == x2:
                thin_line(x1 + 1, y1, x2 + 1, y2, color)
            else:
                thin_line(x1 + 1, y1, x2 + 1, y2, color)

        def medium_line(x1: int, y1: int, x2: int, y2: int, color):
            icon_line(x1, y1, x2, y2, color)

        def rect(x1: int, y1: int, x2: int, y2: int, color, fill=True):
            if fill:
                for y in range(y1, y2 + 1):
                    for x in range(x1, x2 + 1):
                        put(x, y, color)
            else:
                line(x1, y1, x2, y1, color)
                line(x2, y1, x2, y2, color)
                line(x2, y2, x1, y2, color)
                line(x1, y2, x1, y1, color)

        def circle(cx: int, cy: int, radius: int, color, fill=True):
            r2 = radius * radius
            for y in range(cy - radius, cy + radius + 1):
                for x in range(cx - radius, cx + radius + 1):
                    d2 = (x - cx) ** 2 + (y - cy) ** 2
                    if (fill and d2 <= r2) or (not fill and r2 - radius <= d2 <= r2 + radius):
                        put(x, y, color)

        blue = (9, 79, 166)
        light_blue = (126, 196, 255)
        green = (15, 124, 70)
        orange = (92, 64, 23)
        red = (145, 39, 35)
        purple = (77, 50, 150)
        gray = (55, 65, 81)
        yellow = (255, 205, 49)
        black = (15, 23, 42)

        # subtle frame, similar to old Windows toolbar icons
        rect(1, 1, size - 2, size - 2, (211, 218, 226), fill=False)

        if kind.startswith("zoom"):
            circle(8, 8, 5, light_blue, fill=True)
            circle(8, 8, 5, blue, fill=False)
            line(12, 12, 18, 18, black, 2)
            if kind == "zoom_out":
                medium_line(5, 8, 11, 8, black)
            elif kind == "zoom_in":
                medium_line(5, 8, 11, 8, black)
                medium_line(8, 5, 8, 11, black)
            else:
                icon_line(5, 8, 11, 8, green)
                icon_line(14, 5, 18, 5, green)
                icon_line(18, 5, 18, 9, green)
                icon_line(18, 5, 15, 8, green)
        elif kind.startswith("height"):
            rect(5, 3, 17, 18, (250, 252, 255), fill=True)
            rect(5, 3, 17, 18, purple, fill=False)
            if kind == "height_in":
                thin_line(11, 5, 11, 16, gray)
                icon_line(11, 5, 11, 9, red)
                icon_line(8, 6, 11, 9, red)
                icon_line(14, 6, 11, 9, red)
                icon_line(11, 17, 11, 13, red)
                icon_line(8, 16, 11, 13, red)
                icon_line(14, 16, 11, 13, red)
                thin_line(7, 11, 15, 11, black)
            elif kind == "height_out":
                thin_line(11, 5, 11, 16, gray)
                icon_line(11, 9, 11, 5, green)
                icon_line(8, 8, 11, 5, green)
                icon_line(14, 8, 11, 5, green)
                icon_line(11, 13, 11, 17, green)
                icon_line(8, 14, 11, 17, green)
                icon_line(14, 14, 11, 17, green)
                thin_line(7, 11, 15, 11, black)
                thin_line(11, 7, 11, 15, black)
            else:
                icon_line(7, 11, 15, 11, blue)
                icon_line(15, 7, 15, 11, blue)
        elif kind.startswith("rows"):
            for y in (5, 9, 13, 17):
                thin_line(4, y, 17, y, green)
            if kind == "rows_in":
                thin_line(10, 4, 10, 18, orange)
                icon_line(7, 8, 10, 5, orange)
                icon_line(13, 8, 10, 5, orange)
                icon_line(7, 14, 10, 17, orange)
                icon_line(13, 14, 10, 17, orange)
            elif kind == "rows_out":
                thin_line(10, 4, 10, 18, blue)
                icon_line(7, 5, 10, 8, blue)
                icon_line(13, 5, 10, 8, blue)
                icon_line(7, 17, 10, 14, blue)
                icon_line(13, 17, 10, 14, blue)
            else:
                icon_line(14, 4, 18, 4, blue)
                icon_line(18, 4, 18, 8, blue)
                icon_line(18, 4, 15, 7, blue)
        elif kind.startswith("width"):
            rect(2, 5, 19, 16, (246, 251, 255), fill=True)
            rect(2, 5, 19, 16, blue, fill=False)
            if kind == "width_in":
                icon_line(4, 11, 9, 11, orange)
                icon_line(6, 9, 9, 11, orange)
                icon_line(6, 13, 9, 11, orange)
                icon_line(17, 11, 12, 11, orange)
                icon_line(15, 9, 12, 11, orange)
                icon_line(15, 13, 12, 11, orange)
                icon_line(8, 3, 14, 3, red)
            elif kind == "width_out":
                icon_line(10, 11, 5, 11, orange)
                icon_line(5, 11, 8, 9, orange)
                icon_line(5, 11, 8, 13, orange)
                icon_line(12, 11, 17, 11, orange)
                icon_line(17, 11, 14, 9, orange)
                icon_line(17, 11, 14, 13, orange)
                icon_line(8, 3, 14, 3, green)
                icon_line(11, 1, 11, 6, green)
            else:
                icon_line(5, 11, 17, 11, orange)
                icon_line(5, 11, 8, 9, orange)
                icon_line(5, 11, 8, 13, orange)
                icon_line(17, 11, 14, 9, orange)
                icon_line(17, 11, 14, 13, orange)
                icon_line(14, 3, 18, 3, blue)
                icon_line(18, 3, 18, 7, blue)
        elif kind == "page":
            rect(5, 3, 15, 17, (255, 255, 255), fill=True)
            rect(5, 3, 15, 17, blue, fill=False)
            thin_line(8, 8, 13, 8, gray)
            thin_line(8, 11, 13, 11, gray)
            icon_line(10, 13, 10, 19, green)
            icon_line(7, 16, 10, 19, green)
            icon_line(13, 16, 10, 19, green)
        elif kind in ("right", "left", "up", "down"):
            color = blue
            if kind == "right":
                rect(3, 5, 18, 16, (246, 251, 255), fill=True)
                rect(3, 5, 18, 16, blue, fill=False)
                icon_line(6, 11, 15, 11, color)
                icon_line(12, 8, 15, 11, color)
                icon_line(12, 14, 15, 11, color)
            elif kind == "left":
                rect(3, 5, 18, 16, (246, 251, 255), fill=True)
                rect(3, 5, 18, 16, blue, fill=False)
                icon_line(15, 11, 6, 11, color)
                icon_line(9, 8, 6, 11, color)
                icon_line(9, 14, 6, 11, color)
            elif kind == "up":
                icon_line(11, 18, 11, 5, color)
                icon_line(7, 9, 11, 5, color)
                icon_line(15, 9, 11, 5, color)
            else:
                icon_line(11, 5, 11, 18, color)
                icon_line(7, 14, 11, 18, color)
                icon_line(15, 14, 11, 18, color)
        elif kind in ("next", "previous"):
            color = green
            if kind == "next":
                rect(3, 4, 16, 17, (229, 245, 230), fill=True)
                icon_line(6, 11, 15, 11, color)
                icon_line(11, 7, 15, 11, color)
                icon_line(11, 15, 15, 11, color)
            else:
                rect(5, 4, 18, 17, (229, 245, 230), fill=True)
                icon_line(16, 11, 7, 11, color)
                icon_line(11, 7, 7, 11, color)
                icon_line(11, 15, 7, 11, color)
        else:
            circle(11, 11, 5, yellow, fill=True)
            circle(11, 11, 5, black, fill=False)

        out = bytearray()
        for y in range(size):
            for x in range(size):
                r = g = b = count = 0
                for yy in range(y * aa, (y + 1) * aa):
                    for xx in range(x * aa, (x + 1) * aa):
                        pr, pg, pb = data[yy * hi_size + xx]
                        r += pr
                        g += pg
                        b += pb
                        count += 1
                out.extend((r // count, g // count, b // count))
        rgb = bytes(out)
        return self.rgb_photo_image(size, size, rgb)

    def open_print_preview(self, width: int, height: int, rgb: bytes):
        win = tk.Toplevel(self.root)
        win.title("תצוגה לפני הדפסה")
        win.transient(self.root)
        self.prepare_child_window(win, 720, 760)
        win.geometry("760x820")
        frame = ttk.Frame(win, padding=8)
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(1, weight=1)
        frame.columnconfigure(0, weight=1)
        border_var = tk.IntVar(value=2)
        ttk.Label(
            frame,
            text="כך תיראה ההדפסה ביחס לדף. ההדפסה תישלח רק לאחר אישור.",
            style="Compact.TLabel",
            anchor="e",
            justify="right",
        ).grid(row=0, column=0, sticky="ew", pady=(0, 6))
        preview_canvas = tk.Canvas(frame, bg="#eeeeee", highlightthickness=0)
        preview_canvas.grid(row=1, column=0, sticky="nsew")
        buttons = ttk.Frame(frame)
        buttons.grid(row=2, column=0, sticky="ew", pady=(7, 0))
        buttons.columnconfigure(0, weight=1)
        border_box = ttk.Frame(buttons)
        border_box.pack(side="left", padx=(0, 8))
        ttk.Label(border_box, text="מסגרת", style="Compact.TLabel").pack(side="right", padx=(0, 4))
        for text, value in (("בלי", 0), ("1 מ״מ", 1), ("2 מ״מ", 2)):
            ttk.Radiobutton(border_box, text=text, value=value, variable=border_var, command=lambda: win.after_idle(draw_preview)).pack(side="right", padx=1)

        page_ratio = (842.0 / 595.0) if width > height else (595.0 / 842.0)

        def draw_preview(_event=None):
            preview_canvas.delete("all")
            canvas_w = max(1, preview_canvas.winfo_width())
            canvas_h = max(1, preview_canvas.winfo_height())
            page_h_px = min(canvas_h - 28, int((canvas_w - 28) / page_ratio))
            page_w_px = int(page_h_px * page_ratio)
            if page_w_px > canvas_w - 28:
                page_w_px = canvas_w - 28
                page_h_px = int(page_w_px / page_ratio)
            page_w_px = max(80, page_w_px)
            page_h_px = max(120, page_h_px)
            page_x = (canvas_w - page_w_px) // 2
            page_y = (canvas_h - page_h_px) // 2
            preview_canvas.create_rectangle(page_x + 4, page_y + 4, page_x + page_w_px + 4, page_y + page_h_px + 4, fill="#d0d0d0", outline="")
            preview_canvas.create_rectangle(page_x, page_y, page_x + page_w_px, page_y + page_h_px, fill="#ffffff", outline="#000000", width=1)
            margin_px = max(12, int(page_w_px * (28.0 / (842.0 if width > height else 595.0))))
            draw_w_limit = max(1, page_w_px - margin_px * 2)
            draw_h_limit = max(1, page_h_px - margin_px * 2)
            scaled_w, scaled_h, scaled_rgb = self.scaled_rgb_for_preview(width, height, rgb, draw_w_limit, draw_h_limit)
            photo = self.rgb_photo_image(scaled_w, scaled_h, scaled_rgb)
            preview_canvas.preview_photo = photo
            img_x = page_x + (page_w_px - scaled_w) // 2
            img_y = page_y + (page_h_px - scaled_h) // 2
            preview_canvas.create_image(img_x, img_y, anchor="nw", image=photo)
            border_mm = max(0, int(border_var.get() or 0))
            if border_mm:
                mm_to_px = page_w_px / (842.0 if width > height else 595.0) * 72.0 / 25.4
                line_px = max(1, int(round(border_mm * mm_to_px)))
                preview_canvas.create_rectangle(
                    img_x - line_px // 2,
                    img_y - line_px // 2,
                    img_x + scaled_w + line_px // 2,
                    img_y + scaled_h + line_px // 2,
                    outline="#000000",
                    width=line_px,
                )

        def confirm_print():
            path = os.path.join(tempfile.gettempdir(), f"gal_einai_print_{int(time.time())}.pdf")
            try:
                self.save_pdf_image(path, width, height, rgb, border_mm=border_var.get())
                os.startfile(path, "print")
                self.status.set("נשלחה תצוגה להדפסה לאחר אישור")
                win.destroy()
            except Exception as e:
                rtl_showinfo("הדפסה", f"התצוגה הוכנה להדפסה בקובץ זמני, אך Windows לא הדפיס אוטומטית:\n{path}\n\n{e}")

        ttk.Button(buttons, text="אישור הדפסה", command=confirm_print).pack(side="right", padx=3)
        ttk.Button(buttons, text="סגור", command=win.destroy).pack(side="right", padx=3)
        preview_canvas.bind("<Configure>", draw_preview)
        win.after(100, draw_preview)

    def print_header_text(self) -> str:
        match = getattr(self, "current_display_match", None)
        if match is None and self.saved and 0 <= self.current < len(self.saved):
            match = self.saved[self.current][0]
        skip_value = abs(match.skip or 1) if match is not None else abs(self.current_display_skip_value())
        skip_text = f"טבלה בדילוג: {skip_value}"
        spp_text = self.model.spp_at(match.start) if match is not None else "-"
        return f"{APP_VERSION} | {skip_text} | ספ״פ: {spp_text}"

    def create_export_context_words_bar(self, parent, width: int):
        groups = self.visible_context_word_groups()
        if not groups:
            return None
        bar = tk.Frame(parent, bg="#fff3cd", bd=0, highlightthickness=0)
        rows = [groups]
        if len(groups) > 1:
            approx_widths = [max(68, len(self.format_context_word_group(group)) * 9 + 18) for group in groups]
            if sum(approx_widths) > max(260, int(width or 0)):
                split = min(
                    range(1, len(groups)),
                    key=lambda index: max(sum(approx_widths[:index]), sum(approx_widths[index:])),
                )
                rows = [groups[:split], groups[split:]]
        for row_groups in rows:
            row = tk.Frame(bar, bg="#fff3cd", bd=0, highlightthickness=0)
            row.pack(side="top", fill="x", pady=(1, 0))
            inner = tk.Frame(row, bg="#fff3cd", bd=0, highlightthickness=0)
            inner.pack(anchor="center")
            for group in row_groups:
                match = group["match"]
                color = group.get("color") or stable_word_color(group.get("word", match.word))
                fg = readable_text_on_bg(color, "#111111")
                text = self.format_context_word_group(group)
                tk.Label(
                    inner,
                    text=rtl_display(text),
                    bg=color,
                    fg=fg,
                    bd=1,
                    relief="solid",
                    padx=5,
                    pady=1,
                    font=("Arial", 9, "bold"),
                ).pack(side="right", padx=2, pady=1)
        return bar

    def capture_display_pixels_for_export(self, print_mode: bool = False):
        header = tk.Label(
            self.display,
            text=rtl_display(self.print_header_text()),
            anchor="center",
            justify="center",
            bg="#fff3cd",
            fg="#3d2b00",
            padx=8,
            pady=3,
            font=("Arial", 11, "bold"),
            wraplength=max(300, self.display.winfo_width() - 20),
        )
        controls = getattr(self, "display_controls", None)
        controls_was_visible = bool(controls and controls.winfo_manager())
        status_bar = getattr(self, "display_status_bar", None)
        status_was_visible = bool(status_bar and status_bar.winfo_manager())
        context_words = getattr(self, "context_words_container", None)
        context_words_was_visible = bool(context_words and context_words.winfo_manager())
        export_words_bar = None
        export_logo = None
        old_highlight = {}
        canvas_widget = getattr(getattr(self, "canvas", None), "canvas", None)
        try:
            if print_mode and controls_was_visible:
                controls.pack_forget()
            if print_mode and status_was_visible:
                status_bar.pack_forget()
            if print_mode and context_words is not None:
                context_words.pack_forget()
            if print_mode and canvas_widget is not None:
                try:
                    old_highlight = {
                        "highlightthickness": canvas_widget.cget("highlightthickness"),
                        "highlightbackground": canvas_widget.cget("highlightbackground"),
                        "highlightcolor": canvas_widget.cget("highlightcolor"),
                    }
                    canvas_widget.configure(highlightthickness=1, highlightbackground="#000000", highlightcolor="#000000")
                except Exception:
                    old_highlight = {}
            self.root.update_idletasks()
            right_edge = self.print_canvas_right_edge_in_display() if print_mode else None
            right_gap = max(0, self.display.winfo_width() - right_edge) if right_edge is not None else 0
            header.pack(
                side="top",
                fill="x",
                padx=(0, right_gap),
                pady=(0, 1),
                before=self.canvas,
            )
            self.root.update_idletasks()
            if print_mode:
                export_words_bar = self.create_export_context_words_bar(self.display, right_edge or self.display.winfo_width())
                if export_words_bar is not None:
                    export_words_bar.pack(
                        side="top",
                        fill="x",
                        padx=(0, right_gap),
                        pady=(0, 1),
                        before=self.canvas,
                    )
                self.root.update_idletasks()
                export_logo = tk.Label(
                    self.display,
                    text=rtl_display("גל עיני"),
                    bg="#fffdf6",
                    fg="#073f33",
                    bd=1,
                    relief="solid",
                    padx=7,
                    pady=2,
                    font=("Arial", 10, "bold"),
                )
                export_logo.place(x=8, y=8, anchor="nw")
                export_logo.lift()
                self.root.update_idletasks()
            width, height, bgr, rgb, stride = self.capture_widget_pixels(self.display)
            if print_mode:
                right_edge = self.print_canvas_right_edge_in_display()
                if right_edge is not None and right_edge < width:
                    width, height, bgr, rgb, stride = self.crop_capture_pixels(width, height, bgr, rgb, stride, 0, right_edge)
            return width, height, bgr, rgb, stride
        finally:
            try:
                if export_words_bar is not None:
                    export_words_bar.destroy()
                if export_logo is not None:
                    export_logo.destroy()
                header.destroy()
                if print_mode and canvas_widget is not None and old_highlight:
                    canvas_widget.configure(**old_highlight)
                if print_mode and status_was_visible and status_bar is not None and not status_bar.winfo_manager():
                    status_bar.pack(side="top", fill="x", pady=(0, 1), before=self.canvas)
                if print_mode and context_words is not None:
                    if context_words_was_visible and not context_words.winfo_manager():
                        context_words.pack(side="top", anchor="w", padx=0, pady=(0, 1), before=self.canvas)
                    elif not context_words_was_visible and context_words.winfo_manager():
                        context_words.pack_forget()
                if print_mode and controls_was_visible and controls is not None and not controls.winfo_manager():
                    controls.pack(side="bottom", fill="x", pady=(0, 0), before=self.canvas)
                self.root.update_idletasks()
            except Exception:
                pass

    def export_current_view(self) -> Optional[str]:
        path = filedialog.asksaveasfilename(
            title="שמור תצוגה PNG או PDF",
            defaultextension=".png",
            filetypes=[("PNG Image", "*.png"), ("PDF", "*.pdf"), ("All", "*.*")],
        )
        if not path:
            return None
        root, ext = os.path.splitext(path)
        if ext.lower() not in (".png", ".pdf"):
            path = root + ".png"
            ext = ".png"
        try:
            width, height, _bgr, rgb, _stride = self.capture_display_pixels_for_export(print_mode=True)
            if ext.lower() == ".pdf":
                self.save_pdf_image(path, width, height, rgb, border_mm=2.0)
            else:
                width, height, rgb = self.add_rgb_border(width, height, rgb, border_mm=2.0)
                self.save_png_image(path, width, height, rgb)
        except Exception as e:
            rtl_showerror("שמירת תצוגה", f"לא הצלחתי לשמור את התצוגה:\n{e}")
            return None
        self.status.set(f"נשמרה תצוגה: {os.path.basename(path)}")
        return path

    def print_current_view(self):
        if os.name != "nt":
            rtl_showinfo("הדפסה", "הדפסה ישירה זמינה כרגע ב-Windows בלבד.")
            return
        try:
            width, height, _bgr, rgb, _stride = self.capture_display_pixels_for_export(print_mode=True)
        except Exception as e:
            rtl_showerror("הדפסה", f"לא הצלחתי להכין את התצוגה להדפסה:\n{e}")
            return
        self.open_print_preview(width, height, rgb)
        self.status.set("נפתחה תצוגה לפני הדפסה")

    def create_desktop_shortcut(self):
        self.create_app_shortcuts()

    def create_app_shortcuts(self):
        if os.name != "nt":
            rtl_showinfo("קיצורי דרך", "יצירת קיצורי דרך אוטומטית זמינה כרגע ב-Windows בלבד.")
            return
        base = app_dir()
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        if not os.path.isdir(desktop):
            desktop = os.path.join(os.path.expanduser("~"), "שולחן עבודה")
        launcher = app_asset_path("פתח_גל_עיני.pyw")
        if not os.path.exists(launcher):
            launcher = app_asset_path("v340.py")
        python_exe = sys.executable if os.path.exists(sys.executable) else launcher
        shortcut_args = f'"{launcher}"' if python_exe != launcher else ""
        icon = app_asset_path(APP_ICON_ICO)
        start_menu = os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs")
        taskbar = os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Internet Explorer", "Quick Launch", "User Pinned", "TaskBar")
        shortcuts = []
        if os.path.isdir(desktop):
            shortcuts.append(os.path.join(desktop, "Gal Einai.lnk"))
        if os.path.isdir(start_menu):
            shortcuts.append(os.path.join(start_menu, "Gal Einai.lnk"))
        if os.path.isdir(taskbar):
            shortcuts.append(os.path.join(taskbar, "Gal Einai.lnk"))
        if not shortcuts:
            rtl_showerror("קיצורי דרך", "לא הצלחתי למצוא תיקייה מתאימה ליצירת קיצורי דרך.")
            return
        ps = r"""
$ErrorActionPreference = 'Stop'
$ws = New-Object -ComObject WScript.Shell
$rawTargets = [Environment]::GetEnvironmentVariable('GE_SHORTCUTS')
$targetPath = [Environment]::GetEnvironmentVariable('GE_TARGET')
$arguments = [Environment]::GetEnvironmentVariable('GE_ARGUMENTS')
$workDir = [Environment]::GetEnvironmentVariable('GE_WORKDIR')
$iconPath = [Environment]::GetEnvironmentVariable('GE_ICON')

if (-not $rawTargets) { throw 'לא נמצאו יעדים לקיצורי הדרך.' }
if (-not $targetPath -or -not (Test-Path -LiteralPath $targetPath)) { throw "קובץ ההפעלה לא נמצא: $targetPath" }
if (-not $workDir -or -not (Test-Path -LiteralPath $workDir)) { throw "תיקיית העבודה לא נמצאה: $workDir" }

$targets = $rawTargets -split [char]31
foreach ($target in $targets) {
    if (-not $target -or -not $target.Trim()) { continue }
    $target = [Environment]::ExpandEnvironmentVariables($target.Trim())
    $parent = Split-Path -Parent $target
    if ($parent -and -not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }
    $shortcut = $ws.CreateShortcut($target)
    $shortcut.TargetPath = $targetPath
    if ($arguments) {
        $shortcut.Arguments = $arguments
    }
    $shortcut.WorkingDirectory = $workDir
    $shortcut.Description = 'גל עיני - תוכנה לחיפוש צפנים בתורה'
    if ($iconPath -and (Test-Path -LiteralPath $iconPath)) {
        $shortcut.IconLocation = $iconPath
    }
    $shortcut.Save()
}
"""
        encoded_ps = base64.b64encode(ps.encode("utf-16le")).decode("ascii")
        env = os.environ.copy()
        env.update({
            "GE_SHORTCUTS": chr(31).join(shortcuts),
            "GE_TARGET": python_exe,
            "GE_ARGUMENTS": shortcut_args,
            "GE_WORKDIR": base,
            "GE_ICON": icon,
        })
        try:
            startupinfo = None
            if os.name == "nt":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = 0
            subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded_ps],
                check=True,
                env=env,
                cwd=base,
                capture_output=True,
                text=True,
                startupinfo=startupinfo,
            )
            made = "\n".join(f"- {path}" for path in shortcuts)
            self.status.set("נוצרו קיצורי דרך לגל עיני")
            rtl_showinfo(
                "קיצורי דרך",
                "נוצרו קיצורי דרך לגל עיני עם האייקון הקבוע:\n\n"
                f"{made}\n\n"
                "אם Windows לא מצמיד אוטומטית לשורת המשימות, פתח את התוכנה מהקיצור ואז לחץ לחיצה ימנית על האייקון בשורת המשימות ובחר 'הצמד לשורת המשימות'."
            )
        except subprocess.CalledProcessError as e:
            detail = "\n".join(
                part.strip()
                for part in (e.stderr or "", e.stdout or "", str(e))
                if part and part.strip()
            )
            rtl_showerror("קיצורי דרך", f"לא הצלחתי ליצור קיצורי דרך:\n{detail}")
        except Exception as e:
            rtl_showerror("קיצורי דרך", f"לא הצלחתי ליצור קיצורי דרך:\n{e}")

    def open_options_table(self):
        win = tk.Toplevel(self.root)
        win.title("אפשרויות תצוגה")
        win.transient(self.root)
        self.prepare_child_window(win, 360, 520)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        ttk.Label(frame, text="אפשרויות תצוגה וסימון", font=("Arial", 11, "bold")).grid(row=0, column=0, sticky="e", pady=(0, 8))
        ttk.Checkbutton(frame, text="מסגרת סביב סימונים", variable=self.opt_mark_borders, command=self.apply_display_options).grid(row=1, column=0, sticky="e", pady=3)
        ttk.Checkbutton(frame, text="הצגת ספ״פ בצד הטבלה", variable=self.opt_spp_labels, command=self.apply_display_options).grid(row=2, column=0, sticky="e", pady=3)
        ttk.Checkbutton(frame, text="מילה שחור / מילה כחול", variable=self.opt_word_colors, command=self.apply_display_options).grid(row=3, column=0, sticky="e", pady=3)
        ttk.Checkbutton(frame, text="רווחים בין מילים", variable=self.opt_word_spaces, command=self.apply_display_options).grid(row=4, column=0, sticky="e", pady=3)
        ttk.Checkbutton(frame, text="פרקי אבות בשורה נעה", variable=self.opt_avot_ticker, command=self.apply_display_options).grid(row=5, column=0, sticky="e", pady=3)
        avot_settings_frame = ttk.Frame(frame)
        avot_settings_frame.grid(row=6, column=0, sticky="e", pady=3)
        avot_order_row = ttk.Frame(avot_settings_frame)
        avot_order_row.pack(anchor="e", fill="x", pady=(0, 4))
        ttk.Label(avot_order_row, text="סדר המשניות:").pack(side="right", padx=(6, 0))
        ttk.Radiobutton(
            avot_order_row,
            text="לפי הסדר",
            variable=self.avot_ticker_order_var,
            value="ordered",
            command=self.on_avot_ticker_order_changed,
        ).pack(side="right")
        ttk.Radiobutton(
            avot_order_row,
            text="אקראי",
            variable=self.avot_ticker_order_var,
            value="random",
            command=self.on_avot_ticker_order_changed,
        ).pack(side="right", padx=(0, 6))
        avot_speed_row = ttk.Frame(avot_settings_frame)
        avot_speed_row.pack(anchor="e", fill="x")
        ttk.Label(avot_speed_row, text="קצב אבות:").pack(side="right", padx=(6, 0))
        avot_speed_spin = ttk.Spinbox(
            avot_speed_row,
            from_=1,
            to=10,
            width=4,
            textvariable=self.avot_ticker_speed_var,
            command=self.on_avot_ticker_speed_changed,
            justify="center",
        )
        avot_speed_spin.pack(side="right")
        ttk.Label(avot_speed_row, text="1 איטי — 10 מהיר").pack(side="right", padx=(0, 6))
        avot_speed_spin.bind("<KeyRelease>", lambda _event: self.on_avot_ticker_speed_changed())
        add_tooltip(avot_speed_spin, "מהירות תנועת פרקי אבות. ברירת המחדל היא קצב קריאה איטי; עמידת העכבר על השורה עוצרת.")
        font_frame = ttk.LabelFrame(frame, text="כתב תצוגה", padding=6)
        font_frame.grid(row=8, column=0, sticky="ew", pady=(6, 0))
        ttk.Radiobutton(font_frame, text="כתב רגיל", variable=self.font_mode_var, value="regular", command=self.apply_display_options).pack(anchor="e")
        ttk.Radiobutton(font_frame, text="אשורי אשכנז", variable=self.font_mode_var, value="ashkenaz", command=self.apply_display_options).pack(anchor="e")
        ttk.Radiobutton(font_frame, text="אשורי ספרדי", variable=self.font_mode_var, value="sefarad", command=self.apply_display_options).pack(anchor="e")
        ttk.Label(frame, textvariable=self.font_mode_label_var, anchor="e", justify="right").grid(row=9, column=0, sticky="e", pady=(4, 0))
        ttk.Label(frame, text=self.canvas.bundled_font_status() if hasattr(self, "canvas") else "", anchor="e", justify="right").grid(row=10, column=0, sticky="e", pady=(2, 0))
        cursor_frame = ttk.LabelFrame(frame, text="סמן עכבר על התצוגה", padding=6)
        cursor_frame.grid(row=10, column=0, sticky="ew", pady=(6, 0))
        ttk.Radiobutton(cursor_frame, text="אצבע כסף של ס״ת", variable=self.cursor_mode_var, value="yad", command=self.apply_display_options).pack(anchor="e")
        ttk.Radiobutton(cursor_frame, text="חץ רגיל", variable=self.cursor_mode_var, value="arrow", command=self.apply_display_options).pack(anchor="e")
        ttk.Button(frame, text="סגור", command=win.destroy).grid(row=11, column=0, sticky="ew", pady=(10, 0))
        add_tooltip(frame, "כאן מרוכזות אפשרויות התצוגה, הכתב והסמן כדי שלא יהיו כפילויות בתפריטים.")

    def open_general_info(self, initial_tab: str = "search"):
        if initial_tab in ("credits", "copyright"):
            self.open_credits_rights_window()
            return
        win = tk.Toplevel(self.root)
        win.title("עזרה ומידע")
        win.transient(self.root)
        self.prepare_child_window(win, 720, 520)
        win.geometry("900x650")
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        notebook = ttk.Notebook(frame, style="Right.TNotebook")
        notebook.grid(row=0, column=0, sticky="nsew")
        info_texts = []
        tabs_by_key = {}

        def add_rtl_tab(tab, text: str):
            notebook.add(tab, text=rtl_display(text))

        info_search_tab = ttk.Frame(notebook, padding=10)
        add_rtl_tab(info_search_tab, "חיפוש בעזרה")
        tabs_by_key["search"] = info_search_tab
        search_row = ttk.Frame(info_search_tab)
        search_row.pack(fill="x", pady=(0, 8))
        search_var = tk.StringVar()
        search_status = tk.StringVar(value="הקלד מילת חיפוש בתוך דפי העזרה והמידע")
        ttk.Label(search_row, text="חיפוש בעזרה:", font=("Arial", 10, "bold")).pack(side="right", padx=(0, 6))
        search_entry = FixedHebrewField(search_row, textvariable=search_var, height=1, width=32, font=("Arial", 11))
        search_entry.pack(side="right", fill="x", expand=True)
        search_btn = ttk.Button(search_row, text="חפש", width=7, command=lambda: search_info())
        search_btn.pack(side="right", padx=(0, 6))
        search_status_label = ttk.Label(info_search_tab, textvariable=search_status, anchor="e", justify="right")
        search_status_label.pack(fill="x", pady=(6, 0))
        full_doc_text = self.load_info_document()
        doc_status = "החיפוש כולל גם את קובץ ההסבר המלא." if full_doc_text else "קובץ ההסבר המלא לא נמצא; החיפוש עובד על התקציר הפנימי."
        ttk.Label(
            info_search_tab,
            text=f"החיפוש כאן מיועד למציאת מושגים בתוך דפי העזרה והמידע בלבד.\n{doc_status}",
            anchor="e",
            justify="right",
            wraplength=430,
            font=("Arial", 10),
        ).pack(fill="x", pady=(8, 0))

        def add_info_text(parent, text, *, bold_first_line=False, font_size=11, title_size=12, font_weight="normal", expand=True, height=9):
            text_frame = ttk.Frame(parent)
            text_frame.pack(fill="both" if expand else "x", expand=expand)
            box = tk.Text(
                text_frame,
                width=58,
                height=height,
                wrap="word",
                font=("Arial", font_size, font_weight),
                padx=8,
                pady=8,
                relief="flat",
                bg="#fbfbf8",
            )
            scroll = ttk.Scrollbar(text_frame, orient="vertical", command=box.yview)
            box.configure(yscrollcommand=scroll.set)
            scroll.pack(side="left", fill="y")
            box.pack(side="right", fill="both", expand=True)
            box.tag_configure("body", justify="right", lmargin1=4, lmargin2=4, rmargin=8)
            box.tag_configure("hit", background="#fff2a8", foreground="#111111")
            box.tag_configure("title", font=("Arial", title_size, "bold"))
            box.insert("1.0", rtl_display(text))
            box.tag_add("body", "1.0", "end")
            if bold_first_line:
                box.tag_add("title", "1.0", "1.end")
            box.configure(state="disabled")
            info_texts.append((parent, box))
            return box

        def clear_info_hits():
            for _, box in info_texts:
                box.configure(state="normal")
                box.tag_remove("hit", "1.0", "end")
                box.configure(state="disabled")

        def search_info(*_):
            needle = search_var.get().strip()
            clear_info_hits()
            if not needle:
                search_status.set("הקלד מילת חיפוש בתוך דפי העזרה והמידע")
                return
            total = 0
            first_tab = None
            active_tabs = set(notebook.tabs())
            for tab, box in info_texts:
                if str(tab) not in active_tabs:
                    continue
                box.configure(state="normal")
                start = "1.0"
                while True:
                    pos = box.search(needle, start, stopindex="end", nocase=True)
                    if not pos:
                        break
                    end = f"{pos}+{len(needle)}c"
                    box.tag_add("hit", pos, end)
                    if first_tab is None:
                        first_tab = tab
                        box.see(pos)
                    total += 1
                    start = end
                box.configure(state="disabled")
            if first_tab is not None:
                notebook.select(first_tab)
            search_status.set(f"נמצאו {total} מופעים" if total else "לא נמצאו מופעים")

        search_var.trace_add("write", search_info)

        usage_tab = ttk.Frame(notebook, padding=10)
        add_rtl_tab(usage_tab, "תפעול מיטבי")
        tabs_by_key["usage"] = usage_tab
        usage_text = (
            "דרך עבודה מומלצת:\n"
            "1. הזן מילה ראשית וטווח דילוגים סביר.\n"
            "2. הוסף מילים משניות בשדה המשניות, מופרדות ברווח.\n"
            "3. לחץ חפש, ואז פתח צופן מהרשימה לפי מספר המשניות.\n"
            "4. אם רוצים להגביל פעולה לתצוגה הנוכחית, סמן רק במסך הנוכחי לפני הסריקה.\n"
            "5. לאחר פתיחת צופן, השתמש בסרוק בכל הראשיות כדי לבדוק את המשניות שכבר הוזנו בכל אזורי הראשיות שנמצאו, בלי לחפש את הראשיות מחדש.\n"
            "6. אפשר להמשיך בסריקה, חצי/שליש/רבע, מפגשים, מקבץ, עמודות, שנה או תאריכים להוספת ממצאים.\n"
            "7. הממצאים נשארים מסומנים עד ניקוי יזום; גם עצירת חיפוש אוטומטי אינה מוחקת את מה שכבר נמצא.\n\n"
            "תוספות אחרונות בתצוגה ובעבודה:\n"
            "סריקת משניות סביב צופן משתמשת בחלון חיפוש רחב, כאילו התצוגה הורחקה בזום שלילי עד כמה שאפשר, כדי לתפוס מילים שנמצאות בסביבה אך אינן נראות בזום הנוכחי.\n"
            "לחיצה ארוכה על חצי המקלדת מזיזה את התורה ברציפות ומרעננת את התצוגה תוך כדי לחיצה, ולא רק לאחר עזיבת החץ.\n"
            "תפריט קליק ימני נוקה מכפילויות בפעולות הסרת סימונים, כדי שהפעולות יהיו ברורות יותר.\n\n"
            "סימון, מסגרות וקווים:\n"
            "פס המילים העליון מציג את המילים שנמצאו בצופן. כפתור 'שלח קווים' מותח קווים מהמילים למעלה אל כל הממצאים המתאימים בתצוגה; כאשר כבר יש קווים הכפתור מתחלף ל'הסר קווים'.\n"
            "כפתור 'נקה קווים' מסיר את כל הקווים שנשלחו מהמילים העליונות אל הממצאים.\n"
            "קליק ימני על ממצא מאפשר להוסיף מסגרת לכל אות מהממצא עצמו, בלי לצבוע מחדש את הממצא. אותה פעולה מאפשרת גם להסיר את המסגרת.\n\n"
            "המלצה חשובה:\n"
            "לא כדאי לכתוב בשדות החיפוש מילים בנות פחות מ-4 אותיות, מפני שהן מצויות הרבה בתורה ועלולות ליצור עומס וממצאים אקראיים שאינם מעידים על צופן אמיתי.\n"
            "אפשר להשתמש במילים קצרות רק כאשר הן באות בצירוף ממצאים קשורים נוספים, למשל שנה יחד עם התשפו.\n\n"
            "שדות שננעלים לפי מצב:\n"
            "במצב טקסט, הדילוג המדויק נקבע ל-1 ושדות הטווח אינם פעילים.\n"
            "במצב טקסט+דילוג, הראשית היא טקסט רגיל והמשניות נבדקות לפי טווח הדילוגים; לכן דילוג מדויק אינו פעיל.\n"
            "במפגשים, מינימום המשניות עולה ל-1 אם היה 0, מפני שהמשנית המסומנת בכוכבית היא תנאי חובה.\n"
            "אם טווח הדילוגים גדול מדי, התוכנה מחלקת אותו אוטומטית לכמה חלקים ונשארת בתוך הטווח שהוגדר.\n"
            "המשך מעבר לטווח פעיל רק כאשר סומנה הבחירה לכך, אין דילוג מדויק, ויש רצון להמשיך מעבר לטווח שהוגדר.\n\n"
            "מושגים שימושיים לחיפוש בעזרה:\n"
            "ראשית - המילה העיקרית שעליה נבנית טבלת הצופן.\n"
            "משניות - מילים נוספות שנבדקות סביב הראשית או בתוך הטבלה.\n"
            "מילים קצרות - פחות מ-4 אותיות בדרך כלל אינן מומלצות לחיפוש עצמאי, מפני שהן נפוצות ועלולות להופיע באקראי.\n"
            "מינימום משניות - כמה משניות חייבות להימצא כדי לשמור צופן; אפשר לסמן כולן כדי לדרוש את כל המשניות.\n"
            "סיכוי - מדד משוער בלבד שמראה עד כמה תנאי המשניות מחמיר לפי מספר המילים הנדרש.\n"
            "חיפוש מורחב - אם לא נמצא צופן בתנאים המבוקשים, התוכנה מנסה עד 5 משניות ארוכות כראשיות חלופיות. פעולה זו יכולה להימשך זמן ממושך.\n"
            "דילוג - המרחק בין אות לאות בממצא. בטבלה ובכותרות מוצג מספר הדילוג בלבד.\n"
            "דילוג חי - משנה את תצוגת הטבלה מיד, גם בלי להריץ חיפוש מחדש.\n"
            "צופן - חיפוש ראשית בטווח הדילוגים יחד עם משניות ותנאי צופן.\n"
            "רגיל - חיפוש המילה הראשית בלבד בכל הדילוגים שנקבעו בשדה הטווח.\n"
            "חיפוש טקסט - חיפוש רצף אותיות בתורה בדילוג 1, בלי טווח דילוגים.\n"
            "טקסט+דילוג - הראשית תחופש כרצף טקסט, והמשניות יחופשו במסך שלה בכל דילוגי הטווח.\n"
            "סריקה - חיפוש מילים בתוך הטבלה המוצגת, בלי למחוק סימונים קיימים.\n"
            "סריקת משניות רחבה - בדיקת המשניות סביב צופן לפי שטח רחב כאילו התצוגה בזום שלילי מרבי, בלי לשנות בפועל את הזום שעל המסך.\n"
            "גם כטקסט - תיבת סימון ליד ראשית/משניות. כאשר היא מסומנת, מילה שנכתבה בשדה ומופיעה כרצף טקסט רגיל במסך הצופן תסומן גם כממצא.\n"
            "חלוקת טווח - כאשר הטווח גדול מדי, התוכנה מחלקת אותו לכמה חלקים וממשיכה ביניהם בלי לחרוג מהטווח שבחרת.\n"
            "מעבר לטווח - בחירה מפורשת שמרשה להמשיך לטווחים גדולים יותר ממה שהוגדר, תוך צבירת ממצאים וכל עוד הזיכרון במצב תקין.\n"
            "חצי, שליש ורבע - חיפוש נוסף בדילוגים מחולקים סביב ממצא קיים.\n"
            "מפגשים - חיפוש חיתוך ממשי בין הראשית לבין המשנית שסומנה בכוכבית, למשל *משיח. שאר המשניות נבדקות כמו בחיפוש צופן רגיל.\n"
            "מקבץ 10x10 - חיפוש נפרד של קירבה בין מילים בתוך אזור 10 על 10.\n"
            "תאריכים - סריקה ייעודית של יום, חודש ושנה עברית במסך הנוכחי.\n"
            "רצועת תצוגה תחתונה - ממצא קודם/הבא, גלילה, רוחב וזום.\n"
            "חצי מקלדת - מאפשרים תזוזה רציפה של התורה בזמן לחיצה ארוכה, כולל ימינה/שמאלה.\n"
            "פס מילים עליון - מציג את מילות הממצא בצבעיהן, מאפשר מרכז ממצא, תפריט קליק ימני ושליחת קווים לכל הממצאים.\n"
            "מסגרת לאותיות ממצא - קליק ימני על ממצא > הוסף מסגרת, יוצר מסגרת סביב כל אות של אותו ממצא בלי לשנות את צבע המילוי.\n"
            "כלים > אפשרויות תצוגה וסמן - פותח חלון אחד שבו מרוכזות אפשרויות צבע, מסגרות, רווחים, פונטים, סמן עכבר ופרקי אבות בשורה נעה.\n"
            "סימן שאלה - ? בתוך מילה משמש כאות לא ידועה."
        )
        add_info_text(usage_tab, usage_text, bold_first_line=True)

        search_tab = ttk.Frame(notebook, padding=10)
        add_rtl_tab(search_tab, "כלי חיפוש צפנים")
        tabs_by_key["tools"] = search_tab
        search_text = (
            "כלי עזר יעיל לחיפוש צפנים, מילים, מפגשים ותאריכים בתורה\n"
            "אפשר לבצע חיפוש צופן עם משניות, חיפוש רגיל של הראשית בכל טווח הדילוגים, חיפוש טקסט בדילוג 1, או טקסט+דילוג.\n"
            "מומלץ להעדיף מילים של 4 אותיות ומעלה בשדות החיפוש. מילים קצרות מדי מצויות מאוד, מכבידות על החיפוש ועלולות להיראות כממצא אקראי, אלא אם הן מצטרפות לממצאים קשורים נוספים כגון שנה והתשפו.\n"
            "במצב טקסט+דילוג הראשית היא רצף אותיות רגיל, והמשניות נבדקות במסך הראשית לפי טווח הדילוגים.\n"
            "במצב טקסט התוכנה קובעת דילוג 1 ונועלת את שדות הטווח. במצב טקסט+דילוג הדילוג המדויק ננעל כדי שהמשניות יעבדו לפי הטווח.\n"
            "במצב צופן אפשר להוסיף מילים משניות ולסרוק את הטבלה לאחר מציאת צופן.\n"
            "סריקת המשניות סביב צופן נעשית לפי שטח רחב כאילו התצוגה הורחקה לזום שלילי מרבי, כדי למצוא גם מילים שנמצאות בסביבה אך אינן נראות בזום הנוכחי.\n"
            "תיבות 'גם כטקסט' ליד ראשית ומשניות גורמות למילים שבשדות להסתמן גם אם נמצאו כרצף טקסט רגיל בתוך מסך הצופן.\n"
            "אפשר לסמן 'כולן' ליד מינימום משניות כדי לדרוש שכל המשניות יימצאו, או להשאיר מספר רגיל למינימום חלקי.\n"
            "הסיכוי המוצג ליד המינימום הוא הערכה שימושית בלבד, כדי להבין אם תנאי החיפוש מחמיר מאוד.\n"
            "חיפוש מורחב מנסה משניות ארוכות כראשיות חלופיות כאשר לא נמצא צופן שעומד בתנאים המבוקשים.\n"
            "כאשר הטווח גדול מדי, התוכנה מחלקת אותו לחלקים ומודיעה על כך. מעבר מעבר לטווח שהוגדר נעשה רק אם סומנה הבחירה 'מעבר לטווח'.\n"
            "המילים שנמצאו נשארות מסומנות עד ניקוי יזום, כדי לאפשר הוספת חיפושים על גבי אותו ממצא.\n"
            "כפתור חלון הטקסט פותח טקסט רציף נפרד סביב הממצא, בלי להזיז את הצופן בתצוגה הראשית.\n"
            "פס המילים העליון מאפשר לשלוח קווים לכל הממצאים בצופן, והכפתור מתחלף להסרת הקווים כאשר קיימים קווים פעילים.\n"
            "קליק ימני על ממצא מאפשר להוסיף או להסיר מסגרת סביב כל אות מהממצא, בלי לצבוע את הממצא מחדש.\n"
            "סימן ? בתוך מילה משמש כתו חופשי במקום אות לא ידועה.\n"
            "אפשרויות מראה כגון כתב רגיל/אשורי, צבעי מילים, רווחים, סמן אצבע כסף/חץ ופרקי אבות בשורה נעה מרוכזות בחלון אפשרויות התצוגה.\n"
            "חצי המקלדת מזיזים את התורה ברציפות בלחיצה ארוכה; קליק ימני על ממצא כולל פעולות צבע, מסגרת, קווים והסרה ללא כפילויות מיותרות.\n"
            "טאב חיפוש בעזרה מיועד למציאת נושא או הוראה בתוך דפי העזרה והמידע.\n\n"
            "אפשר לחפש לדוגמה: דילוג, ראשית, משניות, סריקה, זום, חצים, קווים, מסגרת, תאריכים, מפגשים, מקבץ, סימון, צבע, ניקוי, גרף, זכויות, מייל.\n"
            "כאשר נמצא מושג, התוכנה מדגישה אותו בצהוב ועוברת לטאב המתאים."
        )
        add_info_text(search_tab, search_text, bold_first_line=True)

        credits_tab = ttk.Frame(notebook, padding=10)
        add_rtl_tab(credits_tab, "קרדיטים")
        tabs_by_key["credits"] = credits_tab
        credits_text = (
            "קרדיטים\n"
            "התוכנה פותחה בהשראת בעידוד ובברכת הרה\"ג יקותיאל פיש שליט\"א, ראש קו סוד החשמל.\n"
            "מס׳ הקו: 026647979\n\n"
            "התוכנה פותחה ע\"י נריה דויטש על פי שיטתו ובהכוונתו.\n"
            "בסיוע הרב אריאל עדי הי\"ו.\n\n"
            "תודה לכל המסייעים, המעירים והבודקים בדרך לשיפור התוכנה."
        )
        credits_box = add_info_text(
            credits_tab,
            credits_text,
            bold_first_line=True,
            font_size=12,
            title_size=14,
            font_weight="bold",
            expand=False,
            height=8,
        )

        if full_doc_text:
            full_doc_tab = ttk.Frame(notebook, padding=10)
            add_rtl_tab(full_doc_tab, "הסבר מלא")
            tabs_by_key["full_doc"] = full_doc_tab
            add_info_text(full_doc_tab, full_doc_text, bold_first_line=True)

        copyright_tab = ttk.Frame(notebook, padding=10)
        add_rtl_tab(copyright_tab, "זכויות יוצרים")
        tabs_by_key["copyright"] = copyright_tab
        copyright_text = (
            "אין להעתיק או לשכפל את קבצי התוכנה בלי רשות מהבעלים.\n\n"
            "הטקסט והכלים נועדו לעיון ולחקירה זהירה בלבד."
        )
        copyright_box = add_info_text(copyright_tab, copyright_text, bold_first_line=True)
        contact_label = ttk.Label(
            copyright_tab,
            text="צור קשר: neriyado20@gmail.com",
            justify="right",
            anchor="e",
            wraplength=430,
            font=("Arial", 10, "bold"),
        )
        contact_label.pack(fill="x", pady=(8, 0))
        add_tooltip(search_entry, "חיפוש מהיר בתוך הוראות העזרה, התפעול והמידע.")
        add_tooltip(search_btn, "מריץ חיפוש בתוך דפי העזרה והמידע.")
        add_tooltip(search_tab, "מידע קצר על כלי חיפוש הצפנים בתוכנה ועל סימן השאלה כתו חופשי.")
        add_tooltip(credits_box, "התוכנה פותחה בהשראת בעידוד ובברכת הרה\"ג יקותיאל פיש שליט\"א. התוכנה פותחה ע\"י נריה דויטש על פי שיטתו ובהכוונתו.")
        add_tooltip(copyright_box, "הבעלים: נריה דויטש | neriyado20@gmail.com")
        add_tooltip(contact_label, "צור קשר: נריה דויטש | neriyado20@gmail.com")

        help_tab_keys = ("search", "usage", "tools", "full_doc")
        info_tab_keys = ("credits", "copyright")
        if initial_tab in info_tab_keys:
            win.title("מידע")
            for key in help_tab_keys:
                if key in tabs_by_key:
                    notebook.forget(tabs_by_key[key])
        else:
            win.title("עזרה")
            for key in info_tab_keys:
                if key in tabs_by_key:
                    notebook.forget(tabs_by_key[key])

        ttk.Button(frame, text="סגור", command=win.destroy).grid(row=1, column=0, sticky="ew", pady=(10, 0))
        add_tooltip(notebook, "עזרה להתמצאות בתוכנה, או מידע כללי לפי התפריט שנפתח.")
        active_tabs = set(notebook.tabs())
        requested_tab = tabs_by_key.get(initial_tab, info_search_tab)
        if str(requested_tab) not in active_tabs:
            requested_tab = notebook.tabs()[0] if notebook.tabs() else info_search_tab
        notebook.select(requested_tab)
        if initial_tab not in info_tab_keys:
            search_entry.focus_set()
            search_entry.icursor("end")
            search_entry.return_command = search_info

    def open_credits_rights_window(self):
        win = tk.Toplevel(self.root)
        win.title("קרדיטים וזכויות")
        win.transient(self.root)
        apply_window_icon(win)
        win.resizable(True, True)
        frame = ttk.Frame(win, padding=12)
        frame.pack(fill="both", expand=True)
        notebook = ttk.Notebook(frame, style="Right.TNotebook")
        notebook.pack(fill="both", expand=True)

        def add_compact_text_tab(title: str, text: str, height: int):
            tab = ttk.Frame(notebook, padding=8)
            notebook.add(tab, text=rtl_display(title))
            box = tk.Text(
                tab,
                width=54,
                height=height,
                wrap="word",
                font=("Arial", 11, "bold"),
                padx=10,
                pady=10,
                relief="flat",
                bg="#fbfbf8",
            )
            box.pack(fill="both", expand=True)
            box.tag_configure("body", justify="right", lmargin1=6, lmargin2=6, rmargin=10)
            box.tag_configure("title", font=("Arial", 13, "bold"))
            box.insert("1.0", rtl_display(text))
            box.tag_add("body", "1.0", "end")
            box.tag_add("title", "1.0", "1.end")
            box.configure(state="disabled")
            return box

        credits_box = add_compact_text_tab(
            "קרדיטים",
            (
            "קרדיטים\n\n"
            "התוכנה פותחה בהשראת בעידוד ובברכת הרה\"ג יקותיאל פיש שליט\"א, ראש קו סוד החשמל.\n"
            "מס׳ הקו: 026647979\n\n"
            "התוכנה פותחה ע\"י נריה דויטש על פי שיטתו ובהכוונתו.\n"
            "בסיוע הרב אריאל עדי הי\"ו.\n\n"
            "תודה לכל המסייעים, המעירים והבודקים בדרך לשיפור התוכנה."
            ),
            8,
        )
        rights_box = add_compact_text_tab(
            "זכויות יוצרים",
            (
            "זכויות יוצרים\n\n"
            "אין להעתיק או לשכפל את קבצי התוכנה בלי רשות מהבעלים.\n\n"
            "הטקסט והכלים נועדו לעיון ולחקירה זהירה בלבד.\n\n"
            "צור קשר: neriyado20@gmail.com"
            ),
            6,
        )
        ttk.Button(frame, text="סגור", command=win.destroy).pack(fill="x", pady=(10, 0))
        add_tooltip(credits_box, "קרדיטים למפתח, להכוונה ולמסייעים.")
        add_tooltip(rights_box, "זכויות יוצרים ופרטי קשר.")
        self.root.update_idletasks()
        win.update_idletasks()
        req_w = max(430, min(620, win.winfo_reqwidth() + 8))
        req_h = max(285, min(390, win.winfo_reqheight() + 8))
        x = self.root.winfo_x() + max(20, (self.root.winfo_width() - req_w) // 2)
        y = self.root.winfo_y() + max(20, (self.root.winfo_height() - req_h) // 2)
        win.geometry(f"{req_w}x{req_h}+{x}+{y}")
        win.minsize(430, 285)
        win.focus_set()

    def open_skip_technical_doc(self):
        text = self.load_text_document(SKIP_TECH_DOC_FILE) or "המסמך הטכני לא נמצא."
        self.open_text_document_window("מסמך טכני על דילוגים", text, initial_size="920x700")

    def open_text_document_window(self, title: str, text: str, initial_size: str = "860x620"):
        win = tk.Toplevel(self.root)
        win.title(title)
        win.transient(self.root)
        self.prepare_child_window(win, 640, 420)
        win.geometry(initial_size)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        box = tk.Text(frame, wrap="word", font=("Arial", 11), padx=10, pady=10, bg="#fbfbf8", relief="flat")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=box.yview)
        box.configure(yscrollcommand=scroll.set)
        scroll.grid(row=0, column=0, sticky="nse")
        box.grid(row=0, column=1, sticky="nsew")
        frame.columnconfigure(1, weight=1)
        box.tag_configure("body", justify="right", lmargin1=6, lmargin2=6, rmargin=10)
        box.insert("1.0", rtl_display(text))
        box.tag_add("body", "1.0", "end")
        box.configure(state="disabled")
        ttk.Button(frame, text="סגור", command=win.destroy).grid(row=1, column=0, columnspan=2, sticky="ew", pady=(10, 0))

    def load_text_document(self, filename: str) -> str:
        candidates = [
            os.path.join(os.path.dirname(os.path.abspath(__file__)), filename),
            os.path.join(os.getcwd(), filename),
        ]
        for path in candidates:
            if not os.path.exists(path):
                continue
            try:
                text = TorahLoader.read_file(path).strip()
                if text:
                    return text
            except Exception:
                continue
        return ""

    def load_info_document(self) -> str:
        return self.load_text_document(INFO_DOC_FILE)

    def apply_display_options(self):
        if not hasattr(self, "canvas"):
            return
        self.canvas.show_mark_borders = self.opt_mark_borders.get()
        self.canvas.show_spp_labels = self.opt_spp_labels.get()
        self.canvas.alternate_word_colors = self.opt_word_colors.get()
        self.canvas.show_word_spaces = self.opt_word_spaces.get()
        self.canvas.set_font_mode(self.font_mode_var.get() if hasattr(self, "font_mode_var") else "regular")
        if hasattr(self, "cursor_mode_var"):
            self.canvas.set_cursor_mode(self.cursor_mode_var.get())
        self.update_avot_ticker_visibility()
        self.update_font_mode_label()
        self.canvas.render()
        self.save_app_settings()
        self.status.set(f"אפשרויות התצוגה עודכנו | {self.canvas.alternate_font_label()}")

    def update_avot_ticker_visibility(self):
        if not hasattr(self, "avot_ticker_frame"):
            return
        if self.opt_avot_ticker.get():
            if not self.avot_ticker_frame.winfo_ismapped():
                self.avot_ticker_frame.grid(row=1, column=1, sticky="ew", padx=4)
            self.update_avot_ticker_text(force=True)
            self.schedule_avot_ticker()
        else:
            self.avot_ticker_frame.grid_remove()
            self.avot_ticker_canvas.delete("ticker")
            self.avot_ticker_item = None
            self.avot_ticker_groups = []
            if self.avot_ticker_after:
                try:
                    self.root.after_cancel(self.avot_ticker_after)
                except Exception:
                    pass
                self.avot_ticker_after = None

    def avot_ticker_speed(self) -> int:
        try:
            speed = int(self.avot_ticker_speed_var.get())
        except Exception:
            speed = 4
        speed = max(1, min(10, speed))
        try:
            current = int(self.avot_ticker_speed_var.get())
        except Exception:
            current = None
        if current != speed:
            try:
                self.avot_ticker_speed_var.set(speed)
            except Exception:
                pass
        return speed

    def create_avot_ticker_group(self, index: int):
        canvas = self.avot_ticker_canvas
        self.avot_ticker_group_serial += 1
        tag = f"ticker_group_{self.avot_ticker_group_serial}"
        text = " ".join(str(AVOT_TICKER_LINES[index % len(AVOT_TICKER_LINES)]).split())
        words = text.split()
        font = tkfont.Font(family="Arial", size=10)
        cursor_x = 0
        items = []
        space_width = max(4, font.measure(" "))
        for word in words:
            item = canvas.create_text(
                cursor_x,
                13,
                text=rtl_display(word),
                anchor="e",
                fill="#493b18",
                font=font,
                tags=("ticker", tag),
            )
            items.append(item)
            cursor_x -= max(1, font.measure(word)) + space_width
        group = {"tag": tag, "items": tuple(items), "index": index, "spawned_next": False}
        self.avot_ticker_groups.append(group)
        self.avot_ticker_item = group["items"]
        return group

    def show_avot_ticker_window(self):
        if not hasattr(self, "avot_ticker_canvas") or not AVOT_TICKER_LINES:
            return
        canvas = self.avot_ticker_canvas
        canvas.delete("ticker")
        canvas.update_idletasks()
        self.avot_ticker_groups = []
        self.create_avot_ticker_group(self.avot_ticker_index)
        self.avot_ticker_x = 0.0

    def update_avot_ticker_text(self, force: bool = False):
        if not hasattr(self, "avot_ticker_canvas") or not AVOT_TICKER_LINES:
            return
        if not self.opt_avot_ticker.get():
            return
        if not force and (self.search_is_running() or self.scan_is_running()):
            return
        self.show_avot_ticker_window()

    def advance_avot_ticker_caption(self):
        if not AVOT_TICKER_LINES:
            return
        if self.avot_ticker_paused or self.search_is_running() or self.scan_is_running():
            return
        if not hasattr(self, "avot_ticker_canvas") or not self.avot_ticker_groups:
            self.show_avot_ticker_window()
            return
        if not self.avot_ticker_paused:
            delta = 0.45 + self.avot_ticker_speed() * 0.22
            self.avot_ticker_x += delta
            self.avot_ticker_canvas.move("ticker", delta, 0)
        canvas_width = max(1, self.avot_ticker_canvas.winfo_width())
        gap_width = tkfont.Font(family="Arial", size=10).measure("א" * 15)
        for group in list(self.avot_ticker_groups):
            bbox = self.avot_ticker_canvas.bbox(group["tag"])
            if not bbox:
                self.avot_ticker_groups.remove(group)
                continue
            if not group["spawned_next"] and bbox[0] >= gap_width:
                group["spawned_next"] = True
                self.avot_ticker_index = self.next_avot_ticker_index(group["index"])
                self.create_avot_ticker_group(self.avot_ticker_index)
            if bbox[0] > canvas_width:
                self.avot_ticker_canvas.delete(group["tag"])
                if group in self.avot_ticker_groups:
                    self.avot_ticker_groups.remove(group)

    def step_avot_ticker(self, direction: int):
        if not AVOT_TICKER_LINES:
            return
        self.avot_ticker_index = (self.avot_ticker_index + direction) % len(AVOT_TICKER_LINES)
        self.show_avot_ticker_window()
        self.schedule_avot_ticker()

    def pause_avot_ticker(self, _event=None):
        self.avot_ticker_paused = True

    def pointer_inside_avot_ticker(self) -> bool:
        if not hasattr(self, "avot_ticker_frame"):
            return False
        try:
            widget = self.root.winfo_containing(self.root.winfo_pointerx(), self.root.winfo_pointery())
            while widget is not None:
                if widget == self.avot_ticker_frame:
                    return True
                widget = widget.master
        except Exception:
            pass
        return False

    def resume_avot_ticker(self, _event=None):
        if self.pointer_inside_avot_ticker():
            return
        self.avot_ticker_paused = False
        self.schedule_avot_ticker()

    def on_avot_ticker_speed_changed(self):
        self.save_app_settings()
        self.schedule_avot_ticker()

    def on_avot_ticker_order_changed(self):
        if self.avot_ticker_order_var.get() not in ("ordered", "random"):
            self.avot_ticker_order_var.set("ordered")
        self.save_app_settings()

    def next_avot_ticker_index(self, current_index: int) -> int:
        line_count = len(AVOT_TICKER_LINES)
        if line_count <= 1:
            return 0
        if self.avot_ticker_order_var.get() == "random":
            next_index = random.randrange(line_count - 1)
            if next_index >= current_index:
                next_index += 1
            return next_index
        return (current_index + 1) % line_count

    def schedule_avot_ticker(self):
        if not hasattr(self, "root"):
            return
        if self.avot_ticker_after:
            try:
                self.root.after_cancel(self.avot_ticker_after)
            except Exception:
                pass
        if hasattr(self, "opt_avot_ticker") and not self.opt_avot_ticker.get():
            self.avot_ticker_after = None
            return
        self.avot_ticker_after = self.root.after(40, self.rotate_avot_ticker)

    def rotate_avot_ticker(self):
        self.avot_ticker_after = None
        self.advance_avot_ticker_caption()
        self.schedule_avot_ticker()

    def update_font_mode_label(self):
        if not hasattr(self, "font_mode_label_var"):
            return
        if hasattr(self, "canvas"):
            label = self.canvas.alternate_font_label()
        else:
            label = "כתב תצוגה נוסף"
        self.font_mode_label_var.set(label)

    def load_app_settings(self) -> dict:
        try:
            if not os.path.exists(APP_SETTINGS_FILE):
                return {}
            with open(APP_SETTINGS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def save_app_settings(self):
        try:
            window_state = self.root.state() if hasattr(self, "root") else "normal"
            is_fullscreen = False
            try:
                is_fullscreen = bool(self.root.attributes("-fullscreen")) if hasattr(self, "root") else False
            except tk.TclError:
                is_fullscreen = False
            previous_geometry = getattr(self, "last_normal_geometry", None) or (
                self.settings_state.get("window_geometry", DEFAULT_WINDOW_GEOMETRY) if hasattr(self, "settings_state") else DEFAULT_WINDOW_GEOMETRY
            )
            current_geometry = self.root.geometry() if hasattr(self, "root") else previous_geometry
            if window_state == "normal" and not is_fullscreen:
                previous_geometry = current_geometry
            data = {
                "mark_borders": bool(self.opt_mark_borders.get()) if hasattr(self, "opt_mark_borders") else True,
                "spp_labels": bool(self.opt_spp_labels.get()) if hasattr(self, "opt_spp_labels") else True,
                "word_colors": bool(self.opt_word_colors.get()) if hasattr(self, "opt_word_colors") else True,
                "word_spaces": bool(self.opt_word_spaces.get()) if hasattr(self, "opt_word_spaces") else False,
                "avot_ticker": bool(self.opt_avot_ticker.get()) if hasattr(self, "opt_avot_ticker") else True,
                "avot_ticker_speed": self.avot_ticker_speed() if hasattr(self, "avot_ticker_speed_var") else 4,
                "avot_ticker_order": self.avot_ticker_order_var.get() if hasattr(self, "avot_ticker_order_var") else "ordered",
                "start_maximized": bool(self.opt_start_maximized.get()) if hasattr(self, "opt_start_maximized") else False,
                "font_mode": self.font_mode_var.get() if hasattr(self, "font_mode_var") else "regular",
                "cursor_mode": self.cursor_mode_var.get() if hasattr(self, "cursor_mode_var") else "yad",
                "date_fraction_fallback": bool(self.opt_date_fraction_fallback.get()) if hasattr(self, "opt_date_fraction_fallback") else True,
                "include_av_dates": bool(self.opt_include_av_dates.get()) if hasattr(self, "opt_include_av_dates") else False,
                "auto_advance_skip": bool(self.opt_auto_advance_skip.get()) if hasattr(self, "opt_auto_advance_skip") else False,
                "extend_beyond_skip_range": bool(self.opt_auto_advance_skip.get()) if hasattr(self, "opt_auto_advance_skip") else False,
                "primary_text_mark": bool(self.opt_primary_text_mark.get()) if hasattr(self, "opt_primary_text_mark") else True,
                "secondary_text_mark": bool(self.opt_secondary_text_mark.get()) if hasattr(self, "opt_secondary_text_mark") else True,
                "try_long_secondary_primary": bool(self.opt_try_long_secondary_primary.get()) if hasattr(self, "opt_try_long_secondary_primary") else False,
                "min_secondary_all": bool(self.opt_min_secondary_all.get()) if hasattr(self, "opt_min_secondary_all") else False,
                "minimal_search": bool(self.opt_minimal_search.get()) if hasattr(self, "opt_minimal_search") else False,
                "current_view_only": bool(self.opt_current_view_only.get()) if hasattr(self, "opt_current_view_only") else False,
                "results_height": int(getattr(self, "results_height", 8)),
                "results_panel_height": int(getattr(self, "results_panel_height", 280)),
                "results_visible": bool(getattr(self, "results_visible", False)),
                "recent_search_limit": int(getattr(self, "recent_search_limit", 20)),
                "recent_searches": list(getattr(self, "recent_searches", []) or [])[:max(1, int(getattr(self, "recent_search_limit", 20)))],
                "side_visible": bool(getattr(self, "side_visible", True)),
                "bottom_controls_visible": bool(getattr(self, "bottom_controls_visible", True)),
                "display_skip": self.live_skip.get().strip() if hasattr(self, "live_skip") else "",
                "hide_startup_quick_start": bool(self.settings_state.get("hide_startup_quick_start", False)) if hasattr(self, "settings_state") else False,
                "openai_api_key": str(getattr(self, "openai_api_key", "") or "") if bool(self.settings_state.get("save_openai_api_key", False)) else "",
                "save_openai_api_key": bool(self.settings_state.get("save_openai_api_key", False)) if hasattr(self, "settings_state") else False,
                "window_zoomed": window_state == "zoomed",
                "window_fullscreen": is_fullscreen,
                "window_geometry": previous_geometry,
            }
            if hasattr(self, "settings_state"):
                self.settings_state.update(data)
            with open(APP_SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def remember_normal_window_geometry(self, _event=None):
        try:
            if not hasattr(self, "root"):
                return
            if self.root.state() != "normal":
                return
            try:
                if bool(self.root.attributes("-fullscreen")):
                    return
            except tk.TclError:
                pass
            geometry = self.root.geometry()
            if re.match(r"^\d+x\d+[+-]\d+[+-]\d+$", geometry):
                self.last_normal_geometry = geometry
        except Exception:
            pass

    def apply_saved_window_state(self):
        self.root.resizable(True, True)
        self.root.minsize(MIN_WINDOW_WIDTH, MIN_WINDOW_HEIGHT)
        geometry = str(self.settings_state.get("window_geometry", DEFAULT_WINDOW_GEOMETRY)).strip()
        if geometry:
            try:
                self.root.geometry(geometry)
            except tk.TclError:
                self.root.geometry(DEFAULT_WINDOW_GEOMETRY)
        should_fullscreen = bool(self.settings_state.get("window_fullscreen", False))
        should_zoom = True
        if should_fullscreen:
            self.root.after(80, lambda: self.root.attributes("-fullscreen", True))
        elif should_zoom:
            self.root.after(80, self.zoom_main_window)

    def zoom_main_window(self):
        try:
            self.root.state("zoomed")
        except tk.TclError:
            try:
                self.root.attributes("-zoomed", True)
            except tk.TclError:
                pass

    def on_close(self):
        self.save_app_settings()
        self.root.destroy()

    def initial_live_skip_value(self) -> str:
        value = str(self.settings_state.get("display_skip", "")).strip() if hasattr(self, "settings_state") else ""
        try:
            skip = int(value)
            if skip != 0:
                return str(abs(skip))
        except ValueError:
            pass
        return "40"

    def reset_live_skip_to_default(self):
        if hasattr(self, "live_skip"):
            self.set_live_skip_display(self.initial_live_skip_value())

    def project_to_dict(self) -> dict:
        saved_items = []
        current_index = 0
        if getattr(self, "saved", None):
            idx = max(0, min(int(getattr(self, "current", 0) or 0), len(self.saved) - 1))
            pm, local = self.saved[idx]
            saved_items = [{
                "primary": match_to_dict(pm),
                "matches": [match_to_dict(m) for m in local],
            }]
        return {
            "version": 1,
            "primary": self.get_primary_word() if hasattr(self, "primary_var") else "",
            "secondary": self.secondary_var.get() if hasattr(self, "secondary_var") else "",
            "exact_skip": self.exact_skip.get() if hasattr(self, "exact_skip") else "",
            "live_skip": self.live_skip.get() if hasattr(self, "live_skip") else "",
            "skip_from": self.skip_from.get() if hasattr(self, "skip_from") else 0,
            "skip_to": self.skip_to.get() if hasattr(self, "skip_to") else 800,
            "min_secondary": self.min_secondary.get() if hasattr(self, "min_secondary") else 0,
            "mode": self.mode.get() if hasattr(self, "mode") else "code",
            "current": current_index,
            "options": {
                "mark_borders": self.opt_mark_borders.get(),
                "spp_labels": self.opt_spp_labels.get(),
                "word_colors": self.opt_word_colors.get(),
                "word_spaces": self.opt_word_spaces.get(),
                "avot_ticker": self.opt_avot_ticker.get(),
                "avot_ticker_speed": self.avot_ticker_speed() if hasattr(self, "avot_ticker_speed_var") else 4,
                "avot_ticker_order": self.avot_ticker_order_var.get() if hasattr(self, "avot_ticker_order_var") else "ordered",
                "font_mode": self.font_mode_var.get(),
                "cursor_mode": self.cursor_mode_var.get(),
                "date_fraction_fallback": self.opt_date_fraction_fallback.get(),
                "auto_advance_skip": self.opt_auto_advance_skip.get(),
                "extend_beyond_skip_range": self.opt_auto_advance_skip.get(),
                "primary_text_mark": self.opt_primary_text_mark.get(),
                "secondary_text_mark": self.opt_secondary_text_mark.get(),
                "try_long_secondary_primary": self.opt_try_long_secondary_primary.get(),
                "min_secondary_all": self.opt_min_secondary_all.get(),
                "minimal_search": self.opt_minimal_search.get(),
                "current_view_only": self.opt_current_view_only.get(),
                "results_height": self.results_height,
                "results_panel_height": self.results_panel_height,
                "side_visible": self.side_visible,
            },
            "saved": saved_items,
            "manual_marks": [match_to_dict(m) for m in getattr(self.canvas, "manual_marks", [])] if hasattr(self, "canvas") else [],
        }

    def app_state_snapshot(self) -> dict:
        canvas_state = {}
        if hasattr(self, "canvas"):
            canvas_state = {
                "font_size": getattr(self.canvas, "font_size", 23),
                "cell_w": getattr(self.canvas, "cell_w", 22),
                "cell_h": getattr(self.canvas, "cell_h", 28),
                "cols": getattr(self.canvas, "cols", 46),
                "rows": getattr(self.canvas, "rows", 24),
                "view_cols_extra": getattr(self.canvas, "view_cols_extra", 0),
                "view_rows_extra": getattr(self.canvas, "view_rows_extra", 0),
                "view_col_offset": getattr(self.canvas, "view_col_offset", 0),
                "linear_start": getattr(self.canvas, "linear_start", 0),
                "skip_view_anchor": getattr(self.canvas, "skip_view_anchor", 0),
                "view_mode": getattr(self.canvas, "view_mode", "linear"),
                "selected_positions": list(getattr(self.canvas, "selected_positions", []) or []),
                "top_connector_lines": [
                    {"x": item.get("x", 0), "match": match_to_dict(item.get("match"))}
                    for item in getattr(self.canvas, "top_connector_lines", []) or []
                    if item.get("match") is not None
                ],
                "hidden_match_frames": [
                    list(item[:-1]) + [list(item[-1])]
                    for item in sorted(getattr(self.canvas, "hidden_match_frames", set()) or set(), key=repr)
                    if isinstance(item, tuple) and item
                ],
            }
        return {
            "primary": self.get_primary_word() if hasattr(self, "primary_var") else "",
            "secondary": self.secondary_var.get() if hasattr(self, "secondary_var") else "",
            "exact_skip": self.exact_skip.get() if hasattr(self, "exact_skip") else "",
            "live_skip": self.live_skip.get() if hasattr(self, "live_skip") else "",
            "skip_from": self.skip_from.get() if hasattr(self, "skip_from") else 0,
            "skip_to": self.skip_to.get() if hasattr(self, "skip_to") else 800,
            "min_secondary": self.min_secondary.get() if hasattr(self, "min_secondary") else 0,
            "mode": self.mode.get() if hasattr(self, "mode") else "code",
            "current": self.current,
            "results_mode": self.results_mode,
            "saved": [
                {
                    "primary": match_to_dict(pm),
                    "matches": [match_to_dict(m) for m in local],
                }
                for pm, local in getattr(self, "saved", [])
            ],
            "manual_marks": [match_to_dict(m) for m in getattr(self.canvas, "manual_marks", [])] if hasattr(self, "canvas") else [],
            "canvas": canvas_state,
        }

    def push_app_undo_snapshot(self, label: str, snapshot: dict):
        if not snapshot:
            return
        if self.app_undo_stack and self.app_undo_stack[-1] == snapshot:
            return
        self.app_undo_stack.append(snapshot)
        self.app_undo_labels.append(label or "פעולה בתוכנה")
        if len(self.app_undo_stack) > self.max_app_history:
            self.app_undo_stack.pop(0)
            if self.app_undo_labels:
                self.app_undo_labels.pop(0)
        self.app_redo_stack.clear()
        self.app_redo_labels.clear()

    def push_app_undo_state(self, label: str = "פעולה בתוכנה"):
        snapshot = self.app_state_snapshot()
        self.push_app_undo_snapshot(label, snapshot)
        self.auto_undo_last_snapshot = self.app_state_snapshot()

    def install_auto_undo_watchers(self):
        watched = [
            ("primary_var", "שינוי ראשית"),
            ("secondary_var", "שינוי משניות"),
            ("exact_skip", "שינוי דילוג יחיד"),
            ("live_skip", "שינוי דילוג חי"),
            ("skip_from", "שינוי תחילת טווח"),
            ("skip_to", "שינוי סוף טווח"),
            ("min_secondary", "שינוי מינימום משניות"),
            ("mode", "שינוי מצב חיפוש"),
            ("opt_min_secondary_all", "שינוי כולן"),
            ("opt_current_view_only", "שינוי רק במסך הנוכחי"),
            ("opt_minimal_search", "שינוי מינימלי"),
            ("opt_auto_advance_skip", "שינוי טווח מורחב"),
            ("opt_try_long_secondary_primary", "שינוי חיפוש מורחב"),
            ("opt_primary_text_mark", "שינוי ראשית כטקסט"),
            ("opt_secondary_text_mark", "שינוי משניות כטקסט"),
            ("selection_mode", "שינוי סימון ידני"),
        ]
        self.auto_undo_trace_ids = []
        self.auto_undo_last_snapshot = self.app_state_snapshot()
        self.auto_undo_ready = True
        for attr, label in watched:
            var = getattr(self, attr, None)
            if hasattr(var, "trace_add"):
                trace_id = var.trace_add("write", lambda *_args, action_label=label: self.on_auto_undo_variable_change(action_label))
                self.auto_undo_trace_ids.append((var, trace_id))

    def on_auto_undo_variable_change(self, label: str):
        if not getattr(self, "auto_undo_ready", False) or getattr(self, "restoring_app_state", False):
            return
        previous = getattr(self, "auto_undo_last_snapshot", None)
        current = self.app_state_snapshot()
        if previous is not None and previous != current:
            self.push_app_undo_snapshot(label, previous)
        self.auto_undo_last_snapshot = current

    def restore_app_state(self, snapshot: dict):
        self.restoring_app_state = True
        try:
            if hasattr(self, "primary_var"):
                self.primary_var.set(str(snapshot.get("primary", "")))
            if hasattr(self, "secondary_var"):
                self.secondary_var.set(str(snapshot.get("secondary", "")))
            if hasattr(self, "exact_skip"):
                self.exact_skip.set(str(snapshot.get("exact_skip", "")))
            if hasattr(self, "live_skip"):
                self.live_skip.set(str(snapshot.get("live_skip", "")))
            if hasattr(self, "skip_from"):
                self.skip_from.set(str(snapshot.get("skip_from", 0)))
            if hasattr(self, "skip_to"):
                self.skip_to.set(str(snapshot.get("skip_to", 800)))
            if hasattr(self, "min_secondary"):
                self.min_secondary.set(str(snapshot.get("min_secondary", 0)))
            if hasattr(self, "mode"):
                mode_value = str(snapshot.get("mode", "code") or "code")
                if mode_value:
                    self.mode.set(mode_value)
            saved = []
            for item in snapshot.get("saved", []) or []:
                primary = match_from_dict(item.get("primary", {}))
                matches = [match_from_dict(m) for m in item.get("matches", []) or []]
                if primary:
                    saved.append((primary, [m for m in matches if m]))
            self.saved = saved
            self.current = max(0, min(int(snapshot.get("current", 0) or 0), max(0, len(self.saved) - 1)))
            if hasattr(self, "canvas"):
                self.canvas.manual_marks = [m for m in (match_from_dict(raw) for raw in snapshot.get("manual_marks", []) or []) if m]
                canvas_state = snapshot.get("canvas", {}) or {}
                for attr in ("font_size", "cell_w", "cell_h", "cols", "rows", "view_cols_extra", "view_rows_extra", "view_col_offset", "linear_start", "skip_view_anchor"):
                    if attr in canvas_state:
                        try:
                            setattr(self.canvas, attr, int(canvas_state.get(attr)))
                        except Exception:
                            pass
                if canvas_state.get("view_mode"):
                    self.canvas.view_mode = str(canvas_state.get("view_mode"))
                self.canvas.selected_positions = [int(p) for p in canvas_state.get("selected_positions", []) or []]
                self.canvas.top_connector_lines = [
                    {"x": item.get("x", 0), "match": restored_match}
                    for item in canvas_state.get("top_connector_lines", []) or []
                    for restored_match in [match_from_dict(item.get("match", {}))]
                    if restored_match is not None
                ]
                hidden_frames = set()
                for raw_key in canvas_state.get("hidden_match_frames", []) or []:
                    if isinstance(raw_key, (list, tuple)) and len(raw_key) >= 5:
                        hidden_frames.add((raw_key[0], raw_key[1], raw_key[2], raw_key[3], tuple(raw_key[4] or [])))
                self.canvas.hidden_match_frames = hidden_frames
            self.results_mode = str(snapshot.get("results_mode", "ciphers") or "ciphers")
            if self.saved:
                self.results_mode = "ciphers" if self.results_mode not in ("ciphers", "details") else self.results_mode
                for pm, local in self.saved:
                    self.apply_word_colors([pm] + local)
                self.open_results_table()
                if self.results_mode == "details":
                    self.populate_current_result_table()
                else:
                    self.populate_cipher_list()
                self.current = max(0, min(self.current, len(self.saved) - 1))
                self.display_current()
            else:
                self.current_display_match = None
                if hasattr(self, "results"):
                    self.results.delete(0, "end")
                self.result_rows = []
                if hasattr(self, "canvas"):
                    self.canvas.set_matches([])
            self.update_context_header()
        finally:
            self.restoring_app_state = False
            self.auto_undo_last_snapshot = self.app_state_snapshot()

    def undo_app_state(self) -> bool:
        if not self.app_undo_stack:
            return False
        label = self.app_undo_labels.pop() if self.app_undo_labels else "פעולה אחרונה"
        self.app_redo_stack.append(self.app_state_snapshot())
        self.app_redo_labels.append(label)
        self.restore_app_state(self.app_undo_stack.pop())
        self.status.set(f"בוטל: {label}")
        return True

    def redo_app_state(self) -> bool:
        if not self.app_redo_stack:
            return False
        label = self.app_redo_labels.pop() if self.app_redo_labels else "פעולה אחרונה"
        self.app_undo_stack.append(self.app_state_snapshot())
        self.app_undo_labels.append(label)
        self.restore_app_state(self.app_redo_stack.pop())
        self.status.set(f"הוחזר: {label}")
        return True

    def save_project(self):
        path = filedialog.asksaveasfilename(
            title="שמור פרויקט גל עיני לטעינה בתוכנה",
            defaultextension=".gal_einai.json",
            filetypes=[("קובץ פרויקט גל עיני", "*.gal_einai.json"), ("JSON", "*.json"), ("All", "*.*")],
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8", newline="\n") as f:
                json.dump(self.project_to_dict(), f, ensure_ascii=False, indent=2)
            self.status.set(f"נשמר הצופן הנוכחי בלבד לטעינה בתוכנה: {os.path.basename(path)}")
        except Exception as e:
            rtl_showerror("שמירת פרויקט", f"לא הצלחתי לשמור את הפרויקט:\n{e}")

    def open_project(self):
        path = filedialog.askopenfilename(
            title="פתח פרויקט גל עיני",
            filetypes=[("Gal Einai Project", "*.gal_einai.json;*.json"), ("JSON", "*.json"), ("All", "*.*")],
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                raise ValueError("קובץ הפרויקט אינו במבנה תקין")
            self.push_app_undo_state("טעינת פרויקט")
            self.load_project_dict(data)
            self.status.set(f"נטען פרויקט: {os.path.basename(path)}")
        except Exception as e:
            rtl_showerror("פתיחת פרויקט", f"לא הצלחתי לפתוח את הפרויקט:\n{e}")

    def open_ai_decode_tool(self):
        if not AI_FEATURES_ENABLED:
            rtl_showinfo("פענוח AI", "גרסה זו היא ללא AI. להורדה עם AI יש לבחור באתר את גרסת Windows עם AI.")
            return
        self.open_ai_keyword_tool()

    def open_ai_keyword_tool(self):
        if not AI_FEATURES_ENABLED:
            rtl_showinfo("פענוח AI", "גרסה זו היא ללא AI. להורדה עם AI יש לבחור באתר את גרסת Windows עם AI.")
            return
        win = tk.Toplevel(self.root)
        win.title("פענוח AI לצופן")
        win.transient(self.root)
        self.prepare_child_window(win, 720, 560)
        win.geometry("900x680")
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        notebook = ttk.Notebook(frame)
        notebook.grid(row=0, column=0, sticky="nsew")
        guide_tab = ttk.Frame(notebook, padding=8)
        decode_tab = ttk.Frame(notebook, padding=8)
        notebook.add(guide_tab, text="מסלול א - חיפוש צופן חדש")
        notebook.add(decode_tab, text="מסלול ב - צופן מוכן לפענוח")
        guide_tab.columnconfigure(0, weight=1)
        guide_tab.rowconfigure(4, weight=1)
        decode_tab.columnconfigure(0, weight=1)
        decode_tab.rowconfigure(2, weight=1)

        topic_var = tk.StringVar(value=self.get_primary_word() if hasattr(self, "primary_var") else "")
        payload_holder = {"payload": None}
        word_vars: List[Tuple[tk.BooleanVar, str]] = []

        route_note = ttk.Label(
            guide_tab,
            text=rtl_display("מסלול א: הצעות מילים → העברה לשדות החיפוש → חיפוש הצופן → מעבר למסלול ב לפענוח."),
            anchor="e",
            justify="right",
            font=("Arial", 10, "bold"),
        )
        route_note.grid(row=0, column=0, sticky="ew", pady=(0, 8))

        top_row = ttk.Frame(guide_tab)
        top_row.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        top_row.columnconfigure(1, weight=1)
        ttk.Label(top_row, text="נושא:", font=("Arial", 11, "bold")).grid(row=0, column=2, sticky="e", padx=(6, 0))
        topic_field = FixedHebrewField(top_row, textvariable=topic_var, height=1, width=44, font=("Arial", 12))
        topic_field.grid(row=0, column=1, sticky="ew", padx=4)
        run_btn = ttk.Button(top_row, text="הצע מילים", width=12)
        run_btn.grid(row=0, column=0, sticky="w", padx=(0, 4))

        note = ttk.Label(
            guide_tab,
            text=rtl_display(f"פענוח AI אמיתי דורש מפתח OPENAI_API_KEY וחיבור רשת. בלי מפתח, אפשר להשתמש בהצעות מקומיות בלבד. כל מילה תעבור אישור שלך לפני כניסה למשניות. {APP_VERSION} {APP_EDITION_LABEL}."),
            anchor="e",
            justify="right",
            font=("Arial", 10),
        )
        note.grid(row=2, column=0, sticky="ew", pady=(0, 6))

        summary_var = tk.StringVar(value="")
        ttk.Label(guide_tab, textvariable=summary_var, anchor="e", justify="right", font=("Arial", 10, "bold")).grid(row=3, column=0, sticky="ew", pady=(0, 4))

        body = ttk.Frame(guide_tab)
        body.grid(row=4, column=0, sticky="nsew")
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        list_shell = ttk.Frame(body)
        list_shell.grid(row=0, column=1, sticky="nsew", padx=(0, 5))
        list_shell.columnconfigure(0, weight=1)
        list_shell.rowconfigure(0, weight=1)
        canvas = tk.Canvas(list_shell, highlightthickness=0, bg="#fbfbf8")
        scroll = ttk.Scrollbar(list_shell, orient="vertical", command=canvas.yview)
        checks = ttk.Frame(canvas)
        checks_id = canvas.create_window((0, 0), window=checks, anchor="ne")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")

        def sync_checks_width(event=None):
            canvas.itemconfigure(checks_id, width=max(260, canvas.winfo_width() - 4))

        checks.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", sync_checks_width)

        output = tk.Text(body, wrap="word", font=("Arial", 10), padx=8, pady=8, bg="#fbfbf8", relief="flat", width=34)
        output.grid(row=0, column=0, sticky="nsew", padx=(5, 0))
        output.tag_configure("body", justify="right", lmargin1=6, lmargin2=6, rmargin=10)
        output.configure(state="disabled")

        decode_intro = ttk.Label(
            decode_tab,
            text=rtl_display("מסלול ב: צופן מוכן לפענוח. אין כאן הצעת מילים לחיפוש; הפענוח מתבסס על הצופן הנוכחי, הממצאים והמשניות שכבר קיימים."),
            anchor="e",
            justify="right",
            font=("Arial", 10, "bold"),
        )
        decode_intro.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        decode_controls = ttk.Frame(decode_tab)
        decode_controls.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        decode_controls.columnconfigure(1, weight=1)
        decode_question_var = tk.StringVar(value="מה ניתן לעיין מהמילים שעלו בצופן?")
        ttk.Label(decode_controls, text="שאלה מנחה:", anchor="e").grid(row=0, column=2, sticky="e", padx=(6, 0))
        decode_question = ttk.Entry(decode_controls, textvariable=decode_question_var, justify="right")
        decode_question.grid(row=0, column=1, sticky="ew", padx=4)
        decode_run_btn = ttk.Button(decode_controls, text="פענח צופן", width=12)
        decode_run_btn.grid(row=0, column=0, sticky="w", padx=(0, 4))
        decode_output = tk.Text(decode_tab, wrap="word", font=("Arial", 11), padx=10, pady=10, bg="#fbfbf8", relief="solid", bd=1)
        decode_output.grid(row=2, column=0, sticky="nsew")
        decode_output.tag_configure("body", justify="right", lmargin1=8, lmargin2=8, rmargin=12)
        decode_output.configure(state="disabled")
        decode_status_var = tk.StringVar(value="")
        decode_bottom = ttk.Frame(decode_tab)
        decode_bottom.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        decode_bottom.columnconfigure(2, weight=1)
        ttk.Label(decode_bottom, textvariable=decode_status_var, anchor="e", justify="right").grid(row=0, column=2, sticky="ew", padx=(8, 0))
        decode_progress = ttk.Progressbar(decode_bottom, mode="indeterminate", length=160)
        decode_progress.grid(row=0, column=1, sticky="e", padx=4)
        decode_progress.grid_remove()
        decode_refresh_btn = ttk.Button(decode_bottom, text="רענן נתוני צופן")
        decode_refresh_btn.grid(row=0, column=0, sticky="w", padx=3)

        buttons = ttk.Frame(guide_tab)
        buttons.grid(row=5, column=0, sticky="ew", pady=(8, 0))
        buttons.columnconfigure(0, weight=1)
        status_var = tk.StringVar(value="")
        ttk.Label(buttons, textvariable=status_var, anchor="e", justify="right").grid(row=0, column=8, sticky="ew", padx=(8, 0))

        def set_output(text: str):
            output.configure(state="normal")
            output.delete("1.0", "end")
            output.insert("1.0", rtl_display(text))
            output.tag_add("body", "1.0", "end")
            output.configure(state="disabled")

        def set_decode_output(text: str):
            decode_output.configure(state="normal")
            decode_output.delete("1.0", "end")
            decode_output.insert("1.0", rtl_display(text))
            decode_output.tag_add("body", "1.0", "end")
            decode_output.configure(state="disabled")

        def actual_saved_words_for_decode() -> Tuple[str, List[str]]:
            primary = self.get_primary_word() if hasattr(self, "primary_var") else ""
            words = []
            if self.saved:
                idx = max(0, min(getattr(self, "current", 0), len(self.saved) - 1))
                saved_primary, local = self.saved[idx]
                primary = primary or saved_primary.word
                for match in local:
                    if match.kind == "primary" and match.word == saved_primary.word:
                        continue
                    words.append(match.word)
            clean_words = []
            seen = set()
            for word in words:
                clean = self.engine.normalize_word(word)
                key = canonical_hebrew(clean)
                if clean and key and key not in seen:
                    seen.add(key)
                    clean_words.append(clean)
            return self.engine.normalize_word(primary), clean_words

        def decode_candidate_words(question: str, ai_candidates: Optional[List[str]] = None) -> List[str]:
            topic_words = [self.engine.normalize_word(t) for t in re.split(r"[\s,;:|/\\-]+", question) if self.engine.normalize_word(t)]
            candidates = []
            candidates.extend(ai_candidates or [])
            candidates.extend(topic_words)
            groups = self.local_ai_topic_groups(topic_words)
            for words in groups.values():
                candidates.extend(words)
            aliases = self.local_ai_keyword_aliases()
            for word in topic_words:
                candidates.extend(aliases.get(canonical_hebrew(word), []))
            if os.path.exists(SCAN_WORDS_FILE):
                try:
                    raw = TorahLoader.read_file(SCAN_WORDS_FILE)
                    candidates.extend(self.engine.normalize_word(w) for w in re.split(r"[\s,;|]+", raw) if self.engine.normalize_word(w))
                except Exception:
                    pass
            out = []
            seen = set()
            for word in candidates:
                clean = self.engine.normalize_word(word)
                key = canonical_hebrew(clean)
                if len(key) < 2 or key in seen:
                    continue
                seen.add(key)
                out.append(clean)
            return out[:MAX_SCAN_WORDS]

        def meaningful_decode_lexicon(question: str, ai_candidates: Optional[List[str]] = None) -> List[str]:
            primary, saved_words = actual_saved_words_for_decode()
            candidates = []
            candidates.extend(ai_candidates or [])
            candidates.extend(saved_words)
            candidates.extend(decode_candidate_words(question, ai_candidates))
            for topic in ("מי שם אדם איש אשה", "איפה מקום עיר רחוב בית", "מתי זמן תאריך חודש שנה", "מה חפץ סימן רכב מסמך", "אירוע פעולה סיבה תוצאה"):
                topic_words = [self.engine.normalize_word(t) for t in topic.split() if self.engine.normalize_word(t)]
                for words in self.local_ai_topic_groups(topic_words).values():
                    candidates.extend(words)
            for file_name in [SCAN_WORDS_FILE, *WORD_CATEGORY_FILES.values()]:
                if not os.path.exists(file_name):
                    continue
                try:
                    raw = TorahLoader.read_file(file_name)
                    candidates.extend(self.engine.normalize_word(w) for w in re.split(r"[\s,;|]+", raw) if self.engine.normalize_word(w))
                except Exception:
                    pass
            out = []
            seen = set()
            primary_key = canonical_hebrew(primary)
            for word in candidates:
                clean = self.engine.normalize_word(word)
                key = canonical_hebrew(clean)
                if len(key) < 2 or len(key) > 14 or key in seen or key == primary_key:
                    continue
                seen.add(key)
                out.append(clean)
            return out[:MAX_SCAN_WORDS]

        def question_relevance_words(question: str, ai_candidates: Optional[List[str]] = None) -> set:
            relevant = set()
            for word in decode_candidate_words(question, ai_candidates):
                key = canonical_hebrew(word)
                if key:
                    relevant.add(key)
            return relevant

        def ai_decode_scan_grids() -> Tuple[List[Tuple[str, List[List[Optional[int]]]]], Tuple[int, int]]:
            if not hasattr(self, "canvas"):
                return [], (0, 0)
            if not self.saved or not (0 <= getattr(self, "current", 0) < len(self.saved)):
                grid = self.visible_grid_snapshot() if hasattr(self, "visible_grid_snapshot") else []
                return [("מישור 1", grid)], (len(grid or []), max((len(row) for row in (grid or [])), default=0))
            primary, _local = self.saved[self.current]
            display_primary = getattr(self, "current_display_match", None) or primary
            n_skip = int(display_primary.skip or 1)
            starts = display_primary.calc_positions()
            start = starts[0] if starts else int(display_primary.start)
            planes = []
            for label, skip in (
                (f"מישור N ({n_skip})", n_skip),
                (f"מישור N+1 ({n_skip + 1})", n_skip + 1),
                (f"מישור N-1 ({n_skip - 1})", n_skip - 1),
                ("מישור 1", 1),
            ):
                if skip == 0:
                    continue
                plane_primary = Match(display_primary.word, start, skip, "primary")
                planes.append((label, self.dense_primary_search_grid(plane_primary, row_multiplier=2)))
            rows = max((len(grid or []) for _label, grid in planes), default=0)
            cols = max((len(row) for _label, grid in planes for row in (grid or [])), default=0)
            return planes, (rows, cols)

        def scan_actual_decode_words(question: str, ai_candidates: Optional[List[str]] = None) -> Tuple[List[Match], int, Tuple[int, int], List[str]]:
            candidates = meaningful_decode_lexicon(question, ai_candidates)
            if not candidates or not hasattr(self, "canvas"):
                return [], len(candidates), (0, 0), []
            scan_grids, grid_size = ai_decode_scan_grids()
            seen = set()
            unique_matches = []
            plane_labels = []
            per_plane_limit = max(60, MAX_SCAN_RESULTS // max(1, len(scan_grids)))
            for label, grid in scan_grids:
                if not grid:
                    continue
                plane_labels.append(label)
                matches = self.canvas.screen_word_paths(candidates, per_plane_limit, grid, self.engine.should_stop)
                for match in matches:
                    key = (canonical_hebrew(match.word), tuple(match.calc_positions()), match.skip, label)
                    if key in seen:
                        continue
                    seen.add(key)
                    match.kind = "ai_decode"
                    unique_matches.append(match)
                    if len(unique_matches) >= MAX_SCAN_RESULTS:
                        return unique_matches, len(candidates), grid_size, plane_labels
            return unique_matches, len(candidates), grid_size, plane_labels

        def ordered_actual_words(matches: List[Match], primary: str, question: str = "", ai_candidates: Optional[List[str]] = None) -> List[str]:
            relevant_keys = question_relevance_words(question, ai_candidates)
            primary_positions = []
            if self.saved:
                idx = max(0, min(getattr(self, "current", 0), len(self.saved) - 1))
                primary_positions = self.saved[idx][0].calc_positions()
            primary_center = sum(primary_positions) / len(primary_positions) if primary_positions else None
            stats = {}
            for match in matches:
                key = canonical_hebrew(match.word)
                if not key:
                    continue
                center_positions = match.calc_positions()
                center = sum(center_positions) / len(center_positions) if center_positions else match.start
                distance = abs(center - primary_center) if primary_center is not None else 10**9
                current = stats.get(key) or {"word": match.word, "count": 0, "distance": distance, "skips": set()}
                current["count"] += 1
                current["distance"] = min(current["distance"], distance)
                current["skips"].add(abs(match.skip or 1))
                stats[key] = current
            primary_key = canonical_hebrew(primary)
            ordered = sorted(
                stats.values(),
                key=lambda item: (
                    0 if canonical_hebrew(item["word"]) in relevant_keys else 1,
                    -item["count"],
                    item["distance"],
                    0 if primary_key and (primary_key in canonical_hebrew(item["word"]) or canonical_hebrew(item["word"]) in primary_key) else 1,
                    item["word"],
                ),
            )
            return [item["word"] for item in ordered]

        def decode_evidence_report(matches: List[Match], primary: str) -> dict:
            primary_positions = []
            if self.saved:
                idx = max(0, min(getattr(self, "current", 0), len(self.saved) - 1))
                primary_positions = self.saved[idx][0].calc_positions()
            primary_center = sum(primary_positions) / len(primary_positions) if primary_positions else None
            stats = {}
            for match in matches:
                key = canonical_hebrew(match.word)
                if not key:
                    continue
                positions = match.calc_positions()
                center = sum(positions) / len(positions) if positions else match.start
                distance = abs(center - primary_center) if primary_center is not None else None
                current = stats.get(key) or {
                    "word": match.word,
                    "count": 0,
                    "best_distance": distance,
                    "skips": set(),
                    "samples": [],
                }
                current["count"] += 1
                if distance is not None:
                    current["best_distance"] = min(current["best_distance"], distance) if current["best_distance"] is not None else distance
                current["skips"].add(abs(match.skip or 1))
                if len(current["samples"]) < 3:
                    current["samples"].append({"start": match.start, "skip": match.skip, "positions": positions[:12]})
                stats[key] = current
            ordered = sorted(
                stats.values(),
                key=lambda item: (-item["count"], item["best_distance"] if item["best_distance"] is not None else 10**9, item["word"]),
            )
            pairs = []
            compact_matches = matches[:80]
            for i, first in enumerate(compact_matches):
                first_positions = first.calc_positions()
                for second in compact_matches[i + 1:]:
                    if canonical_hebrew(first.word) == canonical_hebrew(second.word):
                        continue
                    second_positions = second.calc_positions()
                    distance = min((abs(a - b) for a in first_positions for b in second_positions), default=10**9)
                    if distance <= 2:
                        pairs.append({"a": first.word, "b": second.word, "distance": distance, "skip_a": first.skip, "skip_b": second.skip})
            pairs.sort(key=lambda item: (item["distance"], abs(item["skip_a"] or 1) + abs(item["skip_b"] or 1)))
            return {
                "primary": primary,
                "match_count": len(matches),
                "words": [
                    {
                        "word": item["word"],
                        "count": item["count"],
                        "best_distance": item["best_distance"],
                        "skips": sorted(item["skips"]),
                        "samples": item["samples"],
                    }
                    for item in ordered[:80]
                ],
                "near_pairs": pairs[:30],
            }

        def build_local_decode_payload(
            question: str,
            title: str,
            ai_candidates: Optional[List[str]] = None,
            ai_summary: str = "",
            ai_error: str = "",
        ) -> dict:
            primary, saved_words = actual_saved_words_for_decode()
            scanned_matches, checked_count, grid_size, plane_labels = scan_actual_decode_words(question, ai_candidates)
            scanned_words = ordered_actual_words(scanned_matches, primary, question, ai_candidates)
            words = []
            seen_words = set()
            for word in scanned_words + saved_words:
                key = canonical_hebrew(word)
                if key and key not in seen_words:
                    seen_words.add(key)
                    words.append(word)
            date_words = [w for w in words if any(ch.isdigit() for ch in w) or any(token in w for token in ("תש", "תמוז", "אב", "ניסן", "אלול", "כסלו", "טבת", "שבט", "אדר"))]
            evidence = decode_evidence_report(scanned_matches, primary)
            lines = [
                "פענוח AI לאחר סריקה בפועל - גל עיני",
                "",
                f"שם הצופן: {title}",
                f"שאלה מנחה: {question}",
                f"ראשית: {primary or 'לא נמצאה ראשית ברורה'}",
                f"סריקה מורחבת: נבדקו {checked_count} מילים משמעותיות ממאגרי התוכנה, מהממצאים הקיימים ומהצעות AI; נמצאו בפועל {len(scanned_matches)} הופעות בטבלת הצופן.",
                f"טווח הסריקה: עד {grid_size[0]} שורות על {grid_size[1]} עמודות סביב הראשית, כמו זום-אאוט מורחב.",
                f"מישורי הסריקה המחייבים: {', '.join(plane_labels) if plane_labels else 'N, N+1, N-1, 1'}.",
                "אחר כך הממצאים שנמצאו בפועל דורגו לפי קשר לשאלה המנחה ולפי קבוצות מילים רלוונטיות.",
                "הפענוח אינו משתמש במילים שרק הוקלדו לחיפוש אם הן לא נמצאו בפועל בצופן.",
            ]
            if ai_candidates:
                lines.append(f"AI הציע {len(ai_candidates)} מועמדות לחקירה; רק מה שנמצא בפועל נכנס לממצאים.")
            if ai_error:
                lines.append(f"הערת AI: {ai_error}")
            if ai_summary:
                lines.extend(["", "ניתוח AI על סמך הממצאים שנמצאו בפועל:", ai_summary])
            lines.extend([
                "",
                "מילים שנמצאו בפועל ומשמשות לפענוח:",
                "\n".join(f"- {word}" for word in words[:60]) if words else "- לא נמצאו מילים מתאימות בפועל בסריקה הנוכחית.",
                "",
                "כיוון עיון ראשוני:",
            ])
            if primary and words:
                focus = ", ".join(words[:8])
                lines.append(f"בסריקה בפועל סביב הראשית \"{primary}\" נמצאו המילים: {focus}. יש לבדוק סמיכות, חזרות, מפגשים וקשר ענייני לפני כל מסקנה.")
            elif primary:
                lines.append(f"קיימת ראשית \"{primary}\", אך חסרות משניות מספיקות לפענוח מסודר.")
            else:
                lines.append("אין מספיק נתונים לפענוח. מומלץ לטעון צופן או לבצע חיפוש לפני הפענוח.")
            lines.extend([
                "",
                "בדיקות המשך מומלצות:",
                "- לבדוק אם המילים הקרובות לראשית חוזרות יותר מפעם אחת.",
                "- לבדוק מפגשים, קווי סמיכות, אלכסונים ודילוג 1.",
                "- לבדוק אם יש מילים מסוג שם, מקום, זמן, תכונה או פעולה בהתאם לשאלה המנחה.",
            ])
            if len(scanned_matches) < 8:
                lines.append("- נמצאו מעט ממצאים בארבעת מישורי הבסיס; שלב המשך אפשרי הוא סריקה רחבה בכל דילוג, אך זה אובר-הד גדול ויש להפעיל אותו רק בבחירה מפורשת.")
            if date_words:
                lines.append(f"- תאריכים/זמנים שעלו לעיון: {', '.join(date_words[:12])}.")
            if self.saved:
                try:
                    pm, local = self.saved[max(0, min(getattr(self, "current", 0), len(self.saved) - 1))]
                    score, _quality, details = self.cipher_quality(pm, local)
                    lines.extend(["", f"מדד איכות פנימי: {self.short_quality_text(score)} | {details}"])
                except Exception:
                    pass
            lines.extend([
                "",
                "הסתייגויות:",
                "- אין להסיק נבואה, הכרעה מעשית, אשמה, פסול או קביעה על אדם מתוך הצופן.",
                "- הפענוח הוא כיוון עיון בלבד וצריך בדיקה חוזרת בתוכנה ובשיקול דעת.",
                "- אם מדובר באדם חי או מקרה רגיש, יש להיזהר במיוחד מלשון הרע ומפגיעה.",
            ])
            return {"text": "\n".join(lines), "evidence": evidence, "words": words}

        def build_local_decode_text() -> str:
            question = decode_question_var.get().strip() or "מה ניתן לעיין מהמילים שעלו בצופן?"
            title = self.context_title.get().strip() if hasattr(self, "context_title") and self.context_title.get().strip() else "הצופן הנוכחי"
            return build_local_decode_payload(question, title)["text"]

        def is_ai_payment_required_error(error: Exception) -> bool:
            text = str(error)
            return any(token in text for token in ("insufficient_quota", "quota", "billing", "תשלום", "מכסה"))

        def open_ai_payment_window():
            try:
                webbrowser.open(GAL_EINAI_PURCHASE_URL, new=2)
                decode_status_var.set("נפתח חלון תשלום להפעלת פענוח AI חי.")
            except Exception:
                decode_status_var.set("כדי להפעיל AI חי יש לפתוח את חלון הרכישה באתר.")

        def ai_payment_required_message() -> str:
            return (
                "פענוח AI חי דורש הפעלת תשלום/קרדיט לחשבון ה-AI.\n"
                "פתחתי עבורך את חלון התשלום המקורי. לאחר השלמת התשלום אפשר לחזור וללחוץ שוב על פענח צופן.\n"
                "בינתיים מוצג דו\"ח הסריקה המקומית המבוסס רק על ממצאים שנמצאו בפועל."
            )

        def run_decode():
            decode_run_btn.configure(state="disabled")
            decode_refresh_btn.configure(state="disabled")
            decode_progress.grid()
            decode_progress.start(12)
            decode_status_var.set("AI מכין כיווני חקירה, סורק בפועל את הצופן המורחב, ואז מסכם רק ממצאים שנמצאו.")
            set_decode_output("")
            question = decode_question_var.get().strip() or "מה ניתן לעיין מהמילים שעלו בצופן?"
            title = self.context_title.get().strip() if hasattr(self, "context_title") and self.context_title.get().strip() else "הצופן הנוכחי"
            api_key = self.get_openai_api_key()

            def worker():
                try:
                    ai_candidates = []
                    ai_summary = ""
                    ai_error = ""
                    if api_key:
                        try:
                            ai_candidates = self.fetch_ai_decode_candidates(question, title, api_key)
                        except Exception as e:
                            if is_ai_payment_required_error(e):
                                self.root.after(0, open_ai_payment_window)
                                ai_error = ai_payment_required_message()
                            else:
                                ai_error = f"שלב הצעת המילים של AI נכשל, בוצעה סריקה מקומית מורחבת: {e}"
                    else:
                        ai_error = "לא הוזן מפתח OpenAI; בוצעה סריקה מקומית מורחבת ללא AI חיצוני."
                    payload = build_local_decode_payload(question, title, ai_candidates, ai_error=ai_error)
                    if api_key and payload.get("evidence", {}).get("match_count", 0):
                        try:
                            ai_summary = self.fetch_ai_decode_interpretation(question, title, payload["evidence"], api_key)
                            payload = build_local_decode_payload(question, title, ai_candidates, ai_summary=ai_summary, ai_error=ai_error)
                        except Exception as e:
                            if is_ai_payment_required_error(e):
                                self.root.after(0, open_ai_payment_window)
                                payment_note = ai_payment_required_message()
                            else:
                                payment_note = f"שלב ניתוח ה-AI נכשל, מוצג דו\"ח סריקה: {e}"
                            payload = build_local_decode_payload(
                                question,
                                title,
                                ai_candidates,
                                ai_error=f"{ai_error} | {payment_note}".strip(" |"),
                            )
                    self.root.after(0, lambda: set_decode_output(payload["text"]))
                    self.root.after(0, lambda: decode_status_var.set("הפענוח הסתיים. התוצאה מבוססת רק על ממצאים שנמצאו בפועל בסריקה."))
                    self.root.after(0, lambda: self.status.set("פענוח AI לאחר סריקה בפועל הסתיים"))
                except Exception as e:
                    self.root.after(0, lambda err=e: decode_status_var.set(f"לא הצלחתי לבנות פענוח: {err}"))
                finally:
                    self.root.after(0, decode_progress.stop)
                    self.root.after(0, decode_progress.grid_remove)
                    self.root.after(0, lambda: decode_run_btn.configure(state="normal"))
                    self.root.after(0, lambda: decode_refresh_btn.configure(state="normal"))

            threading.Thread(target=worker, daemon=True).start()

        decode_run_btn.configure(command=run_decode)
        decode_refresh_btn.configure(command=run_decode)

        def selected_words() -> List[str]:
            out = []
            seen = set()
            for var, word in word_vars:
                if not var.get():
                    continue
                key = canonical_hebrew(word)
                if key and key not in seen:
                    seen.add(key)
                    out.append(word)
            return out

        def refresh_checks(payload: dict):
            for child in checks.winfo_children():
                child.destroy()
            word_vars.clear()
            groups = payload.get("secondary_groups", {}) if isinstance(payload.get("secondary_groups", {}), dict) else {}
            row = 0
            for group_name, words in groups.items():
                clean_words = [self.engine.normalize_word(w) for w in words if self.engine.normalize_word(w)]
                if not clean_words:
                    continue
                ttk.Label(checks, text=group_name, anchor="e", font=("Arial", 10, "bold")).grid(row=row, column=0, sticky="ew", padx=6, pady=(8, 2))
                row += 1
                for word in clean_words:
                    word_len = len(canonical_hebrew(word))
                    default_selected = 3 <= word_len <= 5
                    var = tk.BooleanVar(value=default_selected)
                    if default_selected:
                        label = word
                    elif word_len < 3:
                        label = f"{word} (קצרה)"
                    else:
                        label = f"{word} (ארוכה)"
                    chk = ttk.Checkbutton(checks, text=label, variable=var)
                    chk.grid(row=row, column=0, sticky="e", padx=12, pady=1)
                    word_vars.append((var, word))
                    row += 1
            canvas.configure(scrollregion=canvas.bbox("all"))

        def suggest():
            topic = topic_var.get().strip()
            if not topic:
                status_var.set("כתוב נושא תחילה")
                return
            payload = self.build_local_ai_keyword_suggestions(topic)
            payload_holder["payload"] = payload
            refresh_checks(payload)
            set_output(self.format_ai_keyword_payload(payload))
            selected_count = sum(1 for var, _word in word_vars if var.get())
            summary_var.set(f"נוצרו {len(word_vars)} הצעות מקומיות. {selected_count} מילים באורך 3-5 מסומנות; קצרות/ארוכות לבחירה ידנית.")
            status_var.set("ההצעות המקומיות מוכנות לבחירה.")

        def apply_research_payload(payload: dict):
            payload_holder["payload"] = payload
            refresh_checks(payload)
            set_output(self.format_ai_keyword_payload(payload))
            source_note = "מחקר AI מהרשת" if payload.get("source") == "openai_web_research" else "הצעות מקומיות"
            selected_count = sum(1 for var, _word in word_vars if var.get())
            summary_var.set(f"{source_note}: נוצרו {len(word_vars)} מילים. {selected_count} מילים באורך 3-5 מסומנות; קצרות/ארוכות לבחירה ידנית.")
            status_var.set("המחקר מוכן לבחירה.")

        def run_ai_research():
            topic = topic_var.get().strip()
            if not topic:
                status_var.set("כתוב נושא תחילה")
                return
            api_key = self.get_openai_api_key()
            if not api_key:
                status_var.set("חסר מפתח OpenAI. לחץ 'מפתח OpenAI' או השתמש בהצעות מקומיות.")
                rtl_showinfo(
                    "מחקר AI",
                    "כדי לבצע מחקר AI מהרשת צריך להזין מפתח OpenAI.\n\n"
                    "עד אז הכפתור 'הצע מקומי' עובד בלי עלות ובלי רשת, אך אינו מחקר אמיתי."
                )
                return
            status_var.set("מבצע מחקר AI מהרשת... זה עשוי לקחת זמן.")
            run_btn.configure(state="disabled")

            def worker():
                try:
                    payload = self.fetch_ai_keyword_research(topic, api_key)
                except Exception as e:
                    self.root.after(0, lambda: rtl_showerror("מחקר AI", f"לא הצלחתי לבצע מחקר AI:\n{e}"))
                    self.root.after(0, lambda: status_var.set("מחקר AI נכשל. אפשר לנסות שוב או להשתמש בהצעות מקומיות."))
                else:
                    self.root.after(0, lambda: apply_research_payload(payload))
                finally:
                    self.root.after(0, lambda: run_btn.configure(state="normal"))

            threading.Thread(target=worker, daemon=True).start()

        def set_all(value: bool):
            for var, _word in word_vars:
                var.set(value)
            status_var.set("סימון ההצעות עודכן")

        def apply_to_fields():
            payload = payload_holder.get("payload")
            if not payload:
                suggest()
                payload = payload_holder.get("payload")
            if not payload:
                return
            chosen = selected_words()
            apply_payload = dict(payload)
            apply_payload["secondary"] = chosen
            primary, secondaries, skipped = self.clean_ai_keyword_payload(apply_payload)
            if primary:
                self.primary_var.set(primary)
            if secondaries:
                existing = self.secondary_words() if hasattr(self, "secondary_var") else []
                combined = []
                seen = set()
                for word in existing + secondaries:
                    clean = self.engine.normalize_word(word)
                    key = canonical_hebrew(clean)
                    if clean and key not in seen:
                        seen.add(key)
                        combined.append(clean)
                self.secondary_var.set(" ".join(combined))
            recommendation = payload.get("recommendation", {})
            if isinstance(recommendation, dict):
                mode = self.normalize_ai_search_mode(recommendation.get("mode"))
                if mode:
                    self.mode.set(mode)
                if recommendation.get("skip_from") and recommendation.get("skip_to"):
                    self.exact_skip.set("")
                    self.skip_from.set(int(recommendation["skip_from"]))
                    self.skip_to.set(int(recommendation["skip_to"]))
                if recommendation.get("min_secondary") not in (None, ""):
                    self.min_secondary.set(max(0, int(recommendation["min_secondary"])))
            self.save_search_state()
            self.status.set(f"הצעות AI הועברו: ראשית {primary or '-'}, נוספו/נשמרו {len(secondaries)} משניות")
            status_var.set(f"הועבר למשניות. דולגו {skipped} מילים קצרות. אחרי חיפוש הצופן, עבור למסלול ב לפענוח.")
            notebook.select(decode_tab)
            decode_status_var.set("מסלול ב מוכן. לאחר שנמצא צופן, לחץ פענח צופן לקבלת תוצאה מסודרת.")

        def save_json():
            payload = payload_holder.get("payload")
            if not payload:
                suggest()
                payload = payload_holder.get("payload")
            if not payload:
                return
            payload_to_save = dict(payload)
            payload_to_save["secondary"] = selected_words()
            path = filedialog.asksaveasfilename(
                title="שמור מילות AI",
                defaultextension=".json",
                initialfile="gal_einai_ai_keywords.json",
                filetypes=[("JSON", "*.json"), ("All", "*.*")],
            )
            if not path:
                return
            try:
                with open(path, "w", encoding="utf-8", newline="\n") as f:
                    json.dump(payload_to_save, f, ensure_ascii=False, indent=2)
                status_var.set(f"נשמר: {os.path.basename(path)}")
            except Exception as e:
                rtl_showerror("שמירת מילות AI", str(e))

        def copy_ai_request():
            topic = topic_var.get().strip()
            if not topic:
                status_var.set("כתוב נושא תחילה")
                return
            prompt = (
                "הצע רשימת מילים משניות לחיפוש צפנים בתורה לפי הנושא הבא:\n"
                f"{topic}\n\n"
                "דרישות:\n"
                "1. החזר רק מילים/ביטויים שיש קשר חזק וברור לנושא.\n"
                "2. חלק לקטגוריות: אנשים/אישים, מקומות, ארגונים, מושגים, תאריכים/כינויים, שונות.\n"
                "3. אל תכניס מילים כלליות מדי אם אינן מוסיפות ערך למחקר.\n"
            "4. העדף מילים של 3 עד 5 אותיות למשניות. מילים של 2 אותיות עלולות להציף; מילים ארוכות יותר רק אם הן הכרחיות ממש.\n"
            "5. החזר JSON עם השדות topic, primary, secondary, dates, recommendation.\n"
            "6. אל תקבע מסקנות; זו רק הצעת מילות חיפוש לבדיקה."
            )
            self.root.clipboard_clear()
            self.root.clipboard_append(prompt)
            status_var.set("בקשת AI הועתקה ללוח. בשלב הבא נחבר זאת ישירות למנוע AI.")

        run_btn.configure(command=suggest, text="הצע מקומי")
        ttk.Button(buttons, text="מחקר AI מהרשת", command=run_ai_research).grid(row=0, column=6, sticky="e", padx=3)
        ttk.Button(buttons, text="מפתח OpenAI", command=self.open_openai_key_dialog).grid(row=0, column=7, sticky="e", padx=3)
        ttk.Button(buttons, text="העבר למשניות", command=apply_to_fields).grid(row=0, column=5, sticky="e", padx=3)
        ttk.Button(buttons, text="סמן הכל", command=lambda: set_all(True)).grid(row=0, column=4, sticky="e", padx=3)
        ttk.Button(buttons, text="נקה סימון", command=lambda: set_all(False)).grid(row=0, column=3, sticky="e", padx=3)
        ttk.Button(buttons, text="העתק בקשת AI", command=copy_ai_request).grid(row=0, column=2, sticky="e", padx=3)
        ttk.Button(buttons, text="שמור JSON", command=save_json).grid(row=0, column=1, sticky="e", padx=3)
        ttk.Button(buttons, text="סגור", command=win.destroy).grid(row=0, column=0, sticky="w", padx=3)
        topic_field.return_command = suggest
        topic_field.icursor("end")
        topic_field.focus_set()
        add_tooltip(run_btn, "מייצר הצעות משניות מתוך מאגר מקומי ראשוני בלבד, בלי רשת ובלי AI פעיל.")
        add_tooltip(canvas, "בחר רק את המילים המתאימות למחקר הנוכחי. ההעברה אינה מוחקת משניות קיימות.")
        add_tooltip(output, "תקציר ההצעות המקומיות. בשלב הבא יחובר מנגנון AI/רשת אמיתי.")

    def get_openai_api_key(self) -> str:
        return (
            str(getattr(self, "openai_api_key", "") or "").strip()
            or os.environ.get("OPENAI_API_KEY", "").strip()
            or os.environ.get("GAL_EINAI_OPENAI_API_KEY", "").strip()
        )

    def masked_openai_key(self) -> str:
        key = self.get_openai_api_key()
        if not key:
            return "לא הוזן מפתח"
        if len(key) <= 12:
            return "*" * len(key)
        return f"{key[:7]}...{key[-5:]}"

    def open_openai_key_dialog(self):
        win = tk.Toplevel(self.root)
        win.title("מפתח OpenAI")
        win.transient(self.root)
        self.prepare_child_window(win, 460, 240)
        frame = ttk.Frame(win, padding=12)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)

        ttk.Label(frame, text="הזן מפתח OpenAI API", font=("Arial", 12, "bold"), anchor="e").grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(
            frame,
            text=rtl_display("המפתח נדרש רק למחקר AI מהרשת. אם תבחר לשמור, הוא יישמר בקובץ ההגדרות של התוכנה במחשב זה."),
            justify="right",
            anchor="e",
            wraplength=420,
        ).grid(row=1, column=0, sticky="ew", pady=(0, 8))
        key_var = tk.StringVar(value=str(getattr(self, "openai_api_key", "") or ""))
        key_entry = ttk.Entry(frame, textvariable=key_var, show="*", width=52)
        key_entry.grid(row=2, column=0, sticky="ew", pady=(0, 6))
        self.add_openai_key_entry_menu(key_entry)
        save_var = tk.BooleanVar(value=bool(self.settings_state.get("save_openai_api_key", False)) if hasattr(self, "settings_state") else False)
        ttk.Checkbutton(frame, text="שמור במחשב זה", variable=save_var).grid(row=3, column=0, sticky="e", pady=(0, 6))
        status_var = tk.StringVar(value=f"מפתח נוכחי: {self.masked_openai_key()}")
        ttk.Label(frame, textvariable=status_var, anchor="e").grid(row=4, column=0, sticky="ew", pady=(0, 8))

        buttons = ttk.Frame(frame)
        buttons.grid(row=5, column=0, sticky="ew")
        buttons.columnconfigure(0, weight=1)

        def save_key():
            key = key_var.get().strip()
            if not key:
                status_var.set("לא הוזן מפתח")
                return
            self.openai_api_key = key
            self.settings_state["save_openai_api_key"] = bool(save_var.get())
            if save_var.get():
                self.settings_state["openai_api_key"] = key
            else:
                self.settings_state["openai_api_key"] = ""
            self.save_app_settings()
            status_var.set(f"המפתח נקלט: {self.masked_openai_key()}")
            self.status.set("מפתח OpenAI נקלט לתוכנה")
            win.destroy()

        def clear_key():
            self.openai_api_key = ""
            self.settings_state["openai_api_key"] = ""
            self.settings_state["save_openai_api_key"] = False
            self.save_app_settings()
            key_var.set("")
            status_var.set("המפתח נמחק מהגדרות התוכנה")
            self.status.set("מפתח OpenAI נמחק")

        ttk.Button(buttons, text="אישור", command=save_key).grid(row=0, column=3, sticky="e", padx=3)
        ttk.Button(buttons, text="מחק מפתח", command=clear_key).grid(row=0, column=2, sticky="e", padx=3)
        ttk.Button(buttons, text="ביטול", command=win.destroy).grid(row=0, column=0, sticky="w", padx=3)
        key_entry.focus_set()

    def add_openai_key_entry_menu(self, widget):
        widget.configure(exportselection=False)

        def has_selection() -> bool:
            try:
                widget.index("sel.first")
                widget.index("sel.last")
                return True
            except tk.TclError:
                return False

        def select_all(_event=None):
            widget.selection_range(0, "end")
            widget.icursor("end")
            return "break"

        def delete_selection():
            if has_selection():
                widget.delete("sel.first", "sel.last")
            return "break"

        def paste_text(_event=None):
            try:
                text = widget.clipboard_get().replace("\r", "").replace("\n", "").strip()
            except tk.TclError:
                return "break"
            if has_selection():
                widget.delete("sel.first", "sel.last")
            widget.insert("insert", text)
            widget.icursor("insert")
            return "break"

        def cut_text(_event=None):
            if has_selection():
                widget.event_generate("<<Cut>>")
            return "break"

        def copy_text(_event=None):
            if has_selection():
                widget.event_generate("<<Copy>>")
            return "break"

        def show_menu(event=None):
            widget.focus_set()
            menu = tk.Menu(widget, tearoff=0)
            menu.add_command(label="הדבק", command=paste_text)
            menu.add_separator()
            menu.add_command(label="גזור", command=cut_text)
            menu.add_command(label="העתק", command=copy_text)
            menu.add_command(label="מחק", command=delete_selection)
            menu.add_separator()
            menu.add_command(label="בחר הכל", command=select_all)
            x = getattr(event, "x_root", widget.winfo_rootx() + 20)
            y = getattr(event, "y_root", widget.winfo_rooty() + widget.winfo_height() + 4)
            menu.tk_popup(x, y)
            return "break"

        widget.bind("<Button-3>", show_menu)
        widget.bind("<Control-v>", paste_text)
        widget.bind("<Control-V>", paste_text)
        widget.bind("<Shift-Insert>", paste_text)
        widget.bind("<Control-a>", select_all)
        widget.bind("<Control-A>", select_all)
        widget.bind("<Menu>", show_menu)
        widget.bind("<Shift-F10>", show_menu)

    def build_ai_keyword_research_prompt(self, topic: str) -> str:
        return (
            "אתה מסייע לחוקר צפנים בתורה להכין מילות חיפוש משניות לנושא מחקר.\n"
            "המטרה אינה להסיק מסקנות, אלא לבחור מילים מרכזיות ומשמעותיות שבלעדיהן הבנת הנושא חסרה.\n"
            "דלה את המילים ממאמרים, כתבות, חדשות, מקורות מידע ורקע היסטורי רלוונטי.\n\n"
            f"נושא המחקר: {topic}\n\n"
            "החזר JSON בלבד, בלי Markdown, במבנה הבא:\n"
            "{\n"
            '  "topic": "...",\n'
            '  "primary": ["..."],\n'
            '  "secondary_groups": {\n'
            '    "אנשים/אישים": [{"word":"...", "reason":"...", "sources":["..."]}],\n'
            '    "מקומות": [{"word":"...", "reason":"...", "sources":["..."]}],\n'
            '    "ארגונים": [{"word":"...", "reason":"...", "sources":["..."]}],\n'
            '    "מושגים": [{"word":"...", "reason":"...", "sources":["..."]}],\n'
            '    "תאריכים/כינויים": [{"word":"...", "reason":"...", "sources":["..."]}],\n'
            '    "שונות": [{"word":"...", "reason":"...", "sources":["..."]}]\n'
            "  },\n"
            '  "dates": ["..."],\n'
            '  "recommendation": {"mode":"צופן", "skip_from":0, "skip_to":800, "min_secondary":3},\n'
            '  "notes": ["..."]\n'
            "}\n\n"
            "כללים מחייבים:\n"
            "1. בחר רק מילים עם קשר חזק וברור לנושא.\n"
            "2. למשניות העדף מילים של 3 עד 5 אותיות.\n"
            "3. מילה של 2 אותיות תיכנס רק אם היא הכרחית במיוחד, מפני שהיא עלולה להציף בתוצאות.\n"
            "4. מילה מעל 5 אותיות תיכנס רק אם בלעדיה הפרשה חסרה באופן משמעותי.\n"
            "5. אל תכניס מילים כלליות מדי כמו 'דבר', 'אדם', 'עולם' אלא אם הן הכרחיות בהקשר.\n"
            "6. העדף שמות אנשים, מקומות, ארגונים, אירועים, מושגים מקצועיים ותאריכים.\n"
            "7. לכל מילה תן נימוק קצר למה היא מרכזית לנושא.\n"
            "8. ציין מקור או שם מקור לכל מילה כשאפשר.\n"
            "9. אל תכתוב מסקנות על הצופן. רק רשימת מילות חיפוש למחקר."
        )

    def fetch_ai_keyword_research(self, topic: str, api_key: str) -> dict:
        model = os.environ.get("GAL_EINAI_OPENAI_MODEL", "gpt-4.1")
        body = {
            "model": model,
            "input": self.build_ai_keyword_research_prompt(topic),
            "tools": [{"type": "web_search"}],
            "tool_choice": "required",
        }
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            "https://api.openai.com/v1/responses",
            data=data,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                response_data = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")
            if e.code == 429 and "insufficient_quota" in detail:
                raise RuntimeError("נדרש תשלום או קרדיט להפעלת פענוח AI חי (insufficient_quota)") from e
            raise RuntimeError(f"שגיאת OpenAI {e.code}: {detail[:800]}") from e
        text = self.extract_openai_response_text(response_data)
        if not text:
            raise RuntimeError("OpenAI לא החזיר טקסט שניתן לקרוא")
        parsed = self.parse_ai_research_json(text)
        return self.normalize_ai_research_payload(parsed, topic)

    def fetch_ai_decode_candidates(self, question: str, title: str, api_key: str) -> List[str]:
        model = os.environ.get("GAL_EINAI_OPENAI_MODEL", "gpt-4.1")
        prompt = (
            "אתה מסייע לחקירת צופן תורה. החזר JSON בלבד.\n"
            "המטרה: להציע מילים מועמדות לסריקה בפועל בטבלת הצופן לפי שאלה מנחה.\n"
            "אסור להסיק מסקנות ואסור לטעון שמילה נמצאה. התוכנה תסרוק בפועל אחר כך.\n"
            "הצע שמות, מקומות, זמנים, תיאורים, פעולות, חפצים ומילות הקשר שיכולות לתת אינדיקציה.\n"
            "העדף כתיב עברי מקובל, כולל כתיב חסר נפוץ, בלי שגיאות שאינן מקובלות.\n"
            "אל תכניס ביטויים ארוכים מדי; עדיף מילים בודדות או צירופים קצרים.\n"
            "החזר בצורה: {\"candidates\":[\"...\"],\"notes\":[\"...\"]}\n\n"
            f"שם הצופן: {title}\n"
            f"שאלה מנחה: {question}\n"
        )
        body = {"model": model, "input": prompt}
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            "https://api.openai.com/v1/responses",
            data=data,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                response_data = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"שגיאת OpenAI {e.code}: {detail[:800]}") from e
        text = self.extract_openai_response_text(response_data)
        parsed = self.parse_ai_research_json(text)
        raw_candidates = parsed.get("candidates", []) if isinstance(parsed, dict) else []
        out = []
        seen = set()
        for word in raw_candidates if isinstance(raw_candidates, list) else []:
            clean = self.engine.normalize_word(str(word))
            key = canonical_hebrew(clean)
            if 2 <= len(key) <= 14 and key not in seen:
                seen.add(key)
                out.append(clean)
        return out[:1200]

    def fetch_ai_decode_interpretation(self, question: str, title: str, evidence: dict, api_key: str) -> str:
        model = os.environ.get("GAL_EINAI_OPENAI_MODEL", "gpt-4.1")
        compact_evidence = json.dumps(evidence, ensure_ascii=False)[:18000]
        prompt = (
            "אתה מסייע בניתוח זהיר של ממצאי צופן תורה לאחר סריקה בפועל.\n"
            "כלל ברזל: מותר להתייחס רק למילים, חזרות, דילוגים, מרחקים וזוגות שמופיעים בנתוני הראיות. "
            "אסור להוסיף מילה שלא נמצאה ואסור להציג השערה כעובדה.\n"
            "ענה בעברית, בצורה מסודרת, עם סעיפים: ממצאים מרכזיים, קשר לשאלה המנחה, חיזוקים, חולשות/מה חסר, בדיקות המשך.\n"
            "אם אין מספיק נתונים, אמור זאת במפורש.\n"
            "במקרים רגישים או אנשים חיים השתמש בלשון אפשרות בלבד, בלי אשמה או הכרעה.\n\n"
            f"שם הצופן: {title}\n"
            f"שאלה מנחה: {question}\n"
            f"ראיות מסריקת התוכנה בפועל:\n{compact_evidence}"
        )
        body = {"model": model, "input": prompt}
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            "https://api.openai.com/v1/responses",
            data=data,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=120) as response:
                response_data = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")
            if e.code == 429 and "insufficient_quota" in detail:
                raise RuntimeError("נדרש תשלום או קרדיט להפעלת פענוח AI חי (insufficient_quota)") from e
            raise RuntimeError(f"שגיאת OpenAI {e.code}: {detail[:800]}") from e
        text = self.extract_openai_response_text(response_data)
        if not text:
            raise RuntimeError("OpenAI לא החזיר ניתוח שניתן לקרוא")
        return text.strip()

    def extract_openai_response_text(self, response_data: dict) -> str:
        texts = []
        if isinstance(response_data.get("output_text"), str):
            texts.append(response_data["output_text"])
        for item in response_data.get("output", []) if isinstance(response_data.get("output"), list) else []:
            if not isinstance(item, dict):
                continue
            for content in item.get("content", []) if isinstance(item.get("content"), list) else []:
                if not isinstance(content, dict):
                    continue
                value = content.get("text") or content.get("output_text")
                if isinstance(value, str):
                    texts.append(value)
        return "\n".join(t for t in texts if t).strip()

    def parse_ai_research_json(self, text: str) -> dict:
        cleaned = text.strip()
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\s*```$", "", cleaned)
        try:
            return json.loads(cleaned)
        except Exception:
            match = re.search(r"\{.*\}", cleaned, flags=re.S)
            if not match:
                raise
            return json.loads(match.group(0))

    def normalize_ai_research_payload(self, data: dict, topic: str) -> dict:
        if not isinstance(data, dict):
            raise ValueError("תשובת AI אינה JSON תקין")
        groups_in = data.get("secondary_groups") if isinstance(data.get("secondary_groups"), dict) else {}
        groups_out: Dict[str, List[str]] = {}
        suggestions = []
        sources = []

        def add_word(group_name: str, item):
            if isinstance(item, dict):
                word = item.get("word") or item.get("term") or item.get("phrase") or item.get("מילה")
                reason = str(item.get("reason") or item.get("סיבה") or "מילה מרכזית לפי מחקר AI")
                item_sources = item.get("sources") or item.get("מקורות") or []
            else:
                word = str(item)
                reason = "מילה מרכזית לפי מחקר AI"
                item_sources = []
            clean = self.engine.normalize_word(str(word or ""))
            if not clean:
                return
            groups_out.setdefault(group_name, []).append(clean)
            suggestions.append({"word": clean, "reason": reason, "priority": "גבוה"})
            if isinstance(item_sources, str):
                item_sources = [item_sources]
            for source in item_sources if isinstance(item_sources, list) else []:
                source = str(source).strip()
                if source and source not in sources:
                    sources.append(source)

        for group_name, items in groups_in.items():
            if isinstance(items, list):
                for item in items:
                    add_word(str(group_name), item)
        for item in data.get("secondary", []) if isinstance(data.get("secondary"), list) else []:
            add_word("שונות", item)

        secondary = []
        seen = set()
        for words in groups_out.values():
            for word in words:
                key = canonical_hebrew(word)
                if key not in seen:
                    seen.add(key)
                    secondary.append(word)
        primary = data.get("primary", []) if isinstance(data.get("primary"), list) else []
        dates = data.get("dates", []) if isinstance(data.get("dates"), list) else []
        recommendation = data.get("recommendation") if isinstance(data.get("recommendation"), dict) else {}
        recommendation.setdefault("mode", "צופן")
        recommendation.setdefault("skip_from", 0)
        recommendation.setdefault("skip_to", 800)
        recommendation.setdefault("min_secondary", min(5, max(1, len(secondary) // 8)))
        notes = data.get("notes", []) if isinstance(data.get("notes"), list) else []
        notes = [str(x) for x in notes]
        notes.insert(0, "בוצע מחקר AI עם חיפוש רשת. יש לבדוק את המילים והמקורות לפני חיפוש.")
        if sources:
            notes.append("מקורות שנזכרו: " + "; ".join(sources[:12]))
        return {
            "topic": data.get("topic") or topic,
            "source": "openai_web_research",
            "primary": primary,
            "secondary": secondary,
            "secondary_groups": groups_out,
            "primary_suggestions": [{"word": self.engine.normalize_word(str(w)), "reason": "ראשית שהוצעה במחקר AI", "priority": "גבוה"} for w in primary if self.engine.normalize_word(str(w))],
            "secondary_suggestions": suggestions,
            "dates_and_years": dates,
            "recommendation": recommendation,
            "notes": notes,
        }

    def build_local_ai_keyword_suggestions(self, topic: str) -> dict:
        raw_tokens = re.split(r"[\s,;:|/\\-]+", topic)
        topic_words = [self.engine.normalize_word(t) for t in raw_tokens if self.engine.normalize_word(t)]
        aliases = self.local_ai_keyword_aliases()
        primary = []
        if topic_words:
            joined = self.engine.normalize_word("".join(topic_words))
            if len(joined) >= 4:
                primary.append(joined)
            primary.extend(topic_words)

        groups = self.local_ai_topic_groups(topic_words)
        secondary = []
        for words in groups.values():
            secondary.extend(words)
        for word in topic_words:
            secondary.extend(aliases.get(canonical_hebrew(word), []))
        secondary.extend(["משיח", "גאולה", "ישראל", "ירושלים"] if any(w in ("גוג", "מגוג", "מלחמה") for w in map(canonical_hebrew, topic_words)) else [])

        years = []
        for token in topic_words:
            if re.search(r"תשפ|התשפ", token):
                years.append(token)
        years.extend(["התשפו", "תשפו"] if any(w in ("משיח", "גאולה") for w in map(canonical_hebrew, topic_words)) else [])

        def unique(words):
            out = []
            seen = set()
            for word in words:
                clean = self.engine.normalize_word(word)
                if not clean:
                    continue
                key = canonical_hebrew(clean)
                if key in seen:
                    continue
                seen.add(key)
                out.append(clean)
            return out

        primary = unique(primary)
        primary_keys = {canonical_hebrew(x) for x in primary[:1]}
        secondary = [w for w in unique(secondary) if canonical_hebrew(w) not in primary_keys]
        years = unique(years)
        clean_groups = {}
        used = set(primary_keys)
        for group_name, words in groups.items():
            group_words = []
            for word in unique(words):
                key = canonical_hebrew(word)
                if key in used:
                    continue
                used.add(key)
                group_words.append(word)
            if group_words:
                clean_groups[group_name] = group_words
        if "כללי" not in clean_groups:
            general = [w for w in secondary if canonical_hebrew(w) not in used]
            if general:
                clean_groups["כללי"] = general[:18]
        return {
            "topic": topic,
            "primary": primary[:6],
            "secondary": secondary[:120],
            "secondary_groups": clean_groups,
            "primary_suggestions": [{"word": w, "reason": "נלקח מתוך הנושא או מצירוף מילות הנושא", "priority": "גבוה" if i == 0 else "בינוני"} for i, w in enumerate(primary[:6])],
            "secondary_suggestions": [{"word": w, "reason": "מילה קשורה לנושא לפי מילון פנימי ראשוני", "priority": "בינוני"} for w in secondary[:80]],
            "dates_and_years": years[:8],
            "recommendation": {"mode": "צופן", "skip_range": "0-800", "skip_from": 0, "skip_to": 800, "try_long_secondary_primary": False, "min_secondary": 1},
            "notes": [
                "לא בוצע חיפוש ברשת. אלו הצעות ממאגר מקומי ראשוני בלבד.",
                "זהו כלי עזר מקומי, לא מסקנה.",
                "יש לערוך ולאשר את המילים לפני חיפוש.",
                "רק מילים באורך 3-5 אותיות מסומנות כברירת מחדל. מילים באורך 2 או מעל 5 נשארות לבחירה ידנית.",
                f"מילים קצרות מדי יסוננו בעת העברה לשדות {APP_VERSION}."
            ],
        }

    def local_ai_keyword_aliases(self) -> Dict[str, List[str]]:
        raw_aliases = {
            "משיח": ["גאולה", "דוד", "מלך", "צמח", "מקדש", "התשפו", "תשפו"],
            "גאולה": ["משיח", "מקדש", "ציון", "ירושלים", "דוד", "תשפו", "קץ", "ישועה", "נחמה"],
            "גוג": ["מגוג", "מלחמה", "אדום", "ישמעאל", "משיח", "גאולה", "צפון", "אחרית"],
            "מגוג": ["גוג", "מלחמה", "אדום", "ישמעאל", "משיח", "גאולה", "צפון", "אחרית"],
            "מלחמה": ["גוג", "מגוג", "אויב", "שלום", "ישראל", "ירושלים", "צבא", "חרב", "אש", "דם", "חיל", "נצחון"],
            "רעידה": ["אדמה", "רעש", "ארץ", "הר", "תהום", "פחד"],
            "אדמה": ["רעידה", "רעש", "ארץ", "תהום"],
            "ירושלים": ["ציון", "מקדש", "ישראל", "שלום", "גאולה"],
            "ישראל": ["ירושלים", "ציון", "עם", "מלחמה", "שלום", "גאולה"],
            "איראן": ["פרס", "טהרן", "גרעין", "אטום", "טילים", "מלחמה", "ישראל", "נתנז", "איספהן", "כור", "אורניום", "משמרות", "מהפכה"],
            "אירן": ["פרס", "טהרן", "גרעין", "אטום", "טילים", "מלחמה", "ישראל", "נתנז", "איספהן", "כור", "אורניום", "משמרות", "מהפכה"],
            "פרס": ["איראן", "אירן", "טהרן", "מלחמה", "המן", "אחשורוש", "כורש", "דריוש", "שושן", "עילם"],
            "אטום": ["גרעין", "פצצה", "אורניום", "כור", "איראן", "מלחמה", "קרינה", "אש", "השמדה", "סכנה"],
            "גרעין": ["אטום", "פצצה", "אורניום", "כור", "נתנז", "איראן", "העשרה", "טיל", "מלחמה"],
        }
        return {canonical_hebrew(key): value for key, value in raw_aliases.items()}

    def local_ai_topic_groups(self, topic_words: List[str]) -> Dict[str, List[str]]:
        keys = {canonical_hebrew(w) for w in topic_words}
        text_key = canonical_hebrew("".join(topic_words))
        groups: Dict[str, List[str]] = {}

        def add_group(name: str, words: List[str]):
            if name not in groups:
                groups[name] = []
            groups[name].extend(words)

        def has_any(words: List[str]) -> bool:
            normalized = {canonical_hebrew(w) for w in words}
            return bool(keys & normalized) or any(k in text_key for k in normalized)

        if has_any(["איראן", "אירן", "פרס", "אטום", "גרעין"]):
            add_group("מקומות", ["איראן", "אירן", "פרס", "טהרן", "נתנז", "איספהן", "קום", "משהד", "שיראז", "כרמאן", "בושהר", "עילם", "שושן", "בבל"])
            add_group("אנשים/אישים", ["עלי", "חמינאי", "ראיסי", "סולימאני", "המן", "אחשורוש", "כורש", "דריוש"])
            add_group("מושגים", ["אטום", "גרעין", "פצצה", "אורניום", "כור", "טיל", "טילים", "מלחמה", "אש", "עשן", "קרינה", "העשרה", "השמדה", "סכנה", "איום", "חרב", "צבא"])
            add_group("ארגונים", ["משמרות", "מהפכה", "צבא", "חיזבאללה", "מיליציות", "מלכות", "ממשלה"])
            add_group("תארים ותכונות", ["אויב", "רשע", "סכנה", "פחד", "נקמה", "מפלה", "מכה", "נפילה", "חורבן", "תבוסה"])
            add_group("ישראל וגאולה", ["ישראל", "ירושלים", "ציון", "גאולה", "משיח", "מקדש", "שלום", "ישועה", "נצחון"])
        if has_any(["מלחמה", "צבא", "טיל", "טילים", "פצצה"]):
            add_group("מושגים", ["מלחמה", "צבא", "חרב", "אש", "אויב", "נצחון", "שלום", "חיל", "מגן", "חץ", "ירי", "פגיעה", "מכה", "מפלה", "הצלה"])
            add_group("מקומות", ["ישראל", "ירושלים", "ציון", "יהודה", "שומרון", "גליל", "נגב"])
        if has_any(["משיח", "גאולה", "מקדש", "ציון", "ירושלים"]):
            add_group("מילות גאולה", ["משיח", "גאולה", "דוד", "מלך", "צמח", "מקדש", "ציון", "ירושלים", "שלום", "ישועה", "נחמה", "קיבוץ", "גלויות", "תשובה", "מלכות"])
            add_group("תאריכים/כינויים", ["התשפו", "תשפו", "קץ", "אחרית", "בעתה", "אחישנה"])
        if has_any(["עמלק", "המן", "אחשורוש"]):
            add_group("אנשים/אישים", ["עמלק", "המן", "אחשורוש", "אגג", "עשו", "אדום"])
            add_group("מושגים", ["אויב", "רשע", "מלחמה", "מחיה", "זכור", "קרך", "ספק", "ראשית", "אחרית", "מפלה"])
        if not groups:
            add_group("כללי", ["ישראל", "ירושלים", "ציון", "יהודה", "גאולה", "משיח", "מלחמה", "שלום", "מלך", "דוד", "מקדש", "ישועה", "אויב", "רשע", "אש", "חרב", "נצחון", "מפלה", "תשובה", "אחרית"])
        return groups

    def format_ai_keyword_payload(self, payload: dict) -> str:
        def words(items):
            return [str(item.get("word", "")) for item in items if isinstance(item, dict) and item.get("word")]
        lines = [f"נושא: {payload.get('topic', '')}", "", "ראשיות מוצעות:"]
        for idx, word in enumerate(words(payload.get("primary_suggestions", [])), 1):
            lines.append(f"{idx}. {word}")
        lines.extend(["", "משניות מוצעות:"])
        for idx, word in enumerate(words(payload.get("secondary_suggestions", [])), 1):
            lines.append(f"{idx}. {word}")
        lines.extend(["", "תאריכים ושנים:"])
        for word in payload.get("dates_and_years", []):
            lines.append(f"- {word}")
        rec = payload.get("recommendation", {})
        lines.extend([
            "",
            "המלצת חיפוש:",
            f"מצב מומלץ: {rec.get('mode', 'צופן')}",
            f"טווח דילוגים מוצע: {rec.get('skip_range', '0-800')}",
            f"מילים מינימליות מומלצות: {rec.get('min_secondary', 1)}",
            "",
            "הערות:",
        ])
        lines.extend(f"- {note}" for note in payload.get("notes", []))
        return "\n".join(lines)

    def import_ai_keywords(self):
        path = filedialog.askopenfilename(
            title="ייבא מילות AI לחיפוש",
            filetypes=[
                ("AI Keywords", "*.json;*.txt"),
                ("JSON", "*.json"),
                ("Text", "*.txt"),
                ("All", "*.*"),
            ],
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8-sig") as f:
                text = f.read()
            if path.lower().endswith(".json"):
                data = json.loads(text)
                payload = self.parse_ai_keywords_json(data)
            else:
                payload = self.parse_ai_keywords_text(text)
            primary, secondaries, skipped = self.clean_ai_keyword_payload(payload)
            if not primary and not secondaries:
                raise ValueError("לא נמצאו מילים מתאימות לייבוא")
            if primary:
                self.primary_var.set(primary)
            if secondaries:
                self.secondary_var.set(" ".join(secondaries))
            recommendation = payload.get("recommendation", {}) if isinstance(payload.get("recommendation", {}), dict) else {}
            mode = self.normalize_ai_search_mode(recommendation.get("mode") or payload.get("mode"))
            if mode:
                self.mode.set(mode)
            skip_from = recommendation.get("skip_from") or payload.get("skip_from")
            skip_to = recommendation.get("skip_to") or payload.get("skip_to")
            if skip_from and skip_to:
                self.exact_skip.set("")
                self.skip_from.set(int(skip_from))
                self.skip_to.set(int(skip_to))
            min_secondary = recommendation.get("min_secondary") or payload.get("min_secondary")
            if min_secondary not in (None, ""):
                self.min_secondary.set(max(0, int(min_secondary)))
            extended = recommendation.get("try_long_secondary_primary")
            if extended is not None:
                self.opt_try_long_secondary_primary.set(bool(extended))
            self.save_search_state()
            self.save_app_settings()
            warning = f" | דולגו {skipped} מילים קצרות" if skipped else ""
            self.status.set(f"יובאו מילות AI: ראשית {1 if primary else 0}, משניות {len(secondaries)}{warning}")
            rtl_showinfo(
                "ייבוא מילות AI",
                "המילים יובאו לשדות החיפוש.\n"
                "ה-AI משמש רק להכנת מילים; החיפוש בתורה נשאר מקומי וללא AI.\n"
                "יש לעבור על המילים ולאשר שהן מתאימות לפני הרצת חיפוש."
            )
        except Exception as e:
            rtl_showerror("ייבוא מילות AI", f"לא הצלחתי לייבא את הקובץ:\n{e}")

    def parse_ai_keywords_json(self, data: dict) -> dict:
        if not isinstance(data, dict):
            raise ValueError("קובץ JSON צריך להכיל אובייקט ראשי")

        def values_from(keys):
            items = []
            for key in keys:
                value = data.get(key)
                if isinstance(value, list):
                    items.extend(value)
                elif value:
                    items.append(value)
            return items

        def words_from(items):
            words = []
            for item in items:
                if isinstance(item, dict):
                    base = item.get("word") or item.get("term") or item.get("phrase") or item.get("מילה") or item.get("ביטוי")
                    alternatives = item.get("alternatives") or item.get("alternate") or item.get("כתיב חלופי") or []
                    if base:
                        words.append(str(base))
                    if isinstance(alternatives, str):
                        words.append(alternatives)
                    elif isinstance(alternatives, list):
                        words.extend(str(x) for x in alternatives if x)
                elif isinstance(item, str):
                    words.append(item)
            return words

        recommendation = data.get("recommendation") or data.get("המלצת חיפוש") or {}
        if not isinstance(recommendation, dict):
            recommendation = {"mode": recommendation}
        skip_range = recommendation.get("skip_range") or recommendation.get("טווח דילוגים מוצע") or data.get("skip_range")
        if isinstance(skip_range, str):
            m = re.search(r"(\d+)\D+(\d+)", skip_range)
            if m:
                recommendation.setdefault("skip_from", int(m.group(1)))
                recommendation.setdefault("skip_to", int(m.group(2)))

        return {
            "topic": data.get("topic") or data.get("נושא") or "",
            "primary": words_from(values_from(["primary", "primaries", "primary_suggestions", "ראשיות מוצעות", "ראשיות"])),
            "secondary": words_from(values_from(["secondary", "secondaries", "secondary_suggestions", "משניות מוצעות", "משניות"])),
            "dates": words_from(values_from(["dates", "years", "dates_and_years", "תאריכים ושנים", "תאריכים", "שנים"])),
            "recommendation": recommendation,
        }

    def parse_ai_keywords_text(self, text: str) -> dict:
        sections = {"primary": [], "secondary": [], "dates": []}
        current = None
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if "ראשיות" in line or line.startswith("ראשית"):
                current = "primary"
                continue
            if "משניות" in line or line.startswith("משנית"):
                current = "secondary"
                continue
            if "תאריכים" in line or "שנים" in line:
                current = "dates"
                continue
            if "המלצת חיפוש" in line or "הערות" in line:
                current = None
                continue
            if current:
                cleaned = re.sub(r"^[\-\*\d\.\)\s]+", "", line)
                cleaned = re.sub(r"^(מילה|ביטוי|כתיב חלופי|עדיפות|סיבה)\s*[:：]\s*", "", cleaned)
                if cleaned and not cleaned.startswith(("סיבה:", "עדיפות:")):
                    sections[current].append(cleaned)
        return sections

    def clean_ai_keyword_payload(self, payload: dict) -> Tuple[str, List[str], int]:
        primary_candidates = payload.get("primary", []) if isinstance(payload.get("primary", []), list) else []
        secondary_candidates = []
        secondary_candidates.extend(payload.get("secondary", []) if isinstance(payload.get("secondary", []), list) else [])
        secondary_candidates.extend(payload.get("dates", []) if isinstance(payload.get("dates", []), list) else [])
        skipped = 0

        def clean_one(value: str, allow_short: bool = False) -> Optional[str]:
            nonlocal skipped
            word = self.engine.normalize_word(str(value).replace("*", ""))
            if not word:
                return None
            if len(word) < 4 and not allow_short:
                skipped += 1
                return None
            return word

        primary = ""
        for candidate in primary_candidates:
            word = clean_one(candidate)
            if word:
                primary = word
                break

        seen = {canonical_hebrew(primary)} if primary else set()
        secondaries = []
        for candidate in secondary_candidates:
            word = clean_one(candidate)
            if not word:
                continue
            key = canonical_hebrew(word)
            if key in seen:
                continue
            seen.add(key)
            secondaries.append(word)
        return primary, secondaries, skipped

    def normalize_ai_search_mode(self, value) -> Optional[str]:
        raw = str(value or "").strip().lower()
        if not raw:
            return None
        if "טק" in raw and "ד" in raw:
            return "text_skip"
        if "טקסט" in raw:
            return "text"
        if "רגיל" in raw:
            return "regular"
        if "צופן" in raw or "code" in raw:
            return "code"
        return None

    def load_project_dict(self, data: dict):
        if hasattr(self, "primary_var"):
            self.primary_var.set(str(data.get("primary", "")))
            self.secondary_var.set(str(data.get("secondary", "")))
            self.exact_skip.set(str(data.get("exact_skip", "")))
            live_value = str(data.get("live_skip", "")).strip()
            self.set_live_skip_display(live_value or self.initial_live_skip_value())
            self.mode.set(str(data.get("mode", "code") or "code"))
            self.skip_from.set(int(data.get("skip_from", 0) or 0))
            self.skip_to.set(int(data.get("skip_to", 800) or 800))
            self.initial_skip_range = (int(self.skip_from.get()), int(self.skip_to.get()))
            self.min_secondary.set(int(data.get("min_secondary", 0) or 0))

        options = data.get("options", {}) if isinstance(data.get("options", {}), dict) else {}
        self.opt_mark_borders.set(bool(options.get("mark_borders", self.opt_mark_borders.get())))
        self.opt_spp_labels.set(bool(options.get("spp_labels", self.opt_spp_labels.get())))
        self.opt_word_colors.set(bool(options.get("word_colors", self.opt_word_colors.get())))
        self.opt_word_spaces.set(bool(options.get("word_spaces", self.opt_word_spaces.get())))
        self.opt_avot_ticker.set(bool(options.get("avot_ticker", self.opt_avot_ticker.get())))
        try:
            self.avot_ticker_speed_var.set(max(1, min(10, int(options.get("avot_ticker_speed", self.avot_ticker_speed_var.get()) or self.avot_ticker_speed_var.get()))))
        except Exception:
            self.avot_ticker_speed_var.set(4)
        avot_order = str(options.get("avot_ticker_order", self.avot_ticker_order_var.get()) or "ordered")
        self.avot_ticker_order_var.set(avot_order if avot_order in ("ordered", "random") else "ordered")
        font_mode = str(options.get("font_mode", self.font_mode_var.get()) or self.font_mode_var.get())
        if font_mode not in ("regular", "ashkenaz", "sefarad"):
            font_mode = "ashkenaz" if bool(options.get("ashuri_font", False)) else "regular"
        self.font_mode_var.set(font_mode)
        cursor_mode = str(options.get("cursor_mode", self.cursor_mode_var.get()) or self.cursor_mode_var.get())
        if cursor_mode == "hand":
            cursor_mode = "yad"
        self.cursor_mode_var.set(cursor_mode if cursor_mode in ("yad", "arrow") else "yad")
        self.opt_date_fraction_fallback.set(bool(options.get("date_fraction_fallback", self.opt_date_fraction_fallback.get())))
        self.opt_auto_advance_skip.set(bool(options.get("extend_beyond_skip_range", options.get("auto_advance_skip", self.opt_auto_advance_skip.get()))))
        self.opt_primary_text_mark.set(bool(options.get("primary_text_mark", self.opt_primary_text_mark.get())))
        self.opt_secondary_text_mark.set(bool(options.get("secondary_text_mark", self.opt_secondary_text_mark.get())))
        self.opt_try_long_secondary_primary.set(bool(options.get("try_long_secondary_primary", self.opt_try_long_secondary_primary.get())))
        self.opt_min_secondary_all.set(bool(options.get("min_secondary_all", self.opt_min_secondary_all.get())))
        self.opt_minimal_search.set(bool(options.get("minimal_search", self.opt_minimal_search.get())))
        self.opt_current_view_only.set(bool(options.get("current_view_only", self.opt_current_view_only.get())))
        self.results_height = max(4, min(26, int(options.get("results_height", self.results_height) or self.results_height)))
        self.results_panel_height = max(160, min(900, int(options.get("results_panel_height", getattr(self, "results_panel_height", 280)) or 280)))
        if hasattr(self, "results"):
            self.results.configure(height=self.results_height)

        loaded_saved: List[Tuple[Match, List[Match]]] = []
        for item in data.get("saved", []):
            if not isinstance(item, dict):
                continue
            pm = match_from_dict(item.get("primary", {}))
            local = [match_from_dict(m) for m in item.get("matches", []) if isinstance(m, dict)]
            if not any(m.kind == "primary" and m.word == pm.word and m.start == pm.start and m.skip == pm.skip for m in local):
                local.insert(0, pm)
            self.apply_word_colors([pm] + local)
            loaded_saved.append((pm, TorahCanvas.drop_matches_inside_longer(local)))
        self.saved = loaded_saved
        try:
            requested_current = int(data.get("current", 0) or 0)
        except (TypeError, ValueError):
            requested_current = 0
        self.current = max(0, min(requested_current, len(self.saved) - 1)) if self.saved else 0
        if hasattr(self, "canvas"):
            self.canvas.manual_marks = [match_from_dict(m) for m in data.get("manual_marks", []) if isinstance(m, dict)]
            self.apply_display_options()
            if self.saved:
                self.display_current()
            else:
                self.current_display_match = None
                self.canvas.set_matches([])
                self.results.delete(0, "end")
                self.result_rows = []
                self.update_context_header()
        self.save_app_settings()

    def load_search_state(self) -> dict:
        try:
            if not os.path.exists(SEARCH_STATE_FILE):
                return {}
            with open(SEARCH_STATE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict) or data.get("cleared"):
                return {}
            return data
        except Exception:
            return {}

    def save_search_state(self):
        data = {
            "primary": self.get_primary_word(),
            "secondary": self.secondary_var.get() if hasattr(self, "secondary_var") else "",
            "cleared": False,
        }
        with open(SEARCH_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        self.remember_recent_search(data["primary"], data["secondary"])

    def clean_recent_searches(self, raw) -> List[dict]:
        limit = max(1, int(getattr(self, "recent_search_limit", 20) or 20))
        cleaned = []
        seen = set()
        if not isinstance(raw, list):
            return cleaned
        for item in raw:
            if not isinstance(item, dict):
                continue
            primary = str(item.get("primary", "") or "").strip()
            secondary = str(item.get("secondary", "") or "").strip()
            if not primary and not secondary:
                continue
            key = (primary, secondary)
            if key in seen:
                continue
            seen.add(key)
            cleaned.append({"primary": primary, "secondary": secondary})
            if len(cleaned) >= limit:
                break
        return cleaned

    def remember_recent_search(self, primary: str, secondary: str):
        primary = str(primary or "").strip()
        secondary = str(secondary or "").strip()
        if not primary and not secondary:
            return
        existing = getattr(self, "recent_searches", [])
        item = {"primary": primary, "secondary": secondary}
        merged = [item]
        for old in existing:
            if not isinstance(old, dict):
                continue
            old_primary = str(old.get("primary", "") or "").strip()
            old_secondary = str(old.get("secondary", "") or "").strip()
            if (old_primary, old_secondary) == (primary, secondary):
                continue
            if old_primary or old_secondary:
                merged.append({"primary": old_primary, "secondary": old_secondary})
        limit = max(1, int(getattr(self, "recent_search_limit", 20) or 20))
        self.recent_searches = merged[:limit]
        self.save_app_settings()

    def set_recent_search_limit(self):
        current = max(1, int(getattr(self, "recent_search_limit", 20) or 20))
        value = simpledialog.askinteger(
            "חיפושים אחרונים",
            "כמה חיפושים אחרונים לשמור ולהציג?",
            parent=self.root,
            initialvalue=current,
            minvalue=1,
            maxvalue=200,
        )
        if value is None:
            return
        self.recent_search_limit = max(1, int(value))
        self.recent_searches = self.clean_recent_searches(getattr(self, "recent_searches", []))
        self.save_app_settings()
        self.status.set(f"מספר החיפושים האחרונים עודכן ל-{self.recent_search_limit}")

    def recent_search_label(self, item: dict, index: int) -> str:
        primary = str(item.get("primary", "") or "").strip() or "-"
        secondary = str(item.get("secondary", "") or "").strip()
        if secondary:
            return f"{index}. ראשית: {primary} | משניות: {secondary}"
        return f"{index}. ראשית: {primary}"

    def apply_recent_search(self, item: dict, win=None):
        primary = str(item.get("primary", "") or "").strip()
        secondary = str(item.get("secondary", "") or "").strip()
        if hasattr(self, "primary_var"):
            self.primary_var.set(primary)
        if hasattr(self, "secondary_var"):
            self.secondary_var.set(secondary)
        self.save_search_state()
        if win is not None:
            win.destroy()
        self.status.set("החיפוש האחרון נטען לשדות החיפוש")

    def open_recent_searches(self):
        items = self.clean_recent_searches(getattr(self, "recent_searches", []))
        if not items:
            rtl_showinfo("חיפושים אחרונים", "עדיין אין חיפושים אחרונים שמורים.")
            return
        win = tk.Toplevel(self.root)
        win.title("חיפושים אחרונים")
        win.transient(self.root)
        self.prepare_child_window(win, 640, 420)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(1, weight=1)
        ttk.Label(
            frame,
            text=f"חיפושים אחרונים: {len(items)} מתוך {max(1, int(getattr(self, 'recent_search_limit', 20) or 20))}",
            font=("Arial", 11, "bold"),
            anchor="e",
        ).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        listbox = tk.Listbox(frame, height=min(16, max(6, len(items))), font=("Arial", 11), activestyle="dotbox")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=listbox.yview)
        listbox.configure(yscrollcommand=scroll.set)
        listbox.grid(row=1, column=0, sticky="nsew")
        scroll.grid(row=1, column=1, sticky="ns")
        for idx, item in enumerate(items, 1):
            listbox.insert("end", self.recent_search_label(item, idx))
        if items:
            listbox.selection_set(0)
            listbox.activate(0)

        def selected_item():
            sel = listbox.curselection()
            if not sel:
                return None
            return items[int(sel[0])]

        def load_selected(_event=None):
            item = selected_item()
            if item is not None:
                self.apply_recent_search(item, win)
            return "break"

        buttons = ttk.Frame(frame)
        buttons.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        ttk.Button(buttons, text="טען לשדות", command=load_selected).pack(side="right", padx=(0, 4))
        ttk.Button(buttons, text="סגור", command=win.destroy).pack(side="left")
        listbox.bind("<Double-Button-1>", load_selected)
        listbox.bind("<Return>", load_selected)
        listbox.focus_set()

    def clear_search_state(self):
        try:
            with open(SEARCH_STATE_FILE, "w", encoding="utf-8") as f:
                json.dump({"cleared": True}, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def build_ui(self):
        style = ttk.Style()
        style.configure("TButton", padding=(4, 2), font=("Arial", 11))
        style.configure("Bold.TButton", padding=(4, 2), font=("Arial", 12, "bold"))
        style.configure("Toolbutton", padding=(4, 2), font=("Arial", 11))
        style.configure("TRadiobutton", padding=(2, 1))
        style.configure("TCheckbutton", padding=(2, 1))
        style.configure("Compact.TLabel", padding=(0, 1))
        style.configure("Right.TNotebook", tabposition="ne")
        style.configure("Right.TNotebook.Tab", anchor="e")
        self.build_menu()
        self.root.bind("<Return>", self.on_global_enter)
        self.root.bind("<KP_Enter>", self.on_global_enter)
        for key in ("<Left>", "<Right>", "<Up>", "<Down>", "<KP_Left>", "<KP_Right>", "<KP_Up>", "<KP_Down>", "<Prior>", "<Next>", "<Home>", "<End>"):
            self.root.bind_all(key, self.on_global_arrow, add="+")
        for key in ("<KeyRelease-Left>", "<KeyRelease-Right>", "<KeyRelease-Up>", "<KeyRelease-Down>", "<KeyRelease-KP_Left>", "<KeyRelease-KP_Right>", "<KeyRelease-KP_Up>", "<KeyRelease-KP_Down>", "<KeyRelease-Prior>", "<KeyRelease-Next>", "<KeyRelease-Home>", "<KeyRelease-End>"):
            self.root.bind_all(key, self.on_global_arrow_release, add="+")

        def live_button(parent, text, command, bg, active, fg="#102030", width=6, height=1, font_size=11):
            return tk.Button(
                parent,
                text=text,
                width=width,
                height=height,
                command=command,
                bg=bg,
                activebackground=active,
                fg=fg,
                activeforeground=fg,
                font=("Arial", font_size, "bold"),
                relief="raised",
                bd=1,
                cursor="hand2",
            )

        top = ttk.Frame(self.root, padding=2)
        top.pack(side="top", fill="x")
        top.columnconfigure(0, weight=0)
        top.columnconfigure(1, weight=1)
        top.columnconfigure(2, weight=0)
        self.status = tk.StringVar(value="טוען...")
        self.status_display = tk.StringVar(value=rtl_display("טוען..."))
        self.status.trace_add("write", self.update_status_display)
        self.status.trace_add("write", self.on_status_write)
        self.panel_btn = ttk.Button(top, text="הצג ממשק", width=11, command=self.toggle_panel)
        add_tooltip(self.panel_btn, "מציג את לוח החיפוש כאשר הוא מוסתר.")
        self.panel_btn.grid(row=0, column=0, sticky="w", padx=1)
        self.panel_btn.grid_remove()
        self.bsiyata_label = ttk.Label(
            top,
            text="בסיעתא דשמייא",
            anchor="e",
            padding=(5, 1),
            font=("Arial", 10, "bold"),
        )
        self.bsiyata_label.grid(row=0, column=2, sticky="e", padx=(4, 2))
        self.progress = ttk.Progressbar(top, mode="determinate", length=170)
        self.progress.grid(row=0, column=1, sticky="e", padx=(2, 92), pady=2)
        add_tooltip(self.progress, "מציג התקדמות בחיפוש או בסריקה כאשר יש פעולה שרצה ברקע.")

        self.app_title = tk.StringVar(value="גל עיני - תוכנה לחיפוש צפנים בתורה")
        self.app_title_display = tk.StringVar(value=rtl_display(self.app_title.get()))
        self.app_title.trace_add("write", self.update_app_title_display)
        self.app_title_label = ttk.Label(
            top,
            textvariable=self.app_title_display,
            anchor="center",
            justify="center",
            padding=(5, 1),
            font=("Arial", 14, "bold"),
        )
        self.app_title_label.grid(row=0, column=1, sticky="ew", padx=6)
        add_tooltip(self.app_title_label, "כותרת התוכנה.")
        self.current_skip_banner = tk.StringVar(value="טבלה בדילוג: 40")
        self.current_skip_banner_display = tk.StringVar(value=rtl_display(self.current_skip_banner.get()))
        self.current_skip_banner.trace_add("write", self.update_current_skip_display)
        self.avot_ticker_frame = ttk.Frame(top)
        self.avot_ticker_canvas = tk.Canvas(
            self.avot_ticker_frame,
            height=27,
            bg="#f7f3e8",
            highlightthickness=0,
            bd=0,
        )
        self.avot_prev_button = ttk.Button(self.avot_ticker_frame, text="‹", width=2, command=lambda: self.step_avot_ticker(-1))
        self.avot_next_button = ttk.Button(self.avot_ticker_frame, text="›", width=2, command=lambda: self.step_avot_ticker(1))
        self.avot_prev_button.pack(side="right", padx=(3, 0))
        self.avot_next_button.pack(side="left", padx=(0, 3))
        self.avot_ticker_canvas.pack(side="left", fill="x", expand=True)
        for widget in (self.avot_ticker_frame, self.avot_ticker_canvas, self.avot_prev_button, self.avot_next_button):
            widget.bind("<Enter>", self.pause_avot_ticker)
            widget.bind("<Leave>", self.resume_avot_ticker)
        self.avot_ticker_canvas.bind("<Configure>", lambda _event: self.show_avot_ticker_window() if not self.avot_ticker_groups else None)
        add_tooltip(self.avot_ticker_canvas, "משנה שלמה ממסכת אבות נעה בשורה אחת משמאל לימין. המשנה הבאה מתחילה אחרי רווח של כ-15 אותיות; עמידת העכבר עוצרת.")
        add_tooltip(self.avot_prev_button, "משנה קודמת באבות.")
        add_tooltip(self.avot_next_button, "משנה הבאה באבות.")

        self.context_title = tk.StringVar(value="")
        self.context_title_display = tk.StringVar(value="")
        self.context_title.trace_add("write", self.update_context_title_display)
        self.context_label = ttk.Label(
            self.root,
            textvariable=self.context_title_display,
            anchor="e",
            padding=(5, 2),
            font=("Arial", 10, "bold"),
        )
        self.context_label.pack_forget()
        add_tooltip(self.context_label, "כותרת התצוגה: הדילוג הנוכחי והמילים שנמצאו ונראות במסך.")

        self.pane = ttk.PanedWindow(self.root, orient="horizontal")
        self.pane.pack(fill="both", expand=True)

        self.target_side_width = 300
        self.side = ttk.Frame(self.pane, padding=1, width=self.target_side_width)
        self.side.pack_propagate(False)
        self.side.grid_propagate(False)
        self.display = ttk.Frame(self.pane)
        self.display_status_bar = ttk.Frame(self.display)
        self.display_status_bar.pack(side="top", fill="x", pady=(0, 1))
        self.bottom_controls_visible = bool(getattr(self, "bottom_controls_visible", True))
        self.bottom_controls_toggle_btn = tk.Button(
            self.display_status_bar,
            text="▾",
            width=2,
            command=self.toggle_bottom_controls,
            bg="#eeeeee",
            activebackground="#dddddd",
            fg="#222222",
            font=("Arial", 9, "bold"),
            relief="raised",
            bd=1,
            cursor="hand2",
        )
        self.bottom_controls_toggle_btn.pack(side="left", padx=(0, 2), pady=0)
        self.add_shortcut_tooltip(self.bottom_controls_toggle_btn, "הסתר / הצג את שורת הכפתורים התחתונה כדי להגדיל את שטח תצוגת התורה.", "הסתר / הצג תחתון")
        self.status_label = tk.Label(
            self.display_status_bar,
            textvariable=self.status_display,
            anchor="e",
            justify="right",
            padx=6,
            pady=0,
            font=("Arial", 10, "bold"),
            bg="#fff3cd",
            fg="#3d2b00",
        )
        self.status_label.pack(side="left", fill="x", expand=True)
        self.current_skip_label = tk.Label(
            self.display_status_bar,
            textvariable=self.current_skip_banner_display,
            anchor="center",
            bg="#fff3cd",
            fg="#7a3b00",
            bd=1,
            relief="solid",
            padx=12,
            pady=2,
            font=("Arial", 18, "bold"),
        )
        self.current_skip_label.pack(side="right", fill="y", padx=(2, 0))
        add_tooltip(self.current_skip_label, "הדילוג שמוצג עכשיו בתצוגת התורה.")
        context_words_width = min(1180, max(460, int(self.root.winfo_screenwidth() * 0.64)))
        self.context_words_container = tk.Frame(self.display, bg="#fff3cd")
        self.context_words_container.pack(side="top", anchor="w", padx=0, pady=(0, 1))
        self.context_words_canvas = tk.Canvas(
            self.context_words_container,
            width=context_words_width,
            height=31,
            bg="#fff3cd",
            highlightthickness=0,
            bd=0,
            xscrollincrement=24,
        )
        self.context_words_scrollbar = ttk.Scrollbar(
            self.context_words_container,
            orient="horizontal",
            command=self.context_words_canvas.xview,
        )
        self.context_words_canvas.configure(xscrollcommand=self.context_words_scrollbar.set)
        self.context_words_canvas.pack(side="top", fill="x", expand=True)
        self.context_words_frame = tk.Frame(self.context_words_canvas, bg="#fff3cd")
        self.context_words_window = self.context_words_canvas.create_window(
            (0, 0),
            window=self.context_words_frame,
            anchor="nw",
        )
        self.context_words_frame.bind("<Configure>", self.on_context_words_configure)
        self.context_words_canvas.bind("<Configure>", self.on_context_words_canvas_configure)
        self.context_words_canvas.bind("<Shift-MouseWheel>", self.on_context_words_mousewheel)
        self.context_word_targets = []
        self.context_word_widgets = []
        self.pane.add(self.display, weight=1)
        self.pane.add(self.side, weight=0)
        self.root.after_idle(self.apply_side_width)
        self.root.after(300, self.apply_side_width)
        if not self.side_visible:
            try:
                self.pane.forget(self.side)
                self.panel_btn.grid()
            except Exception:
                pass

        side_header = ttk.Frame(self.side)
        self.results_toggle_container = side_header
        side_header.pack(fill="x", pady=(0, 2))
        self.results_btn = tk.Button(
            side_header,
            text="▤ טבלת ממצאים",
            height=1,
            command=self.toggle_results_table,
            bg="#fff2cc",
            activebackground="#ffe599",
            fg="#5f4300",
            font=("Arial", 10, "bold"),
            relief="raised",
            bd=1,
        )
        self.results_btn.pack(side="left", fill="x", expand=True, padx=(0, 1))
        self.add_shortcut_tooltip(self.results_btn, "פותח את טבלת הצפנים והממצאים על מקום הממשק כדי לתת לה יותר שטח. לחיצה נוספת מחזירה אותה לגודל מצומצם.", "טבלת ממצאים")
        self.hide_panel_btn = tk.Button(
            side_header,
            text="☰ הסתר",
            command=self.toggle_panel,
            bg="#cfe2f3",
            activebackground="#9fc5e8",
            fg="#073763",
            font=("Arial", 10, "bold"),
            relief="raised",
            bd=1,
            cursor="hand2",
        )
        self.hide_panel_btn.pack(side="right", fill="x", expand=True, padx=(1, 0))
        self.add_shortcut_tooltip(self.hide_panel_btn, "מסתיר את לוח החיפוש כדי להשאיר יותר מקום לתצוגת התורה.", "הסתר / הצג ממשק צד")

        self.mode = tk.StringVar(value="code")
        self.saved_text_skip_exact = ""
        mode_header = ttk.Frame(self.side)
        mode_header.pack(anchor="e", fill="x", pady=(0, 1))
        search_btn = tk.Button(
            mode_header,
            text="🔍 חפש",
            width=7,
            height=2,
            command=self.search_or_stop,
            bg="#d9ead3",
            activebackground="#b6d7a8",
            fg="#0b3d1f",
            font=("Arial", 10, "bold"),
            relief="raised",
            bd=1,
        )
        self.search_btn = search_btn
        search_btn.pack(side="left", fill="y", padx=(0, 1))
        self.add_shortcut_tooltip(search_btn, "מחפש את המילה הראשית בדילוגים שנבחרו ומציג טבלת צופן סביב הממצא.", "חפש / עצור")
        recent_btn = tk.Button(
            mode_header,
            text="אחרונים",
            width=7,
            height=2,
            command=self.open_recent_searches,
            bg="#fff2cc",
            activebackground="#ffe599",
            fg="#5f4300",
            font=("Arial", 10, "bold"),
            relief="raised",
            bd=1,
        )
        recent_btn.pack(side="left", fill="y", padx=(0, 2))
        add_tooltip(recent_btn, "פותח רשימת חיפושים אחרונים לפי ראשית ומשניות. את מספר הרשומות אפשר לשנות דרך כלים.")
        undo_btn = tk.Button(
            mode_header,
            text="↶ בטל",
            width=6,
            height=2,
            command=lambda: self.open_field_history_menu("undo"),
            bg="#e8f0fe",
            activebackground="#c9daf8",
            fg="#1c4587",
            font=("Arial", 10, "bold"),
            relief="raised",
            bd=1,
        )
        undo_btn.pack(side="left", fill="y", padx=(0, 1))
        add_tooltip(undo_btn, "פותח רשימת פעולות לביטול בשדה הפעיל.\nקיצור מהיר לצעד אחד: Ctrl+Z")
        redo_btn = tk.Button(
            mode_header,
            text="↷ שוב",
            width=6,
            height=2,
            command=lambda: self.open_field_history_menu("redo"),
            bg="#e8f0fe",
            activebackground="#c9daf8",
            fg="#1c4587",
            font=("Arial", 10, "bold"),
            relief="raised",
            bd=1,
        )
        redo_btn.pack(side="left", fill="y", padx=(0, 1))
        add_tooltip(redo_btn, "פותח רשימת פעולות לביצוע מחדש בשדה הפעיל.\nקיצור מהיר לצעד אחד: Ctrl+Y")
        ttk.Label(mode_header, text="מצב", style="Compact.TLabel").pack(side="right", padx=(2, 0))
        mode_box = ttk.Frame(self.side)
        mode_box.pack(anchor="e", fill="x")
        def add_mode_option(col: int, label: str, value: str, tip: str):
            mode_label = ttk.Label(mode_box, text=label, anchor="center", justify="center", style="Compact.TLabel")
            mode_label.grid(row=0, column=col, sticky="ew", padx=1, pady=(0, 0))
            radio = ttk.Radiobutton(mode_box, text="", variable=self.mode, value=value, width=2)
            radio.grid(row=1, column=col, sticky="n", padx=1, pady=(0, 1))
            mode_label.bind("<Button-1>", lambda _event, mode_value=value: self.mode.set(mode_value))
            add_tooltip(mode_label, tip)
            add_tooltip(radio, tip)
            return radio

        code_mode = add_mode_option(3, "צופן", "code", "חיפוש צופן: מחפש ראשית בטווח הדילוגים, ואז בודק משניות רק במסך הראשית הממורכז לפי גודל התצוגה בזמן החיפוש.")
        regular_mode = add_mode_option(2, "רגיל", "regular", "חיפוש רגיל: מחפש רק את המילה הראשית בכל הדילוגים שנקבעו בשדה הטווח, בלי בדיקת משניות.")
        text_mode = add_mode_option(1, "טקסט", "text", "חיפוש טקסט: מחפש רצף אותיות רגיל בתורה בדילוג 1, בלי טווח דילוגים.")
        text_skip_mode = add_mode_option(0, "טק+ד", "text_skip", "מפגש טקסט+דילוג: הראשית תחופש כטקסט רציף, והמשניות יחופשו במסך הראשית בכל דילוגי הטווח.")
        for col in range(4):
            mode_box.columnconfigure(col, weight=1)
        primary_header = ttk.Frame(self.side)
        primary_header.pack(anchor="e", fill="x", pady=(0, 0))
        ttk.Checkbutton(primary_header, text="גם כטקסט", variable=self.opt_primary_text_mark, command=self.save_app_settings).pack(side="left")
        clear_primary_btn = tk.Button(
            primary_header, text="⌫", width=2, command=self.clear_primary_field,
            bg="#f4cccc", activebackground="#ea9999", fg="#660000",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        clear_primary_btn.pack(side="left", padx=(0, 2))
        add_tooltip(clear_primary_btn, "מנקה את שדה הראשית בלבד.")
        ttk.Label(primary_header, text="ראשית", style="Compact.TLabel").pack(side="right")
        primary_found_label = ttk.Label(primary_header, textvariable=self.primary_found_var, anchor="e", justify="right", style="Compact.TLabel")
        primary_found_label.pack(side="right", padx=(0, 6))
        add_tooltip(primary_found_label, "מספר הראשיות שנמצאו בחיפוש האחרון נשאר מוצג עד ניקוי שדה הראשית.")
        reached_skip_label = ttk.Label(primary_header, textvariable=self.search_reached_skip_var, anchor="e", justify="right", style="Compact.TLabel")
        reached_skip_label.pack(side="right", padx=(0, 6))
        add_tooltip(reached_skip_label, "הדילוג שאליו הגיע החיפוש בזמן מעבר על טווח הדילוגים.")
        self.primary_var = tk.StringVar(value=self.search_state.get("primary", ""))
        self.primary_text = FixedHebrewField(self.side, textvariable=self.primary_var, height=1, width=30, font=("Arial", 11))
        self.primary_text.pack(fill="x")
        add_tooltip(self.primary_text, "המילה או הביטוי הראשי לחיפוש. מומלץ להימנע ממילים קצרות מ-4 אותיות, כי הן מצויות מאוד ועלולות ליצור עומס ואקראיות. אפשר להשתמש בהן רק בצירוף ממצאים קשורים. אפשר להשתמש ב-? במקום אות לא ידועה; כל אות שתימצא במקום זה תתקבל.")
        add_tooltip(primary_header, "כאשר מסומן, אם הראשית מופיעה כרצף טקסט רגיל בתוך מסך הצופן, היא תסומן גם כממצא.")
        self.primary_text.icursor("end")
        self.primary_text.return_command = self.search_cipher
        self.primary_var.trace_add("write", lambda *_args: self.on_search_terms_changed())

        secondary_header = ttk.Frame(self.side)
        secondary_header.pack(anchor="e", fill="x", pady=(0, 0))
        ttk.Checkbutton(secondary_header, text="גם כטקסט", variable=self.opt_secondary_text_mark, command=self.save_app_settings).pack(side="left")
        clear_secondary_btn = tk.Button(
            secondary_header, text="⌫", width=2, command=self.clear_secondary_field,
            bg="#f4cccc", activebackground="#ea9999", fg="#660000",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        clear_secondary_btn.pack(side="left", padx=(0, 2))
        add_tooltip(clear_secondary_btn, "מנקה את שדה המשניות בלבד.")
        scan_existing_secondaries_btn = ttk.Button(secondary_header, text="סרוק", width=5, command=self.scan_secondary_field_all_primaries)
        scan_existing_secondaries_btn.pack(side="left", padx=(2, 0))
        self.add_shortcut_tooltip(scan_existing_secondaries_btn, "סורק את כל המשניות שכבר כתובות בשדה בכל אזורי הראשיות השמורות, בלי לחפש ראשיות מחדש ובלי להוסיף מילים.", "סרוק משניות קיימות")
        scan_all_secondaries_btn = ttk.Button(secondary_header, text="+מילים", width=6, command=self.add_secondary_words_and_scan)
        scan_all_secondaries_btn.pack(side="left", padx=(2, 0))
        self.add_shortcut_tooltip(scan_all_secondaries_btn, "פותח חלון קטן להוספת משניות חדשות, מוסיף אותן לשדה המשניות, וסורק רק אותן בכל אזורי הראשיות שכבר נמצאו.", "הוסף וסרוק משניות")
        ttk.Label(secondary_header, text="משניות", style="Compact.TLabel").pack(side="right")
        self.secondary_var = tk.StringVar(value=self.search_state.get("secondary", ""))
        self.secondary = FixedHebrewField(self.side, textvariable=self.secondary_var, height=2, width=30, font=("Arial", 11))
        self.secondary.pack(fill="x")
        add_tooltip(self.secondary, "מילים נוספות לבדיקה ליד הצופן הראשי. מומלץ לא להכניס מילים בנות פחות מ-4 אותיות, כי הן נפוצות ועלולות להכביד ולהופיע באקראי; יוצא מן הכלל כאשר הן באות עם ממצאים קשורים, למשל שנה והתשפו. אפשר להפריד ברווח, פסיק או נקודה-פסיק. סימן ? משמש כתו חופשי במקום אות לא ידועה. סימן ! לפני מילה קובע שהיא חייבת להימצא בצופן כדי שהצופן יישמר. במפגשים, סמן * ליד המשנית שחייבת לפגוש את הראשית, למשל *משיח.")
        add_tooltip(secondary_header, "כאשר מסומן, משניות שמופיעות כרצף טקסט רגיל בתוך מסך הצופן יסומנו גם כממצא.")
        self.secondary.icursor("end")
        self.secondary.return_command = self.search_cipher
        self.secondary_var.trace_add("write", lambda *_args: self.on_search_terms_changed())
        self.primary_text.set_drag_transfer(self.secondary, target_mode="append", status_callback=self.on_word_field_drag_transfer)
        self.secondary.set_drag_transfer(self.primary_text, target_mode="replace", status_callback=self.on_word_field_drag_transfer)

        self.min_secondary = tk.IntVar(value=0)
        min_secondary_row = ttk.Frame(self.side)
        self.min_secondary_row = min_secondary_row
        min_secondary_row.pack(anchor="e", fill="x", pady=(0, 0))
        ttk.Label(min_secondary_row, text="מינ' משניות").pack(side="right", padx=2)
        min_secondary_spin = tk.Spinbox(
            min_secondary_row,
            from_=0,
            to=20,
            textvariable=self.min_secondary,
            width=3,
            justify="center",
            font=("Arial", 12, "bold"),
            buttonbackground="#fff2cc",
            relief="solid",
            bd=1,
        )
        min_secondary_spin.pack(side="right")
        add_tooltip(min_secondary_spin, "כמה מילים משניות חייבות להימצא ליד הצופן כדי לשמור את הממצא.")
        self.min_secondary.trace_add("write", self.on_min_secondary_changed)
        min_all_check = ttk.Checkbutton(
            min_secondary_row,
            text="כולן",
            variable=self.opt_min_secondary_all,
            command=self.on_min_secondary_all_changed,
        )
        min_all_check.pack(side="right", padx=(2, 4))
        add_tooltip(min_all_check, "כאשר מסומן, צופן יישמר רק אם כל המילים המשניות נמצאו במסך הצופן.")
        self.find_chance_var = tk.StringVar(value="")
        chance_label = ttk.Label(min_secondary_row, textvariable=self.find_chance_var, style="Compact.TLabel")
        chance_label.pack(side="right", padx=(0, 2))
        add_tooltip(chance_label, "סיכוי משוער בלבד לפי מספר המשניות הנדרש מתוך המילים שנכתבו. זה אינו חישוב סטטיסטי ודאי.")
        skip_box = ttk.Frame(self.side)
        skip_box.pack(fill="x", pady=0)
        self.exact_skip = tk.StringVar(value="")
        self.live_skip = tk.StringVar(value=self.initial_live_skip_value())
        self.skip_from = tk.IntVar(value=0)
        self.skip_to = tk.IntVar(value=800)
        self.initial_skip_range = (0, 800)
        self.saved_non_text_skip_fields = {"exact": "", "from": 0, "to": 800}
        self.adjusting_mode_fields = False
        skip_range_row = ttk.Frame(skip_box)
        skip_range_row.pack(anchor="e", fill="x", pady=(0, 0))
        skip_range_group = ttk.Frame(skip_range_row)
        skip_range_group.pack(side="right", padx=(0, 2))
        skip_from_entry = ttk.Entry(skip_range_group, textvariable=self.skip_from, width=5, justify="right")
        self.skip_from_entry = skip_from_entry
        skip_from_entry.pack(side="right", padx=0)
        skip_from_entry.bind("<Return>", self.confirm_skip_fields)
        skip_from_entry.bind("<KP_Enter>", self.confirm_skip_fields)
        add_tooltip(skip_from_entry, "תחילת טווח הדילוגים לחיפוש כאשר אין דילוג מדויק.")
        self.skip_from.trace_add("write", self.on_skip_fields_changed)
        ttk.Label(skip_range_group, text="עד").pack(side="right", padx=2)
        skip_to_entry = ttk.Entry(skip_range_group, textvariable=self.skip_to, width=5, justify="right")
        self.skip_to_entry = skip_to_entry
        skip_to_entry.pack(side="right", padx=0)
        skip_to_entry.bind("<Return>", self.confirm_skip_fields)
        skip_to_entry.bind("<KP_Enter>", self.confirm_skip_fields)
        add_tooltip(skip_to_entry, "סוף טווח הדילוגים. טווח גדול מדי נחסם כדי לא להעמיס על המערכת.")
        self.skip_to.trace_add("write", self.on_skip_fields_changed)
        range_forward_btn = tk.Button(
            skip_range_row, text="טווח+", width=5, command=lambda: self.adjust_skip_range(1),
            bg="#e8f0fe", activebackground="#c9daf8", fg="#1c4587",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        range_forward_btn.pack(side="right", padx=(0, 1))
        add_tooltip(range_forward_btn, "מקפיץ את טווח הדילוגים קדימה בגודל הטווח הנוכחי, למשל 0-800 עובר ל-801-1601.")
        range_back_btn = tk.Button(
            skip_range_row, text="טווח-", width=5, command=lambda: self.adjust_skip_range(-1),
            bg="#e8f0fe", activebackground="#c9daf8", fg="#1c4587",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        range_back_btn.pack(side="right", padx=(0, 1))
        add_tooltip(range_back_btn, "מקפיץ את טווח הדילוגים אחורה בגודל הטווח הנוכחי, למשל 801-1601 חוזר ל-0-800.")
        range_reset_btn = tk.Button(
            skip_range_row, text="אפס", width=4, command=self.reset_skip_range_to_first,
            bg="#fff2cc", activebackground="#ffe599", fg="#5f4300",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        range_reset_btn.pack(side="right", padx=(0, 1))
        add_tooltip(range_reset_btn, "מחזיר תמיד את טווח הדילוגים ל-0-800. החיפוש עצמו מדלג בפועל מדילוג 1 ומעלה.")
        display_fraction_col = tk.LabelFrame(
            skip_range_row,
            text="חש״ר",
            bg=PARCHMENT_BG,
            fg="#333333",
            bd=1,
            relief="solid",
            padx=0,
            pady=0,
            font=("Arial", 7, "bold"),
            labelanchor="n",
        )
        self.display_fraction_row = display_fraction_col
        display_fraction_col.pack(side="left", padx=(2, 0), pady=0)
        view_half_btn = tk.Button(
            display_fraction_col, text="½", width=3, command=lambda: self.apply_display_fraction(2),
            bg=PARCHMENT_BG, activebackground="#eee1c8", fg="#333333",
            font=("Arial", 8, "bold"), relief="flat", bd=0, padx=0, pady=0,
        )
        self.view_half_btn = view_half_btn
        view_half_btn.pack(side="right", pady=0, padx=0)
        add_tooltip(view_half_btn, "חש״ר ללא חיפוש: מציג את אותו אזור בחצי מדילוג התצוגה הנוכחי, בלי להריץ חיפוש ובלי למחוק ממצאים.")
        view_third_btn = tk.Button(
            display_fraction_col, text="⅓", width=3, command=lambda: self.apply_display_fraction(3),
            bg=PARCHMENT_BG, activebackground="#eee1c8", fg="#333333",
            font=("Arial", 8, "bold"), relief="flat", bd=0, padx=0, pady=0,
        )
        self.view_third_btn = view_third_btn
        view_third_btn.pack(side="right", pady=0, padx=0)
        add_tooltip(view_third_btn, "חש״ר ללא חיפוש: מציג את אותו אזור בשליש מדילוג התצוגה הנוכחי, בלי להריץ חיפוש ובלי למחוק ממצאים.")
        view_quarter_btn = tk.Button(
            display_fraction_col, text="¼", width=3, command=lambda: self.apply_display_fraction(4),
            bg=PARCHMENT_BG, activebackground="#eee1c8", fg="#333333",
            font=("Arial", 8, "bold"), relief="flat", bd=0, padx=0, pady=0,
        )
        self.view_quarter_btn = view_quarter_btn
        view_quarter_btn.pack(side="right", pady=0, padx=0)
        add_tooltip(view_quarter_btn, "חש״ר ללא חיפוש: מציג את אותו אזור ברבע מדילוג התצוגה הנוכחי, בלי להריץ חיפוש ובלי למחוק ממצאים.")
        skip_exact_row = ttk.Frame(skip_box)
        skip_exact_row.pack(anchor="e", fill="x", pady=(0, 0))
        ttk.Label(skip_exact_row, text="דילוג יחיד", style="Compact.TLabel").pack(side="right", padx=(0, 1))
        exact_skip_entry = ttk.Entry(skip_exact_row, textvariable=self.exact_skip, width=5, justify="right")
        self.exact_skip_entry = exact_skip_entry
        exact_skip_entry.pack(side="right", padx=(0, 1))
        exact_skip_entry.bind("<Return>", self.confirm_skip_fields)
        exact_skip_entry.bind("<KP_Enter>", self.confirm_skip_fields)
        add_tooltip(exact_skip_entry, "אם הוזן כאן מספר, החיפוש ירוץ רק בדילוג הזה ובכיוון ההפוך שלו.")
        self.exact_skip.trace_add("write", self.on_skip_fields_changed)
        year_btn = tk.Button(
            skip_exact_row, text="שנה", width=4, command=self.open_year_skip_search,
            bg="#fce5cd", activebackground="#f9cb9c", fg="#783f04",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        year_btn.pack(side="right", padx=(0, 1))
        self.year_skip_button = year_btn
        self.add_shortcut_tooltip(year_btn, "חיפוש ראשית בדילוג השנה, למשל 5786.", "דילוג שנה")
        live_skip_frame = ttk.Frame(skip_exact_row)
        self.live_skip_frame = live_skip_frame
        live_skip_frame.pack(side="right", padx=(0, 1))
        ttk.Label(live_skip_frame, text="חי", style="Compact.TLabel").pack(side="right", padx=(0, 1))
        live_skip_up_btn = ttk.Button(live_skip_frame, text="+", width=2, command=lambda: self.adjust_live_skip(1))
        self.live_skip_up_btn = live_skip_up_btn
        live_skip_up_btn.pack(side="right")
        live_skip_entry = ttk.Entry(live_skip_frame, textvariable=self.live_skip, width=4, justify="right")
        self.live_skip_entry = live_skip_entry
        live_skip_entry.pack(side="right", padx=1)
        live_skip_down_btn = ttk.Button(live_skip_frame, text="-", width=2, command=lambda: self.adjust_live_skip(-1))
        self.live_skip_down_btn = live_skip_down_btn
        live_skip_down_btn.pack(side="right")
        live_skip_entry.bind("<Return>", lambda event: (self.apply_live_skip(event), "break")[1])
        live_skip_entry.bind("<KP_Enter>", lambda event: (self.apply_live_skip(event), "break")[1])
        live_skip_entry.bind("<FocusOut>", self.apply_live_skip)
        add_tooltip(live_skip_entry, "שדה חי לדילוג תצוגה עכשווי: משנה מיד את טבלת הצופן, גם לפני חיפוש, בלי להריץ חיפוש מחדש.")
        self.live_skip.trace_add("write", lambda *_args: self.schedule_live_skip_apply())
        add_tooltip(live_skip_up_btn, "מגדיל את דילוג התצוגה ב-1 בלי להריץ חיפוש.")
        add_tooltip(live_skip_down_btn, "מקטין את דילוג התצוגה ב-1 בלי להריץ חיפוש.")
        skip_options_row = ttk.Frame(skip_box)
        skip_options_row.pack(anchor="e", fill="x", pady=(0, 0))
        minimal_check = tk.Checkbutton(
            skip_options_row,
            text="מינימלי",
            variable=self.opt_minimal_search,
            command=self.on_minimal_search_changed,
            anchor="e",
            justify="right",
            bg=PARCHMENT_BG,
            activebackground=PARCHMENT_BG,
            selectcolor="#ffffff",
            font=("Arial", 9, "bold"),
            padx=0,
            pady=0,
        )
        minimal_check.pack(side="right", padx=(0, 1))
        add_tooltip(minimal_check, "כאשר מסומן, כפתור חפש מחפש דילוג מינימלי של הראשית בלבד; המשניות נסרקות אחר כך סביב ממצאי הראשית.")
        auto_advance_check = tk.Checkbutton(
            skip_options_row,
            text="טווח מורחב",
            variable=self.opt_auto_advance_skip,
            command=self.save_app_settings,
            anchor="e",
            justify="right",
            bg=PARCHMENT_BG,
            activebackground=PARCHMENT_BG,
            selectcolor="#ffffff",
            font=("Arial", 9, "bold"),
            padx=0,
            pady=0,
        )
        self.auto_advance_check = auto_advance_check
        auto_advance_check.pack(side="right", padx=(0, 1))
        auto_limit_text = f"עד דילוג {MAX_AUTO_EXTENDED_SKIP:,}" if MAX_AUTO_EXTENDED_SKIP else "ללא מגבלת דילוג מוגדרת"
        add_tooltip(auto_advance_check, f"קופסת סימון לטווח מורחב: מרשה להמשיך אוטומטית לטווחים שמעבר לטווח שהוגדר, {auto_limit_text}. חלוקת טווח גדול בתוך הטווח המקורי נעשית גם בלי סימון זה.")
        screen_range_btn = tk.Button(
            skip_options_row, text="סרוק משניות בטווח", width=14, command=self.search_screen_secondaries_in_skip_range,
            bg="#cfe2f3", activebackground="#9fc5e8", fg="#073763",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        screen_range_btn.pack(side="right", padx=(0, 1))
        add_tooltip(screen_range_btn, "לאחר שנמצא צופן: סורק את המילים המשניות בכל טווח הדילוגים בתוך אזור/מסך הראשית הנוכחית, בלי לחפש ראשיות מחדש.")
        self.mode.trace_add("write", self.on_search_mode_changed)
        self.on_search_mode_changed()

        advanced_row = ttk.Frame(self.side)
        advanced_row.pack(anchor="e", fill="x", pady=(0, 0))
        self.selection_mode = tk.BooleanVar(value=False)
        selection_check = tk.Checkbutton(
            advanced_row,
            text="סימון ידני",
            variable=self.selection_mode,
            command=self.toggle_selection_mode,
            anchor="e",
            justify="right",
            bg=PARCHMENT_BG,
            activebackground=PARCHMENT_BG,
            selectcolor="#ffffff",
            font=("Arial", 10, "bold"),
            padx=0,
            pady=0,
        )
        selection_check.pack(side="right", fill="x", expand=True, padx=(0, 2))
        self.add_shortcut_tooltip(selection_check, "כשהמצב פעיל, גרירה על אותיות בוחרת אותן לסימון ידני. כשהוא כבוי, גרירה מזיזה את התצוגה.", "סימון ידני")
        self.marker_graph_btn = tk.Button(
            advanced_row, text="הסתר גרף", width=8, command=self.toggle_marker_graph,
            bg="#d9e2f3", activebackground="#b4c7e7", fg="#1a3d7c",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        self.marker_graph_btn.pack(side="right", fill="x", expand=True, padx=(0, 2))
        add_tooltip(self.marker_graph_btn, "מסתיר או מציג את גרף המיקום הצבעוני שבצד התצוגה כדי לפנות עוד רוחב לתצוגת התורה.")
        fallback_primary_check = tk.Checkbutton(
            advanced_row,
            text="חיפוש מורחב",
            variable=self.opt_try_long_secondary_primary,
            command=self.save_app_settings,
            anchor="e",
            justify="right",
            bg=PARCHMENT_BG,
            activebackground=PARCHMENT_BG,
            selectcolor="#ffffff",
            font=("Arial", 10, "bold"),
            padx=0,
            pady=0,
        )
        fallback_primary_check.pack(side="right", fill="x", expand=True, padx=(0, 2))
        add_tooltip(
            fallback_primary_check,
            "קופסת סימון לחיפוש מורחב: אם לא נמצא צופן שעומד בתנאים, התוכנה תנסה עד 5 משניות ארוכות כראשיות חלופיות, אחת אחרי השנייה.",
        )
        if AI_FEATURES_ENABLED:
            ai_decode_btn = tk.Button(
                advanced_row,
                text="פענוח AI",
                width=9,
                command=self.open_ai_decode_tool,
                bg="#d9ead3",
                activebackground="#b6d7a8",
                fg="#274e13",
                activeforeground="#274e13",
                relief="raised",
                bd=1,
                font=("Arial", 9, "bold"),
                padx=0,
                pady=0,
            )
            ai_decode_btn.pack(side="right", fill="x", expand=True, padx=(0, 2))
            add_tooltip(ai_decode_btn, "פותח פענוח AI לצופן: הצעת מילים, שמות, מקומות ותיאורים לחיפוש סביב הממצא. דורש מפתח OpenAI כדי לעבוד מהרשת.")
        clear_manual_near_btn = tk.Button(
            advanced_row, text="⌫", width=2, command=self.clear_manual_marks,
            bg="#ead1dc", activebackground="#d5a6bd", fg="#4c1130",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        clear_manual_near_btn.pack(side="right", padx=(0, 2))
        add_tooltip(clear_manual_near_btn, "מנקה סימונים ותוספות ידניות.")
        current_view_row = ttk.Frame(self.side)
        current_view_row.pack(anchor="e", fill="x", pady=(0, 0))
        current_view_check = tk.Checkbutton(
            current_view_row,
            text="רק במסך הנוכחי",
            variable=self.opt_current_view_only,
            command=self.save_app_settings,
            anchor="e",
            justify="right",
            bg=PARCHMENT_BG,
            activebackground=PARCHMENT_BG,
            selectcolor="#ffffff",
            font=("Arial", 10, "bold"),
            padx=0,
            pady=0,
        )
        current_view_check.pack(side="right", fill="x", expand=True, padx=(0, 2))
        add_tooltip(current_view_check, "כאשר מסומן, חיפוש חדש יחפש רק בטבלת הצופן או התצוגה שמופיעה כרגע, בלי לעבור על כל התורה.")
        self.context_top_lines_btn = tk.Button(
            current_view_row,
            text="שלח קווים",
            width=8,
            command=self.toggle_all_top_context_connectors,
            bg="#d9e8fb",
            activebackground="#b4d0f4",
            fg="#174f8a",
            activeforeground="#174f8a",
            relief="raised",
            bd=1,
            font=("Arial", 8, "bold"),
        )
        self.context_top_lines_btn.pack(side="right", padx=(0, 2))
        add_tooltip(self.context_top_lines_btn, "כשאין קווים: מותח קווים מהמילים למעלה אל כל הממצאים. כשיש קווים: מסיר אותם.")
        clear_top_lines_btn = tk.Button(
            current_view_row, text="נקה קווים", width=8, command=self.clear_all_top_connectors_in_cipher,
            bg="#f4cccc", activebackground="#ea9999", fg="#660000",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        clear_top_lines_btn.pack(side="right", padx=(0, 2))
        add_tooltip(clear_top_lines_btn, "מסיר את כל הקווים שנמתחו מהמילים למעלה אל הממצאים בצופן הנוכחי.")
        all_screen_skips_btn = tk.Button(
            current_view_row, text="כל דילוג", width=8, command=self.search_screen_secondaries_in_skip_range,
            bg="#d9ead3", activebackground="#b6d7a8", fg="#274e13",
            font=("Arial", 8, "bold"), relief="raised", bd=1,
        )
        all_screen_skips_btn.pack(side="right", padx=(0, 2))
        add_tooltip(all_screen_skips_btn, "סורק את המשניות בכל דילוג אפשרי לפי טווח הדילוגים, בתוך אזור התצוגה של הצופן הנוכחי.")
        self.update_find_chance_label()

        fraction_btns = ttk.Frame(self.side)
        fraction_btns.pack(anchor="e", fill="x", pady=(0, 0))
        half_btn = live_button(fraction_btns, "½", lambda: self.search_cipher_with_fraction(2), "#f9cb9c", "#f6b26b", "#5b2f00", width=10, height=1)
        half_btn.grid(row=0, column=2, padx=1, pady=0, sticky="ew")
        add_tooltip(half_btn, "על ממצא קיים: מוסיף חיפוש משניות בדילוג 1 ובחצי דילוג, N/N+1/N-1 בשני הכיוונים, בלי למחוק סימונים קיימים.")
        third_btn = live_button(fraction_btns, "⅓", lambda: self.search_cipher_with_fraction(3), "#ffe599", "#ffd966", "#5f4300", width=10, height=1)
        third_btn.grid(row=0, column=1, padx=1, pady=0, sticky="ew")
        add_tooltip(third_btn, "על ממצא קיים: מוסיף חיפוש משניות בדילוג 1 ובשליש דילוג, N/N+1/N-1 בשני הכיוונים, בלי למחוק סימונים קיימים.")
        quarter_btn = live_button(fraction_btns, "¼", lambda: self.search_cipher_with_fraction(4), "#d5a6bd", "#c27ba0", "#4c1130", width=10, height=1)
        quarter_btn.grid(row=0, column=0, padx=1, pady=0, sticky="ew")
        add_tooltip(quarter_btn, "על ממצא קיים: מוסיף חיפוש משניות בדילוג 1 וברבע דילוג, N/N+1/N-1 בשני הכיוונים, בלי למחוק סימונים קיימים.")
        columns_btn = live_button(fraction_btns, "▥ עמודות", self.scan_stacked_words, "#d9d2e9", "#b4a7d6", "#20124d", width=10, height=1)
        columns_btn.grid(row=1, column=2, padx=1, pady=0, sticky="ew")
        self.add_shortcut_tooltip(columns_btn, "מחפש בדיוק ביטוי אחד בראשית וביטוי אחד במשניות, ומסדר אותם אחת מתחת לשנייה אם נמצאו בטקסט.", "עמודות")
        meetings_btn = live_button(fraction_btns, "🔗 מפגשים", self.run_meetings_search, "#b4a7d6", "#8e7cc3", "#20124d", width=10, height=1)
        meetings_btn.grid(row=1, column=1, padx=1, pady=0, sticky="ew")
        self.add_shortcut_tooltip(meetings_btn, "מחפש מפגש ממש בין הראשית לבין המשנית שסומנה בכוכבית בשדה המשניות. שאר המשניות נבדקות כמו בחיפוש צופן רגיל, והמינימום נספר מהמשנית המסומנת.", "מפגשים")
        cluster_btn = live_button(fraction_btns, "▦ מקבץ", self.run_cluster_search, "#9fc5e8", "#6fa8dc", "#073763", width=10, height=1)
        cluster_btn.grid(row=1, column=0, padx=1, pady=0, sticky="ew")
        self.add_shortcut_tooltip(cluster_btn, "חיפוש נפרד: ראשית ומשניות שנמצאות בקירבה בתוך חלון 10 על 10, גם בלי אות משותפת.", "מקבץ")
        repeated_btn = live_button(fraction_btns, "↻ חוזרות", self.run_repeated_phrase_search, "#b6d7a8", "#93c47d", "#274e13", width=10, height=1)
        repeated_btn.grid(row=2, column=2, padx=1, pady=0, sticky="ew")
        self.add_shortcut_tooltip(repeated_btn, "מחפש רק ביטוי אחד בשדה ראשית, בלי משניות: איפה אותו טקסט מופיע שוב, ומסדר את שתי ההופעות אחת מתחת לשנייה.", "חוזרות")
        scan_cell = tk.Frame(fraction_btns, bg="#ead1dc", bd=1, relief="raised")
        scan_cell.grid(row=2, column=1, padx=1, pady=0, sticky="nsew")
        scan_cell.columnconfigure(0, weight=1)
        scan_cell.columnconfigure(1, weight=0)
        self.auto_scan = tk.BooleanVar(value=False)
        scan_btn = tk.Button(
            scan_cell, text="🔎 סרוק", height=1, command=self.scan_current_screen,
            bg="#ead1dc", activebackground="#d5a6bd", fg="#4c1130",
            font=("Arial", 10, "bold"), relief="flat", bd=0,
        )
        scan_btn.grid(row=0, column=0, padx=(1, 0), pady=0, sticky="nsew")
        self.add_shortcut_tooltip(scan_btn, "סורק את המסך בלבד לפי קובץ המילים ועוד המשניות שנכתבו. תאריכים נסרקים בפקודה נפרדת.", "סרוק מסך")
        auto_scan_check = tk.Checkbutton(
            scan_cell,
            text="אוט׳",
            variable=self.auto_scan,
            anchor="center",
            justify="center",
            bg="#ead1dc",
            activebackground="#d5a6bd",
            selectcolor="#ffffff",
            font=("Arial", 8, "bold"),
            padx=0,
            pady=0,
        )
        self.auto_scan_check = auto_scan_check
        auto_scan_check.grid(row=0, column=1, padx=(0, 1), pady=0, sticky="ns")
        add_tooltip(auto_scan_check, "לאחר מציאת צופן, סורק אוטומטית את הטבלה הנוכחית לפי מילון או המילים המשניות.")
        dates_btn = tk.Button(fraction_btns, text="📅 תאריכים", width=10, height=1, command=self.open_dates_tool,
                              bg="#d9ead3", activebackground="#b6d7a8", fg="#274e13",
                              font=("Arial", 10, "bold"), relief="raised", bd=1)
        dates_btn.grid(row=2, column=0, padx=1, pady=0, sticky="ew")
        self.add_shortcut_tooltip(dates_btn, "פותח את כלי התאריכים וסורק תאריכים במסך הנוכחי לפי בחירה.", "תאריכים")
        for col in range(3):
            fraction_btns.columnconfigure(col, weight=1)

        clear_row = ttk.Frame(self.side)
        clear_row.pack(anchor="e", fill="x", pady=0)
        clear_words_btn = live_button(clear_row, "⌫ מילים", self.clear_search_words, "#cfe2f3", "#9fc5e8", "#073763", width=8, font_size=12)
        clear_words_btn.grid(row=0, column=2, padx=1, pady=0, sticky="ew")
        self.add_shortcut_tooltip(clear_words_btn, "מנקה את שדות המילה הראשית והמילים המשניות בלבד.", "נקה מילים")
        clear_manual_btn = live_button(clear_row, "✋ סימון", self.clear_manual_marks, "#ead1dc", "#d5a6bd", "#4c1130", width=8, font_size=12)
        clear_manual_btn.grid(row=0, column=1, padx=1, pady=0, sticky="ew")
        self.add_shortcut_tooltip(clear_manual_btn, "מנקה רק סימונים ותוספות ידניות מהתצוגה.", "נקה סימונים ידניים")
        clear_all_btn = live_button(clear_row, "🧹 הכל", self.clear_all_work, "#f4cccc", "#ea9999", "#660000", width=8, font_size=12)
        clear_all_btn.grid(row=0, column=0, padx=1, pady=0, sticky="ew")
        self.add_shortcut_tooltip(clear_all_btn, "מנקה שדות חיפוש, ממצאים, סריקות וסימונים ידניים.", "נקה הכל")
        for col in range(3):
            clear_row.columnconfigure(col, weight=1)

        self.results_frame = ttk.Frame(self.side)
        self.results_frame.configure(height=self.results_panel_height)
        self.results_frame.pack_propagate(False)
        self.results_header = tk.Frame(self.results_frame, bg="#e8f0fe")
        self.results_header.grid(row=0, column=0, columnspan=2, sticky="ew")
        self.results_header.columnconfigure(1, weight=1)
        self.results_title_var = tk.StringVar(value="")
        self.results_title = tk.Label(
            self.results_header,
            textvariable=self.results_title_var,
            anchor="e",
            bg="#e8f0fe",
            fg="#1a3d7c",
            font=("Arial", 10, "bold"),
            padx=3,
            pady=1,
        )
        self.results_back_btn = tk.Button(
            self.results_header,
            text="← רשימת צפנים",
            command=self.show_cipher_list_from_details,
            bg="#f3f3f3",
            activebackground="#e8f0fe",
            fg="#1a3d7c",
            font=("Arial", 9, "bold"),
            relief="flat",
            padx=3,
            pady=0,
        )
        self.results_back_btn.grid(row=0, column=0, sticky="w")
        self.results_title.grid(row=0, column=1, sticky="ew")
        self.results_back_btn.grid_remove()
        self.results = ResultsTable(self.results_frame, height=self.results_height, width=36, font=("Arial", 12))
        self.results_scrollbar = ttk.Scrollbar(self.results_frame, orient="vertical", command=self.results.yview)
        self.results_hscrollbar = ttk.Scrollbar(self.results_frame, orient="horizontal", command=self.results.xview)
        self.results.configure(yscrollcommand=self.results_scrollbar.set, xscrollcommand=self.results_hscrollbar.set)
        self.results.grid(row=1, column=0, sticky="nsew")
        self.results_scrollbar.grid(row=1, column=1, sticky="ns")
        self.results_hscrollbar.grid(row=2, column=0, sticky="ew")
        self.results_frame.rowconfigure(1, weight=1)
        self.results_frame.columnconfigure(0, weight=1)
        self.results.bind("<<ListboxSelect>>", self.select_result)
        self.results.bind("<Double-Button-1>", self.open_selected_result)
        self.results.bind("<Button-1>", self.left_click_result)
        self.results.bind("<Button-3>", self.result_context_menu)
        self.results.bind("<Up>", lambda event: self.move_result_selection(-1))
        self.results.bind("<Down>", lambda event: self.move_result_selection(1))
        self.results.bind("<KP_Up>", lambda event: self.move_result_selection(-1))
        self.results.bind("<KP_Down>", lambda event: self.move_result_selection(1))
        self.results.bind("<Enter>", self.focus_results_from_pointer)
        self.results_frame.bind("<Enter>", self.focus_results_from_pointer)
        self.results.bind("<MouseWheel>", self.on_results_mouse_wheel)
        self.results.bind("<Button-4>", self.on_results_mouse_wheel)
        self.results.bind("<Button-5>", self.on_results_mouse_wheel)
        add_tooltip(self.results, "טבלת צפנים וממצאים: ניתן לפתוח לגובה גדול, לגלול לאורך ולרוחב, קליק שמאלי מרכז, קליק ימני משנה צבע או מסיר סימון.")
        self.results_resize_grip = tk.Frame(self.results_frame, height=7, cursor="sb_v_double_arrow", bg="#d7d7d7")
        self.results_resize_grip.grid(row=3, column=0, columnspan=2, sticky="ew")
        self.results_resize_grip.bind("<ButtonPress-1>", self.start_results_resize)
        self.results_resize_grip.bind("<B1-Motion>", self.drag_results_resize)
        self.results_resize_grip.bind("<ButtonRelease-1>", self.end_results_resize)
        add_tooltip(self.results_resize_grip, "גרור כאן כדי לפתוח או לצמצם את טבלת הממצאים.")
        self.results_controls = None

        self.canvas = TorahCanvas(self.display, self.model)
        self.canvas.view_cols_extra = 0
        self.canvas.view_rows_extra = 0
        self.canvas.app_remove_match = self.remove_match_from_current_saved
        self.canvas.app_remove_word_marks_on_screen = self.remove_result_word_marks_on_screen
        self.canvas.app_delete_word_from_scan_file = self.delete_word_from_scan_file
        self.canvas.app_add_word_to_scan_file = self.add_word_to_scan_file
        self.canvas.app_show_canvas_context_menu = self.show_canvas_letter_context_menu
        self.canvas.app_center_match = self.center_match_in_view
        self.canvas.app_current_display_match = lambda: getattr(self, "current_display_match", None)
        self.canvas.app_push_undo_state = self.push_app_undo_state
        self.canvas.app_status = self.status
        self.canvas.app_top_connectors_changed = self.update_context_top_lines_button
        self.canvas.on_view_change = self.update_context_header
        self.canvas.findings_provider = self.graph_points
        self.canvas.finding_click_handler = self.open_marker_graph_point
        self.canvas.canvas.bind("<Enter>", self.focus_torah_from_pointer, add="+")
        display_controls = ttk.Frame(self.display)
        self.display_controls = display_controls
        display_controls.pack(side="bottom", fill="x", pady=(1, 0))
        self.display_button_images = []

        def stacked_triangle_image(direction: str, color="#034638"):
            img = tk.PhotoImage(width=20, height=18)

            def put_triangle(cx, top, orientation):
                if orientation == "up":
                    rows = ((0, 0), (1, 1), (2, 2), (3, 3), (4, 3), (5, 4), (6, 4))
                else:
                    rows = ((0, 4), (1, 4), (2, 3), (3, 3), (4, 2), (5, 1), (6, 0))
                for dy, half_width in rows:
                    y = top + dy
                    for x in range(cx - half_width, cx + half_width + 1):
                        img.put(color, (x, y))

            if direction == "in":
                put_triangle(10, 1, "down")
                put_triangle(10, 11, "up")
            else:
                put_triangle(10, 1, "up")
                put_triangle(10, 10, "down")
            self.display_button_images.append(img)
            return img

        def minus_bar_image(color):
            img = tk.PhotoImage(width=16, height=14)
            for y in range(6, 9):
                for x in range(3, 14):
                    img.put(color, (x, y))
            self.display_button_images.append(img)
            return img

        def horizontal_triangle_image(direction: str, color):
            img = tk.PhotoImage(width=18, height=14)

            def put_triangle(cx, cy, orientation):
                if orientation == "right":
                    cols = ((0, 4), (1, 4), (2, 3), (3, 3), (4, 2), (5, 1), (6, 0))
                else:
                    cols = ((0, 0), (1, 1), (2, 2), (3, 3), (4, 3), (5, 4), (6, 4))
                for dx, half_height in cols:
                    x = cx + dx
                    for y in range(cy - half_height, cy + half_height + 1):
                        img.put(color, (x, y))

            if direction == "right":
                put_triangle(6, 7, "right")
            else:
                put_triangle(5, 7, "left")
            self.display_button_images.append(img)
            return img

        def horizontal_pair_image(direction: str, color):
            img = tk.PhotoImage(width=24, height=14)

            def put_triangle(cx, cy, orientation):
                if orientation == "right":
                    cols = ((0, 4), (1, 4), (2, 3), (3, 3), (4, 2), (5, 1), (6, 0))
                else:
                    cols = ((0, 0), (1, 1), (2, 2), (3, 3), (4, 3), (5, 4), (6, 4))
                for dx, half_height in cols:
                    x = cx + dx
                    for y in range(cy - half_height, cy + half_height + 1):
                        img.put(color, (x, y))

            if direction == "in":
                put_triangle(4, 7, "right")
                put_triangle(14, 7, "left")
            else:
                put_triangle(3, 7, "left")
                put_triangle(15, 7, "right")
            self.display_button_images.append(img)
            return img

        def page_down_image(color):
            img = tk.PhotoImage(width=18, height=14)
            for dy, half_width in ((0, 4), (1, 4), (2, 3), (3, 3), (4, 2), (5, 1), (6, 0)):
                y = 4 + dy
                for x in range(9 - half_width, 9 + half_width + 1):
                    img.put(color, (x, y))
            self.display_button_images.append(img)
            return img

        def display_text_label(kind):
            return {
                "zoom_out": "זום",
                "zoom_in": "זום ✚",
                "zoom_reset": "זום רגיל",
                "height_in": "גופן",
                "height_out": "גופן ✚",
                "height_reset": "גופן רגיל",
                "rows_reset": "גובה מסך",
                "rows_in": "צמצם",
                "rows_out": "הרחב",
                "width_reset": "רוחב מסך",
                "width_in": "צר",
                "width_out": "רחב",
                "page": "עמוד",
                "right": "ימין",
                "left": "שמאל",
                "down": "▼ מטה",
                "up": "▲ מעלה",
                "next": "הבא",
                "previous": "קודם",
            }.get(kind, "")

        def display_button(kind, command, normal, hover, fg, tooltip, col, shortcut_label="", accent="#ffffff"):
            btn = live_button(display_controls, display_text_label(kind), command, normal, hover, fg, width=7, font_size=9)
            if kind == "rows_in":
                btn.configure(image=stacked_triangle_image("in", fg), compound="left")
            elif kind == "rows_out":
                btn.configure(image=stacked_triangle_image("out", fg), compound="left")
            elif kind in ("zoom_out", "height_in"):
                btn.configure(image=minus_bar_image(fg), compound="right")
            elif kind == "width_in":
                btn.configure(image=horizontal_pair_image("in", fg), compound="left")
            elif kind == "width_out":
                btn.configure(image=horizontal_pair_image("out", fg), compound="left")
            elif kind == "page":
                btn.configure(image=page_down_image(fg), compound="left")
            elif kind in ("right", "next"):
                btn.configure(image=horizontal_triangle_image("right", fg), compound="left")
            elif kind in ("left", "previous"):
                btn.configure(image=horizontal_triangle_image("left", fg), compound="left")
            btn.configure(
                width=8,
                height=1,
                padx=2,
                pady=3,
                relief="raised",
                bd=1,
                font=("Segoe UI", 9, "bold"),
                highlightthickness=1,
                highlightbackground=accent,
                activeforeground=fg,
            )
            btn.grid(row=0, column=col, padx=1, pady=0, sticky="nsew")
            add_tooltip(btn, self.tooltip_with_shortcut(tooltip, shortcut_label))
            return btn

        for col in range(19):
            display_controls.columnconfigure(col, weight=1, uniform="display_controls")
        display_controls.rowconfigure(0, weight=1)
        zoom_out_btn = display_button("zoom_out", self.zoom_out, "#f4df9a", "#ebc85b", "#4d3400", "הקטנת האותיות והתאים.", 0, accent="#8a6100")
        zoom_in_btn = display_button("zoom_in", self.zoom_in, "#f4df9a", "#ebc85b", "#4d3400", "הגדלת האותיות והתאים.", 1, accent="#8a6100")
        zoom_reset_btn = display_button("zoom_reset", self.zoom_reset, "#f4df9a", "#ebc85b", "#4d3400", "איפוס גודל האותיות.", 2, accent="#8a6100")
        height_short_btn = display_button("height_in", self.display_height_shorter, "#d4b9ed", "#bd91df", "#35105f", "הקטנת גובה המשבצות.", 3, accent="#7b42a8")
        height_tall_btn = display_button("height_out", self.display_height_taller, "#d4b9ed", "#bd91df", "#35105f", "הגדלת גובה המשבצות.", 4, accent="#7b42a8")
        height_reset_btn = display_button("height_reset", self.display_height_reset, "#d4b9ed", "#bd91df", "#35105f", "איפוס גובה המשבצות.", 5, accent="#7b42a8")
        rows_reset_btn = display_button("rows_reset", self.display_rows_reset, "#afd7c9", "#8bc5b1", "#034638", "איפוס תחום חשיפת השורות.", 6, accent="#3d8b73")
        rows_narrow_btn = display_button("rows_in", self.display_rows_narrower, "#afd7c9", "#8bc5b1", "#034638", "צמצום תחום חשיפת האותיות האנכי מלמעלה ומלמטה תוך שמירת התצוגה במרכז.", 7, accent="#3d8b73")
        rows_wide_btn = display_button("rows_out", self.display_rows_wider, "#afd7c9", "#8bc5b1", "#034638", "הרחבת תחום חשיפת האותיות האנכי.", 8, accent="#3d8b73")
        width_reset_btn = display_button("width_reset", self.display_width_reset, "#afc8e5", "#89add5", "#0c3764", "איפוס רוחב התצוגה.", 9, "אפס רוחב תצוגה", accent="#477cae")
        width_narrow_btn = display_button("width_in", self.display_narrower, "#afc8e5", "#89add5", "#0c3764", "צמצום רוחב התצוגה.", 10, "צמצם רוחב תצוגה", accent="#477cae")
        width_wide_btn = display_button("width_out", self.display_wider, "#afc8e5", "#89add5", "#0c3764", "הרחבת רוחב התצוגה.", 11, "הרחב רוחב תצוגה", accent="#477cae")
        page_btn = display_button("page", lambda: self.canvas.move_linear_pages(1), "#abc8e9", "#82acd9", "#0c3c70", "קפיצה עמוד אחד קדימה בתצוגת התורה.", 12, accent="#4d7fae")
        scroll_right_btn = display_button("right", None, "#d9e8fb", "#b4d0f4", "#174f8a", "גלילה אופקית ימינה באות אחת.", 13)
        self.scroll_right_btn = scroll_right_btn
        self.bind_hold_horizontal_button(scroll_right_btn, lambda: self.canvas.move_horizontal(-1, units=1), -1)
        scroll_left_btn = display_button("left", None, "#d9e8fb", "#b4d0f4", "#174f8a", "גלילה אופקית שמאלה באות אחת.", 14)
        self.scroll_left_btn = scroll_left_btn
        self.bind_hold_horizontal_button(scroll_left_btn, lambda: self.canvas.move_horizontal(1, units=1), 1)
        scroll_down_btn = display_button("down", None, "#d9e8fb", "#b4d0f4", "#174f8a", "גלילה למטה בשורה אחת. לחיצה רציפה ממשיכה לגלול.", 15)
        self.bind_hold_scroll_button(scroll_down_btn, lambda: self.canvas.move_linear_rows(1), 1)
        scroll_up_btn = display_button("up", None, "#d9e8fb", "#b4d0f4", "#174f8a", "גלילה למעלה בשורה אחת. לחיצה רציפה ממשיכה לגלול.", 16)
        self.bind_hold_scroll_button(scroll_up_btn, lambda: self.canvas.move_linear_rows(-1), -1)
        next_btn = display_button("next", self.next_result, "#b9dcae", "#96c687", "#184e0e", "ממצא הבא ברשימת הצפנים או ברשימת הממצאים.", 17, "ממצא הבא", accent="#5b9b4a")
        prev_btn = display_button("previous", self.prev_result, "#b9dcae", "#96c687", "#184e0e", "ממצא קודם ברשימת הצפנים או ברשימת הממצאים.", 18, "ממצא קודם", accent="#5b9b4a")
        self.canvas.pack(fill="both", expand=True)
        self.update_font_mode_label()
        self.canvas.set_font_mode(self.font_mode_var.get())
        add_tooltip(
            self.canvas.canvas,
            "תצוגת התורה: גלגלת מזיזה שורות, חצים במקלדת מנווטים, וגרירה מזיזה את המסך כשמצב סימון ידני כבוי.",
            visible_ms=5000,
        )
        if self.live_skip.get().strip():
            self.root.after_idle(self.apply_initial_live_skip)
        if not self.bottom_controls_visible:
            self.root.after_idle(lambda: self.apply_bottom_controls_visibility(save=False))
        if self.results_visible:
            self.root.after_idle(self.open_results_table)
        self.update_avot_ticker_visibility()
        self.schedule_avot_ticker()
        self.update_context_header()
        self.update_skip_range_field_state()
        self.sync_min_secondary_all_count()
        self.update_find_chance_label()
        self.enable_tab_navigation()
        self.register_core_ctrl_shortcuts()
        self.root.bind_all("<Control-KeyPress>", self.on_ctrl_shortcut, add="+")

    def enable_tab_navigation(self):
        focusable_types = (
            tk.Button,
            tk.Checkbutton,
            tk.Entry,
            tk.Listbox,
            tk.Radiobutton,
            tk.Scale,
            tk.Spinbox,
            tk.Text,
            ttk.Button,
            ttk.Checkbutton,
            ttk.Combobox,
            ttk.Entry,
            ttk.Radiobutton,
            ttk.Scale,
            ttk.Spinbox,
        )

        def move_focus(widget, forward: bool):
            next_widget = widget.tk_focusNext() if forward else widget.tk_focusPrev()
            if next_widget:
                next_widget.focus_set()
            return "break"

        def walk(widget):
            if isinstance(widget, focusable_types):
                try:
                    widget.configure(takefocus=1)
                except tk.TclError:
                    pass
            if isinstance(widget, tk.Text):
                widget.bind("<Tab>", lambda event: move_focus(event.widget, True), add="+")
                widget.bind("<ISO_Left_Tab>", lambda event: move_focus(event.widget, False), add="+")
                widget.bind("<Shift-Tab>", lambda event: move_focus(event.widget, False), add="+")
            for child in widget.winfo_children():
                walk(child)

        walk(self.root)

    def pointer_over_widget(self, widget) -> bool:
        if widget is None:
            return False
        try:
            x, y = self.root.winfo_pointerxy()
            target = self.root.winfo_containing(x, y)
        except Exception:
            return False
        while target is not None:
            if target == widget:
                return True
            try:
                target = target.master
            except Exception:
                return False
        return False

    def focus_results_from_pointer(self, _event=None):
        self.pointer_keyboard_zone = "results"
        try:
            self.results.focus_set()
        except Exception:
            pass

    def focus_torah_from_pointer(self, _event=None):
        self.pointer_keyboard_zone = "torah"
        try:
            self.canvas.canvas.focus_set()
        except Exception:
            pass

    def route_arrow_key_by_pointer(self, event):
        key = getattr(event, "keysym", "")
        over_results = self.pointer_over_widget(getattr(self, "results", None))
        over_torah = self.pointer_over_widget(getattr(getattr(self, "canvas", None), "canvas", None))
        if key in ("Up", "KP_Up") and over_results:
            return self.move_result_selection(-1)
        if key in ("Down", "KP_Down") and over_results:
            return self.move_result_selection(1)
        if over_torah:
            return self.start_keyboard_torah_scroll(key)
        return None

    def keyboard_torah_scroll_action(self, key: str):
        actions = {
            "Up": lambda: self.canvas.move_linear_rows(-1),
            "KP_Up": lambda: self.canvas.move_linear_rows(-1),
            "Down": lambda: self.canvas.move_linear_rows(1),
            "KP_Down": lambda: self.canvas.move_linear_rows(1),
            "Left": lambda: self.canvas.move_horizontal(1),
            "KP_Left": lambda: self.canvas.move_horizontal(1),
            "Right": lambda: self.canvas.move_horizontal(-1),
            "KP_Right": lambda: self.canvas.move_horizontal(-1),
            "Prior": lambda: self.canvas.move_linear_pages(-1),
            "Next": lambda: self.canvas.move_linear_pages(1),
            "Home": lambda: self.canvas.move_linear_home_end(False),
            "End": lambda: self.canvas.move_linear_home_end(True),
        }
        return actions.get(key)

    def start_keyboard_torah_scroll(self, key: str):
        action = self.keyboard_torah_scroll_action(key)
        if action is None:
            return None
        now = time.monotonic()
        self.keyboard_scroll_last_event = now
        if self.keyboard_scroll_key != key or self.keyboard_scroll_after is None:
            self.stop_keyboard_torah_scroll()
            self.keyboard_scroll_key = key
            self.keyboard_scroll_action = action
            action()
            self.keyboard_scroll_after = self.root.after(70, self.keyboard_torah_scroll_step)
        return "break"

    def keyboard_torah_scroll_step(self):
        self.keyboard_scroll_after = None
        action = self.keyboard_scroll_action
        if action is None:
            return
        if time.monotonic() - float(self.keyboard_scroll_last_event or 0.0) > 0.35:
            self.stop_keyboard_torah_scroll()
            return
        action()
        try:
            self.root.update_idletasks()
        except Exception:
            pass
        self.keyboard_scroll_after = self.root.after(55, self.keyboard_torah_scroll_step)

    def stop_keyboard_torah_scroll(self, key: str = ""):
        if key and self.keyboard_scroll_key and key != self.keyboard_scroll_key:
            return
        if self.keyboard_scroll_after is not None:
            try:
                self.root.after_cancel(self.keyboard_scroll_after)
            except Exception:
                pass
        self.keyboard_scroll_after = None
        self.keyboard_scroll_key = ""
        self.keyboard_scroll_action = None

    def on_global_arrow_release(self, event):
        self.stop_keyboard_torah_scroll(getattr(event, "keysym", ""))
        return None

    def register_core_ctrl_shortcuts(self):
        self.register_ctrl_shortcut("ח", "חפש / עצור", self.search_or_stop)
        self.register_ctrl_shortcut("ס", "סרוק מסך", self.scan_current_screen)
        self.register_ctrl_shortcut("ט", "טבלת ממצאים", self.toggle_results_table)
        self.register_ctrl_shortcut("ה", "הסתר / הצג ממשק צד", self.toggle_panel)
        self.register_ctrl_shortcut("ת", "הסתר / הצג תחתון", self.toggle_bottom_controls)
        self.register_ctrl_shortcut("מ", "נקה מילים", self.clear_search_words)
        self.register_ctrl_shortcut("פ", "נקה הכל", self.clear_all_work)
        self.register_ctrl_shortcut("ו", "סרוק משניות בכל הראשיות", self.add_secondary_words_and_scan)
        self.register_ctrl_shortcut("ד", "תאריכים", self.open_dates_tool)
        self.register_ctrl_shortcut("ש", "דילוג שנה", self.open_year_skip_search)
        self.register_ctrl_shortcut("ג", "מפגשים", self.run_meetings_search)
        self.register_ctrl_shortcut("צ", "מקבץ", self.run_cluster_search)
        self.register_ctrl_shortcut("ז", "חוזרות", self.run_repeated_phrase_search)
        self.register_ctrl_shortcut("ע", "עמודות", self.scan_stacked_words)
        self.register_ctrl_shortcut("נ", "סימון ידני", self.add_manual_mark)
        self.register_ctrl_shortcut("ק", "נקה סימונים ידניים", self.clear_manual_marks)
        self.register_ctrl_shortcut("ל", "ממצא הבא", self.next_result)
        self.register_ctrl_shortcut("ר", "ממצא קודם", self.prev_result)
        self.register_ctrl_shortcut("ב", "הרחב רוחב תצוגה", self.display_wider)
        self.register_ctrl_shortcut("י", "צמצם רוחב תצוגה", self.display_narrower)
        self.register_ctrl_shortcut("א", "אפס רוחב תצוגה", self.display_width_reset)

    def open_shortcuts_report(self):
        win = tk.Toplevel(self.root)
        win.title("דוח קיצורי Ctrl")
        win.transient(self.root)
        self.prepare_child_window(win, 520, 520)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(1, weight=1)
        frame.columnconfigure(0, weight=1)
        summary = f"קיצורי Ctrl רשומים: {len(self.ctrl_shortcut_labels)} | התנגשויות שנחסמו: {len(self.shortcut_conflicts)}"
        ttk.Label(frame, text=summary, anchor="e", justify="right", font=("Arial", 11, "bold")).grid(row=0, column=0, sticky="ew", pady=(0, 6))
        text = tk.Text(frame, wrap="word", height=20, font=("Arial", 11))
        scroll = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.grid(row=1, column=0, sticky="nsew")
        scroll.grid(row=1, column=1, sticky="ns")
        lines = ["קיצורי Ctrl:"]
        for key, label in sorted(self.ctrl_shortcut_labels.items(), key=lambda item: item[0]):
            lines.append(f"Ctrl+{key}: {label}")
        if self.shortcut_conflicts:
            lines.extend(["", "קיצורים שנחסמו בגלל כפילות:"])
            for modifier, key, label in self.shortcut_conflicts:
                lines.append(f"{modifier.upper()}+{key}: {label}")
        text.insert("1.0", "\n".join(lines))
        text.configure(state="disabled")
        ttk.Button(frame, text="סגור", command=win.destroy).grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))

    def toggle_panel(self):
        try:
            if self.side_visible:
                self.pane.forget(self.side)
                self.side_visible = False
                if hasattr(self, "panel_btn"):
                    self.panel_btn.grid()
            else:
                self.pane.add(self.side, weight=0)
                self.side_visible = True
                if hasattr(self, "panel_btn"):
                    self.panel_btn.grid_remove()
                self.root.after_idle(self.apply_side_width)
            self.save_app_settings()
        except Exception:
            pass

    def apply_side_width(self):
        if not getattr(self, "side_visible", True):
            return
        if not hasattr(self, "pane") or not hasattr(self, "side"):
            return
        try:
            self.side.configure(width=self.target_side_width)
            total = self.pane.winfo_width()
            if total > self.target_side_width + 300:
                self.pane.sashpos(0, max(300, total - self.target_side_width))
        except Exception:
            pass

    def zoom_in(self):
        self.canvas.set_zoom(2)
        self.status.set("התצוגה הוגדלה")
        self.update_context_header()

    def display_wider(self):
        status_message = self.canvas.adjust_display_width(2)
        self.save_app_settings()
        self.status.set(status_message or "גבולות התצוגה הורחבו בלי שינוי גודל האותיות")
        self.update_context_header()

    def display_narrower(self):
        self.canvas.adjust_display_width(-2)
        self.save_app_settings()
        self.status.set("גבולות התצוגה צומצמו בלי שינוי גודל האותיות")
        self.update_context_header()

    def display_width_reset(self):
        self.canvas.adjust_display_width(reset=True)
        self.save_app_settings()
        self.status.set("גבולות התצוגה חזרו להתאמה רגילה למסך")
        self.update_context_header()

    def display_rows_wider(self):
        self.canvas.adjust_display_rows(2)
        self.save_app_settings()
        self.status.set("תחום חשיפת האותיות האנכי הורחב ונוספו שורות לתצוגה")
        self.update_context_header()

    def display_rows_narrower(self):
        self.canvas.adjust_display_rows(-2)
        self.save_app_settings()
        self.status.set("תחום חשיפת האותיות האנכי צומצם מלמעלה ומלמטה והתצוגה נשארה ממורכזת")
        self.update_context_header()

    def display_rows_reset(self):
        self.canvas.adjust_display_rows(reset=True)
        self.save_app_settings()
        self.status.set("תחום חשיפת האותיות האנכי חזר להתאמה רגילה למסך")
        self.update_context_header()

    def display_height_taller(self):
        self.canvas.set_display_height(2)
        self.status.set("גובה שורות התצוגה הוגדל")
        self.update_context_header()

    def display_height_shorter(self):
        self.canvas.set_display_height(-2)
        self.status.set("גובה שורות התצוגה צומצם ומוצגות יותר שורות")
        self.update_context_header()

    def display_height_reset(self):
        self.canvas.set_display_height(reset=True)
        self.status.set("גובה שורות התצוגה אופס")
        self.update_context_header()

    def toggle_bottom_controls(self):
        self.bottom_controls_visible = not self.bottom_controls_visible
        self.apply_bottom_controls_visibility(save=True)

    def apply_bottom_controls_visibility(self, save: bool = False):
        controls = getattr(self, "display_controls", None)
        if not controls:
            return
        if self.bottom_controls_visible:
            if not controls.winfo_manager():
                controls.pack(side="bottom", fill="x", pady=(1, 0), before=self.canvas)
            self.bottom_controls_toggle_btn.configure(text="▾")
            self.status.set("פקדי התצוגה מוצגים")
        else:
            controls.pack_forget()
            self.bottom_controls_toggle_btn.configure(text="▴")
            self.status.set("פקדי התצוגה הוסתרו והשטח נוסף לתצוגת התורה")
        if save:
            self.save_app_settings()
        self.root.after_idle(self.refresh_canvas_after_layout_change)

    def refresh_canvas_after_layout_change(self):
        try:
            self.canvas.reflow_to_canvas()
            self.canvas.render()
            self.update_context_header()
        except Exception:
            pass

    def zoom_out(self):
        self.canvas.set_zoom(-2)
        self.status.set("התצוגה הוקטנה ומוצגות יותר אותיות")
        self.update_context_header()

    def zoom_reset(self):
        self.canvas.set_zoom(reset=True)
        self.status.set("גודל התצוגה אופס")
        self.update_context_header()

    def active_word_field(self) -> Optional[FixedHebrewField]:
        focus = self.root.focus_get()
        fields = [getattr(self, "primary_text", None), getattr(self, "secondary", None)]
        for field in fields:
            if isinstance(field, FixedHebrewField) and focus == field.canvas:
                return field
        for field in reversed(fields):
            if isinstance(field, FixedHebrewField):
                return field
        return None

    def on_word_field_drag_transfer(self, text: str, source, peer):
        target_name = "לראשית" if peer is getattr(self, "primary_text", None) else "למשניות"
        self.status.set(f"הועבר {target_name}: {text}")

    def hebrew_shortcut_to_latin_key(self, key: str) -> str:
        for english_ord, hebrew in ENGLISH_TO_HEBREW_KEYS.items():
            english = chr(english_ord)
            if english.islower() and hebrew == key:
                return english
        return key.lower()

    def register_ctrl_shortcut(self, key: str, label: str, command) -> bool:
        key = str(key or "").strip()[:1]
        if not key or not callable(command):
            return False
        shortcut_keys = [key]
        latin_key = self.hebrew_shortcut_to_latin_key(key)
        if latin_key and latin_key not in shortcut_keys:
            shortcut_keys.append(latin_key)
        existing = [k for k in shortcut_keys if self.ctrl_shortcuts.get(k) not in (None, command)]
        if existing:
            self.shortcut_conflicts.append(("ctrl", key, label))
            return False
        for shortcut_key in shortcut_keys:
            self.ctrl_shortcuts[shortcut_key] = command
        self.ctrl_shortcut_labels[key] = label
        return True

    def on_ctrl_shortcut(self, event):
        if self.active_word_field() is not None:
            return None
        focus = self.root.focus_get()
        if isinstance(focus, (tk.Entry, tk.Text, tk.Listbox, ttk.Entry, ttk.Spinbox)):
            return None
        keys = []
        if event.char:
            keys.extend([event.char, force_hebrew_keyboard_text(event.char)])
        if event.keysym:
            keys.extend([event.keysym, event.keysym.lower(), force_hebrew_keyboard_text(event.keysym.lower())])
        seen = set()
        for key in keys:
            key = str(key or "").strip()[:1]
            if not key or key in seen:
                continue
            seen.add(key)
            action = self.ctrl_shortcuts.get(key)
            if action:
                action()
                return "break"
        return None

    def undo_active_word_field(self):
        if self.undo_app_state():
            return
        field = self.active_word_field()
        if field:
            field.undo()
            field.focus_set()
            self.status.set("Undo בשדה המילים")
        else:
            self.status.set("אין פעולה זמינה לביטול")

    def redo_active_word_field(self):
        if self.redo_app_state():
            return
        field = self.active_word_field()
        if field:
            field.redo()
            field.focus_set()
            self.status.set("Redo בשדה המילים")
        else:
            self.status.set("אין פעולה זמינה לביצוע מחדש")

    def open_field_history_menu(self, action: str):
        field = self.active_word_field()
        app_stack = self.app_undo_stack if action == "undo" else self.app_redo_stack
        app_labels = self.app_undo_labels if action == "undo" else self.app_redo_labels
        stack_name = "undo_stack" if action == "undo" else "redo_stack"
        labels_name = "undo_labels" if action == "undo" else "redo_labels"
        field_count = len(getattr(field, stack_name, []) or []) if field else 0
        app_count = len(app_stack or [])
        if field_count <= 0 and app_count <= 0:
            self.status.set("אין פעולות זמינות לביטול" if action == "undo" else "אין פעולות זמינות לביצוע מחדש")
            return
        menu = tk.Menu(self.root, tearoff=0)
        title = "בטל" if action == "undo" else "עשה שוב"

        if app_count:
            app_command = self.undo_app_state if action == "undo" else self.redo_app_state
            app_display_labels = list(reversed(app_labels or []))
            if len(app_display_labels) < app_count:
                app_display_labels.extend(["פעולה בתוכנה"] * (app_count - len(app_display_labels)))
            for steps in range(1, min(10, app_count) + 1):
                selected = app_display_labels[:steps]
                label = f"{title}: {selected[0]}" if steps == 1 else f"{title} {steps}: " + " + ".join(selected[:3])
                menu.add_command(label=label, command=lambda n=steps, cmd=app_command: [cmd() for _ in range(n)])
            if field_count:
                menu.add_separator()

        if not field_count:
            x = self.root.winfo_pointerx()
            y = self.root.winfo_pointery()
            menu.tk_popup(x, y)
            return

        command = field.undo if action == "undo" else field.redo
        labels = list(reversed(getattr(field, labels_name, []) or []))
        if len(labels) < field_count:
            labels.extend(["פעולה אחרונה"] * (field_count - len(labels)))

        def steps_label(steps: int) -> str:
            selected = labels[:steps]
            if steps == 1:
                return f"{title}: {selected[0]}"
            preview = " + ".join(selected[:3])
            if steps > 3:
                preview += f" + עוד {steps - 3}"
            return f"{title} {steps}: {preview}"

        def run_steps(steps: int):
            for _ in range(steps):
                command()
            field.focus_set()
            self.status.set(steps_label(steps))

        for steps in range(1, min(10, field_count) + 1):
            menu.add_command(label=steps_label(steps), command=lambda n=steps: run_steps(n))
        x = self.root.winfo_pointerx()
        y = self.root.winfo_pointery()
        menu.tk_popup(x, y)

    def make_simple_word_entry(self, widget):
        widget.configure(
            exportselection=False,
            insertwidth=2,
            selectbackground="#9fc5e8",
            selectforeground="#000000",
        )

        def select_all(_event=None):
            widget.selection_range(0, "end")
            widget.icursor("end")
            return "break"

        def delete_selection():
            try:
                widget.delete("sel.first", "sel.last")
                return True
            except tk.TclError:
                return False

        def show_menu(event):
            menu = tk.Menu(widget, tearoff=0)
            menu.add_command(label="גזור", command=lambda: widget.event_generate("<<Cut>>"))
            menu.add_command(label="העתק", command=lambda: widget.event_generate("<<Copy>>"))
            menu.add_command(label="הדבק", command=lambda: widget.event_generate("<<Paste>>"))
            menu.add_command(label="מחק", command=delete_selection)
            menu.add_separator()
            menu.add_command(label="בחר הכל", command=select_all)
            menu.tk_popup(event.x_root, event.y_root)
            return "break"

        widget.bind("<Control-a>", select_all)
        widget.bind("<Control-A>", select_all)
        widget.bind("<Button-3>", show_menu)

    def make_word_like_entry(self, widget):
        widget._drag_anchor_index = None

        def mouse_index(event):
            try:
                return widget.index(f"@{event.x}")
            except tk.TclError:
                return widget.index("insert")

        def mouse_down(event):
            widget.focus_set()
            idx = mouse_index(event)
            widget._drag_anchor_index = idx
            widget.selection_clear()
            widget.icursor(idx)
            return "break"

        def mouse_drag(event):
            widget.focus_set()
            anchor = getattr(widget, "_drag_anchor_index", None)
            if anchor is None:
                anchor = widget.index("insert")
                widget._drag_anchor_index = anchor
            idx = mouse_index(event)
            first, last = sorted((anchor, idx))
            widget.selection_clear()
            if first != last:
                widget.selection_range(first, last)
            widget.icursor(idx)
            return "break"

        def mouse_up(event):
            idx = mouse_index(event)
            anchor = getattr(widget, "_drag_anchor_index", None)
            if anchor is not None and anchor == idx:
                widget.selection_clear()
                widget.icursor(idx)
            widget._drag_anchor_index = None
            return "break"

        def select_all(_event):
            widget.selection_range(0, "end")
            widget.icursor("end")
            return "break"

        def has_selection():
            try:
                widget.index("sel.first")
                widget.index("sel.last")
                return True
            except tk.TclError:
                return False

        def delete_selection():
            if has_selection():
                widget.delete("sel.first", "sel.last")
                return True
            return False

        def backspace(_event):
            if delete_selection():
                return "break"
            idx = widget.index("insert")
            if idx > 0:
                widget.delete(idx - 1, idx)
                widget.icursor(idx - 1)
            return "break"

        def delete_forward(_event):
            if delete_selection():
                return "break"
            idx = widget.index("insert")
            if idx < widget.index("end"):
                widget.delete(idx, idx + 1)
                widget.icursor(idx)
            return "break"

        def type_printable(event):
            if event.state & 0x4 or event.state & 0x8:
                return None
            if not event.char or event.char in ("\r", "\n", "\t", "\x08", "\x7f"):
                return None
            delete_selection()
            widget.insert("insert", event.char)
            widget.icursor("insert")
            return "break"

        def cut():
            if has_selection():
                widget.event_generate("<<Cut>>")

        def copy():
            if has_selection():
                widget.event_generate("<<Copy>>")

        def paste():
            widget.event_generate("<<Paste>>")

        def show_menu(event):
            menu = tk.Menu(widget, tearoff=0)
            menu.add_command(label="גזור", command=cut)
            menu.add_command(label="העתק", command=copy)
            menu.add_command(label="הדבק", command=paste)
            menu.add_command(label="מחק", command=delete_selection)
            menu.add_separator()
            menu.add_command(label="בחר הכל", command=lambda: select_all(None))
            menu.tk_popup(event.x_root, event.y_root)
            return "break"

        widget.bind("<Control-a>", select_all)
        widget.bind("<Control-A>", select_all)
        widget.bind("<Button-1>", mouse_down)
        widget.bind("<B1-Motion>", mouse_drag)
        widget.bind("<ButtonRelease-1>", mouse_up)
        widget.bind("<Button-3>", show_menu)
        widget.bind("<BackSpace>", backspace)
        widget.bind("<Delete>", delete_forward)
        widget.bind("<KeyPress>", type_printable)

    def insert_entry_text(self, widget, text: str):
        try:
            widget.delete("sel.first", "sel.last")
        except tk.TclError:
            pass
        widget.insert("insert", text)
        widget.icursor("insert")
        return "break"

    def on_secondary_words_changed(self):
        self.adjust_secondary_field_width()
        self.update_context_header()

    def adjust_secondary_field_width(self):
        if not hasattr(self, "secondary"):
            return
        raw = self.secondary_var.get() if hasattr(self, "secondary_var") else ""
        words = [w for w in re.split(r"[\s,;|]+", raw.strip()) if w]
        longest = max([len(w) for w in words], default=0)
        # Entry נשאר שדה כתיבה רגיל בעברית; רק הרוחב גדל לפי כמות המילים.
        width = max(22, min(31, longest + 10 + len(words)))
        try:
            self.secondary.configure(width=width)
            self.side.configure(width=max(260, min(320, 90 + width * 7)))
        except tk.TclError:
            pass

    def toggle_results_table(self):
        if getattr(self, "results_expanded", False):
            self.collapse_results_table()
        else:
            self.open_results_table(expanded=True)

    def _clean_pack_info(self, widget) -> dict:
        try:
            return {k: v for k, v in widget.pack_info().items() if k != "in"}
        except tk.TclError:
            return {}

    def hide_side_controls_for_results(self):
        if getattr(self, "results_overlay_hidden_widgets", None):
            return
        keep = {
            getattr(self, "results_frame", None),
            getattr(self, "results_controls", None),
            getattr(self, "results_toggle_container", None),
        }
        hidden = []
        for child in list(self.side.pack_slaves()):
            if child in keep:
                continue
            hidden.append((child, self._clean_pack_info(child)))
            child.pack_forget()
        self.results_overlay_hidden_widgets = hidden

    def restore_side_controls_after_results(self):
        if getattr(self, "results_controls", None) is not None:
            self.results_controls.pack_forget()
        if hasattr(self, "results_frame"):
            self.results_frame.pack_forget()
        for child, info in getattr(self, "results_overlay_hidden_widgets", []):
            try:
                child.pack(**info)
            except tk.TclError:
                pass
        self.results_overlay_hidden_widgets = []

    def open_results_table(self, expanded: bool = False):
        if not hasattr(self, "results_frame"):
            return
        if expanded:
            self.hide_side_controls_for_results()
            if getattr(self, "results_controls", None) is not None:
                self.results_controls.pack_forget()
            self.results_frame.pack_forget()
            self.results_panel_height = self.results_table_height_for_rows(minimum=360, maximum=900)
            self.results_frame.pack(fill="both", expand=False, pady=(1, 0))
            if getattr(self, "results_controls", None) is not None:
                self.results_controls.pack(anchor="e", pady=(1, 0), fill="x")
            self.results_expanded = True
            if hasattr(self, "results_btn"):
                self.results_btn.configure(text="▤ סגור טבלה")
            self.status.set("טבלת הממצאים פתוחה על שטח לוח הצד")
        else:
            if getattr(self, "results_expanded", False):
                self.collapse_results_table()
                return
            if not self.results_frame.winfo_manager():
                if getattr(self, "results_controls", None) is not None:
                    self.results_frame.pack(fill="both", expand=True, pady=(1, 0), before=self.results_controls)
                else:
                    self.results_frame.pack(fill="both", expand=True, pady=(1, 0))
            elif not self.results_frame.pack_info().get("expand"):
                self.results_frame.pack_forget()
                self.results_frame.pack(fill="both", expand=True, pady=(1, 0))
            if self.saved:
                self.results_panel_height = self.results_table_height_for_rows(minimum=260, maximum=620)
        self.results_visible = True
        self.apply_results_panel_height()
        self.save_app_settings()

    def collapse_results_table(self):
        if not hasattr(self, "results_frame"):
            return
        self.restore_side_controls_after_results()
        if not getattr(self, "side_visible", True):
            self.results_visible = False
            self.results_expanded = False
            if hasattr(self, "results_btn"):
                self.results_btn.configure(text="▤ טבלה")
            self.save_app_settings()
            return
        if getattr(self, "results_controls", None) is not None:
            self.results_controls.pack(anchor="e", pady=(1, 0), fill="x")
            self.results_frame.pack(fill="both", expand=True, pady=(1, 0), before=self.results_controls)
        else:
            self.results_frame.pack(fill="both", expand=True, pady=(1, 0))
        self.results_visible = True
        self.results_expanded = False
        if hasattr(self, "results_btn"):
            self.results_btn.configure(text="▤ פתח טבלה")
        self.apply_results_panel_height()
        self.save_app_settings()
        self.status.set("טבלת הממצאים חזרה לגודל מצומצם")

    def resize_results_table(self, delta: int):
        self.results_panel_height = max(160, min(900, int(getattr(self, "results_panel_height", 280)) + int(delta)))
        self.apply_results_panel_height()
        self.save_app_settings()
        self.status.set(f"גובה טבלת הממצאים: {self.results_panel_height} פיקסלים")

    def apply_results_panel_height(self):
        if not hasattr(self, "results_frame"):
            return
        try:
            self.results_frame.configure(height=max(160, int(self.results_panel_height)))
        except tk.TclError:
            pass

    def start_results_resize(self, event):
        self._results_resize_start_y = event.y_root
        self._results_resize_start_height = int(getattr(self, "results_panel_height", 280))
        return "break"

    def drag_results_resize(self, event):
        start_y = getattr(self, "_results_resize_start_y", event.y_root)
        start_h = getattr(self, "_results_resize_start_height", getattr(self, "results_panel_height", 280))
        # Dragging upward opens more room because the table grows above the grip.
        self.results_panel_height = max(160, min(900, int(start_h + (start_y - event.y_root))))
        self.apply_results_panel_height()
        return "break"

    def end_results_resize(self, _event=None):
        self.save_app_settings()
        self.status.set(f"גובה טבלת הממצאים: {self.results_panel_height} פיקסלים")
        return "break"

    def results_table_height_for_rows(self, minimum: int = 220, maximum: int = 900):
        row_count = len(getattr(self, "result_rows", []) or [])
        if row_count <= 0 and hasattr(self, "results"):
            try:
                row_count = int(self.results.size())
            except tk.TclError:
                row_count = 0
        if row_count <= 0:
            row_count = max(1, len(getattr(self, "saved", []) or []) + 2)
        desired = 90 + max(1, row_count) * 28
        return max(int(minimum), min(int(maximum), int(desired)))

    def fit_results_table_to_rows(self, row_count: int, minimum: int = 220):
        row_count = max(1, int(row_count or 1))
        desired = 90 + row_count * 28
        self.results_panel_height = max(minimum, min(900, desired))
        self.open_results_table()
        self.apply_results_panel_height()
        self.save_app_settings()

    def bind_hold_scroll_button(self, button, click_command, rows_delta: int):
        button.bind("<ButtonPress-1>", lambda event, btn=button: self.start_hold_scroll(rows_delta, btn), add="+")
        button.bind("<ButtonRelease-1>", lambda event: self.finish_hold_scroll(), add="+")

    def bind_hold_horizontal_button(self, button, click_command, direction: int):
        button.bind("<ButtonPress-1>", lambda event, btn=button: self.start_hold_horizontal(direction, btn), add="+")
        button.bind("<ButtonRelease-1>", lambda event: self.finish_hold_scroll(), add="+")

    def start_hold_scroll(self, rows_delta: int, button=None):
        self.cancel_hold_scroll()
        self.hold_scroll_button = button
        self.grab_hold_scroll_pointer()
        self.hold_scroll_delta = rows_delta
        self.hold_scroll_axis = "vertical"
        self.hold_scroll_active = True
        self.hold_scroll_step(schedule_next=False)
        self.hold_scroll_after = self.root.after(80, self.hold_scroll_step)
        return "break"

    def start_hold_horizontal(self, direction: int, button=None):
        self.cancel_hold_scroll()
        self.hold_scroll_button = button
        self.grab_hold_scroll_pointer()
        self.hold_scroll_delta = int(direction)
        self.hold_scroll_axis = "horizontal"
        self.hold_scroll_active = True
        self.hold_scroll_step(schedule_next=False)
        self.hold_scroll_after = self.root.after(80, self.hold_scroll_step)
        return "break"

    def hold_scroll_step(self, schedule_next: bool = True):
        self.hold_scroll_after = None
        if not self.hold_scroll_active:
            return
        if getattr(self, "hold_scroll_axis", "vertical") == "horizontal":
            self.canvas.move_horizontal(self.hold_scroll_delta, units=1)
        else:
            self.canvas.move_linear_rows(self.hold_scroll_delta)
        if not getattr(self, "hold_scroll_updating", False):
            self.hold_scroll_updating = True
            try:
                self.root.update()
            except Exception:
                pass
            finally:
                self.hold_scroll_updating = False
        if schedule_next and self.hold_scroll_active:
            self.hold_scroll_after = self.root.after(110, self.hold_scroll_step)

    def finish_hold_scroll(self):
        self.cancel_hold_scroll()
        return "break"

    def grab_hold_scroll_pointer(self):
        button = getattr(self, "hold_scroll_button", None)
        if not button:
            return
        try:
            button.grab_set()
        except Exception:
            pass

    def release_hold_scroll_pointer(self):
        button = getattr(self, "hold_scroll_button", None)
        if not button:
            return
        try:
            if button.grab_current() is button:
                button.grab_release()
        except Exception:
            try:
                button.grab_release()
            except Exception:
                pass

    def cancel_hold_scroll(self):
        if self.hold_scroll_after is not None:
            try:
                self.root.after_cancel(self.hold_scroll_after)
            except Exception:
                pass
        self.hold_scroll_after = None
        self.hold_scroll_active = False
        self.hold_scroll_axis = "vertical"
        self.hold_scroll_updating = False
        self.release_hold_scroll_pointer()
        self.hold_scroll_button = None

    def set_live_skip_display(self, value):
        if getattr(self, "live_skip_after", None):
            try:
                self.root.after_cancel(self.live_skip_after)
            except Exception:
                pass
            self.live_skip_after = None
        self.programmatic_live_skip_updates = getattr(self, "programmatic_live_skip_updates", 0) + 1
        try:
            skip = int(str(value).strip())
        except Exception:
            self.live_skip.set(str(value))
            return
        if skip != 0:
            was_applying = getattr(self, "applying_live_skip", False)
            self.applying_live_skip = True
            try:
                self.live_skip.set(str(abs(skip)))
            finally:
                self.applying_live_skip = was_applying

    def schedule_live_skip_apply(self):
        self.update_context_header()
        pending_programmatic = getattr(self, "programmatic_live_skip_updates", 0)
        if pending_programmatic:
            self.programmatic_live_skip_updates = max(0, pending_programmatic - 1)
            return
        if self.applying_live_skip:
            return
        value = self.live_skip.get().strip()
        if value == "-":
            self.live_skip.set("")
            return
        if value.startswith("-") and value not in ("-", "+"):
            self.set_live_skip_display(value)
            return
        if not value or value in ("-", "+"):
            return
        try:
            int(value)
        except ValueError:
            return
        if self.live_skip_after:
            self.root.after_cancel(self.live_skip_after)
        self.live_skip_after = self.root.after(350, self.apply_live_skip)

    def apply_initial_live_skip(self):
        if self.saved or self.current_display_match:
            return
        self.apply_live_skip()

    def apply_live_skip(self, _event=None):
        if self.live_skip_after:
            self.root.after_cancel(self.live_skip_after)
            self.live_skip_after = None
        value = self.live_skip.get().strip()
        if not value:
            self.reset_live_skip_to_default()
            self.update_context_header()
            return
        try:
            new_skip = int(value)
            if new_skip == 0:
                raise ValueError
        except ValueError:
            self.status.set("דילוג חי חייב להיות מספר שלם שאינו 0")
            return

        self.applying_live_skip = True
        try:
            self._apply_live_skip_value(new_skip)
            self.save_app_settings()
        finally:
            self.applying_live_skip = False

    def current_display_skip_value(self) -> int:
        candidates = []
        if getattr(self, "current_display_match", None):
            candidates.append(getattr(self.current_display_match, "skip", None))
        if hasattr(self, "live_skip"):
            candidates.append(self.live_skip.get())
        if hasattr(self, "exact_skip"):
            candidates.append(self.exact_skip.get())
        if hasattr(self, "skip_from"):
            candidates.append(self.skip_from.get())
        for value in candidates:
            try:
                skip = int(str(value).strip())
                if skip != 0:
                    return abs(skip)
            except Exception:
                continue
        return 1

    def apply_display_fraction(self, divisor: int):
        divisor = max(1, int(divisor or 1))
        base_skip = self.current_display_skip_value()
        if self.active_display_fraction_divisor == divisor and self.display_fraction_original_skip:
            original = max(1, abs(int(self.display_fraction_original_skip)))
            self.set_live_skip_display(original)
            self._apply_live_skip_value(original)
            self.active_display_fraction_divisor = None
            self.display_fraction_original_skip = None
            self.save_app_settings()
            self.status.set(f"תצוגה בלבד: חזרה לדילוג הרגיל {original}.")
            return
        self.display_fraction_original_skip = base_skip
        self.active_display_fraction_divisor = divisor
        new_skip = max(1, int(round(abs(base_skip) / divisor)))
        if new_skip == 0:
            new_skip = 1
        self.set_live_skip_display(new_skip)
        self._apply_live_skip_value(new_skip)
        self.save_app_settings()
        self.status.set(f"תצוגה בלבד: דילוג {abs(base_skip)} חולק ל-{abs(new_skip)}. אפשר לסרוק את המסך הנוכחי.")

    def adjust_live_skip(self, delta: int):
        self.active_display_fraction_divisor = None
        self.display_fraction_original_skip = None
        new_skip = self.current_display_skip_value() + int(delta)
        if new_skip == 0:
            new_skip = 1
        new_skip = abs(new_skip)
        self.set_live_skip_display(new_skip)
        self._apply_live_skip_value(new_skip)
        self.save_app_settings()
        self.status.set(f"דילוג תצוגה עודכן ל-{abs(new_skip)}")

    def confirm_skip_fields(self, _event=None):
        if hasattr(self, "mode") and self.mode.get() == "text":
            self.exact_skip.set("1")
            self.status.set("חיפוש טקסט עובד בדילוג 1 בלבד; שדות הדילוג נעולים במצב זה.")
            return "break"
        if hasattr(self, "mode") and self.mode.get() == "text_skip" and self.exact_skip.get().strip():
            self.exact_skip.set("")
            self.status.set("טקסט+דילוג משתמש בטווח הדילוגים למשניות; דילוג מדויק אינו פעיל במצב זה.")
            return "break"
        try:
            if self.exact_skip.get().strip():
                self.parse_skips()
            else:
                chunks = self.split_skip_range_chunks(self.skip_from.get(), self.skip_to.get())
                if len(chunks) > 1:
                    self.status.set(f"טווח גדול יאותר בחלקים: {len(chunks)} טווחי משנה בתוך הטווח שהגדרת.")
                    self.update_context_header()
                    self.save_app_settings()
                    return "break"
                self.parse_skips()
        except Exception as e:
            self.status.set(str(e))
            return "break"
        self.update_context_header()
        self.save_app_settings()
        exact = self.exact_skip.get().strip() if hasattr(self, "exact_skip") else ""
        if exact:
            suffix = " מינימלי לא רלוונטי כשדילוג יחיד מלא, אך אפשר להשאיר אותו מסומן." if self.minimal_exact_skip_notice() else ""
            self.status.set(f"דילוג מדויק אושר: {exact}. לחץ Enter שוב או חפש כדי להריץ.{suffix}")
        else:
            self.status.set(f"טווח דילוגים אושר: {self.skip_from.get()}-{self.skip_to.get()}. לחץ Enter שוב או חפש כדי להריץ.")
        return "break"

    def adjust_skip_range(self, direction: int):
        if hasattr(self, "mode") and self.mode.get() == "text":
            self.status.set("במצב טקסט טווח הדילוגים נעול לדילוג 1.")
            return
        try:
            start = int(self.skip_from.get())
            end = int(self.skip_to.get())
        except Exception:
            self.status.set("כדי להקפיץ טווח, הזן קודם מספרים תקינים בשדות מ-עד.")
            return

        low, high = sorted((max(1, abs(start)), max(1, abs(end))))
        span = max(1, high - low + 1)
        step = span if int(direction) >= 0 else -span
        new_low = low + step
        new_high = high + step
        if new_low < 1:
            new_low = 1
            new_high = span
        if MAX_AUTO_EXTENDED_SKIP and new_high > MAX_AUTO_EXTENDED_SKIP:
            new_high = MAX_AUTO_EXTENDED_SKIP
            new_low = max(1, new_high - span + 1)
        if hasattr(self, "exact_skip") and self.exact_skip.get().strip():
            self.exact_skip.set("")
        self.skip_from.set(int(new_low))
        self.skip_to.set(int(new_high))
        self.update_context_header()
        self.save_app_settings()
        self.status.set(f"טווח הדילוגים הוקפץ ל-{new_low}-{new_high}.")

    def reset_skip_range_to_first(self):
        if hasattr(self, "mode") and self.mode.get() == "text":
            self.status.set("במצב טקסט טווח הדילוגים נעול לדילוג 1.")
            return
        first_from, first_to = 0, 800
        if hasattr(self, "exact_skip") and self.exact_skip.get().strip():
            self.exact_skip.set("")
        self.skip_from.set(first_from)
        self.skip_to.set(first_to)
        self.skip_chunk_queue = []
        self.skip_chunk_active = False
        self.skip_chunk_original_range = None
        self.update_context_header()
        self.save_app_settings()
        self.status.set(f"טווח הדילוגים אופס ל-{first_from}-{first_to}.")

    def on_skip_fields_changed(self, *_args):
        self.update_context_header()
        self.update_auto_advance_state()
        self.update_skip_range_field_state()

    def update_auto_advance_state(self):
        if not hasattr(self, "auto_advance_check"):
            return
        try:
            disabled = bool(self.exact_skip.get().strip()) or (hasattr(self, "mode") and self.mode.get() == "text")
            self.auto_advance_check.configure(state="disabled" if disabled else "normal")
        except tk.TclError:
            pass

    def update_skip_range_field_state(self):
        if not all(hasattr(self, name) for name in ("exact_skip_entry", "skip_from_entry", "skip_to_entry", "mode")):
            return
        try:
            mode = self.mode.get()
            exact_filled = bool(self.exact_skip.get().strip())
            exact_state = "disabled" if mode == "text_skip" else "normal"
            range_state = "disabled" if mode == "text" or exact_filled else "normal"
            if mode == "text":
                exact_state = "disabled"
            self.exact_skip_entry.configure(state=exact_state)
            for widget in (self.skip_from_entry, self.skip_to_entry):
                widget.configure(state=range_state)
        except tk.TclError:
            pass

    def minimal_exact_skip_notice(self) -> bool:
        return bool(
            hasattr(self, "opt_minimal_search")
            and self.opt_minimal_search.get()
            and hasattr(self, "exact_skip")
            and self.exact_skip.get().strip()
        )

    def on_search_mode_changed(self, *_args):
        if getattr(self, "adjusting_mode_fields", False):
            return
        if not all(hasattr(self, name) for name in ("exact_skip_entry", "skip_from_entry", "skip_to_entry", "mode")):
            return
        mode = self.mode.get()
        text_mode = mode == "text"
        text_skip_mode = mode == "text_skip"
        self.adjusting_mode_fields = True
        try:
            if text_mode:
                self.saved_non_text_skip_fields = {
                    "exact": self.exact_skip.get(),
                    "from": self.skip_from.get(),
                    "to": self.skip_to.get(),
                }
                self.exact_skip.set("1")
                self.status.set("מצב טקסט: החיפוש מתבצע בדילוג 1 בלבד.")
            elif text_skip_mode:
                if self.exact_skip.get().strip():
                    self.saved_text_skip_exact = self.exact_skip.get()
                    self.exact_skip.set("")
                self.status.set("מצב טקסט+דילוג: הראשית בדילוג 1, המשניות לפי טווח הדילוגים.")
            else:
                saved = getattr(self, "saved_non_text_skip_fields", {})
                if self.exact_skip.get().strip() == "1" and saved:
                    self.exact_skip.set(str(saved.get("exact", "")))
                    try:
                        self.skip_from.set(int(saved.get("from", self.skip_from.get())))
                        self.skip_to.set(int(saved.get("to", self.skip_to.get())))
                    except Exception:
                        pass
                elif not self.exact_skip.get().strip() and getattr(self, "saved_text_skip_exact", ""):
                    self.exact_skip.set(self.saved_text_skip_exact)
                    self.saved_text_skip_exact = ""
            self.update_context_header()
            self.update_auto_advance_state()
            self.update_skip_range_field_state()
        finally:
            self.adjusting_mode_fields = False

    def _apply_live_skip_value(self, new_skip: int):
        new_skip = abs(int(new_skip or 1))
        if new_skip == 0:
            new_skip = 1
        if not self.saved or not self.current_display_match:
            anchor = getattr(self.canvas, "linear_start", 0)
            if self.current_display_match:
                anchor = self.current_display_match.start
            word = self.engine.normalize_word(self.get_primary_word()) or "דילוג"
            display_primary = Match(word, anchor, new_skip, "display")
            display_primary.calc_positions()
            self.current_display_match = display_primary
            self.canvas.build_skip_grid(display_primary)
            self.canvas.set_matches([])
            self.update_context_header()
            return

        pm, local = self.saved[self.current]
        display_primary = Match(pm.word, pm.start, new_skip, "display", pm.color, [])
        display_primary.calc_positions()
        self.current_display_match = display_primary
        self.canvas.build_skip_grid(display_primary)
        self.canvas.set_matches(local)
        self.status.set(f"דילוג תצוגה עודכן ל-{abs(new_skip)}; הממצא המקורי נשמר בדילוג {abs(pm.skip or 1)}")
        self.update_context_header()

    def update_context_header(self):
        if not hasattr(self, "context_title"):
            return
        def safe_var(var, default=""):
            try:
                return var.get()
            except Exception:
                return default
        primary = self.engine.normalize_word(self.get_primary_word()) if hasattr(self, "primary_text") else ""
        secondary = self.secondary_words() if hasattr(self, "secondary") else []
        canvas_obj = getattr(self, "canvas", None)
        mode = getattr(canvas_obj, "view_mode", "linear")
        if self.current_display_match:
            current_skip_text = str(abs(self.current_display_match.skip or 1))
            search_skip_text = current_skip_text
            pos_text = f"מיקום {self.current_display_match.start + 1:,}"
            spp_text = self.model.spp_at(self.current_display_match.start)
        else:
            live_value = str(safe_var(self.live_skip, "")).strip() if hasattr(self, "live_skip") else ""
            exact = str(safe_var(self.exact_skip, "")).strip() if hasattr(self, "exact_skip") else ""
            if exact:
                search_skip_text = exact
            elif hasattr(self, "skip_from") and hasattr(self, "skip_to"):
                search_skip_text = f"{safe_var(self.skip_from, '?')}-{safe_var(self.skip_to, '?')}"
            else:
                search_skip_text = "-"
            current_skip_text = live_value or exact
            try:
                display_skip_value = int(current_skip_text)
                current_skip_text = str(abs(display_skip_value))
            except Exception:
                pass
            if not current_skip_text and mode == "skip" and hasattr(self, "skip_from"):
                current_skip_text = str(safe_var(self.skip_from, "0")).strip() or "0"
            if not current_skip_text:
                current_skip_text = str(getattr(canvas_obj, "cols", 1) or 1)
            pos_text = f"מיקום {getattr(canvas_obj, 'linear_start', 0) + 1:,}" if canvas_obj else "מיקום 1"
            spp_text = self.model.spp_at(getattr(canvas_obj, "linear_start", 0)) if canvas_obj else ""
        mode_text = "טבלת צופן" if mode == "skip" else "טקסט רציף"
        visible_words = self.visible_found_words_summary()
        if mode == "skip":
            extra = int(getattr(canvas_obj, "view_cols_extra", 0) or 0)
            if extra < 0:
                width_text = "חלון תצוגה: מצומצם"
            elif extra > 0:
                width_text = "חלון תצוגה: מורחב"
            else:
                width_text = "חלון תצוגה: רגיל"
        else:
            width_text = f"אותיות בשורה: {getattr(canvas_obj, 'cols', '-')}"
        self.context_title.set(
            f"{mode_text} | דילוג: {current_skip_text} | {width_text} | מילים במסך: {visible_words} | {pos_text} {spp_text}"
        )
        if hasattr(self, "current_skip_banner"):
            self.current_skip_banner.set(f"טבלה בדילוג: {current_skip_text}")
        self.update_context_word_buttons()
        if hasattr(self, "root"):
            self.root.title(APP_WINDOW_TITLE)

    def visible_context_matches(self):
        canvas_obj = getattr(self, "canvas", None)
        if not canvas_obj:
            return []
        visible = canvas_obj.visible_positions()
        matches = []
        seen = set()
        for match in getattr(canvas_obj, "matches", []):
            if match.kind == "manual":
                continue
            positions = set(match.calc_positions())
            if visible and not (positions & visible):
                continue
            key = (canonical_hebrew(match.word), match.start, match.skip, match.kind)
            if key in seen:
                continue
            seen.add(key)
            matches.append(match)
        matches.sort(key=lambda m: (0 if m.kind == "primary" else 1, m.start, abs(m.skip or 1), m.word))
        return matches

    def current_cipher_context_matches(self):
        if self.saved and 0 <= self.current < len(self.saved):
            primary, local = self.saved[self.current]
            matches = [primary] + list(local or [])
        else:
            matches = list(getattr(getattr(self, "canvas", None), "matches", []) or [])
        unique = []
        seen = set()
        for match in matches:
            if match.kind == "manual":
                continue
            key = (canonical_hebrew(match.word), match.start, match.skip, match.kind)
            if key in seen:
                continue
            seen.add(key)
            unique.append(match)
        unique.sort(key=lambda m: (0 if m.kind == "primary" else 1, m.start, abs(m.skip or 1), m.word))
        return unique

    def visible_context_word_groups(self):
        groups: Dict[str, dict] = {}
        order = []
        canvas_obj = getattr(self, "canvas", None)
        if not canvas_obj:
            return []
        visible_positions = canvas_obj.visible_positions()
        if not visible_positions:
            return []
        for match in self.current_cipher_context_matches():
            positions = set(match.calc_positions())
            if not positions or not (positions & visible_positions):
                continue
            key = canonical_hebrew(match.word)
            if not key:
                continue
            if key not in groups:
                groups[key] = {
                    "word": match.word,
                    "match": match,
                    "matches": [],
                    "count": 0,
                    "skip_counts": {},
                    "skip_matches": {},
                    "color": match.color or ("#ff3b30" if match.kind == "primary" else stable_word_color(match.word)),
                    "priority": 0 if match.kind == "primary" else 1,
                }
                order.append(key)
            group = groups[key]
            group["matches"].append(match)
            group["count"] += 1
            skip_abs = abs(match.skip or 1)
            group["skip_counts"][skip_abs] = group["skip_counts"].get(skip_abs, 0) + 1
            group["skip_matches"].setdefault(skip_abs, match)
            if match.kind == "primary" and group["priority"] != 0:
                group["match"] = match
                group["color"] = match.color or "#ff3b30"
                group["priority"] = 0
                group["skip_matches"][skip_abs] = match
        return [groups[key] for key in order]

    def format_context_word_group(self, group: dict) -> str:
        word_part = str(group.get("word", ""))
        count = int(group.get("count", 0) or 0)
        if count > 1:
            word_part += f" X{count}"
        skip_parts = []
        for skip_value, skip_count in sorted(group.get("skip_counts", {}).items()):
            part = str(abs(skip_value or 1))
            if skip_count > 1:
                part += f" X{skip_count}"
            skip_parts.append(part)
        skips_text = ", ".join(skip_parts) if skip_parts else "-"
        return f"{word_part} {skips_text}"

    def update_context_word_buttons(self):
        frame = getattr(self, "context_words_frame", None)
        if not frame:
            return
        for child in frame.winfo_children():
            child.destroy()
        groups = self.visible_context_word_groups()
        shown_groups = groups
        self.context_word_targets = [group["match"] for group in shown_groups]
        self.context_word_widgets = []
        self.context_word_groups = shown_groups
        for group in shown_groups:
            match = group["match"]
            color = group.get("color") or stable_word_color(group.get("word", match.word))
            fg = readable_text_on_bg(color, "#111111")
            holder = tk.Frame(frame, bg=color, bd=1, relief="solid", cursor="hand2")
            count = int(group.get("count", 0) or 0)
            word_text = str(group.get("word", match.word))
            if count > 1:
                word_text += f" X{count}"
            word_label = tk.Label(
                holder,
                text=rtl_display(word_text),
                bg=color,
                fg=fg,
                bd=0,
                padx=5,
                pady=1,
                font=("Arial", 9, "bold"),
                cursor="hand2",
            )
            word_label.pack(side="right")
            word_label.bind("<Double-Button-1>", lambda _event, item=match: self.center_context_match(item))
            word_label.bind("<Button-3>", lambda event, item=match: self.match_context_menu(event, item, source="top"))
            holder.bind("<Double-Button-1>", lambda _event, item=match: self.center_context_match(item))
            holder.bind("<Button-3>", lambda event, item=match: self.match_context_menu(event, item, source="top"))
            for skip_value, skip_count in sorted(group.get("skip_counts", {}).items()):
                skip_match = group.get("skip_matches", {}).get(skip_value, match)
                skip_text = str(abs(skip_value or 1))
                if skip_count > 1:
                    skip_text += f" X{skip_count}"
                skip_label = tk.Label(
                    holder,
                    text=skip_text,
                    bg=color,
                    fg=fg,
                    bd=0,
                    padx=4,
                    pady=1,
                    font=("Arial", 9, "bold"),
                    cursor="hand2",
                )
                skip_label.pack(side="right")
                skip_label.bind("<Double-Button-1>", lambda _event, item=skip_match: self.center_context_match(item))
                skip_label.bind("<Button-3>", lambda event, item=skip_match: self.match_context_menu(event, item, source="top"))
                add_tooltip(skip_label, "דילוג של המילה. דאבל קליק מרכז לממצא בדילוג זה; קליק ימני פותח את תפריט הממצא.")
            add_tooltip(holder, "דאבל קליק מרכז לתוך ממצא זה. קליק ימני פותח את תפריט הממצא.")
            self.context_word_widgets.append(holder)
        self.update_context_top_lines_button()
        self.root.after_idle(self.layout_context_word_buttons)

    def context_top_connectors_exist(self) -> bool:
        canvas_obj = getattr(self, "canvas", None)
        return bool(canvas_obj and getattr(canvas_obj, "top_connector_lines", []))

    def update_context_top_lines_button(self):
        btn = getattr(self, "context_top_lines_btn", None)
        if not btn:
            return
        if self.context_top_connectors_exist():
            btn.configure(text="הסר קווים", bg="#f4cccc", activebackground="#ea9999", fg="#660000", activeforeground="#660000")
        else:
            btn.configure(text="שלח קווים", bg="#d9e8fb", activebackground="#b4d0f4", fg="#174f8a", activeforeground="#174f8a")

    def toggle_all_top_context_connectors(self):
        if not hasattr(self, "canvas"):
            return
        if self.context_top_connectors_exist():
            removed = self.canvas.clear_top_connectors()
            self.status.set(f"הוסרו {removed} קווים מהממצאים" if removed else "אין קווים להסרה")
            self.update_context_top_lines_button()
            return
        groups = list(getattr(self, "context_word_groups", []) or [])
        widgets = list(getattr(self, "context_word_widgets", []) or [])
        added = self.canvas.add_top_connectors_for_groups(list(zip(groups, widgets)))
        self.status.set(f"נשלחו {added} קווים מהמילים למעלה אל הממצאים" if added else "לא נוספו קווים חדשים")
        self.update_context_top_lines_button()

    def layout_context_word_buttons(self):
        canvas = getattr(self, "context_words_canvas", None)
        frame = getattr(self, "context_words_frame", None)
        widgets = list(getattr(self, "context_word_widgets", []) or [])
        if not canvas or not frame:
            return
        canvas.update_idletasks()
        available = max(1, canvas.winfo_width(), canvas.winfo_reqwidth())
        display_width = self.print_canvas_right_edge_in_display()
        if display_width:
            available = max(1, int(display_width))
            canvas.configure(width=available)
        widths = [max(1, widget.winfo_reqwidth()) + 2 for widget in widgets]
        rows = []
        current_row = []
        current_width = 0
        for index, width in enumerate(widths):
            if current_row and current_width + width > available:
                rows.append(current_row)
                current_row = []
                current_width = 0
            current_row.append(index)
            current_width += width
        if current_row:
            rows.append(current_row)
        if not rows:
            rows = [[]]
        row_height = 27
        band_height = max(31, row_height * len(rows) + 4)
        frame.configure(width=available, height=band_height)
        canvas.configure(height=band_height)
        canvas.itemconfigure(self.context_words_window, width=available, height=band_height)
        for widget in widgets:
            widget.place_forget()
        top = max(1, (band_height - row_height * len(rows)) // 2)
        for row_number, indices in enumerate(rows):
            row_width = sum(widths[index] for index in indices)
            cursor = (available + min(available, row_width)) / 2
            for index in indices:
                width = widths[index]
                cursor -= width
                widgets[index].place(x=max(0, int(cursor)), y=top + row_number * row_height)
        self.refresh_context_words_scrollregion()

    def on_context_words_configure(self, _event=None):
        self.refresh_context_words_scrollregion()

    def on_context_words_canvas_configure(self, event=None):
        canvas = getattr(self, "context_words_canvas", None)
        window = getattr(self, "context_words_window", None)
        if not canvas or window is None:
            return
        width = max(1, int(getattr(event, "width", canvas.winfo_width()) or canvas.winfo_width()))
        canvas.coords(window, 0, 0)
        self.layout_context_word_buttons()

    def refresh_context_words_scrollregion(self):
        canvas = getattr(self, "context_words_canvas", None)
        frame = getattr(self, "context_words_frame", None)
        if not canvas or not frame:
            return
        frame.update_idletasks()
        bbox = canvas.bbox("all")
        if bbox:
            canvas.configure(scrollregion=bbox)
            canvas.xview_moveto(0.0)

    def on_context_words_mousewheel(self, event):
        canvas = getattr(self, "context_words_canvas", None)
        if not canvas:
            return "break"
        delta = -1 if getattr(event, "delta", 0) > 0 else 1
        canvas.xview_scroll(delta, "units")
        return "break"

    def center_context_match(self, match: Match):
        self.center_match_in_view(match)
        self.canvas.canvas.focus_set()
        self.status.set(f"{match.word} נפתח במרכז מדאבל קליק בשורה העליונה")
        return "break"

    def visible_found_words_summary(self) -> str:
        items = [self.format_context_word_group(group) for group in self.visible_context_word_groups()]
        if not items:
            return "-"
        shown = ", ".join(items[:8])
        if len(items) > 8:
            shown += f" ועוד {len(items) - 8}"
        return shown

    def toggle_selection_mode(self):
        self.canvas.set_selection_enabled(self.selection_mode.get())
        self.status.set("מצב סימון ידני פעיל" if self.selection_mode.get() else "מצב סימון ידני כבוי")

    def add_manual_mark(self):
        if not self.selection_mode.get() and not self.canvas.selected_positions:
            self.selection_mode.set(True)
            self.toggle_selection_mode()
            self.status.set("מצב סימון ידני הופעל. גרור על אותיות ואז לחץ שוב על סמן.")
            return
        if self.canvas.add_manual_mark():
            self.status.set(f"סומן ידנית: {self.canvas.manual_marks[-1].word}")
        else:
            self.status.set("גרור על אותיות במסך ואז לחץ שוב על סמן כדי לשמור את ההדגשה")

    def clear_manual_marks(self):
        self.push_app_undo_state("ניקוי סימונים ידניים")
        if self.canvas.clear_manual():
            self.status.set("הסימונים הידניים נוקו")
        else:
            self.status.set("אין סימונים ידניים לניקוי")

    def clear_primary_field(self):
        self.primary_var.set("")
        self.primary_text.icursor("end")
        self.save_search_state()
        self.update_context_header()
        self.status.set("שדה הראשית נוקה")

    def clear_secondary_field(self):
        self.secondary_var.set("")
        self.secondary.icursor("end")
        self.save_search_state()
        self.update_find_chance_label()
        self.status.set("שדה המשניות נוקה")

    def clear_search_words(self):
        self.push_app_undo_state("ניקוי שדות מילים")
        self.primary_var.set("")
        self.secondary_var.set("")
        self.clear_search_state()
        self.current_display_match = None
        self.reset_live_skip_to_default()
        self.update_context_header()
        self.status.set("שדות המילים לחיפוש נוקו")

    def clear_all_work(self):
        self.push_app_undo_state("ניקוי כל העבודה")
        self.engine.stop_flag = True
        self.scan_stop = True
        self.primary_var.set("")
        self.secondary_var.set("")
        self.clear_search_state()
        self.preserve_saved_on_next_results = False
        self.cached_primary_key = None
        self.cached_primary_matches = []
        self.saved = []
        self.current = 0
        self.current_display_match = None
        self.reset_live_skip_to_default()
        self.results.delete(0, "end")
        self.result_rows = []
        self.canvas.clear_manual()
        self.canvas.set_matches([])
        self.canvas.build_linear(getattr(self.canvas, "linear_start", 0))
        self.progress.configure(value=0)
        self.update_context_header()
        self.status.set("נוקה הכל: מילים, ממצאים, סריקות וסימונים ידניים")

    def open_dates_tool(self):
        win = tk.Toplevel(self.root)
        win.title("קובץ תאריכים")
        win.transient(self.root)
        self.prepare_child_window(win, 520, 390)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)
        frame.columnconfigure(2, weight=1)
        frame.rowconfigure(1, weight=1)

        ttk.Label(frame, text="סריקת התאריכים נפרדת מכפתור סרוק הרגיל. הסריקה מוגבלת רק לארבעת הדילוגים סביב הצופן: N, N-1, N+1 ודילוג 1.", wraplength=390, justify="right").grid(
            row=0, column=0, columnspan=3, sticky="e", pady=(0, 6)
        )
        preview = tk.Listbox(frame, height=9, width=48)
        preview.grid(row=1, column=0, columnspan=3, sticky="nsew", pady=(6, 4))
        av_check = ttk.Checkbutton(
            frame,
            text="כלול גם תאריכים עם חודש אב",
            variable=self.opt_include_av_dates,
            command=self.save_app_settings,
        )
        av_check.grid(row=2, column=0, columnspan=3, sticky="e", pady=(0, 4))
        add_tooltip(av_check, "חודש אב קצר ועלול להוסיף הרבה צירופים; לכן הוא נבדק רק לפי בחירה.")

        def refresh():
            data = self.ensure_date_words_file()
            words = (
                data.get("months", [])
                + data.get("days", [])
                + data.get("years_full", [])[:8]
                + data.get("years_short", [])[:8]
                + data.get("day_month", [])[:20]
            )
            preview.delete(0, "end")
            preview.insert("end", f"קובץ: {DATE_WORDS_FILE}")
            preview.insert("end", f"חודשים: {len(data.get('months', []))} | ימים: {len(data.get('days', []))}")
            preview.insert("end", f"צירופי יום+חודש: {len(data.get('day_month', []))}")
            preview.insert("end", f"שנים מלאות: {len(data.get('years_full', []))} | בלי אלפים: {len(data.get('years_short', []))}")
            preview.insert("end", "דוגמאות:")
            for word in words[:80]:
                preview.insert("end", word)
            self.status.set(f"קובץ התאריכים מוכן: {DATE_WORDS_FILE}")

        ttk.Button(frame, text="סרוק תאריכים", command=lambda: (win.destroy(), self.scan_current_dates())).grid(row=3, column=0, sticky="ew", padx=2, pady=(4, 0))
        ttk.Button(frame, text="רענן קובץ", command=refresh).grid(row=3, column=1, sticky="ew", padx=2, pady=(4, 0))
        ttk.Button(frame, text="סגור", command=win.destroy).grid(row=3, column=2, sticky="ew", padx=2, pady=(4, 0))
        refresh()

    def date_search_variants(self, day: str = "", month: str = "", year: str = "") -> List[str]:
        def clean(value: str) -> str:
            value = (value or "").strip()
            if value.isdigit():
                return hebrew_number(int(value))
            return self.engine.normalize_word(value)

        day_word = clean(day)
        month_word = clean(month)
        year_word = clean(year)
        if year.strip().isdigit():
            y = int(year.strip())
            if y >= 5000:
                year_word = hebrew_number(y - 5000)

        words = []
        if day_word:
            words.extend([day_word, f"יום{day_word}", f"ב{day_word}"])
        if month_word:
            words.extend([month_word, f"ב{month_word}", f"חודש{month_word}", f"בחודש{month_word}"])
        if year_word:
            words.extend([year_word, f"ה{year_word}", f"שנת{year_word}", f"בשנת{year_word}"])
        if day_word and month_word:
            words.extend([f"{day_word}{month_word}", f"{month_word}{day_word}", f"ב{day_word}{month_word}"])
        if month_word and year_word:
            words.extend([f"{month_word}{year_word}", f"{year_word}{month_word}", f"ב{month_word}{year_word}"])
        if day_word and month_word and year_word:
            words.extend([f"{day_word}{month_word}{year_word}", f"{year_word}{month_word}{day_word}"])
        normalized = [self.engine.normalize_word(w) for w in words]
        return [w for w in dict.fromkeys(normalized) if len(w) >= 2]

    def add_words_to_secondary(self, words: List[str], mark_as_dates: bool = False):
        self.push_app_undo_state("הוספת מילים למשניות")
        existing = self.secondary_words()
        seen = {canonical_hebrew(w) for w in existing}
        additions = []
        for word in words:
            key = canonical_hebrew(word)
            if key not in seen:
                seen.add(key)
                additions.append(word)
        if additions:
            current = self.secondary_var.get().strip()
            sep = " " if current else ""
            self.secondary_var.set(current + sep + " ".join(additions))
            self.secondary.icursor("end")
        if mark_as_dates:
            for word in words:
                if len(word) >= 2:
                    self.date_fraction_words.add(canonical_hebrew(word))

    def ask_hebrew_words_text(self, title: str, prompt: str, initial: str = "") -> Optional[str]:
        win = tk.Toplevel(self.root)
        win.title(title)
        win.transient(self.root)
        self.prepare_child_window(win, 460, 170)
        win.resizable(True, False)
        result = {"value": None}
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        ttk.Label(frame, text=rtl_display(prompt), anchor="e", justify="right", wraplength=420).grid(row=0, column=0, sticky="ew", pady=(0, 6))
        value_var = tk.StringVar(value=initial)
        field = FixedHebrewField(frame, textvariable=value_var, height=2, width=44, font=("Arial", 12))
        field.grid(row=1, column=0, sticky="ew")
        buttons = ttk.Frame(frame)
        buttons.grid(row=2, column=0, sticky="ew", pady=(8, 0))

        def ok():
            result["value"] = value_var.get()
            win.destroy()

        def cancel():
            result["value"] = None
            win.destroy()

        field.return_command = ok
        ttk.Button(buttons, text="אישור", command=ok).pack(side="right", padx=(0, 4))
        ttk.Button(buttons, text="בטל", command=cancel).pack(side="right", padx=4)
        win.protocol("WM_DELETE_WINDOW", cancel)
        win.after(80, lambda: (field.focus_set(), field.icursor("end")))
        self.root.wait_window(win)
        return result["value"]

    def add_secondary_words_and_scan(self):
        raw = self.ask_hebrew_words_text(
            "הוסף משניות וסרוק",
            "הקלד מילים או ביטויים להוספה למשניות, מופרדים ברווח או פסיק:",
        )
        if raw is None:
            return
        words = [self.engine.normalize_word(w) for w in re.split(r"[\s,;|]+", raw) if self.engine.normalize_word(w)]
        words = [w for w in dict.fromkeys(words) if len(w) >= 2]
        if not words:
            self.status.set("לא נוספו מילים: יש להקליד מילים באורך שתי אותיות לפחות")
            return
        before = {canonical_hebrew(w) for w in self.secondary_words()}
        self.add_words_to_secondary(words)
        added_words = [w for w in words if canonical_hebrew(w) not in before]
        added = len(added_words)
        if added:
            self.save_search_state()
            self.update_find_chance_label()
        if not self.saved:
            self.status.set(f"נוספו {added} מילים למשניות. לאחר פתיחת צופן אפשר ללחוץ שוב כדי לסרוק את המסך.")
            return
        if not added_words:
            self.lock_status_until_next_search("לא נוספו משניות חדשות לסריקה בכל הראשיות")
            return
        self.scan_added_secondaries_all_primaries(added_words)

    def scan_added_secondaries_all_primaries(self, words: List[str]):
        if self.stop_running_then(lambda: self.scan_added_secondaries_all_primaries(words), "סריקת משניות בכל הראשיות"):
            return
        words = [w for w in dict.fromkeys(self.engine.normalize_word(w) for w in words) if len(w) >= 2]
        if not words:
            self.status.set("אין משניות חדשות לסריקה")
            return
        if not self.saved:
            self.status.set("אין ראשיות שמורות לסריקת תוספת משניות")
            return
        self.clear_status_lock()
        current_only = bool(hasattr(self, "opt_current_view_only") and self.opt_current_view_only.get())
        if current_only and 0 <= self.current < len(self.saved):
            saved_indices = [self.current]
        else:
            saved_indices = list(range(len(self.saved)))
        saved_snapshot = [(idx, self.saved[idx][0], list(self.saved[idx][1])) for idx in saved_indices]
        current_key = None
        if 0 <= self.current < len(self.saved):
            cur_pm, _cur_local = self.saved[self.current]
            current_key = (cur_pm.word, cur_pm.start, cur_pm.skip)
        scope_text = "בצופן הנוכחי" if current_only else f"בכל {len(saved_snapshot)} הראשיות"
        self.status.set(f"סורק {len(words)} משניות {scope_text} בלי לחפש ראשיות מחדש...")
        self.progress.configure(value=0)
        self.engine.begin_search()
        self.scan_stop = False
        self.update_search_button_state()
        self.scan_thread = threading.Thread(
            target=self._scan_added_secondaries_all_primaries_worker,
            args=(saved_snapshot, words, current_key),
            daemon=True,
        )
        self.scan_thread.start()

    def scan_secondary_field_all_primaries(self):
        words = [w for w in self.secondary_words() if len(w) >= 2]
        if not words:
            rtl_showinfo("סריקת משניות", "אין מילים בשדה משניות")
            return
        if not self.saved:
            rtl_showinfo("סריקת משניות", "אין ראשיות שמורות. קודם חפש ראשית אחת לפחות.")
            return
        self.scan_added_secondaries_all_primaries(words)

    def _scan_added_secondaries_all_primaries_worker(
        self,
        saved_snapshot: List[Tuple[int, Match, List[Match]]],
        words: List[str],
        current_key: Optional[Tuple[str, int, int]],
    ):
        try:
            updated, total_added, affected = self.scan_secondaries_into_saved_snapshot(
                saved_snapshot,
                words,
                progress=lambda idx, total: self.set_progress(idx, total, f"סורק משניות בכל הראשיות {idx}/{total}"),
            )
            self.root.after(0, lambda: self.finish_added_secondaries_all_primaries(updated, total_added, affected, current_key))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("סריקת משניות", str(e)))
            self.root.after(0, self.mark_search_finished)

    def scan_secondaries_into_saved_snapshot(
        self,
        saved_snapshot: List[Tuple[int, Match, List[Match]]],
        words: List[str],
        progress=None,
    ) -> Tuple[List[Tuple[int, Match, List[Match]]], int, int]:
        updated = []
        total_added = 0
        affected = 0
        total = max(1, len(saved_snapshot))
        for idx, (saved_idx, pm, local) in enumerate(saved_snapshot, 1):
            if self.engine.should_stop():
                updated.extend(saved_snapshot[idx - 1:])
                break
            if progress:
                progress(idx, total)
            window = self.positions_for_primary_grid(pm)
            existing = {(m.word, tuple(m.calc_positions()), m.kind) for m in local}
            existing_core = {(canonical_hebrew(m.word), tuple(m.calc_positions())) for m in local}
            additions = []
            for word in words:
                if self.engine.should_stop():
                    break
                matches = self.engine.find_in_window(word, window, self.secondary_skip_options(pm.skip), "secondary")
                for match in matches:
                    key = (match.word, tuple(match.calc_positions()), match.kind)
                    core_key = (canonical_hebrew(match.word), tuple(match.calc_positions()))
                    if key in existing or core_key in existing_core:
                        continue
                    existing.add(key)
                    existing_core.add(core_key)
                    additions.append(match)
            if additions:
                self.apply_word_colors(additions)
                local = TorahCanvas.drop_matches_inside_longer(local + additions)
                total_added += len(additions)
                affected += 1
            updated.append((saved_idx, pm, local))
        return updated, total_added, affected

    def finish_added_secondaries_all_primaries(
        self,
        updated: List[Tuple[int, Match, List[Match]]],
        total_added: int,
        affected: int,
        current_key: Optional[Tuple[str, int, int]],
    ):
        if updated:
            merged = list(self.saved)
            for saved_idx, pm, local in updated:
                if 0 <= saved_idx < len(merged):
                    merged[saved_idx] = (pm, local)
            self.saved = self.sort_saved_ciphers(merged)
            self.current = 0
            if current_key:
                for idx, (pm, _local) in enumerate(self.saved):
                    if (pm.word, pm.start, pm.skip) == current_key:
                        self.current = idx
                        break
            self.open_results_table()
            self.refresh_current_saved_without_recenter()
        if self.scan_stop or self.engine.stop_reason:
            reason = self.engine.stop_reason or "סריקת המשניות נעצרה ידנית"
            self.status.set(f"{reason} | נוספו {total_added} סימונים ב-{affected} ראשיות")
        elif total_added:
            self.status.set(f"נוספו {total_added} סימוני משניות ב-{affected} ראשיות, בלי חיפוש ראשיות מחדש")
        else:
            self.lock_status_until_next_search("לא נמצאו משניות חדשות סביב הראשיות הקיימות")
        self.mark_search_finished()

    def normalize_year_skip_value(self, value: str) -> int:
        raw = str(value).strip()
        if not raw:
            raise ValueError("empty")
        year_skip = abs(int(raw))
        if year_skip == 0:
            raise ValueError("zero")
        if year_skip < 1000:
            year_skip += 5000
        return year_skip

    def position_year_skip_window(self, win: tk.Toplevel, width: int, height: int):
        self.root.update_idletasks()
        anchor = getattr(self, "year_skip_button", None)
        if anchor is not None and anchor.winfo_exists():
            x = anchor.winfo_rootx()
            y = anchor.winfo_rooty() + anchor.winfo_height() + 4
        else:
            x = self.root.winfo_pointerx()
            y = self.root.winfo_pointery()
        screen_w = win.winfo_screenwidth()
        screen_h = win.winfo_screenheight()
        x = max(0, min(x, screen_w - width - 8))
        y = max(0, min(y, screen_h - height - 48))
        win.geometry(f"{width}x{height}+{x}+{y}")
        try:
            win.minsize(width, height)
            win.maxsize(width, height)
        except tk.TclError:
            pass

    def open_year_skip_search(self):
        win = tk.Toplevel(self.root)
        win.title("דילוג שנה")
        win.transient(self.root)
        apply_window_icon(win)
        win.resizable(False, False)
        self.position_year_skip_window(win, 260, 112)
        frame = ttk.Frame(win, padding=8)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)
        ttk.Label(frame, text="שנה", style="Compact.TLabel").grid(row=0, column=3, sticky="e", padx=(2, 0), pady=2)
        year_var = tk.StringVar(value="5786")
        year_entry = ttk.Entry(frame, textvariable=year_var, width=7, justify="center")
        year_entry.grid(row=0, column=1, sticky="ew", padx=2, pady=2)

        def adjust_year(delta: int):
            try:
                year_skip = self.normalize_year_skip_value(year_var.get())
            except ValueError:
                year_skip = 5786
            year_var.set(str(max(1, year_skip + delta)))

        ttk.Button(frame, text="▲", width=3, command=lambda: adjust_year(1)).grid(row=0, column=0, sticky="ew", padx=1, pady=2)
        ttk.Button(frame, text="▼", width=3, command=lambda: adjust_year(-1)).grid(row=0, column=2, sticky="ew", padx=1, pady=2)
        ttk.Label(frame, text="אפשר 786 במקום 5786", style="Compact.TLabel").grid(
            row=1, column=0, columnspan=4, sticky="e", pady=(0, 4)
        )

        def run():
            try:
                year_skip = self.normalize_year_skip_value(year_var.get())
            except ValueError:
                rtl_showerror("דילוג שנה", "יש להזין שנה כמספר, למשל 5786 או 786")
                return
            win.destroy()
            self.search_by_year_skip(year_skip)

        def confirm_from_keyboard(_event=None):
            run()
            return "break"

        ttk.Button(frame, text="אישור", command=run).grid(row=2, column=0, columnspan=2, sticky="ew", padx=2)
        ttk.Button(frame, text="סגור", command=win.destroy).grid(row=2, column=2, columnspan=2, sticky="ew", padx=2)
        year_entry.bind("<Return>", confirm_from_keyboard)
        year_entry.bind("<KP_Enter>", confirm_from_keyboard)
        win.bind("<Return>", confirm_from_keyboard)
        win.bind("<KP_Enter>", confirm_from_keyboard)
        year_entry.focus_set()
        year_entry.selection_range(0, "end")

    def search_by_year_skip(self, year_skip: int):
        if self.stop_running_then(lambda: self.search_by_year_skip(year_skip), "חיפוש בדילוג השנה"):
            return
        self.cluster_fraction_mode = 1
        self.mode.set("code")
        self.exact_skip.set(str(year_skip))
        self.status.set(f"חיפוש ראשית בדילוג השנה {year_skip}; משניות גם באלכסון")
        self.run_search()

    def load_auto(self):
        try:
            info = self.model.load(TORAH_SEARCH_FILE, TORAH_DISPLAY_FILE)
            self.engine = SearchEngine(self.model)
            self.engine.build_index()
            self.canvas.model = self.model
            self.current_display_match = None
            self.reset_live_skip_to_default()
            self.canvas.build_linear(0)
            self.status.set("")
            if not info["count_ok"]:
                rtl_showerror("תורה לא מאומתת", f"{TORAH_SEARCH_FILE} אינו 304,805 אותיות.\nלא להמשיך עד תיקון.")
        except Exception as e:
            self.status.set(str(e))
            rtl_showerror("טעינה", str(e))

    def load_dialog(self):
        p = filedialog.askopenfilename(title="בחר torah_clean.txt", filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if p:
            try:
                info = self.model.load(p, TORAH_DISPLAY_FILE)
                self.engine = SearchEngine(self.model)
                self.engine.build_index()
                self.canvas.model = self.model
                self.current_display_match = None
                self.reset_live_skip_to_default()
                self.canvas.build_linear(0)
                self.status.set(f"נטען {os.path.basename(p)}: {info['count']:,} | תקין {info['count_ok']} | sha {info['sha256'][:12]}")
                if not info["count_ok"] or not info["start_ok"] or not info["end_ok"]:
                    rtl_showwarning(
                        "קובץ תורה חשוד",
                        "הקובץ נטען לבדיקה, אבל הוא לא עומד בכל תנאי האימות.\n"
                        "אפשר להשוות ולחקור, אבל לא מומלץ לסמוך עליו לצפנים."
                    )
            except Exception as e:
                rtl_showerror("טעינה", str(e))

    def compare_torah_files(self):
        paths = filedialog.askopenfilenames(title="בחר קבצי תורה להשוואה", filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if not paths:
            return
        lines = ["השוואת קבצי תורה", ""]
        base_letters = None
        base_name = ""
        for path in paths:
            try:
                raw = TorahLoader.read_file(path)
                letters = TorahLoader.hebrew_only(TorahLoader.strip_marks(raw))
                digest = hashlib.sha256(letters.encode("utf-8")).hexdigest()
                diff = ""
                if base_letters is None:
                    base_letters = letters
                    base_name = os.path.basename(path)
                    diff = "קובץ בסיס"
                else:
                    first = next((i for i, (a, b) in enumerate(zip(base_letters, letters)) if a != b), None)
                    if first is None and len(base_letters) == len(letters):
                        diff = f"זהה ל-{base_name}"
                    elif first is None:
                        diff = f"אין הבדל בתחילת הטקסט; הפרש אורך {len(letters) - len(base_letters):,}"
                    else:
                        diff = f"הבדל ראשון במיקום {first + 1:,}: בסיס={base_letters[first]} קובץ={letters[first]}"
                lines.append(
                    f"{os.path.basename(path)} | אותיות {len(letters):,} | הפרש {len(letters) - TARGET_COUNT:,} | "
                    f"sha {digest[:16]} | {diff}"
                )
            except Exception as e:
                lines.append(f"{path} | שגיאה: {e}")
        rtl_showinfo("השוואת תורה", "\n".join(lines))

    def get_primary_word(self) -> str:
        try:
            return self.primary_var.get().strip()
        except Exception:
            return self.get_primary_word().strip() if hasattr(self, "primary") else ""

    def set_primary_word(self, value: str):
        try:
            self.primary_var.set(value)
            self.primary_text.icursor("end")
        except Exception:
            pass

    def validate_torah(self):
        info = self.model.info or {
            "path": self.model.search_path,
            "raw_chars": 0,
            "sha256": "",
            "count_ok": len(self.model.search_text) == TARGET_COUNT,
            "start_ok": self.model.search_text.startswith("בראשיתבראאלהים"),
            "end_ok": self.model.search_text.endswith("לעיניכלישראל"),
        }
        msg = (
            f"קובץ חיפוש: {info.get('path', self.model.search_path)}\n"
            f"תווים גולמיים בקובץ: {info.get('raw_chars', 0):,}\n"
            f"אורך: {len(self.model.search_text):,}\n"
            f"יעד: {TARGET_COUNT:,}\n"
            f"הפרש: {len(self.model.search_text) - TARGET_COUNT:,}\n"
            f"תקין אורך: {info.get('count_ok', False)}\n"
            f"SHA256 אותיות: {info.get('sha256', '')}\n"
            f"התחלה: {self.model.search_text[:40]}\n"
            f"סוף: {self.model.search_text[-40:]}\n"
            f"התחלה תקינה: {info.get('start_ok', False)}\n"
            f"סוף תקין: {info.get('end_ok', False)}\n"
            f"ספ״פ ממופה: {bool(self.model.verses and self.model.verses[0].book != '?')}\n"
            f"קובץ תצוגה: {self.model.display_path}"
        )
        rtl_showinfo("אימות תורה", msg)

    def parse_skips(self) -> List[int]:
        ex = self.exact_skip.get().strip()
        if ex:
            n = int(ex)
            if n == 0:
                raise ValueError("דילוג 0 אינו חוקי")
            if FREE_SKIP_LIMIT and abs(n) > FREE_SKIP_LIMIT:
                raise ValueError(f"בגרסה זו החיפוש מוגבל בינתיים עד דילוג {FREE_SKIP_LIMIT:,}.")
            return [n, -n] if n > 0 else [n, abs(n)]
        start = int(self.skip_from.get())
        end = int(self.skip_to.get())
        if FREE_SKIP_LIMIT and max(abs(start), abs(end)) > FREE_SKIP_LIMIT:
            raise ValueError(f"בגרסה זו טווח הדילוגים מוגבל בינתיים עד {FREE_SKIP_LIMIT:,}.")
        skips = self.engine.build_skip_list(self.skip_from.get(), self.skip_to.get(), include_plain=False)
        if len(skips) > MAX_SKIP_VALUES:
            raise ValueError(f"טווח הדילוגים גדול מדי ({len(skips):,} בדיקות). צמצם טווח או השתמש בדילוג מדויק.")
        return skips

    def split_skip_range_chunks(self, start: int, end: int) -> List[Tuple[int, int]]:
        a, b = int(start), int(end)
        if a > b:
            a, b = b, a
        a, b = max(1, abs(a)), max(1, abs(b))
        if a > b:
            a, b = b, a
        if FREE_SKIP_LIMIT and b > FREE_SKIP_LIMIT:
            raise ValueError(f"בגרסה זו טווח הדילוגים מוגבל בינתיים עד {FREE_SKIP_LIMIT:,}.")
        max_width = max(1, MAX_SKIP_VALUES // 2)
        if b - a + 1 <= max_width:
            return [(a, b)]
        chunks = []
        current = a
        while current <= b:
            chunk_end = min(b, current + max_width - 1)
            chunks.append((current, chunk_end))
            current = chunk_end + 1
        return chunks

    def prepare_skip_range_chunks(self, runner_name: str):
        self.skip_chunk_queue = []
        self.skip_chunk_original_range = None
        self.skip_chunk_active = False
        if runner_name not in ("search", "meetings", "cluster"):
            return
        if self.exact_skip.get().strip():
            return
        mode = self.mode.get() if hasattr(self, "mode") else ""
        if mode == "text":
            return
        try:
            start = int(self.skip_from.get())
            end = int(self.skip_to.get())
        except Exception:
            return
        chunks = self.split_skip_range_chunks(start, end)
        if len(chunks) <= 1:
            return
        self.skip_chunk_original_range = (start, end)
        first_start, first_end = chunks[0]
        self.skip_chunk_queue = chunks[1:]
        self.skip_chunk_active = True
        self.skip_from.set(first_start)
        self.skip_to.set(first_end)
        self.update_context_header()
        self.status.set(f"טווח גדול חולק ל-{len(chunks)} חלקים; מחפש תחילה {first_start}-{first_end}")

    def advance_skip_range_after_no_results(self) -> str:
        if not hasattr(self, "skip_from") or not hasattr(self, "skip_to") or not hasattr(self, "exact_skip"):
            return ""
        if self.exact_skip.get().strip():
            return ""
        if getattr(self, "skip_chunk_queue", None):
            next_start, next_end = self.skip_chunk_queue.pop(0)
            try:
                self.skip_from.set(next_start)
                self.skip_to.set(next_end)
                self.update_context_header()
            except Exception:
                return ""
            self.schedule_auto_advance_search(next_start, next_end)
            remaining = len(self.skip_chunk_queue)
            tail = f"; נשארו {remaining} חלקים" if remaining else "; זה החלק האחרון בטווח שהוגדר"
            return f" | ממשיך בתוך הטווח שהוגדר: {next_start}-{next_end}{tail}"
        self.skip_chunk_active = False
        self.skip_chunk_original_range = None
        if hasattr(self, "opt_auto_advance_skip") and not self.opt_auto_advance_skip.get():
            return ""
        try:
            start = int(self.skip_from.get())
            end = int(self.skip_to.get())
        except Exception:
            return ""
        if start == end:
            step = 1 if start >= 0 else -1
            new_start = start + step
            new_end = end + step
        else:
            direction = 1 if end > start else -1
            width = abs(end - start) + 1
            new_start = end + direction
            new_end = end + direction * width
        if new_start == 0:
            new_start += 1 if new_end >= 0 else -1
        if new_end == 0:
            new_end += 1 if new_start >= 0 else -1
        if MAX_AUTO_EXTENDED_SKIP and max(abs(new_start), abs(new_end)) > MAX_AUTO_EXTENDED_SKIP:
            self.skip_chunk_active = False
            self.skip_chunk_original_range = None
            try:
                self.opt_auto_advance_skip.set(False)
                self.save_app_settings()
            except Exception:
                pass
            return f" | טווח מורחב נעצר: דילוג מעל {MAX_AUTO_EXTENDED_SKIP:,} אינו יעיל לרוב החיפושים"
        try:
            self.skip_from.set(new_start)
            self.skip_to.set(new_end)
            self.update_context_header()
        except Exception:
            return ""
        self.schedule_auto_advance_search(new_start, new_end)
        return f" | ממשיך מעבר לטווח שהוגדר: {new_start}-{new_end}"

    def schedule_auto_advance_search(self, new_start: int, new_end: int):
        if self.engine.stop_flag:
            return
        if not self.ram_allows_auto_continue():
            return
        self.pending_auto_advance_search = True
        self.auto_advance_chain_active = True

        def run_when_ready():
            if not getattr(self, "pending_auto_advance_search", False):
                return
            if self.engine.stop_flag:
                self.pending_auto_advance_search = False
                return
            if self.operation_is_running():
                self.root.after(250, run_when_ready)
                return
            self.pending_auto_advance_search = False
            if (
                hasattr(self, "opt_auto_advance_skip")
                and not self.opt_auto_advance_skip.get()
                and not getattr(self, "skip_chunk_active", False)
            ):
                return
            if self.exact_skip.get().strip():
                return
            self.status.set(f"ממשיך חיפוש אוטומטי בטווח דילוגים {new_start}-{new_end}...")
            self.auto_advance_launching = True
            try:
                runner = getattr(self, "active_search_runner", "search")
                if runner == "minimal":
                    self.run_minimal_search()
                elif runner == "meetings":
                    self.run_meetings_search()
                elif runner == "cluster":
                    self.run_cluster_search()
                else:
                    self.run_search()
            finally:
                self.auto_advance_launching = False

        self.root.after(350, run_when_ready)

    def ram_allows_auto_continue(self) -> bool:
        guard = getattr(self.engine, "memory_guard", None)
        if not guard:
            return True
        try:
            guard.next_check = 0.0
            if guard.should_stop():
                self.engine.stop_flag = True
                self.engine.stop_reason = guard.last_reason or "המשך אוטומטי נעצר כדי לא להעמיס על הזיכרון"
                self.status.set(self.engine.stop_reason)
                return False
        except Exception:
            return True
        return True

    def no_results_status(self, text: str, advance_skip: bool = False):
        suffix = self.advance_skip_range_after_no_results() if advance_skip else ""
        message = text + suffix
        if not suffix and message == getattr(self, "last_no_results_status_text", ""):
            return
        self.last_no_results_status_text = message
        self.lock_status_until_next_search(message)

    def secondary_words(self) -> List[str]:
        return [spec["word"] for spec in self.secondary_word_specs()]

    def primary_terms(self) -> List[str]:
        raw = self.primary_var.get() if hasattr(self, "primary_var") else ""
        terms = []
        seen = set()
        for token in re.split(r"[\s,;|]+", raw.strip()):
            word = self.engine.normalize_word(token)
            if not word:
                continue
            key = canonical_hebrew(word)
            if key in seen:
                continue
            seen.add(key)
            terms.append(word)
        return terms

    def primary_term_keys(self) -> set:
        return {canonical_hebrew(word) for word in self.primary_terms() if canonical_hebrew(word)}

    def secondary_word_specs(self) -> List[dict]:
        raw = self.secondary_var.get()
        specs = []
        seen = {}
        primary_keys = self.primary_term_keys()
        for token in re.split(r"[\s,;|]+", raw):
            if not token:
                continue
            is_meeting = "*" in token
            is_required = "!" in token
            word = self.engine.normalize_word(token.replace("*", "").replace("!", ""))
            if not word:
                continue
            word_key = canonical_hebrew(word)
            if word_key and word_key in primary_keys:
                continue
            key = (word_key, is_meeting)
            if key in seen:
                if is_required:
                    specs[seen[key]]["required"] = True
                continue
            seen[key] = len(specs)
            specs.append({"word": word, "meeting": is_meeting, "required": is_required})
        return specs

    def remove_duplicate_secondary_terms_from_field(self):
        if not hasattr(self, "secondary_var") or getattr(self, "cleaning_secondary_terms", False):
            return
        raw = self.secondary_var.get()
        tokens = [token for token in re.split(r"[\s,;|]+", raw.strip()) if token]
        if len(tokens) < 2:
            return
        kept = []
        seen = {}
        changed = False
        for token in tokens:
            word = self.engine.normalize_word(token.replace("*", "").replace("!", ""))
            key = canonical_hebrew(word)
            if key and key in seen:
                changed = True
                kept_idx = seen[key]
                if "!" in token and "!" not in kept[kept_idx]:
                    previous = kept[kept_idx]
                    kept[kept_idx] = "*!" + previous[1:] if previous.startswith("*") else "!" + previous
                continue
            if key:
                seen[key] = len(kept)
            kept.append(token)
        cleaned = " ".join(kept)
        if changed and cleaned != raw.strip():
            self.cleaning_secondary_terms = True
            try:
                self.secondary_var.set(cleaned)
                if hasattr(self, "secondary"):
                    self.secondary.icursor("end")
            finally:
                self.cleaning_secondary_terms = False

    def unique_secondary_count(self, words: List[str]) -> int:
        return len({canonical_hebrew(w) for w in words if canonical_hebrew(w)})

    def required_secondary_count(self, words: List[str]) -> int:
        total = self.unique_secondary_count(words)
        if total <= 0:
            return 0
        if hasattr(self, "opt_min_secondary_all") and self.opt_min_secondary_all.get():
            return total
        try:
            required = int(self.min_secondary.get() or 0)
        except Exception:
            required = 0
        return max(0, min(total, required))

    def required_secondary_specs(self) -> List[dict]:
        return [spec for spec in self.secondary_word_specs() if spec.get("required")]

    def mandatory_secondaries_satisfied(self, found_words: set, specs: Optional[List[dict]] = None) -> bool:
        required_specs = [spec for spec in (specs if specs is not None else self.secondary_word_specs()) if spec.get("required")]
        if not required_specs:
            return True
        found = {canonical_hebrew(word) for word in found_words if canonical_hebrew(word)}
        for spec in required_specs:
            pattern = canonical_hebrew(spec.get("word", ""))
            if not pattern:
                continue
            if not any(self.word_matches_secondary_pattern(word, pattern) for word in found):
                return False
        return True

    def reset_primary_found_count_for_search(self):
        if not hasattr(self, "primary_found_var"):
            return
        if self.primary_terms() or self.engine.normalize_word(self.get_primary_word()):
            self.primary_found_count = 0
            self.primary_found_var.set("ראשיות שנמצאו: 0")
            if hasattr(self, "search_reached_skip_var"):
                self.search_reached_skip_var.set("דילוג: -")

    def set_primary_found_count(self, count: int):
        if not hasattr(self, "primary_found_var"):
            return
        if not (self.primary_terms() or self.engine.normalize_word(self.get_primary_word())):
            self.primary_found_count = 0
            self.primary_found_var.set("")
            return
        self.primary_found_count = max(0, int(count or 0))
        self.primary_found_var.set(f"ראשיות שנמצאו: {self.primary_found_count}")

    def publish_primary_found_count(self, count: int):
        self.root.after(0, lambda c=count: self.set_primary_found_count(c))

    def set_search_reached_skip(self, skip: Optional[int]):
        if not hasattr(self, "search_reached_skip_var") or skip in (None, 0):
            return
        try:
            text = f"דילוג: {abs(int(skip))}"
        except Exception:
            return
        self.search_reached_skip_var.set(text)

    def on_search_terms_changed(self):
        self.remove_duplicate_secondary_terms_from_field()
        if hasattr(self, "primary_var") and not self.primary_var.get().strip():
            self.primary_found_count = 0
            if hasattr(self, "primary_found_var"):
                self.primary_found_var.set("")
            if hasattr(self, "search_reached_skip_var"):
                self.search_reached_skip_var.set("")
            self.cached_primary_key = None
            self.cached_primary_matches = []
        self.update_context_header()
        self.sync_min_secondary_all_count()
        self.update_find_chance_label()

    def on_min_secondary_all_changed(self):
        self.sync_min_secondary_all_count()
        self.update_find_chance_label()
        self.save_app_settings()

    def on_min_secondary_changed(self, *_args):
        if not hasattr(self, "opt_min_secondary_all"):
            self.update_find_chance_label()
            return
        try:
            required = int(self.min_secondary.get() or 0)
        except Exception:
            required = 0
        words = self.secondary_words() if hasattr(self, "secondary_var") else []
        total = self.unique_secondary_count(words)
        if self.opt_min_secondary_all.get():
            if total > 0 and required < total:
                self.opt_min_secondary_all.set(False)
                self.save_app_settings()
        else:
            if total > 0 and required >= total:
                self.opt_min_secondary_all.set(True)
                self.save_app_settings()
        self.update_find_chance_label()

    def sync_min_secondary_all_count(self):
        if not all(hasattr(self, name) for name in ("opt_min_secondary_all", "min_secondary")):
            return
        if not self.opt_min_secondary_all.get():
            return
        words = self.secondary_words() if hasattr(self, "secondary_var") else []
        self.min_secondary.set(self.unique_secondary_count(words))

    def update_find_chance_label(self):
        if not hasattr(self, "find_chance_var"):
            return
        try:
            words = self.secondary_words() if hasattr(self, "secondary_var") else []
            total = self.unique_secondary_count(words)
            required = self.required_secondary_count(words)
            if total <= 0:
                text = "סיכוי ~100%"
            elif required <= 0:
                text = f"סיכוי ~100% (0/{total})"
            else:
                pressure = required / max(1, total)
                pct = round(100 - pressure * 78)
                if required >= total:
                    pct = min(pct, 20)
                pct = max(5, min(95, pct))
                text = f"סיכוי ~{pct}% ({required}/{total})"
            self.find_chance_var.set(text)
        except Exception:
            self.find_chance_var.set("")

    def search_words_for_scan_file(self) -> List[str]:
        words = []
        primary = self.engine.normalize_word(self.get_primary_word())
        if primary:
            words.append(primary)
        words.extend(self.secondary_words())
        return [w for w in dict.fromkeys(words) if len(w) >= 2]

    def add_search_words_to_scan_file(self) -> int:
        words = self.search_words_for_scan_file()
        if not words:
            return 0
        existing = []
        if os.path.exists(SCAN_WORDS_FILE):
            raw = TorahLoader.read_file(SCAN_WORDS_FILE)
            existing = [
                self.engine.normalize_word(w)
                for w in re.split(r"[\s,;|]+", raw)
                if len(self.engine.normalize_word(w)) >= 2
            ]
        seen = {canonical_hebrew(w) for w in existing}
        additions = []
        for word in words:
            key = canonical_hebrew(word)
            if key not in seen:
                seen.add(key)
                additions.append(word)
        if additions:
            with open(SCAN_WORDS_FILE, "a", encoding="utf-8", newline="\n") as f:
                if existing and os.path.getsize(SCAN_WORDS_FILE) > 0:
                    f.write("\n")
                f.write("\n".join(additions))
                f.write("\n")
        return len(additions)

    def add_word_to_scan_file(self, word: str) -> int:
        clean = self.engine.normalize_word(str(word or "").replace("*", ""))
        if len(clean) < 2:
            self.status.set("המילה קצרה מדי להוספה לקובץ הסריקה")
            return 0
        existing = []
        if os.path.exists(SCAN_WORDS_FILE):
            raw = TorahLoader.read_file(SCAN_WORDS_FILE)
            existing = [
                self.engine.normalize_word(w)
                for w in re.split(r"[\s,;|]+", raw)
                if len(self.engine.normalize_word(w)) >= 2
            ]
        key = canonical_hebrew(clean)
        if key in {canonical_hebrew(w) for w in existing}:
            self.status.set(f"{clean} כבר קיימת בקובץ {SCAN_WORDS_FILE}")
            return 0
        with open(SCAN_WORDS_FILE, "a", encoding="utf-8", newline="\n") as f:
            if existing and os.path.exists(SCAN_WORDS_FILE) and os.path.getsize(SCAN_WORDS_FILE) > 0:
                f.write("\n")
            f.write(clean)
            f.write("\n")
        self.status.set(f"נוספה לקובץ הסריקה: {clean}")
        return 1

    def add_word_to_category_file(self, word: str, category: str, file_name: str) -> int:
        clean = self.engine.normalize_word(str(word or "").replace("*", ""))
        if len(clean) < 1:
            self.status.set("אין מילה להעברה לקובץ")
            return 0
        existing = []
        if os.path.exists(file_name):
            raw = TorahLoader.read_file(file_name)
            existing = [
                self.engine.normalize_word(w)
                for w in re.split(r"[\s,;|]+", raw)
                if self.engine.normalize_word(w)
            ]
        key = canonical_hebrew(clean)
        if key in {canonical_hebrew(w) for w in existing}:
            self.status.set(f"{clean} כבר קיימת בקובץ {category}")
            return 0
        with open(file_name, "a", encoding="utf-8", newline="\n") as f:
            if existing and os.path.exists(file_name) and os.path.getsize(file_name) > 0:
                f.write("\n")
            f.write(clean)
            f.write("\n")
        self.status.set(f"{clean} הועברה לקובץ {category}")
        return 1

    def move_match_word_to_category_file(self, match: Match, category: str, file_name: str):
        added = self.add_word_to_category_file(match.word, category, file_name)
        if added and os.path.exists(SCAN_WORDS_FILE):
            self.remove_word_from_scan_file_without_prompt(match.word)

    def remove_word_from_scan_file_without_prompt(self, word: str) -> int:
        clean = self.engine.normalize_word(str(word or "").replace("*", ""))
        key = canonical_hebrew(clean)
        if len(key) < 1:
            return 0
        if not os.path.exists(SCAN_WORDS_FILE):
            return 0
        raw = TorahLoader.read_file(SCAN_WORDS_FILE)
        tokens = [t for t in re.split(r"[\s,;|]+", raw) if t.strip()]
        kept = []
        removed = 0
        for token in tokens:
            token_clean = self.engine.normalize_word(token.replace("*", ""))
            if canonical_hebrew(token_clean) == key:
                removed += 1
            else:
                kept.append(token_clean or token.strip())
        if removed:
            with open(SCAN_WORDS_FILE, "w", encoding="utf-8", newline="\n") as f:
                if kept:
                    f.write("\n".join(dict.fromkeys(kept)))
                    f.write("\n")
        return removed

    def delete_word_from_scan_file(self, word: str):
        clean = self.engine.normalize_word(str(word or "").replace("*", ""))
        key = canonical_hebrew(clean)
        if len(key) < 1:
            self.status.set("אין מילה למחיקה מקובץ המילים")
            return
        if not rtl_askyesno("מחיקה מקובץ מילים", f"למחוק את {clean} מתוך {SCAN_WORDS_FILE}?"):
            return
        if not os.path.exists(SCAN_WORDS_FILE):
            self.status.set(f"קובץ המילים {SCAN_WORDS_FILE} לא נמצא")
            return
        try:
            removed = self.remove_word_from_scan_file_without_prompt(clean)
            if not removed:
                self.status.set(f"{clean} לא נמצא בקובץ {SCAN_WORDS_FILE}")
                return
            self.status.set(f"נמחק מהקובץ {SCAN_WORDS_FILE}: {clean} ({removed} מופעים)")
        except Exception as e:
            rtl_showerror("מחיקה מקובץ מילים", str(e))

    def load_scan_words(self) -> Tuple[List[str], str]:
        secondary = [w for w in self.secondary_words() if len(w) >= 2]
        for fn in (SCAN_WORDS_FILE, "words_6000.txt", "hebrew_words.txt", "milim_scan.txt"):
            if os.path.exists(fn):
                raw = TorahLoader.read_file(fn)
                words = [self.engine.normalize_word(w) for w in re.split(r"[\s,;|]+", raw) if len(self.engine.normalize_word(w)) >= 2]
                unique = list(dict.fromkeys(words + secondary))
                source = f"{fn} + המשניות" if secondary else fn
                return unique[:MAX_SCAN_WORDS], source
        fallback = list(dict.fromkeys(secondary))
        return fallback[:MAX_SCAN_WORDS], "המילים המשניות"

    def current_hebrew_year(self) -> int:
        now = time.localtime()
        return now.tm_year + (3761 if now.tm_mon >= 9 else 3760)

    def build_date_lexicon(self) -> dict:
        days = [hebrew_number(i) for i in range(1, 31)]
        months = [self.engine.normalize_word(m) for m in HEBREW_MONTHS]
        months = [m for m in dict.fromkeys(months) if m]
        day_month = []
        for day in days:
            for month in months:
                day_month.extend([
                    f"{day}{month}",
                    f"{month}{day}",
                ])
        start_year = self.current_hebrew_year()
        years_full = []
        years_short = []
        for year in range(start_year, start_year + 21):
            short = hebrew_number(year - 5000 if year >= 5000 else year)
            if not short:
                continue
            years_short.extend([short, f"שנת{short}", f"בשנת{short}"])
            years_full.extend([f"ה{short}", f"שנתה{short}", f"בשנתה{short}"])
        return {
            "generated_for_hebrew_year": start_year,
            "days": days,
            "months": months,
            "day_month": [w for w in dict.fromkeys(day_month) if len(w) >= 2],
            "years_full": [w for w in dict.fromkeys(years_full) if len(w) >= 2],
            "years_short": [w for w in dict.fromkeys(years_short) if len(w) >= 2],
        }

    def ensure_date_words_file(self) -> dict:
        data = self.build_date_lexicon()
        try:
            old = {}
            if os.path.exists(DATE_WORDS_FILE):
                with open(DATE_WORDS_FILE, "r", encoding="utf-8") as f:
                    old = json.load(f)
            if old.get("generated_for_hebrew_year") == data["generated_for_hebrew_year"]:
                return old
        except Exception:
            pass
        with open(DATE_WORDS_FILE, "w", encoding="utf-8", newline="\n") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return data

    def load_date_words(self) -> dict:
        try:
            return self.ensure_date_words_file()
        except Exception:
            return self.build_date_lexicon()

    def set_status(self, text: str):
        text = self.status_with_search_progress(text)
        self.root.after(0, lambda: self.status.set(text))

    def status_with_search_progress(self, text: str) -> str:
        parts = []
        try:
            count_text = self.primary_found_var.get().strip() if getattr(self, "primary_found_var", None) else ""
            if count_text and "ראשיות שנמצאו" not in text:
                parts.append(count_text)
        except Exception:
            pass
        try:
            skip_text = self.search_reached_skip_var.get().strip() if getattr(self, "search_reached_skip_var", None) else ""
            if skip_text and skip_text != "דילוג: -" and "דילוג:" not in text:
                parts.append(skip_text)
        except Exception:
            pass
        return f"{text} | {' | '.join(parts)}" if parts else text

    def describe_search_flow(self) -> str:
        parts = ["שלב 1: חיפוש בטווח הנוכחי"]
        if hasattr(self, "opt_try_long_secondary_primary") and self.opt_try_long_secondary_primary.get():
            parts.append("שלב 2: חיפוש מורחב עד 5 משניות כראשיות חלופיות")
        if hasattr(self, "opt_auto_advance_skip") and self.opt_auto_advance_skip.get():
            limit_text = f"עד דילוג {MAX_AUTO_EXTENDED_SKIP:,}" if MAX_AUTO_EXTENDED_SKIP else "ללא מגבלת דילוג מוגדרת"
            parts.append(f"שלב 3: טווח מורחב {limit_text}")
        return " | ".join(parts)

    def update_status_display(self, *_args):
        if hasattr(self, "status_display"):
            self.status_display.set(rtl_display(self.status.get()))

    def update_app_title_display(self, *_args):
        if hasattr(self, "app_title_display"):
            self.app_title_display.set(rtl_display(self.app_title.get()))

    def update_current_skip_display(self, *_args):
        if hasattr(self, "current_skip_banner_display"):
            self.current_skip_banner_display.set(rtl_display(self.current_skip_banner.get()))

    def update_context_title_display(self, *_args):
        if hasattr(self, "context_title_display"):
            self.context_title_display.set(rtl_display(self.context_title.get()))

    def clear_status_lock(self):
        self.status_lock_text = None

    def on_status_write(self, *_args):
        if self.restoring_locked_status or not self.status_lock_text:
            return
        try:
            current = self.status.get()
        except Exception:
            return
        if current == self.status_lock_text:
            return

        def restore():
            if not self.status_lock_text:
                return
            self.restoring_locked_status = True
            try:
                self.status.set(self.status_lock_text)
            finally:
                self.restoring_locked_status = False

        self.root.after_idle(restore)

    def lock_status_until_next_search(self, text: str):
        self.status_lock_text = text
        self.status.set(text)

        def restore(expected=text):
            if self.status_lock_text == expected:
                self.status.set(expected)

        self.root.after(120, restore)
        self.root.after(450, restore)
        self.root.after(900, restore)

    def set_progress(
        self,
        done,
        total,
        message: Optional[str] = None,
        skip: Optional[int] = None,
        found_count: Optional[int] = None,
        primary_count_base: int = 0,
    ):
        def update():
            if skip not in (None, 0):
                self.set_search_reached_skip(skip)
            if found_count is not None:
                self.set_primary_found_count(primary_count_base + int(found_count or 0))
            self.progress.configure(maximum=max(1, total))
            self.progress.configure(value=done)
            if message:
                percent = int((done / max(1, total)) * 100)
                self.status.set(self.status_with_search_progress(f"{message} ({percent}%)"))
        self.root.after(0, update)

    def progress_for(self, message: str, primary_count_base: int = 0):
        return lambda done, total, skip=None, found_count=None: self.set_progress(
            done,
            total,
            message,
            skip=skip,
            found_count=found_count,
            primary_count_base=primary_count_base,
        )

    def update_search_button_state(self, stopping: bool = False):
        btn = getattr(self, "search_btn", None)
        if not btn:
            return
        running = self.operation_is_running()
        if stopping:
            btn.configure(
                text="⏹ עוצר",
                command=self.stop,
                bg="#fce5cd",
                activebackground="#f9cb9c",
                fg="#783f04",
            )
        elif running:
            btn.configure(
                text="⏹ עצור",
                command=self.stop,
                bg="#f4cccc",
                activebackground="#ea9999",
                fg="#660000",
            )
        else:
            minimal_active = (
                getattr(self, "opt_minimal_search", None) is not None
                and self.opt_minimal_search.get()
                and not (hasattr(self, "exact_skip") and self.exact_skip.get().strip())
            )
            search_text = "🔍 חפש מינ'" if minimal_active else "🔍 חפש"
            btn.configure(
                text=search_text,
                command=self.search_or_stop,
                bg="#d9ead3",
                activebackground="#b6d7a8",
                fg="#0b3d1f",
            )

    def search_or_stop(self):
        if self.operation_is_running():
            self.stop()
            return
        self.search_cipher()

    def on_minimal_search_changed(self):
        self.save_app_settings()
        self.update_search_button_state()
        self.update_skip_range_field_state()
        if self.minimal_exact_skip_notice():
            self.status.set("מינימלי לא רלוונטי כשדילוג יחיד מלא, אך אפשר להשאיר אותו מסומן.")

    def stop(self):
        self.engine.stop_flag = True
        self.engine.stop_reason = "הפעולה נעצרה ידנית"
        self.scan_stop = True
        self.pending_auto_advance_search = False
        self.auto_advance_launching = False
        self.update_search_button_state(stopping=True)
        self.status.set("בקשת עצירה התקבלה...")

    def search_is_running(self) -> bool:
        return bool(self.search_thread and self.search_thread.is_alive())

    def scan_is_running(self) -> bool:
        return bool(self.scan_thread and self.scan_thread.is_alive())

    def operation_is_running(self) -> bool:
        return self.search_is_running() or self.scan_is_running()

    def stop_running_then(self, callback, label: str, retries: int = 40) -> bool:
        if not self.operation_is_running():
            return False
        if self.saved:
            self.preserve_saved_on_next_results = True
        self.stop()
        keep_note = " הממצאים הקיימים נשמרים." if self.saved else ""
        self.status.set(f"עוצר פעולה קודמת כדי להתחיל {label}...{keep_note}")

        def wait_and_run(remaining: int):
            if not self.operation_is_running():
                self.status.set(f"הפעולה הקודמת נעצרה; מתחיל {label}...")
                callback()
                return
            if remaining <= 0:
                self.status.set(f"הפעולה הקודמת עדיין נסגרת. נסה שוב בעוד רגע כדי להתחיל {label}.")
                return
            self.root.after(250, lambda: wait_and_run(remaining - 1))

        self.root.after(250, lambda: wait_and_run(retries))
        return True

    def refuse_if_busy(self) -> bool:
        if self.operation_is_running():
            self.status.set("כבר רצה פעולה. לחץ עצור או המתן לסיום.")
            return True
        return False

    def prepare_search_start(self, runner_name: str):
        if runner_name in ("search", "minimal", "meetings", "fraction", "cached_secondaries", "scan"):
            self.push_app_undo_state("לפני חיפוש/סריקה")
        self.active_search_runner = runner_name
        self.root.after(0, self.update_search_button_state)
        if not getattr(self, "auto_advance_launching", False):
            self.pending_auto_advance_search = False
            self.auto_advance_chain_active = False
            self.prepare_skip_range_chunks(runner_name)

    def get_divisor_steps(self, base_skip: int) -> List[int]:
        steps = [base_skip]
        if self.cluster_fraction_mode in (2, 3, 4):
            sign = -1 if base_skip < 0 else 1
            abs_skip = abs(base_skip)
            if abs_skip % self.cluster_fraction_mode == 0:
                steps.append(sign * (abs_skip // self.cluster_fraction_mode))
        seen = set()
        out = []
        for step in steps:
            if step and step not in seen:
                seen.add(step)
                out.append(step)
        return out

    def secondary_skip_options(self, primary_skip: int) -> List[int]:
        seen = set()
        out = []
        for step in (1, -1):
            seen.add(step)
            out.append(step)
        for base in self.get_divisor_steps(primary_skip):
            for step in (base, base + 1, base - 1, -base, -base + 1, -base - 1):
                if step and step not in seen:
                    seen.add(step)
                    out.append(step)
        return out

    def fraction_label(self) -> str:
        return {1: "", 2: " | גם בחצי דילוג", 3: " | גם בשליש", 4: " | גם ברבע"}.get(self.cluster_fraction_mode, "")

    def search_cipher(self):
        self.cluster_fraction_mode = 1
        if not self.confirm_current_view_skip_range_if_needed():
            return
        if self.can_scan_cached_primary_secondaries():
            self.run_cached_primary_secondaries_search()
            return
        if hasattr(self, "opt_minimal_search") and self.opt_minimal_search.get():
            if hasattr(self, "exact_skip") and self.exact_skip.get().strip():
                self.status.set("מינימלי לא רלוונטי כשדילוג יחיד מלא; מריץ חיפוש בדילוג היחיד.")
                self.run_search()
                return
            self.run_minimal_search()
        else:
            self.run_search()

    def primary_cache_key(self, primary_words: Optional[List[str]] = None, skips: Optional[List[int]] = None, mode: Optional[str] = None):
        try:
            search_mode = mode or self.mode.get()
        except Exception:
            search_mode = ""
        if search_mode != "code":
            return None
        if primary_words is None:
            primary_words = self.primary_terms() or [self.engine.normalize_word(self.get_primary_word())]
        primary_key = tuple(canonical_hebrew(w) for w in primary_words if canonical_hebrew(w))
        if not primary_key:
            return None
        if skips is None:
            try:
                skips = self.parse_skips()
            except Exception:
                return None
        skip_key = tuple(int(s) for s in skips if int(s) != 0)
        return (search_mode, primary_key, skip_key)

    def can_scan_cached_primary_secondaries(self) -> bool:
        if self.operation_is_running():
            return False
        if hasattr(self, "opt_minimal_search") and self.opt_minimal_search.get():
            return False
        if hasattr(self, "opt_current_view_only") and self.opt_current_view_only.get():
            return False
        key = self.primary_cache_key()
        return bool(key and key == self.cached_primary_key and self.cached_primary_matches)

    def run_cached_primary_secondaries_search(self):
        if self.stop_running_then(self.run_cached_primary_secondaries_search, "חיפוש משניות בראשיות שמורות"):
            return
        if not self.can_scan_cached_primary_secondaries():
            self.run_search()
            return
        self.prepare_search_start("cached_secondaries")
        self.clear_status_lock()
        try:
            self.save_search_state()
        except Exception as e:
            self.status.set(f"אזהרה: לא הצלחתי לשמור את מילות החיפוש: {e}")
        self.engine.begin_search()
        self.progress.configure(value=0)
        self.status.set(f"מחפש משניות מחדש על {len(self.cached_primary_matches)} ראשיות שמורות, בלי חיפוש ראשיות...")
        primary_snapshot = list(self.cached_primary_matches)
        self.search_thread = threading.Thread(
            target=self._cached_primary_secondaries_worker,
            args=(primary_snapshot,),
            daemon=True,
        )
        self.search_thread.start()

    def search_cipher_with_fraction(self, divisor: int):
        if self.saved and self.search_words_for_scan_file():
            self.search_fraction_secondaries(divisor)
            return
        self.cluster_fraction_mode = divisor
        self.mode.set("code")
        self.run_search()

    def secondary_matches_for_primary(self, primary: Match, secondaries: List[str]) -> List[Match]:
        window = self.positions_for_primary_grid(primary)
        local = [primary]
        seen = {(primary.word, tuple(primary.calc_positions()), primary.kind)}
        for word in secondaries:
            if self.engine.should_stop():
                break
            matches = self.engine.find_in_window(word, window, self.secondary_skip_options(primary.skip), "secondary")
            for match in matches:
                key = (match.word, tuple(match.calc_positions()), match.kind)
                if key in seen:
                    continue
                seen.add(key)
                local.append(match)
        field_texts = self.field_text_matches_in_window(self.field_text_words_for_marks(), window, seen)
        if field_texts:
            local.extend(field_texts)
        return TorahCanvas.drop_matches_inside_longer(local)

    def fraction_secondary_steps(self, base_skip: int, divisor: int) -> List[int]:
        n = max(1, int(round(abs(base_skip) / max(1, divisor))))
        candidates = [n, n + 1]
        if n > 1:
            candidates.append(n - 1)
        out = []
        seen = set()
        for step in (1, -1):
            seen.add(step)
            out.append(step)
        for step in candidates:
            for signed in (step, -step):
                if signed not in seen:
                    seen.add(signed)
                    out.append(signed)
        return out

    def date_fraction_fallback_steps(self, base_skip: int) -> List[int]:
        seen = set()
        out = []
        for divisor in (2, 3, 4):
            n = int(round(abs(base_skip) / divisor))
            if n < 3:
                continue
            for step in (n, n + 1, n - 1):
                if step < 3:
                    continue
                for signed in (step, -step):
                    if signed not in seen:
                        seen.add(signed)
                        out.append(signed)
        return out

    def should_try_date_fraction_fallback(self, word: str) -> bool:
        return bool(
            self.opt_date_fraction_fallback.get()
            and canonical_hebrew(word) in self.date_fraction_words
        )

    def find_year_dates_in_window(self, words: List[str], window: set, base_skip: int, should_stop=None) -> List[Match]:
        found = []
        stages = [
            self.secondary_skip_options(base_skip),
            self.fraction_secondary_steps(base_skip, 2),
            self.fraction_secondary_steps(base_skip, 3),
            self.fraction_secondary_steps(base_skip, 4),
        ]
        for word in words:
            if should_stop and should_stop():
                break
            word_hits = []
            for steps in stages:
                if should_stop and should_stop():
                    break
                usable_steps = [s for s in steps if abs(s) >= 3 or abs(s) == 1]
                word_hits = self.engine.find_in_window(word, window, usable_steps, "date")
                if word_hits:
                    break
            found.extend(word_hits)
        return found

    def date_scan_steps_for_primary(self, primary: Optional[Match] = None) -> List[int]:
        primary = primary or getattr(self, "current_display_match", None)
        if primary is None and self.saved and 0 <= self.current < len(self.saved):
            primary = self.saved[self.current][0]
        base = abs(int(getattr(primary, "skip", 1) or 1))
        candidates = [base]
        if base > 1:
            candidates.append(base - 1)
        candidates.append(base + 1)
        candidates.append(1)
        steps: List[int] = []
        seen = set()
        for step in candidates:
            step = abs(int(step or 1))
            if step < 1 or step in seen:
                continue
            seen.add(step)
            steps.append(step)
        return steps

    def date_scan_grids(self, primary: Optional[Match] = None) -> List[Tuple[str, List[List[Optional[int]]]]]:
        primary = primary or getattr(self, "current_display_match", None)
        if primary is None and self.saved and 0 <= self.current < len(self.saved):
            primary = self.saved[self.current][0]
        if primary is None:
            return [("1", self.visible_grid_snapshot())]
        grids: List[Tuple[str, List[List[Optional[int]]]]] = []
        for step in self.date_scan_steps_for_primary(primary):
            date_primary = Match(primary.word, primary.start, step, primary.kind, positions=[primary.start + step * i for i in range(len(primary.word))])
            if step == 1:
                anchor = max(0, primary.start - max(1, self.canvas.fitted_linear_cols() // 2))
                cols = self.canvas.fitted_linear_cols()
                rows = self.canvas.fitted_linear_rows()
                grid = []
                pos = anchor
                for _r in range(rows):
                    row = []
                    for _c in range(cols):
                        row.append(pos if 0 <= pos < len(self.model.search_text) else None)
                        pos += 1
                    grid.append(row)
            else:
                grid, _pos_to_cell = self.grid_for_primary_match(date_primary)
            grids.append((str(step), grid))
        return grids

    def day_month_date_matches(self, date_words: dict, grid_snapshot: List[List[Optional[int]]], should_stop, label: str = "") -> List[Match]:
        days = [self.engine.normalize_word(w) for w in date_words.get("days", []) if self.engine.normalize_word(w)]
        months = [self.engine.normalize_word(w) for w in date_words.get("months", []) if self.engine.normalize_word(w)]
        if not bool(date_words.get("include_av", False)):
            months = [m for m in months if m != "אב"]
        found: List[Match] = []
        seen = set()
        spec_by_term = {}
        for day in days:
            for month in months:
                spec_by_term[f"{day}{month}"] = (day, month, "day_first")
                spec_by_term[f"{month}{day}"] = (day, month, "month_first")
        if not spec_by_term:
            return found
        hits = self.canvas.screen_word_paths(
            list(spec_by_term.keys()),
            MAX_SCAN_RESULTS,
            grid_snapshot,
            should_stop,
            self.progress_for(f"סריקת תאריכים: יום וחודש בדילוג {label}" if label else "סריקת תאריכים: יום וחודש"),
        )
        for hit in hits:
            term_key = canonical_hebrew(hit.word)
            spec = spec_by_term.get(term_key)
            if not spec:
                continue
            day, month, order = spec
            positions = hit.calc_positions()
            if len(positions) != len(term_key):
                continue
            if order == "day_first":
                day_positions = positions[:len(day)]
                month_positions = positions[len(day):]
            else:
                month_positions = positions[:len(month)]
                day_positions = positions[len(month):]
            pair_key = (tuple(day_positions), tuple(month_positions))
            if pair_key in seen:
                continue
            seen.add(pair_key)
            found.append(Match(day, day_positions[0], hit.skip, "date_day", "#fff176", day_positions))
            found.append(Match(month, month_positions[0], hit.skip, "date_month", "#ffb74d", month_positions))
            if len(found) >= MAX_SCAN_RESULTS:
                return found
        return found

    def search_fraction_secondaries(self, divisor: int):
        if self.stop_running_then(lambda: self.search_fraction_secondaries(divisor), f"חיפוש {self.fraction_label_for(divisor)}"):
            return
        if not self.saved:
            self.search_cipher_with_fraction(divisor)
            return
        words = self.search_words_for_scan_file()
        if not words:
            self.status.set("אין מילים לחיפוש בדילוג מחולק")
            return
        self.clear_status_lock()
        current_index = self.current
        primary, _local = self.saved[current_index]
        steps = self.fraction_secondary_steps(primary.skip, divisor)
        display_step = max(1, round(abs(primary.skip or 1) / divisor))
        if (primary.skip or 1) < 0:
            display_step = -display_step
        display_primary = Match(primary.word, primary.start, display_step, "display", primary.color, [])
        display_primary.calc_positions()
        self.current_display_match = display_primary
        self.set_live_skip_display(display_step)
        self.canvas.view_col_offset = 0
        self.canvas.build_skip_grid(display_primary)
        self.canvas.set_matches(_local)
        window = self.positions_for_primary_grid_rows(display_primary, row_multiplier=divisor)
        if not window:
            self.status.set("אין שטח מסך גלוי לחיפוש דילוג מחולק")
            return
        self.prepare_search_start("fraction")
        self.engine.begin_search()
        self.progress.configure(value=0)
        self.status.set(f"מחפש ראשית ומשניות בדילוג 1 ובדילוג {self.fraction_label_for(divisor)}: {', '.join(str(abs(s)) for s in steps[:5])}")
        self.search_thread = threading.Thread(
            target=self._fraction_secondary_worker,
            args=(current_index, words, window, steps, divisor),
            daemon=True,
        )
        self.search_thread.start()

    def fraction_label_for(self, divisor: int) -> str:
        return {2: "חצי", 3: "שליש", 4: "רבע"}.get(divisor, str(divisor))

    def _fraction_secondary_worker(self, current_index: int, words: List[str], window: set, steps: List[int], divisor: int):
        try:
            found = []
            for idx, word in enumerate(words, 1):
                if self.engine.should_stop():
                    break
                self.set_progress(idx, max(1, len(words)), f"חיפוש מילים בדילוג {self.fraction_label_for(divisor)}")
                found.extend(self.engine.find_in_window(word, window, steps, "secondary"))
            seen = {(m.word, tuple(m.calc_positions()), m.kind) for m in found}
            found.extend(self.field_text_matches_in_window(self.field_text_words_for_marks(), window, seen))
            self.root.after(0, lambda: self.add_fraction_secondaries(current_index, found, divisor, steps))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("חיפוש דילוג מחולק", str(e)))
        finally:
            self.root.after(0, self.mark_search_finished)

    def add_fraction_secondaries(self, current_index: int, matches: List[Match], divisor: int, steps: List[int]):
        if not (0 <= current_index < len(self.saved)):
            return
        self.push_app_undo_state("הוספת משניות בדילוג חלקי")
        self.current = current_index
        self.apply_word_colors(matches)
        added = self.merge_matches_into_current(matches)
        self.update_result_row(current_index)
        if added:
            used = sorted({abs(m.skip) for m in matches})
            self.status.set(f"נוספו {added} סימונים בדילוג {self.fraction_label_for(divisor)}: {', '.join(map(str, used[:8]))}; ממצאים קודמים נשארו")
            self.display_current()
        else:
            self.lock_status_until_next_search(f"לא נמצאו מילים חדשות בדילוג 1 ובדילוג {self.fraction_label_for(divisor)} ({', '.join(str(abs(s)) for s in steps[:5])})")

    def search_screen_secondaries_in_skip_range(self):
        if self.stop_running_then(self.search_screen_secondaries_in_skip_range, "חיפוש משניות במסך בטווח"):
            return
        if not self.confirm_current_view_skip_range_if_needed():
            return
        if not self.saved:
            rtl_showinfo("משניות בטווח", "אין ממצא נוכחי. קודם חפש ראשית או פתח צופן מהרשימה.")
            return
        words = self.secondary_words()
        if not words:
            rtl_showinfo("משניות בטווח", "אין מילים בשדה משניות.")
            return
        try:
            skips = self.parse_skips()
        except Exception as e:
            self.status.set(str(e))
            return
        window = self.canvas.visible_positions()
        if not window:
            self.status.set("אין שטח מסך גלוי לסריקת משניות")
            return
        self.clear_status_lock()
        current_index = self.current
        self.prepare_search_start("screen_secondaries")
        self.engine.begin_search()
        self.progress.configure(value=0)
        self.status.set(f"סורק משניות באזור הראשית בכל טווח הדילוגים: {len(skips)} דילוגים")
        self.search_thread = threading.Thread(
            target=self._screen_secondaries_range_worker,
            args=(current_index, words, window, skips),
            daemon=True,
        )
        self.search_thread.start()

    def _screen_secondaries_range_worker(self, current_index: int, words: List[str], window: set, skips: List[int]):
        try:
            found: List[Match] = []
            for idx, word in enumerate(words, 1):
                if self.engine.should_stop() or len(found) >= MAX_SCAN_RESULTS:
                    break
                self.set_progress(idx, max(1, len(words)), "משניות במסך בטווח")
                matches = self.engine.find_in_window(word, window, skips, "secondary")
                remaining = max(0, MAX_SCAN_RESULTS - len(found))
                found.extend(matches[:remaining])
            self.root.after(0, lambda: self.add_screen_secondaries_range(current_index, found, skips))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("משניות בטווח", str(e)))
        finally:
            self.root.after(0, self.mark_search_finished)

    def add_screen_secondaries_range(self, current_index: int, matches: List[Match], skips: List[int]):
        if not (0 <= current_index < len(self.saved)):
            return
        self.push_app_undo_state("הוספת משניות בטווח")
        self.current = current_index
        self.apply_word_colors(matches)
        added = self.merge_matches_into_current(matches)
        self.update_result_row(current_index)
        if added:
            used = sorted({abs(m.skip) for m in matches})
            shown = ", ".join(map(str, used[:8]))
            suffix = f": {shown}" if shown else ""
            self.status.set(f"נוספו {added} משניות באזור הראשית בדילוגי הטווח{suffix}")
            self.display_current()
        else:
            self.lock_status_until_next_search(f"לא נמצאו משניות חדשות שכל אותיותיהן בתוך אזור הראשית ({len(skips)} דילוגים)")

    def engine_smoke_test(self):
        self.engine.begin_search()
        tests = [
            ("בראשית", 1),
            ("משיח", 1),
            (self.engine.normalize_word(self.get_primary_word()), int(self.exact_skip.get() or self.skip_from.get() or 1)),
        ]
        lines = []
        for word, skip in tests:
            if not word:
                continue
            res = self.engine.find_word(word, [skip, -skip] if skip > 0 else [skip, -skip], limit=10)
            lines.append(f"{word} | דילוג {abs(skip)} בשני הכיוונים | נמצאו {len(res)}")
            for m in res[:5]:
                lines.append(f"  מיקום {m.start}, דילוג {abs(m.skip or 1)}, ספ״פ {self.model.spp_at(m.start)}")
        rtl_showinfo("בדיקת מנוע", "\n".join(lines) if lines else "אין מה לבדוק")

    def test_skip(self):
        word = self.engine.normalize_word(self.get_primary_word())
        if not word:
            return
        self.engine.begin_search()
        try:
            ex = self.exact_skip.get().strip()
            skip = int(ex) if ex else int(self.skip_from.get())
        except Exception:
            rtl_showerror("דילוג", "דילוג לא תקין")
            return
        skips = [skip, -skip] if skip > 0 else [skip, -skip]
        found = self.engine.find_word(word, skips, limit=50, progress=self.set_progress)
        if not found:
            rtl_showinfo("בדיקת דילוג", f"לא נמצא {word} בדילוג {abs(skip)} בשני הכיוונים")
            return
        lines = []
        for m in found[:20]:
            lines.append(f"מיקום {m.start}, דילוג {abs(m.skip or 1)}, אותיות {self.engine.letters_at(m.start, m.skip, len(m.word))}, ספ״פ {self.model.spp_at(m.start)}")
        rtl_showinfo("בדיקת דילוג", "\n".join(lines))
        self.show_matches([(found[0], found)])

    def run_minimal_search(self):
        if self.stop_running_then(self.run_minimal_search, "חיפוש מינימלי"):
            return
        self.prepare_search_start("minimal")
        self.reset_primary_found_count_for_search()
        self.clear_status_lock()
        try:
            self.save_search_state()
            self.add_search_words_to_scan_file()
        except Exception as e:
            self.status.set(f"אזהרה: לא הצלחתי לשמור את מילות החיפוש: {e}")
        self.engine.begin_search()
        self.progress.configure(value=0)
        self.status.set("מכין חיפוש מינימלי...")
        self.search_thread = threading.Thread(target=self._minimal_worker, daemon=True)
        self.search_thread.start()

    def _minimal_worker(self):
        try:
            word = self.get_primary_word()
            skip_from = int(self.skip_from.get())
            skip_to = int(self.skip_to.get())
            self.set_status("מחפש דילוג מינימלי...")
            found = self.engine.find_minimal_word(word, skip_from, skip_to, progress=self.progress_for("חיפוש מינימלי"))
            self.publish_primary_found_count(len(found))
            if self.engine.stop_flag:
                self.root.after(0, lambda: self.show_plain_matches(found))
                return
            secondaries = self.secondary_words()
            if found:
                self.set_status(f"נמצא דילוג מינימלי {abs(found[0].skip)}; סורק משניות סביב {len(found)} ממצאים...")
            saved = []
            for idx, pm in enumerate(found, 1):
                if self.engine.should_stop():
                    break
                if secondaries:
                    self.set_progress(idx, max(1, len(found)), "חיפוש מינימלי: סורק משניות במסך")
                    local = self.secondary_matches_for_primary(pm, secondaries)
                else:
                    local = [pm]
                found_words = self.secondary_field_words_found(pm, local)
                if not secondaries or self.mandatory_secondaries_satisfied(found_words):
                    saved.append((pm, local))
            self.root.after(0, lambda: self.show_minimal_result(saved, skip_from, skip_to))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("מינימלי", str(e)))
        finally:
            self.root.after(0, self.mark_search_finished)

    def show_minimal_result(self, saved: List[Tuple[Match, List[Match]]], skip_from: int, skip_to: int):
        a, b = int(skip_from), int(skip_to)
        if a > b:
            a, b = b, a
        if not saved:
            self.show_matches([])
            self.no_results_status(f"לא נמצא מינימלי בטווח דילוג {a}-{b}", advance_skip=True)
            return
        skip_abs = abs(saved[0][0].skip)
        secondary_total = sum(max(0, len(local) - 1) for _pm, local in saved)
        self.show_matches(saved)
        if secondary_total:
            self.status.set(f"מינימלי נמצא בטווח {a}-{b}: דילוג {skip_abs}, ראשיות {len(saved)}, נוספו משניות {secondary_total}")
        else:
            self.status.set(f"מינימלי נמצא בטווח {a}-{b}: דילוג {skip_abs}, ראשיות {len(saved)}")

    def run_search(self):
        if self.stop_running_then(self.run_search, "חיפוש חדש"):
            return
        self.prepare_search_start("search")
        self.reset_primary_found_count_for_search()
        self.clear_status_lock()
        try:
            self.save_search_state()
            added = self.add_search_words_to_scan_file()
            if added:
                self.status.set(f"נוספו {added} מילים לקובץ הסריקה")
        except Exception as e:
            self.status.set(f"אזהרה: לא הצלחתי לעדכן את קובץ המילים לסריקה: {e}")
        self.engine.begin_search()
        self.progress.configure(value=0)
        self.status.set("מכין חיפוש...")
        self.search_thread = threading.Thread(target=self._search_worker, daemon=True)
        self.search_thread.start()

    def run_meetings_search(self):
        if self.stop_running_then(self.run_meetings_search, "חיפוש מפגשים"):
            return
        self.prepare_search_start("meetings")
        self.reset_primary_found_count_for_search()
        if (
            hasattr(self, "min_secondary")
            and not (hasattr(self, "opt_min_secondary_all") and self.opt_min_secondary_all.get())
            and int(self.min_secondary.get() or 0) < 1
        ):
            self.min_secondary.set(1)
        specs = self.secondary_word_specs()
        if not specs:
            self.status.set("מפגשים צריכים לפחות מילה אחת בשדה משניות")
            return
        if not any(spec.get("meeting") for spec in specs):
            self.status.set("במפגשים צריך לסמן בכוכבית את המשנית למפגש, למשל *משיח")
            return
        primary_word = self.engine.normalize_word(self.get_primary_word())
        meeting_words = [spec["word"] for spec in specs if spec.get("meeting")]
        if primary_word and meeting_words and not self.meeting_overlap_possible(primary_word, meeting_words):
            words_text = ", ".join(meeting_words)
            msg = f"לא יתכן מפגש: אין אות משותפת בין הראשית {primary_word} לבין המשנית המסומנת {words_text}"
            self.lock_status_until_next_search(msg)
            rtl_showinfo("מפגשים", msg)
            return
        self.clear_status_lock()
        try:
            self.save_search_state()
            self.add_search_words_to_scan_file()
        except Exception as e:
            self.status.set(f"אזהרה: לא הצלחתי לשמור את מילות החיפוש: {e}")
        self.engine.begin_search()
        self.progress.configure(value=0)
        self.status.set("מכין חיפוש מפגשים...")
        self.search_thread = threading.Thread(target=self._meetings_worker, daemon=True)
        self.search_thread.start()

    def meeting_overlap_possible(self, primary_word: str, meeting_words: List[str]) -> bool:
        primary = canonical_hebrew(primary_word)
        if "?" in primary:
            return True
        primary_letters = {ch for ch in primary if ch != "?"}
        for word in meeting_words:
            clean = canonical_hebrew(word)
            if "?" in clean:
                return True
            if primary_letters & {ch for ch in clean if ch != "?"}:
                return True
        return False

    def run_cluster_search(self):
        if self.stop_running_then(self.run_cluster_search, "חיפוש מקבץ"):
            return
        self.prepare_search_start("cluster")
        self.reset_primary_found_count_for_search()
        if not self.secondary_words():
            self.status.set("מקבץ צריך לפחות מילה אחת בשדה משניות")
            return
        self.clear_status_lock()
        try:
            self.save_search_state()
            self.add_search_words_to_scan_file()
        except Exception as e:
            self.status.set(f"אזהרה: לא הצלחתי לשמור את מילות החיפוש: {e}")
        self.engine.begin_search()
        self.progress.configure(value=0)
        self.status.set("מכין חיפוש מקבץ 10x10...")
        self.search_thread = threading.Thread(target=self._cluster_worker, daemon=True)
        self.search_thread.start()

    def run_repeated_phrase_search(self):
        if self.stop_running_then(self.run_repeated_phrase_search, "חיפוש חוזרות"):
            return
        self.prepare_search_start("repeated")
        primary_terms = self.primary_terms()
        secondary_terms = self.secondary_words()
        if len(primary_terms) != 1:
            rtl_showinfo("חוזרות", "חיפוש חוזרות מיועד לביטוי אחד בלבד בשדה ראשית.")
            self.status.set("חוזרות: הכנס ביטוי אחד בלבד בשדה ראשית")
            return
        if secondary_terms:
            rtl_showinfo("חוזרות", "חיפוש חוזרות עובד בלי משניות. אם רצונך לסדר ראשית ומשנית אחת מתחת לשנייה, השתמש בכפתור עמודות.")
            self.status.set("חוזרות: מחק משניות או השתמש בעמודות")
            return
        phrase = primary_terms[0]
        if len(phrase) < 2:
            self.status.set("חוזרות צריך ביטוי של שתי אותיות לפחות בשדה ראשית")
            return
        self.clear_status_lock()
        try:
            self.save_search_state()
            self.add_search_words_to_scan_file()
        except Exception as e:
            self.status.set(f"אזהרה: לא הצלחתי לשמור את מילות החיפוש: {e}")
        self.engine.begin_search()
        self.progress.configure(value=0)
        self.status.set("מחפש הופעות חוזרות...")
        self.search_thread = threading.Thread(target=self._repeated_phrase_worker, daemon=True)
        self.search_thread.start()

    def _repeated_phrase_worker(self):
        try:
            phrase = self.engine.normalize_word(self.get_primary_word())
            hits = self.engine.find_text(phrase)
            if self.engine.should_stop():
                self.root.after(0, lambda: self.show_plain_matches(hits))
                return
            saved = []
            max_pairs = 250
            pair_count = max(0, len(hits) * (len(hits) - 1) // 2)
            idx = 0
            for first_index, first in enumerate(hits):
                for second in hits[first_index + 1:]:
                    idx += 1
                    if self.engine.should_stop() or len(saved) >= max_pairs:
                        break
                    gap = second.start - first.start
                    if gap <= 0:
                        continue
                    self.set_progress(idx, max(1, pair_count), "חוזרות: מחשב דילוגים")
                    anchor = Match(
                        phrase,
                        first.start,
                        gap,
                        "primary",
                        positions=[first.start, second.start],
                    )
                    first_mark = Match(phrase, first.start, 1, "repeat_text", positions=list(range(first.start, first.start + len(phrase))))
                    second_mark = Match(phrase, second.start, 1, "repeat_text", positions=list(range(second.start, second.start + len(phrase))))
                    saved.append((anchor, [anchor, first_mark, second_mark]))
                if self.engine.should_stop() or len(saved) >= max_pairs:
                    break
            self.root.after(0, lambda: self.show_matches(saved))
            if saved:
                self.root.after(0, lambda: self.status.set(f"חוזרות: נמצאו {len(saved)} דילוגים בין הופעות"))
            else:
                self.root.after(0, lambda: self.lock_status_until_next_search("חוזרות: לא נמצאו שתי הופעות של הביטוי"))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("חוזרות", str(e)))
        finally:
            self.root.after(0, self.mark_search_finished)

    def _meetings_worker(self):
        try:
            primary_word = self.get_primary_word()
            specs = self.secondary_word_specs()
            meeting_words = [spec["word"] for spec in specs if spec.get("meeting")]
            regular_words = [spec["word"] for spec in specs if not spec.get("meeting")]
            min_required = max(1, self.required_secondary_count(meeting_words + regular_words))
            skips = self.parse_skips()
            if self.current_view_search_enabled():
                self.set_status("מפגשים: מחפש רק במסך הצופן הנוכחי...")
                saved, primary_count, filtered = self.search_current_view_meetings(primary_word, specs)
                self.root.after(0, lambda: self.show_matches_with_reason(saved, primary_count, filtered, fallback_note=" | מפגשים במסך הנוכחי"))
                return
            primaries = self.existing_primary_matches()
            using_existing_primaries = bool(primaries)
            if using_existing_primaries:
                self.set_status(f"מפגשים: עובד על {len(primaries)} ראשיות קיימות מהחיפוש האחרון...")
                self.publish_primary_found_count(len(primaries))
            else:
                self.set_status("מפגשים: מחפש מילה ראשית בדילוג...")
                primaries = self.engine.find_word(primary_word, skips, progress=self.progress_for("מפגשים: ראשית", primary_count_base=0))
                self.publish_primary_found_count(len(primaries))
                if self.engine.should_stop():
                    self.root.after(0, lambda: self.show_plain_matches(primaries))
                    return

            meeting_text_matches = []
            for idx, word in enumerate(meeting_words, 1):
                if self.engine.should_stop():
                    break
                self.set_progress(idx, max(1, len(meeting_words)), "מפגשים: המשנית המסומנת בכוכבית")
                meeting_text_matches.extend(self.engine.find_text(word))

            saved = []
            filtered = 0
            for idx, pm in enumerate(primaries, 1):
                if self.engine.should_stop():
                    break
                if idx == 1 or idx % 20 == 0:
                    self.set_progress(idx, max(1, len(primaries)), "מפגשים: בדיקת אות משותפת ומשניות")
                pm_positions = set(pm.calc_positions())
                window = self.positions_for_primary_grid(pm)
                local = [pm]
                seen = {(pm.word, tuple(pm.calc_positions()), pm.kind)}
                found_words = set()
                meeting_found = False

                for tm in meeting_text_matches:
                    tm_positions = set(tm.calc_positions())
                    if pm_positions & tm_positions and tm_positions <= window:
                        marked = Match(tm.word, tm.start, tm.skip, "secondary", positions=list(tm.calc_positions()))
                        key = (marked.word, tuple(marked.calc_positions()), marked.kind)
                        if key not in seen:
                            seen.add(key)
                            local.append(marked)
                        found_words.add(canonical_hebrew(tm.word))
                        meeting_found = True

                if not meeting_found:
                    filtered += 1
                    continue

                for word in regular_words:
                    if self.engine.should_stop():
                        break
                    ms = self.engine.find_in_window(word, window, self.secondary_skip_options(pm.skip), "secondary")
                    for match in ms:
                        key = (match.word, tuple(match.calc_positions()), match.kind)
                        if key not in seen:
                            seen.add(key)
                            local.append(match)
                    if ms:
                        found_words.add(canonical_hebrew(word))

                field_texts = self.field_text_matches_in_window(self.field_text_words_for_marks(), window, seen)
                if field_texts:
                    local.extend(field_texts)
                    secondary_keys = {canonical_hebrew(word) for word in meeting_words + regular_words}
                    for match in field_texts:
                        clean = canonical_hebrew(match.word)
                        if clean in secondary_keys:
                            found_words.add(clean)

                if len(found_words) >= min_required and self.mandatory_secondaries_satisfied(found_words, specs):
                    saved.append((pm, local))
                    self.root.after(0, lambda item=(pm, local): self.publish_live_matches([item], "נוסף מפגש לטבלת הממצאים"))
                else:
                    filtered += 1

            self.root.after(0, lambda: self.show_matches(saved))
            if saved:
                suffix = " על ראשיות קיימות" if using_existing_primaries else ""
                self.root.after(0, lambda: self.status.set(f"מפגשים{suffix}: נמצאו {len(saved)} צפנים. הכוכבית נספרה כחובת מינימום 1"))
            else:
                if using_existing_primaries:
                    self.root.after(0, lambda: self.lock_status_until_next_search(f"מפגשים על ראשיות קיימות: לא נמצאו תוספות שעומדות בכוכבית ובמינימום המשניות; נפסלו {filtered}"))
                else:
                    self.root.after(0, lambda: self.no_results_status(f"מפגשים: לא נמצאו צפנים שעומדים בכוכבית ובמינימום המשניות; נפסלו {filtered}", advance_skip=True))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("מפגשים", str(e)))
        finally:
            self.root.after(0, self.mark_search_finished)

    def _cluster_worker(self):
        try:
            primary_word = self.get_primary_word()
            text_words = self.secondary_words()
            min_required = self.required_secondary_count(text_words)
            skips = self.parse_skips()
            if self.current_view_search_enabled():
                self.set_status("מקבץ 10x10: מחפש רק במסך הצופן הנוכחי...")
                saved, primary_count, filtered = self.search_current_view_cluster(primary_word, text_words)
                self.root.after(0, lambda: self.show_matches_with_reason(saved, primary_count, filtered, fallback_note=" | מקבץ במסך הנוכחי"))
                return
            primaries = self.existing_primary_matches()
            using_existing_primaries = bool(primaries)
            if using_existing_primaries:
                self.set_status(f"מקבץ 10x10: עובד על {len(primaries)} ראשיות קיימות מהחיפוש האחרון...")
                self.publish_primary_found_count(len(primaries))
            else:
                self.set_status("מקבץ 10x10: מחפש מילה ראשית בדילוג...")
                primaries = self.engine.find_word(primary_word, skips, progress=self.progress_for("מקבץ 10x10: ראשית", primary_count_base=0))
                self.publish_primary_found_count(len(primaries))
                if self.engine.should_stop():
                    self.root.after(0, lambda: self.show_plain_matches(primaries))
                    return

            saved = []
            filtered = 0
            for idx, pm in enumerate(primaries, 1):
                if self.engine.should_stop():
                    break
                if idx == 1 or idx % 20 == 0:
                    self.set_progress(idx, max(1, len(primaries)), "מקבץ 10x10: בדיקת קירבה")
                window = self.positions_for_primary_grid(pm)
                _grid, pos_to_cell = self.grid_for_primary_match(pm)
                local = [pm]
                seen = {(pm.word, tuple(pm.calc_positions()), pm.kind)}
                found_words = set()
                for word in text_words:
                    if self.engine.should_stop():
                        break
                    cluster_steps = list(dict.fromkeys([pm.skip, -pm.skip]))
                    cluster_matches = self.engine.find_in_window(word, window, cluster_steps, "cluster")
                    word_found = False
                    for cm in cluster_matches:
                        if not self.matches_within_cluster_box(pm, cm, pos_to_cell):
                            continue
                        cm.color = stable_word_color(cm.word)
                        key = (cm.word, tuple(cm.calc_positions()), cm.kind)
                        if key not in seen:
                            seen.add(key)
                            local.append(cm)
                        word_found = True
                        if len(local) >= MAX_SCAN_RESULTS:
                            break
                    if word_found:
                        found_words.add(canonical_hebrew(word))
                    if len(local) >= MAX_SCAN_RESULTS:
                        break
                if len(found_words) >= min_required and len(local) > 1 and self.mandatory_secondaries_satisfied(found_words):
                    saved.append((pm, local))
                    self.root.after(0, lambda item=(pm, local): self.publish_live_matches([item], "נוסף מקבץ לטבלת הממצאים"))
                else:
                    filtered += 1

            self.root.after(0, lambda: self.show_matches(saved))
            if saved:
                suffix = " על ראשיות קיימות" if using_existing_primaries else ""
                self.root.after(0, lambda: self.status.set(f"מקבץ 10x10{suffix}: נמצאו {len(saved)} צפנים בקירבה עד {CLUSTER_BOX_COLS}x{CLUSTER_BOX_ROWS}"))
            else:
                if using_existing_primaries:
                    self.root.after(0, lambda: self.lock_status_until_next_search(f"מקבץ 10x10 על ראשיות קיימות: לא נמצאו תוספות שעומדות במינימום המשניות; נפסלו {filtered}"))
                else:
                    self.root.after(0, lambda: self.no_results_status(f"מקבץ 10x10: לא נמצאו מילים בקירבה שעומדות במינימום המשניות; נפסלו {filtered}", advance_skip=True))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("מקבץ 10x10", str(e)))
        finally:
            self.root.after(0, self.mark_search_finished)

    def grid_for_primary_match(self, primary: Match, side_cols=None, extra_rows=7) -> Tuple[List[List[Optional[int]]], Dict[int, Tuple[int, int]]]:
        skip = primary.skip or 1
        rows, cols, _center_col, base = self.canvas.skip_grid_metrics(primary, extra_rows)
        row_step = abs(skip)
        grid = []
        pos_to_cell = {}
        for r in range(rows):
            row = []
            for c in range(cols):
                p = base + r * row_step + c
                if 0 <= p < len(self.model.search_text):
                    row.append(p)
                    pos_to_cell[p] = (r, c)
                else:
                    row.append(None)
            grid.append(row)
        return grid, pos_to_cell

    def matches_within_cluster_box(self, first: Match, second: Match, pos_to_cell: Dict[int, Tuple[int, int]]) -> bool:
        positions = first.calc_positions() + second.calc_positions()
        cells = [pos_to_cell.get(p) for p in positions]
        if not cells or any(cell is None for cell in cells):
            return False
        rows = [r for r, _c in cells]
        cols = [c for _r, c in cells]
        return (max(rows) - min(rows) + 1) <= CLUSTER_BOX_ROWS and (max(cols) - min(cols) + 1) <= CLUSTER_BOX_COLS

    def positions_for_primary_grid(self, primary: Match, side_cols=None, extra_rows=7) -> set:
        return self.positions_for_primary_grid_rows(primary, row_multiplier=1)

    def dense_search_rows(self, row_multiplier: int = 1) -> int:
        height = self.canvas.canvas.winfo_height() if hasattr(self, "canvas") else 0
        if height <= 1 and hasattr(self, "canvas"):
            height = self.canvas.canvas.winfo_reqheight()
        dense_cell_h = 13
        natural_rows = int(max(dense_cell_h, height - 20) // dense_cell_h)
        rows = max(8, min(260, natural_rows + int(getattr(self.canvas, "view_rows_extra", 0) or 0)))
        return max(1, rows * max(1, int(row_multiplier or 1)))

    def dense_search_linear_cols(self) -> int:
        width = self.canvas.canvas.winfo_width() if hasattr(self, "canvas") else 0
        if width <= 1 and hasattr(self, "canvas"):
            width = self.canvas.canvas.winfo_reqwidth()
        dense_cell_w = 8
        usable = max(dense_cell_w, width - getattr(self.canvas, "spp_w", 150) - 12)
        return max(1, min(MAX_GRID_COLS, int(usable // dense_cell_w) + int(getattr(self.canvas, "view_cols_extra", 0) or 0)))

    def dense_primary_search_grid(self, primary: Match, row_multiplier: int = 1) -> List[List[Optional[int]]]:
        skip = primary.skip or 1
        if abs(skip) == 1:
            cols = self.dense_search_linear_cols()
            rows = self.dense_search_rows(row_multiplier)
            start = max(0, primary.start - cols // 2)
            max_start = max(0, len(self.model.search_text) - cols * rows)
            start = min(start, max_start)
            return [
                [p if p < len(self.model.search_text) else None for p in range(start + r * cols, start + (r + 1) * cols)]
                for r in range(rows)
            ]

        row_step = abs(skip)
        rows = self.dense_search_rows(row_multiplier)
        cols = self.canvas.displayed_cols_for_skip(skip)
        center_col = cols // 2
        positions = primary.calc_positions()
        anchor = min(positions) if positions else primary.start
        primary_center_row = max(0, min(rows - 1, rows // 2))
        base = anchor - primary_center_row * row_step - center_col
        domain_start, domain_end = self.canvas.natural_col_bounds_for_skip(skip, cols, center_col)
        grid = []
        used = set()
        for r in range(rows):
            row = []
            for c in range(cols):
                if not (domain_start <= c < domain_end):
                    row.append(None)
                    continue
                p = base + r * row_step + c
                if 0 <= p < len(self.model.search_text) and p not in used:
                    used.add(p)
                    row.append(p)
                else:
                    row.append(None)
            grid.append(row)
        return grid

    def dense_primary_search_positions(self, primary: Match, row_multiplier: int = 1) -> set:
        return {p for row in self.dense_primary_search_grid(primary, row_multiplier) for p in row if p is not None}

    def positions_for_primary_grid_rows(self, primary: Match, row_multiplier: int = 1) -> set:
        return self.dense_primary_search_positions(primary, row_multiplier)

    def positions_for_text_primary_screen(self, primary: Match) -> set:
        cols = max(1, self.dense_search_linear_cols())
        rows = max(1, self.dense_search_rows())
        start = max(0, primary.start - cols // 2)
        max_start = max(0, len(self.model.search_text) - cols * rows)
        start = min(start, max_start)
        return {p for p in range(start, min(len(self.model.search_text), start + cols * rows))}

    def visible_grid_snapshot(self) -> List[List[Optional[int]]]:
        if not hasattr(self, "canvas") or not getattr(self.canvas, "grid", None):
            return []
        return [list(row) for row in self.canvas.grid]

    def dense_current_primary_grid_snapshot(self, row_multiplier: int = 1) -> List[List[Optional[int]]]:
        if not self.saved or not (0 <= self.current < len(self.saved)):
            return self.visible_grid_snapshot()
        primary, _local = self.saved[self.current]
        display_primary = getattr(self, "current_display_match", None) or primary
        if getattr(display_primary, "word", None):
            return self.dense_primary_search_grid(display_primary, row_multiplier)
        return self.visible_grid_snapshot()

    def field_text_matches_in_window(self, words: List[str], window: set, seen: Optional[set] = None) -> List[Match]:
        """Mark plain-text appearances of words that the user typed in the search fields."""
        seen = seen if seen is not None else set()
        found: List[Match] = []
        for word in dict.fromkeys(words):
            if self.engine.should_stop():
                break
            clean = self.engine.normalize_word(word)
            if len(clean) < 2:
                continue
            for match in self.engine.find_in_window(clean, window, [1, -1], "text"):
                key = (canonical_hebrew(match.word), tuple(match.calc_positions()), match.kind)
                if key in seen:
                    continue
                seen.add(key)
                found.append(match)
        return found

    def field_text_words_for_marks(self) -> List[str]:
        words: List[str] = []
        if getattr(self, "opt_primary_text_mark", None) is None or self.opt_primary_text_mark.get():
            primary = self.engine.normalize_word(self.get_primary_word())
            if primary:
                words.append(primary)
        if getattr(self, "opt_secondary_text_mark", None) is None or self.opt_secondary_text_mark.get():
            words.extend(self.secondary_words())
        return [w for w in dict.fromkeys(words) if len(w) >= 2]

    def primary_from_text_match(self, match: Match) -> Match:
        positions = match.calc_positions()
        if not positions:
            positions = list(range(match.start, min(len(self.model.search_text), match.start + len(match.word))))
        return Match(match.word, match.start, 1, "primary", positions=positions)

    def secondary_primary_candidates(self, original_primary: str, limit: int = 5) -> List[str]:
        secondaries = [w for w in self.secondary_words() if canonical_hebrew(w) != canonical_hebrew(original_primary)]
        if not secondaries:
            return []
        unique = {}
        for word in secondaries:
            key = canonical_hebrew(word)
            if key and key not in unique:
                unique[key] = word
        ordered = sorted(unique.values(), key=lambda w: (-len(canonical_hebrew(w)), canonical_hebrew(w)))
        return ordered[:max(1, int(limit))]

    def alternate_secondaries_for_primary(self, alternate: str, original_primary: str) -> List[str]:
        secondaries = [w for w in self.secondary_words() if canonical_hebrew(w) != canonical_hebrew(original_primary)]
        new_secondaries = []
        if original_primary:
            new_secondaries.append(original_primary)
        new_secondaries.extend(w for w in secondaries if canonical_hebrew(w) != canonical_hebrew(alternate))
        return [w for w in dict.fromkeys(new_secondaries) if w]

    def search_ciphers_for_primary(
        self,
        primary_word: str,
        secondaries: List[str],
        skips: List[int],
        *,
        label: str = "",
        primary_count_base: int = 0,
    ) -> Tuple[List[Tuple[Match, List[Match]]], int, int, List[Match]]:
        primaries = self.engine.find_word(
            primary_word,
            skips,
            progress=self.progress_for(label or "חיפוש מילה ראשית", primary_count_base=primary_count_base),
        )
        self.publish_primary_found_count(len(primaries))
        if self.engine.should_stop():
            return ([(pm, [pm]) for pm in primaries], len(primaries), 0, primaries)
        saved, filtered = self.ciphers_for_primary_matches(primaries, secondaries, label=label)
        return saved, len(primaries), filtered, primaries

    def ciphers_for_primary_matches(
        self,
        primaries: List[Match],
        secondaries: List[str],
        *,
        label: str = "",
        live_message: str = "נוסף ממצא חי לטבלת הממצאים",
    ) -> Tuple[List[Tuple[Match, List[Match]]], int]:
        saved: List[Tuple[Match, List[Match]]] = []
        filtered = 0

        for idx, pm in enumerate(primaries, 1):
            if self.engine.should_stop():
                break
            prefix = f"{label}: " if label else ""
            self.set_status(f"{prefix}בודק משניות במסך הראשית הממורכזת: ממצא {idx} מתוך {len(primaries)}")
            window = self.positions_for_primary_grid(pm)
            local = [pm]
            seen = {(pm.word, tuple(pm.calc_positions()), pm.kind)}
            found_words = set()

            for sw_idx, sw in enumerate(secondaries, 1):
                if self.engine.should_stop():
                    break
                if sw_idx == 1 or sw_idx % 5 == 0:
                    self.set_progress(sw_idx, max(1, len(secondaries)), f"{prefix}בודק משניות {idx}/{len(primaries)}")
                ms = self.engine.find_in_window(sw, window, self.secondary_skip_options(pm.skip), "secondary")
                if not ms and self.should_try_date_fraction_fallback(sw):
                    fallback_steps = self.date_fraction_fallback_steps(pm.skip)
                    if fallback_steps:
                        ms = self.engine.find_in_window(sw, window, fallback_steps, "secondary")
                if ms:
                    found_words.add(canonical_hebrew(sw))
                    local.extend(ms)
                    for match in ms:
                        seen.add((match.word, tuple(match.calc_positions()), match.kind))
            field_texts = self.field_text_matches_in_window(self.field_text_words_for_marks(), window, seen)
            if field_texts:
                local.extend(field_texts)
                secondary_keys = {canonical_hebrew(sw) for sw in secondaries}
                for match in field_texts:
                    clean = canonical_hebrew(match.word)
                    if clean in secondary_keys:
                        found_words.add(clean)
            if self.engine.should_stop():
                break

            if not secondaries or (len(found_words) >= self.required_secondary_count(secondaries) and self.mandatory_secondaries_satisfied(found_words)):
                saved.append((pm, local))
                self.root.after(0, lambda item=(pm, local), msg=live_message: self.publish_live_matches([item], msg))
            else:
                filtered += 1
        return saved, filtered

    def existing_primary_matches(self) -> List[Match]:
        primaries: List[Match] = []
        seen = set()
        for pm, _local in getattr(self, "saved", []) or []:
            key = (canonical_hebrew(pm.word), int(pm.start), int(pm.skip or 1), tuple(pm.calc_positions()))
            if key in seen:
                continue
            seen.add(key)
            primaries.append(pm)
        if primaries:
            return primaries
        for pm in getattr(self, "cached_primary_matches", []) or []:
            key = (canonical_hebrew(pm.word), int(pm.start), int(pm.skip or 1), tuple(pm.calc_positions()))
            if key in seen:
                continue
            seen.add(key)
            primaries.append(pm)
        return primaries

    def _cached_primary_secondaries_worker(self, primary_snapshot: List[Match]):
        try:
            secondaries = self.secondary_words()
            saved, filtered = self.ciphers_for_primary_matches(
                primary_snapshot,
                secondaries,
                label="משניות על ראשיות שמורות",
                live_message="נוסף ממצא מסריקת משניות על ראשיות שמורות",
            )
            self.root.after(0, lambda: self.finish_cached_primary_secondaries_search(saved, len(primary_snapshot), filtered))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("סריקת משניות", str(e)))
        finally:
            self.root.after(0, self.mark_search_finished)

    def finish_cached_primary_secondaries_search(self, saved: List[Tuple[Match, List[Match]]], primary_count: int, filtered: int):
        self.saved = []
        self.current = 0
        self.current_display_match = None
        self.show_matches_with_reason(saved, primary_count, filtered, fallback_note=" | בלי חיפוש ראשיות מחדש")

    def current_view_search_enabled(self) -> bool:
        return bool(
            hasattr(self, "opt_current_view_only")
            and self.opt_current_view_only.get()
            and hasattr(self, "canvas")
            and getattr(self.canvas, "grid", None)
        )

    def confirm_current_view_skip_range_if_needed(self) -> bool:
        if not (
            hasattr(self, "opt_current_view_only")
            and self.opt_current_view_only.get()
            and hasattr(self, "skip_from")
            and hasattr(self, "skip_to")
        ):
            return True
        try:
            current_skip = max(1, abs(int(self.current_display_skip_value())))
            start = int(self.skip_from.get())
            end = int(self.skip_to.get())
            low, high = sorted((abs(start), abs(end)))
        except Exception:
            return True
        if low <= current_skip <= high:
            return True
        message = (
            "סומן 'רק במסך הנוכחי', אבל הדילוג הנוכחי אינו נמצא בטווח הדילוגים שבשדות.\n\n"
            f"הדילוג הנוכחי בתצוגה: {current_skip}\n"
            f"הטווח הרשום בשדות: {low}-{high}\n\n"
            f"האם לעבור כעת לטווח הדילוג הנוכחי {current_skip}-{current_skip}?"
        )
        if not rtl_askyesno("טווח דילוגים אינו מתאים למסך הנוכחי", message):
            self.status.set("הפעולה בוטלה: הדילוג הנוכחי אינו נמצא בטווח הדילוגים שבשדות.")
            return False
        if hasattr(self, "exact_skip") and self.exact_skip.get().strip():
            self.exact_skip.set("")
        self.skip_from.set(current_skip)
        self.skip_to.set(current_skip)
        self.update_context_header()
        self.save_app_settings()
        self.status.set(f"טווח הדילוגים עודכן לדילוג הנוכחי: {current_skip}-{current_skip}.")
        return True

    def screen_matches_for_words(self, words: List[str], kind: str = "scan", limit: int = MAX_SCAN_RESULTS) -> List[Match]:
        matches = self.canvas.screen_word_paths(words, limit, self.visible_grid_snapshot(), self.engine.should_stop)
        for match in matches:
            match.kind = kind
        return matches

    def search_current_view_only(self, mode: str, primary_word: str, secondaries: List[str]) -> Tuple[List[Tuple[Match, List[Match]]], int, int]:
        primary_matches = self.screen_matches_for_words([primary_word], "primary", MAX_SCAN_RESULTS)
        saved: List[Tuple[Match, List[Match]]] = []
        filtered = 0
        if mode in ("regular", "text"):
            return [(pm, [pm]) for pm in primary_matches], len(primary_matches), 0

        secondary_matches_by_word = {
            word: self.screen_matches_for_words([word], "secondary", MAX_SCAN_RESULTS)
            for word in secondaries
        }
        for pm in primary_matches:
            if self.engine.should_stop():
                break
            local = [pm]
            seen = {(pm.word, tuple(pm.calc_positions()), pm.kind)}
            found_words = set()
            for word, matches in secondary_matches_by_word.items():
                added_for_word = False
                for match in matches:
                    key = (match.word, tuple(match.calc_positions()), match.kind)
                    if key in seen:
                        continue
                    seen.add(key)
                    local.append(match)
                    added_for_word = True
                if added_for_word:
                    found_words.add(canonical_hebrew(word))
            if not secondaries or (len(found_words) >= self.required_secondary_count(secondaries) and self.mandatory_secondaries_satisfied(found_words)):
                saved.append((pm, local))
            else:
                filtered += 1
        return saved, len(primary_matches), filtered

    def search_current_view_meetings(self, primary_word: str, specs: List[dict]) -> Tuple[List[Tuple[Match, List[Match]]], int, int]:
        meeting_words = [spec["word"] for spec in specs if spec.get("meeting")]
        regular_words = [spec["word"] for spec in specs if not spec.get("meeting")]
        primary_matches = self.screen_matches_for_words([primary_word], "primary", MAX_SCAN_RESULTS)
        meeting_matches = []
        for word in meeting_words:
            meeting_matches.extend(self.screen_matches_for_words([word], "secondary", MAX_SCAN_RESULTS))
        regular_by_word = {word: self.screen_matches_for_words([word], "secondary", MAX_SCAN_RESULTS) for word in regular_words}
        min_required = max(1, self.required_secondary_count(meeting_words + regular_words))
        saved = []
        filtered = 0
        for pm in primary_matches:
            pm_positions = set(pm.calc_positions())
            local = [pm]
            seen = {(pm.word, tuple(pm.calc_positions()), pm.kind)}
            found_words = set()
            meeting_found = False
            for match in meeting_matches:
                if pm_positions & set(match.calc_positions()):
                    key = (match.word, tuple(match.calc_positions()), match.kind)
                    if key not in seen:
                        seen.add(key)
                        local.append(match)
                    found_words.add(canonical_hebrew(match.word))
                    meeting_found = True
            if not meeting_found:
                filtered += 1
                continue
            for word, matches in regular_by_word.items():
                added_for_word = False
                for match in matches:
                    key = (match.word, tuple(match.calc_positions()), match.kind)
                    if key not in seen:
                        seen.add(key)
                        local.append(match)
                        added_for_word = True
                if added_for_word:
                    found_words.add(canonical_hebrew(word))
            if len(found_words) >= min_required and self.mandatory_secondaries_satisfied(found_words, specs):
                saved.append((pm, local))
            else:
                filtered += 1
        return saved, len(primary_matches), filtered

    def search_current_view_cluster(self, primary_word: str, text_words: List[str]) -> Tuple[List[Tuple[Match, List[Match]]], int, int]:
        primary_matches = self.screen_matches_for_words([primary_word], "primary", MAX_SCAN_RESULTS)
        pos_to_cell = {p: (r, c) for r, row in enumerate(self.canvas.grid) for c, p in enumerate(row) if p is not None}
        by_word = {word: self.screen_matches_for_words([word], "cluster", MAX_SCAN_RESULTS) for word in text_words}
        min_required = self.required_secondary_count(text_words)
        saved = []
        filtered = 0
        for pm in primary_matches:
            pm_cells = [pos_to_cell.get(p) for p in pm.calc_positions()]
            pm_cells = [cell for cell in pm_cells if cell is not None]
            if not pm_cells:
                filtered += 1
                continue
            pr = [r for r, _c in pm_cells]
            pc = [c for _r, c in pm_cells]
            local = [pm]
            seen = {(pm.word, tuple(pm.calc_positions()), pm.kind)}
            found_words = set()
            for word, matches in by_word.items():
                for match in matches:
                    cells = [pos_to_cell.get(p) for p in match.calc_positions()]
                    cells = [cell for cell in cells if cell is not None]
                    if not cells:
                        continue
                    rows = pr + [r for r, _c in cells]
                    cols = pc + [c for _r, c in cells]
                    if (max(rows) - min(rows) + 1) > CLUSTER_BOX_ROWS or (max(cols) - min(cols) + 1) > CLUSTER_BOX_COLS:
                        continue
                    key = (match.word, tuple(match.calc_positions()), match.kind)
                    if key not in seen:
                        seen.add(key)
                        local.append(match)
                    found_words.add(canonical_hebrew(word))
                    break
            if len(found_words) >= min_required and len(local) > 1 and self.mandatory_secondaries_satisfied(found_words):
                saved.append((pm, local))
            else:
                filtered += 1
        return saved, len(primary_matches), filtered

    def _search_worker(self):
        try:
            mode = self.mode.get()
            primary_words = self.primary_terms() or [self.engine.normalize_word(self.get_primary_word())]
            primary_words = [w for w in dict.fromkeys(primary_words) if w]
            if not primary_words:
                self.root.after(0, lambda: self.lock_status_until_next_search("לא הוזנה ראשית לחיפוש"))
                return
            self.set_status("מכין את טווח הדילוגים לחיפוש...")
            skips = self.parse_skips()

            if self.current_view_search_enabled() and mode != "minimal":
                self.set_status("מחפש רק במסך הצופן הנוכחי...")
                saved = []
                primary_count = 0
                filtered = 0
                secondaries = self.secondary_words()
                for term_idx, word in enumerate(primary_words, 1):
                    if self.engine.should_stop():
                        break
                    self.set_status(f"מסך נוכחי: מחפש ראשית {term_idx}/{len(primary_words)}: {word}")
                    part_saved, part_primary_count, part_filtered = self.search_current_view_only(mode, word, secondaries)
                    saved.extend(part_saved)
                    primary_count += part_primary_count
                    self.publish_primary_found_count(primary_count)
                    filtered += part_filtered
                self.root.after(0, lambda: self.show_matches_with_reason(saved, primary_count, filtered, fallback_note=" | חיפוש במסך הנוכחי"))
                return

            if mode == "minimal":
                skip_from = int(self.skip_from.get())
                skip_to = int(self.skip_to.get())
                self.set_status("מחפש דילוג מינימלי...")
                secondaries = self.secondary_words()
                saved = []
                total_found = 0
                for term_idx, word in enumerate(primary_words, 1):
                    if self.engine.should_stop():
                        break
                    self.set_status(f"חיפוש מינימלי: ראשית {term_idx}/{len(primary_words)}: {word}")
                    found = self.engine.find_minimal_word(word, skip_from, skip_to, progress=self.progress_for(f"חיפוש מינימלי {word}"))
                    total_found += len(found)
                    self.publish_primary_found_count(total_found)
                    if found:
                        self.set_status(f"נמצא דילוג מינימלי {abs(found[0].skip)} עבור {word}; סורק משניות סביב {len(found)} ממצאים...")
                    for idx, pm in enumerate(found, 1):
                        if self.engine.should_stop():
                            break
                        if secondaries:
                            self.set_progress(idx, max(1, len(found)), "חיפוש מינימלי: סורק משניות במסך")
                            local = self.secondary_matches_for_primary(pm, secondaries)
                        else:
                            local = [pm]
                        found_words = self.secondary_field_words_found(pm, local)
                        if not secondaries or self.mandatory_secondaries_satisfied(found_words):
                            saved.append((pm, local))
                self.root.after(0, lambda: self.show_minimal_result(saved, skip_from, skip_to))
                return

            if mode == "text":
                self.set_status("מחפש רצף טקסט בתורה...")
                matches = []
                for term_idx, word in enumerate(primary_words, 1):
                    if self.engine.should_stop():
                        break
                    self.set_status(f"טקסט: מחפש ראשית {term_idx}/{len(primary_words)}: {word}")
                    matches.extend(self.engine.find_text(word))
                    self.publish_primary_found_count(len(matches))
                self.root.after(0, lambda: self.show_plain_matches(matches))
                return

            if mode == "regular":
                self.set_status("חיפוש רגיל: מחפש מילה ראשית בטווח הדילוגים...")
                matches = []
                for term_idx, word in enumerate(primary_words, 1):
                    if self.engine.should_stop():
                        break
                    self.set_status(f"חיפוש רגיל: ראשית {term_idx}/{len(primary_words)}: {word}")
                    matches.extend(self.engine.find_word(word, skips, progress=self.progress_for(f"חיפוש רגיל {word}", primary_count_base=len(matches))))
                    self.publish_primary_found_count(len(matches))
                self.root.after(0, lambda: self.show_plain_matches(matches))
                return

            if mode == "text_skip":
                self.set_status("מחפש ראשית כטקסט רציף...")
                secondaries = self.secondary_words()
                saved = []
                filtered = 0
                total_text_hits = 0
                for term_idx, word in enumerate(primary_words, 1):
                    if self.engine.should_stop():
                        break
                    self.set_status(f"טקסט+דילוג: מחפש ראשית {term_idx}/{len(primary_words)}: {word}")
                    text_hits = self.engine.find_text(word)
                    total_text_hits += len(text_hits)
                    self.publish_primary_found_count(total_text_hits)
                    if self.engine.should_stop():
                        break
                    for idx, text_match in enumerate(text_hits, 1):
                        if self.engine.should_stop():
                            break
                        pm = self.primary_from_text_match(text_match)
                        self.set_status(f"בודק משניות בדילוגי הטווח סביב {word}: ממצא {idx} מתוך {len(text_hits)}")
                        window = self.positions_for_text_primary_screen(pm)
                        local = [pm]
                        seen = {(pm.word, tuple(pm.calc_positions()), pm.kind)}
                        found_words = set()
                        for sw_idx, sw in enumerate(secondaries, 1):
                            if self.engine.should_stop():
                                break
                            if sw_idx == 1 or sw_idx % 5 == 0:
                                self.set_progress(sw_idx, max(1, len(secondaries)), f"בודק משניות בטווח סביב טקסט {idx}/{len(text_hits)}")
                            ms = self.engine.find_in_window(sw, window, skips, "secondary")
                            if ms:
                                found_words.add(canonical_hebrew(sw))
                                local.extend(ms)
                                for match in ms:
                                    seen.add((match.word, tuple(match.calc_positions()), match.kind))
                        field_texts = self.field_text_matches_in_window(self.field_text_words_for_marks(), window, seen)
                        if field_texts:
                            local.extend(field_texts)
                            for match in field_texts:
                                clean = canonical_hebrew(match.word)
                                if clean in {canonical_hebrew(sw) for sw in secondaries}:
                                    found_words.add(clean)
                        if not secondaries or (len(found_words) >= self.required_secondary_count(secondaries) and self.mandatory_secondaries_satisfied(found_words)):
                            saved.append((pm, local))
                            self.root.after(0, lambda item=(pm, local): self.publish_live_matches([item], "נוסף ממצא טקסט+דילוג לטבלת הממצאים"))
                        else:
                            filtered += 1
                self.set_status("מצייר מפגשי טקסט+דילוג...")
                self.root.after(0, lambda: self.show_matches_with_reason(saved, total_text_hits, filtered))
                return

            secondaries = self.secondary_words()
            self.set_status("מחפש ראשיות בכל התורה לפי טווח הדילוגים...")
            saved = []
            primary_count = 0
            primary_cache_key = self.primary_cache_key(primary_words, skips, mode)
            primary_cache_matches: List[Match] = []
            filtered = 0
            fallback_note = ""
            for term_idx, word in enumerate(primary_words, 1):
                if self.engine.should_stop():
                    break
                self.set_status(f"חיפוש מילה ראשית {term_idx}/{len(primary_words)}: {word}")
                part_saved, part_primary_count, part_filtered, part_primaries = self.search_ciphers_for_primary(
                    word,
                    secondaries,
                    skips,
                    label=f"חיפוש ראשית {term_idx}/{len(primary_words)} {word}",
                    primary_count_base=primary_count,
                )
                saved.extend(part_saved)
                primary_count += part_primary_count
                primary_cache_matches.extend(part_primaries)
                self.publish_primary_found_count(primary_count)
                filtered += part_filtered
                if (
                    not part_saved
                    and mode == "code"
                    and hasattr(self, "opt_try_long_secondary_primary")
                    and self.opt_try_long_secondary_primary.get()
                ):
                    candidates = self.secondary_primary_candidates(word, limit=5)
                    if candidates:
                        warning = (
                            f"לא נמצא צופן שעומד בתנאים המבוקשים עבור {word}. "
                            f"חיפוש מורחב מנסה ראשיות חלופיות מתוך המשניות, לפי אורך. "
                            f"ייבדקו עד {len(candidates)} מילים. פעולה זו יכולה להימשך זמן ממושך."
                        )
                        self.root.after(0, lambda msg=warning: rtl_showinfo("חיפוש מורחב", msg))
                        attempts = []
                        for cand_idx, alternate in enumerate(candidates, 1):
                            if self.engine.should_stop():
                                break
                            alternate_secondaries = self.alternate_secondaries_for_primary(alternate, word)
                            attempts.append(alternate)
                            self.set_status(f"חיפוש מורחב {word}: {cand_idx}/{len(candidates)} בודק את {alternate} כראשית חלופית")
                            alt_saved, alt_primary_count, alt_filtered, _alt_primaries = self.search_ciphers_for_primary(
                                alternate,
                                alternate_secondaries,
                                skips,
                                label=f"חיפוש מורחב {alternate}",
                                primary_count_base=primary_count,
                            )
                            primary_count += alt_primary_count
                            self.publish_primary_found_count(primary_count)
                            filtered += alt_filtered
                            fallback_note = f" | חיפוש מורחב: נבדקו {len(attempts)}/{len(candidates)} עבור {word}"
                            if alt_saved:
                                saved.extend(alt_saved)
                                fallback_note = f" | חיפוש מורחב: נמצא עם {alternate} עבור {word}"
                                break

            self.set_status("מצייר ממצאים...")
            if primary_cache_key:
                self.cached_primary_key = primary_cache_key
                self.cached_primary_matches = primary_cache_matches
            self.root.after(0, lambda: self.show_matches_with_reason(saved, primary_count, filtered, fallback_note=fallback_note))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("שגיאה", str(e)))
        finally:
            self.root.after(0, self.mark_search_finished)

    def mark_search_finished(self):
        if self.engine.stop_reason:
            self.status.set(self.engine.stop_reason)
            if getattr(self, "auto_advance_chain_active", False):
                self.status.set(f"{self.engine.stop_reason}; הממצאים שנמצאו נשמרו")
        self.root.after(80, self.update_search_button_state)

    def show_plain_matches(self, matches: List[Match]):
        self.show_matches([(m, [m]) for m in matches])

    def merge_matches_into_current(self, matches: List[Match]) -> int:
        if not self.saved:
            return 0
        pm, local = self.saved[self.current]
        matches = TorahCanvas.drop_matches_inside_longer(local + matches)
        existing_match_ids = {id(m) for m in local}
        existing = {(m.word, tuple(m.calc_positions()), m.kind) for m in local}
        existing_core = {(canonical_hebrew(m.word), tuple(m.calc_positions())) for m in local}
        added = []
        for match in matches:
            if id(match) in existing_match_ids:
                continue
            key = (match.word, tuple(match.calc_positions()), match.kind)
            core_key = (canonical_hebrew(match.word), tuple(match.calc_positions()))
            if key not in existing and core_key not in existing_core:
                existing.add(key)
                existing_core.add(core_key)
                added.append(match)
        if added:
            merged = TorahCanvas.drop_matches_inside_longer(local + added)
            self.saved[self.current] = (pm, merged)
            self.canvas.set_matches(merged)
        return len(added)

    def apply_word_colors(self, matches: List[Match]):
        for match in matches:
            if match.kind == "primary":
                match.color = match.color or "#ff3b30"
            elif match.kind in ("date", "date_day", "date_month"):
                if match.kind == "date":
                    match.color = match.color or "#c2185b"
                elif match.kind == "date_day":
                    match.color = match.color or "#fff176"
                else:
                    match.color = match.color or "#ffb74d"
            elif match.kind in ("secondary", "cluster", "scan", "stacked", "text", "repeat_text"):
                match.color = match.color or stable_word_color(match.word)

    def show_matches_with_reason(self, saved: List[Tuple[Match, List[Match]]], primary_count: int, filtered_count: int, fallback_note: str = ""):
        self.show_matches(saved)
        if not saved:
            advance = "מסך הנוכחי" not in fallback_note
            if primary_count == 0:
                self.no_results_status("לא נמצאו ממצאים ראשיים בטווח הדילוגים" + fallback_note, advance_skip=advance)
            else:
                self.no_results_status(f"נמצאו {primary_count} ראשיים, אבל {filtered_count} נפסלו בגלל מינימום משניות{fallback_note}", advance_skip=advance)
        elif self.cluster_fraction_mode in (2, 3, 4):
            self.status.set(f"נמצאו {len(saved)} ממצאים{self.fraction_label()}{fallback_note}")
        elif fallback_note:
            self.status.set(f"נמצאו {len(saved)} צפנים{fallback_note}")

    def sort_saved_ciphers(self, saved: List[Tuple[Match, List[Match]]]) -> List[Tuple[Match, List[Match]]]:
        def sort_key(item):
            original_idx, (pm, local) = item
            score, _quality, _details = self.cipher_quality(pm, local) if hasattr(self, "canvas") else (0, "", "")
            secondary_count = self.secondary_count_for_cipher(pm, local)
            marked_count = max(0, len(local) - 1)
            primary_len = len(pm.word or "")
            return (-score, -secondary_count, -marked_count, -primary_len, abs(pm.skip or 0), original_idx)

        return [pair for _idx, pair in sorted(enumerate(saved), key=sort_key)]

    def sort_current_cipher_table_by(self, key: str):
        if not self.saved:
            return
        current_pm = self.saved[self.current][0] if 0 <= self.current < len(self.saved) else None
        labels = {"secondary": "משניות", "skip": "דילוג", "quality": "איכות"}
        default_reverse = key in ("secondary", "quality")
        if key == "secondary":
            self.cipher_sort_key = key
            self.cipher_sort_reverse = True
        elif self.cipher_sort_key == key:
            self.cipher_sort_reverse = not self.cipher_sort_reverse
        else:
            self.cipher_sort_key = key
            self.cipher_sort_reverse = default_reverse
        reverse = self.cipher_sort_reverse
        if key == "secondary":
            self.saved.sort(key=lambda item: (self.secondary_count_for_cipher(item[0], item[1]), self.cipher_quality(item[0], item[1])[0], -abs(item[0].skip or 1), -item[0].start), reverse=reverse)
        elif key == "skip":
            self.saved.sort(key=lambda item: (abs(item[0].skip or 1), -self.secondary_count_for_cipher(item[0], item[1]), -self.cipher_quality(item[0], item[1])[0], item[0].start), reverse=reverse)
        elif key == "quality":
            self.saved.sort(key=lambda item: (self.cipher_quality(item[0], item[1])[0], self.secondary_count_for_cipher(item[0], item[1]), -abs(item[0].skip or 1), -item[0].start), reverse=reverse)
        else:
            return
        if current_pm is not None:
            for idx, (pm, _local) in enumerate(self.saved):
                if pm is current_pm or self.same_result_match_identity(pm, current_pm):
                    self.current = idx
                    break
        self.populate_cipher_list()
        self.select_current_cipher_row(focus_results=True)
        direction = "יורד" if reverse else "עולה"
        self.status.set(f"טבלת הממצאים סודרה לפי {labels.get(key, key)} ({direction})")

    def same_result_match_identity(self, a: Optional[Match], b: Optional[Match]) -> bool:
        if a is None or b is None:
            return False
        a_positions = tuple(a.calc_positions())
        b_positions = tuple(b.calc_positions())
        same_word = canonical_hebrew(a.word) == canonical_hebrew(b.word)
        same_positions = a_positions == b_positions
        if same_positions and same_word:
            return True
        if same_positions and (not canonical_hebrew(a.word) or not canonical_hebrew(b.word)):
            return True
        return (
            same_word
            and int(a.start) == int(b.start)
            and int(a.skip or 1) == int(b.skip or 1)
        )

    def resolve_current_match_reference(self, match: Match) -> Match:
        if not self.saved or not (0 <= self.current < len(self.saved)):
            return match
        pm, local = self.saved[self.current]
        if match is pm or self.same_result_match_identity(pm, match):
            return pm
        for item in local:
            if item is match or self.same_result_match_identity(item, match):
                return item
        target_positions = set(match.calc_positions())
        target_word = canonical_hebrew(match.word)
        if target_positions:
            for item in local:
                if set(item.calc_positions()) == target_positions:
                    return item
            for item in local:
                if target_word and canonical_hebrew(item.word) == target_word and target_positions & set(item.calc_positions()):
                    return item
        return match

    def merge_saved_cipher_lists(self, existing: List[Tuple[Match, List[Match]]], new: List[Tuple[Match, List[Match]]]) -> List[Tuple[Match, List[Match]]]:
        merged = list(existing)
        index = {(pm.word, pm.start, pm.skip): idx for idx, (pm, _local) in enumerate(merged)}
        for pm, local in new:
            key = (pm.word, pm.start, pm.skip)
            if key in index:
                old_pm, old_local = merged[index[key]]
                combined = TorahCanvas.drop_matches_inside_longer(old_local + local)
                merged[index[key]] = (old_pm, combined)
            else:
                index[key] = len(merged)
                merged.append((pm, local))
        return merged

    def combine_saved_matches_for_display(
        self,
        existing: List[Tuple[Match, List[Match]]],
        incoming: List[Tuple[Match, List[Match]]],
    ) -> Tuple[List[Tuple[Match, List[Match]]], bool]:
        if existing and incoming:
            return self.merge_saved_cipher_lists(existing, incoming), True
        if existing and not incoming:
            return list(existing), True
        return list(incoming), False

    def publish_live_matches(self, new_saved: List[Tuple[Match, List[Match]]], message: str = ""):
        if not new_saved:
            return
        current_key = None
        if self.saved and 0 <= self.current < len(self.saved):
            cur_pm, _cur_local = self.saved[self.current]
            current_key = (cur_pm.word, cur_pm.start, cur_pm.skip)
        cleaned = []
        for pm, local in new_saved:
            local = TorahCanvas.drop_matches_inside_longer(local)
            self.apply_word_colors([pm] + local)
            cleaned.append((pm, local))
        self.saved = self.sort_saved_ciphers(self.merge_saved_cipher_lists(self.saved, cleaned))
        if current_key:
            for idx, (pm, _local) in enumerate(self.saved):
                if (pm.word, pm.start, pm.skip) == current_key:
                    self.current = idx
                    break
        elif self.saved:
            self.current = 0
        self.open_results_table()
        if self.current_display_match is None and self.saved:
            self.display_current()
        elif self.results_mode == "details":
            self.populate_current_result_table()
        else:
            self.populate_cipher_list()
        if message:
            self.status.set(f"{message}: סה״כ {len(self.saved)} | הטבלה זמינה וממוינת לפי דירוג הצופן")

    def show_matches(self, saved: List[Tuple[Match, List[Match]]]):
        saved = [(pm, TorahCanvas.drop_matches_inside_longer(local)) for pm, local in saved]
        has_new_saved = bool(saved)
        self.result_selection_highlight = False
        for pm, local in saved:
            self.apply_word_colors([pm] + local)
        current_key = None
        if (not has_new_saved) and self.saved and 0 <= self.current < len(self.saved):
            cur_pm, _cur_local = self.saved[self.current]
            current_key = (cur_pm.word, cur_pm.start, cur_pm.skip)
        saved, kept_existing = self.combine_saved_matches_for_display(self.saved, saved)
        if getattr(self, "preserve_saved_on_next_results", False):
            self.preserve_saved_on_next_results = False
        self.saved = self.sort_saved_ciphers(saved)
        self.current = 0
        if current_key:
            for idx, (pm, _local) in enumerate(self.saved):
                if (pm.word, pm.start, pm.skip) == current_key:
                    self.current = idx
                    break
        self.results_mode = "ciphers"
        if saved:
            if kept_existing and not has_new_saved:
                status = f"לא נמצאו ממצאים חדשים; הממצאים הקיימים נשמרו ({len(saved)})"
            else:
                status = f"נמצאו {len(saved)} צפנים{self.fraction_label()}"
            if has_new_saved and self.should_continue_to_next_range():
                status += self.advance_skip_range_after_no_results()
                self.open_results_table()
                self.display_current()
                self.select_current_cipher_row(focus_results=True)
                self.fit_results_table_to_rows(len(getattr(self, "result_rows", []) or []), minimum=260)
                self.select_current_cipher_row(focus_results=True)
                self.status.set(status)
                return
            self.open_results_table()
            self.display_current()
            self.select_current_cipher_row(focus_results=True)
            self.fit_results_table_to_rows(len(getattr(self, "result_rows", []) or []), minimum=260)
            self.select_current_cipher_row(focus_results=True)
            self.status.set(status)
            if self.auto_scan.get() and not self.engine.stop_flag:
                self.root.after(50, self.scan_current_screen)
        else:
            if self.engine.stop_flag and self.saved:
                self.display_current()
                self.status.set("החיפוש נעצר ידנית; הממצאים שנמצאו נשמרו")
                self.update_context_header()
                return
            self.current_display_match = None
            self.reset_live_skip_to_default()
            self.results.delete(0, "end")
            self.result_rows = []
            self.results_mode = "ciphers"
            self.canvas.set_matches([])
            mode = self.mode.get() if hasattr(self, "mode") else ""
            self.no_results_status("לא נמצאו ממצאים", advance_skip=mode == "regular")
            self.update_context_header()

    def should_continue_to_next_range(self) -> bool:
        if self.engine.stop_flag or self.exact_skip.get().strip():
            return False
        mode = self.mode.get() if hasattr(self, "mode") else ""
        if mode == "text":
            return False
        if getattr(self, "skip_chunk_queue", None):
            return self.ram_allows_auto_continue()
        if not hasattr(self, "opt_auto_advance_skip") or not self.opt_auto_advance_skip.get():
            return False
        return self.ram_allows_auto_continue()

    def match_row_text(self, label: str, match: Match) -> str:
        widths = getattr(self, "detail_table_widths", [18, 7])
        return self.table_row_pixels([match.word, str(abs(match.skip or 1))], widths)

    def match_kind_text(self, match: Match) -> str:
        return {
            "primary": "ראשית",
            "secondary": "משנית",
            "cluster": "מקבץ",
            "scan": "סריקה",
            "stacked": "עמודות",
            "repeat_text": "חוזרות",
            "text": "טקסט",
            "manual": "ידני",
            "date": "תאריך",
            "date_day": "יום בתאריך",
            "date_month": "חודש בתאריך",
        }.get(match.kind, match.kind)

    def table_cell(self, value, width: int) -> str:
        text = str(value if value is not None else "").replace("\n", " ").strip()
        if len(text) > width:
            text = text[:max(1, width - 1)] + "…"
        return text.rjust(width)

    def table_row(self, values: List[str], widths: List[int]) -> str:
        return " | ".join(self.table_cell(value, width) for value, width in zip(values, widths))

    def results_table_font(self):
        try:
            return tkfont.Font(font=self.results.cget("font"))
        except Exception:
            return tkfont.Font(family="Arial", size=12)

    def table_text_for_width(self, value, max_px: int, font_obj) -> str:
        text = str(value if value is not None else "").replace("\n", " ").strip()
        if font_obj.measure(text) <= max_px:
            return text
        suffix = "…"
        while text and font_obj.measure(text + suffix) > max_px:
            text = text[:-1]
        return (text + suffix) if text else suffix

    def table_row_pixels(self, values: List[str], widths_px: List[int]) -> str:
        font_obj = self.results_table_font()
        cells = []
        for value, width_px in zip(values, widths_px):
            text = self.table_text_for_width(value, width_px, font_obj)
            pad_px = max(0, width_px - font_obj.measure(text))
            cells.append(self.table_pixel_padding(pad_px, font_obj) + text)
        return " | ".join(cells)

    def table_pixel_padding(self, pad_px: int, font_obj) -> str:
        if pad_px <= 0:
            return ""
        units = [
            (" ", max(1, font_obj.measure(" "))),
            ("\u2009", max(1, font_obj.measure("\u2009"))),
            ("\u200a", max(1, font_obj.measure("\u200a"))),
        ]
        best = ("", 0, abs(pad_px))
        candidates = [("", 0)]
        for ch, unit_px in units:
            next_candidates = []
            for prefix, prefix_px in candidates:
                max_count = max(0, int((pad_px - prefix_px) / unit_px) + 2)
                for count in range(max_count + 1):
                    value = prefix + (ch * count)
                    measured = prefix_px + unit_px * count
                    distance = abs(pad_px - measured)
                    if distance < best[2]:
                        best = (value, measured, distance)
                    next_candidates.append((value, measured))
            candidates = sorted(next_candidates, key=lambda item: abs(pad_px - item[1]))[:24]
        return best[0]

    def compact_table_pixel_widths(self, headers: List[str], rows: List[List[str]], max_chars: List[int]) -> List[int]:
        font_obj = self.results_table_font()
        widths = []
        for col, header in enumerate(headers):
            max_px = font_obj.measure(str(header))
            for row in rows:
                if col < len(row):
                    max_px = max(max_px, font_obj.measure(str(row[col])))
            if col < len(max_chars) and max_chars[col] > 0:
                max_px = min(max_px, font_obj.measure("מ" * max_chars[col]))
            widths.append(max_px)
        return widths

    def fixed_table_pixel_widths(self, headers: List[str], rows: List[List[str]], fixed_samples: List[str], max_chars: List[int]) -> List[int]:
        font_obj = self.results_table_font()
        widths = []
        for col, header in enumerate(headers):
            max_px = font_obj.measure(str(header))
            fixed_sample = fixed_samples[col] if col < len(fixed_samples) else ""
            if fixed_sample:
                max_px = max(max_px, font_obj.measure(fixed_sample))
            else:
                for row in rows:
                    if col < len(row):
                        max_px = max(max_px, font_obj.measure(str(row[col])))
                if col < len(max_chars) and max_chars[col] > 0:
                    max_px = min(max_px, font_obj.measure("מ" * max_chars[col]))
            widths.append(max_px)
        return widths

    def compact_table_widths(self, headers: List[str], rows: List[List[str]], max_widths: List[int]) -> List[int]:
        widths = []
        for col, header in enumerate(headers):
            longest = len(str(header))
            for row in rows:
                if col < len(row):
                    longest = max(longest, len(str(row[col])))
            widths.append(min(max_widths[col], longest))
        return widths

    def cipher_quality(self, primary: Match, matches: List[Match]) -> Tuple[int, str, str]:
        useful = [
            m for m in matches
            if not (m.kind == "primary" and m.word == primary.word and m.start == primary.start and m.skip == primary.skip)
        ]
        unique_words = {canonical_hebrew(m.word) for m in useful if canonical_hebrew(m.word)}
        score = min(35, len(unique_words) * 8)
        positions = []
        for match in [primary] + useful:
            positions.extend(match.calc_positions())
        cells = [self.canvas.pos_to_cell[p] for p in positions if p in self.canvas.pos_to_cell]
        detail_parts = [f"משניות {len(unique_words)}"]
        if cells:
            rows = [r for r, _c in cells]
            cols = [c for _r, c in cells]
            h = max(rows) - min(rows) + 1
            w = max(cols) - min(cols) + 1
            area = h * w
            detail_parts.append(f"שטח {w}x{h}")
            if w <= 10 and h <= 10:
                score += 35
            elif w <= 20 and h <= 20:
                score += 22
            elif area <= 900:
                score += 10
            if len(cells) == len(positions):
                score += 10
        if any(m.kind == "date" for m in useful):
            score += 8
        if any(m.kind == "cluster" for m in useful):
            score += 10
            detail_parts.append("מקבץ 10x10")
        if any(m.kind in ("scan", "stacked", "repeat_text", "text") for m in useful):
            score += 6
        score = max(0, min(100, score))
        label = self.quality_rank(score)
        return score, label, " | ".join(detail_parts)

    @staticmethod
    def quality_rank(score: int) -> str:
        if score >= 80:
            return "א"
        if score >= 60:
            return "ב"
        if score >= 40:
            return "ג"
        return "ד"

    @staticmethod
    def short_quality_text(score: int) -> str:
        return f"{App.quality_rank(score)} {score}%"

    def update_result_row(self, idx: int):
        if self.results_mode == "ciphers":
            self.populate_cipher_list()
        elif idx == self.current:
            self.populate_current_result_table()

    def secondary_count_for_cipher(self, primary: Match, local: List[Match]) -> int:
        field_total = self.secondary_field_total()
        if field_total:
            return len(self.secondary_field_words_found(primary, local))
        return len(self.visible_detail_matches(primary, local))

    def secondary_count_on_screen(self, primary: Match, local: List[Match]) -> int:
        field_total = self.secondary_field_total()
        canvas_obj = getattr(self, "canvas", None)
        if not canvas_obj:
            return 0
        visible = canvas_obj.visible_positions()
        if not visible:
            return 0
        if field_total:
            return len(self.secondary_field_words_found(primary, local, visible_positions=visible))
        count = 0
        for match in self.visible_detail_matches(primary, local):
            positions = set(match.calc_positions())
            if positions and positions & visible:
                count += 1
        return count

    def secondary_count_label(self, primary: Match, local: List[Match], *, include_screen: bool = False) -> str:
        total = self.secondary_count_for_cipher(primary, local)
        field_total = self.secondary_field_total()
        if include_screen:
            shown = self.secondary_count_on_screen(primary, local)
            if field_total:
                return f"משניות במסך {shown}/{field_total}"
            return f"משניות במסך {shown}/{total}"
        if field_total:
            return f"משניות {total}/{field_total}"
        return f"משניות {total}"

    def secondary_field_patterns(self) -> List[str]:
        if not hasattr(self, "secondary_var"):
            return []
        patterns = []
        seen = set()
        for word in self.secondary_words():
            pattern = canonical_hebrew(word)
            if pattern and pattern not in seen:
                seen.add(pattern)
                patterns.append(pattern)
        return patterns

    def secondary_field_total(self) -> int:
        return len(self.secondary_field_patterns())

    def word_matches_secondary_pattern(self, word: str, pattern: str) -> bool:
        clean = canonical_hebrew(word)
        if not clean or len(clean) != len(pattern):
            return False
        return all(p == "?" or p == c for p, c in zip(pattern, clean))

    def secondary_field_words_found(self, primary: Match, local: List[Match], visible_positions: Optional[set] = None) -> set:
        patterns = self.secondary_field_patterns()
        if not patterns:
            return set()
        found = set()
        for match in self.visible_detail_matches(primary, local):
            positions = set(match.calc_positions())
            if visible_positions is not None and (not positions or not positions.issubset(visible_positions)):
                continue
            for pattern in patterns:
                if pattern not in found and self.word_matches_secondary_pattern(match.word, pattern):
                    found.add(pattern)
                    break
        return found

    def visible_detail_matches(self, primary: Match, local: List[Match]) -> List[Match]:
        visible = []
        seen = set()
        for match in local:
            if match is primary:
                continue
            if match.kind == "primary" and match.word == primary.word and match.start == primary.start and match.skip == primary.skip:
                continue
            key = canonical_hebrew(match.word)
            if not key:
                key = match.word
            if key in seen:
                continue
            seen.add(key)
            visible.append(match)
        return visible

    def populate_cipher_list(self):
        self.updating_result_selection = True
        self.results.delete(0, "end")
        self.result_rows = []
        self.results_mode = "ciphers"
        if hasattr(self, "results_back_btn"):
            self.results_back_btn.grid_remove()
        try:
            if not self.saved:
                if hasattr(self, "results_title_var"):
                    self.results_title_var.set("")
                return
            if hasattr(self, "results_title_var"):
                self.results_title_var.set(f"נמצאו {len(self.saved)} צפנים העונים על התנאים")
            header_values = ["שם", "דילוג", "משניות", "איכות"]
            table_rows: List[List[str]] = []
            row_meta: List[Tuple[int, Match]] = []
            for idx, (pm, local) in enumerate(self.saved, 1):
                score, _quality, _details = self.cipher_quality(pm, local)
                sec_label = self.secondary_count_label(pm, local, include_screen=(idx - 1 == self.current))
                sec_value = sec_label.replace("משניות במסך ", "").replace("משניות ", "")
                table_rows.append([pm.word, str(abs(pm.skip or 1)), sec_value, self.short_quality_text(score)])
                row_meta.append((idx, pm))
            skip_sample = max((row[1] for row in table_rows), key=len, default="0")
            row_widths = self.fixed_table_pixel_widths(header_values, table_rows, ["", skip_sample, "30/30", "א 100%"], [22, 0, 0, 0])
            if hasattr(self.results, "set_columns"):
                self.results.set_columns(
                    header_values,
                    row_widths,
                    sort_command=self.sort_current_cipher_table_by,
                    active_sort_key=self.cipher_sort_key,
                    reverse=self.cipher_sort_reverse,
                )
            data_start = len(self.result_rows)
            for values, (idx, pm) in zip(table_rows, row_meta):
                self.results.insert("end", values)
                self.result_rows.append(("צופן", pm))
                row_index = data_start + idx - 1
                if getattr(self, "result_selection_highlight", False) and idx - 1 == self.current:
                    bg = pm.color or "#ff3b30"
                    fg = "#ffe600" if is_primary_red(bg) else readable_text_on_bg(bg, "#111111")
                else:
                    bg = "#ffffff" if idx % 2 else "#f7f7f7"
                    fg = "#111111"
                self.results.itemconfig(row_index, background=bg, foreground=fg)
            if 0 <= self.current < len(self.saved):
                current_row = data_start + self.current
                self.results.selection_set(current_row)
                self.results.see(current_row)
        finally:
            self.updating_result_selection = False

    def populate_current_result_table(self):
        self.updating_result_selection = True
        self.results.delete(0, "end")
        self.result_rows = []
        self.results_mode = "details"
        if hasattr(self, "results_back_btn"):
            self.results_back_btn.grid()
        try:
            if not self.saved:
                if hasattr(self, "results_title_var"):
                    self.results_title_var.set("")
                return
            pm, local = self.saved[self.current]
            score, _quality, details = self.cipher_quality(pm, local)
            if hasattr(self, "results_title_var"):
                self.results_title_var.set(f"ראשית: {pm.word} | דילוג {abs(pm.skip or 1)} | איכות: {self.short_quality_text(score)}")
            rows: List[Tuple[str, Match]] = []
            for match in self.visible_detail_matches(pm, local):
                rows.append(("משנית", match))
            detail_headers = ["מילה", "דילוג"]
            detail_rows = [[match.word, str(abs(match.skip or 1))] for _label, match in rows]
            self.detail_table_widths = self.compact_table_pixel_widths(detail_headers, detail_rows, [22, 5])
            if hasattr(self.results, "set_columns"):
                self.results.set_columns(detail_headers, self.detail_table_widths, fill_first=True)
            for idx, (label, match) in enumerate(rows, 1):
                self.results.insert("end", [match.word, str(abs(match.skip or 1))])
                self.result_rows.append((label, match))
                color = (match.color or "#ff3b30") if match is pm or match.kind == "primary" else (match.color or stable_word_color(match.word))
                self.results.itemconfig(len(self.result_rows) - 1, background=color, foreground="#111111")
            if rows:
                self.results.selection_set(0)
        finally:
            self.updating_result_selection = False

    def show_cipher_list_from_details(self):
        self.populate_cipher_list()
        self.status.set("רשימת צפנים פתוחה")
        if hasattr(self, "results"):
            self.results.focus_set()

    def update_marker_graph_button_text(self):
        if not hasattr(self, "marker_graph_btn") or not hasattr(self, "canvas"):
            return
        visible = self.canvas.marker_graph_is_visible() if hasattr(self.canvas, "marker_graph_is_visible") else True
        self.marker_graph_btn.configure(text="הסתר גרף" if visible else "הצג גרף")

    def toggle_marker_graph(self):
        if not hasattr(self, "canvas") or not hasattr(self.canvas, "set_marker_graph_visible"):
            return
        visible = self.canvas.marker_graph_is_visible()
        self.canvas.set_marker_graph_visible(not visible)
        self.update_marker_graph_button_text()
        self.status.set("הגרף הוצג" if not visible else "הגרף הוסתר")

    def refresh_current_saved_without_recenter(self):
        if not self.saved or not (0 <= self.current < len(self.saved)):
            return
        pm, local = self.saved[self.current]
        self.current_display_match = pm
        self.set_live_skip_display(pm.skip)
        self.canvas.set_matches(local)
        if self.results_mode == "details":
            self.populate_current_result_table()
        else:
            self.populate_cipher_list()
        self.update_context_header()

    def display_current(self):
        if not self.saved:
            return
        pm, local = self.saved[self.current]
        self.current_display_match = pm
        self.set_live_skip_display(pm.skip)
        self.canvas.view_col_offset = 0
        self.canvas.lock_to_primary_anchor = True
        if pm.kind == "text" or abs(pm.skip or 1) == 1:
            self.canvas.build_linear(self.linear_start_for_match(pm))
        else:
            self.canvas.build_skip_grid(pm)
        self.canvas.set_matches(local)
        if self.results_mode == "details":
            self.populate_current_result_table()
        else:
            self.populate_cipher_list()
        self.update_context_header()

    def show_text_from_current(self):
        if not self.saved:
            self.current_display_match = None
            self.canvas.build_linear(getattr(self.canvas, "linear_start", 0))
            self.canvas.set_matches([])
            self.status.set("תצוגת טקסט רציף פתוחה")
            self.update_context_header()
            return
        pm, local = self.saved[self.current]
        self.current_display_match = pm
        self.set_live_skip_display(pm.skip)
        self.canvas.view_col_offset = 0
        self.canvas.lock_to_primary_anchor = False
        self.canvas.build_linear(self.linear_start_for_match(pm))
        self.canvas.set_matches(local)
        if self.results_mode == "details":
            self.populate_current_result_table()
        else:
            self.populate_cipher_list()
        self.status.set("טקסט רציף סביב הממצא פתוח. אפשר לגלול קדימה ואחורה לאורך כל התורה.")
        self.update_context_header()

    def graph_points(self) -> List[dict]:
        points = []
        for idx, (pm, local) in enumerate(self.saved):
            matches = [pm]
            for match in local:
                if match is pm:
                    continue
                if match.kind == "primary" and match.word == pm.word and match.start == pm.start and match.skip == pm.skip:
                    continue
                matches.append(match)
            for match in matches:
                positions = match.calc_positions()
                if not positions:
                    continue
                center = sum(positions) / len(positions)
                color = match.color or ("#ff3b30" if match.kind == "primary" else stable_word_color(match.word))
                points.append({
                    "saved_index": idx,
                    "match": match,
                    "center": center,
                    "start": min(positions),
                    "end": max(positions),
                    "color": color,
                })
        return points

    def open_marker_graph_point(self, point: dict):
        idx = int(point.get("saved_index", self.current))
        match = point.get("match")
        if not (0 <= idx < len(self.saved)) or match is None:
            return
        self.current = idx
        self.display_current()
        self.center_match_in_view(match)
        self.status.set(f"ציר התורה: מעבר לממצא {match.word} | {self.model.spp_at(match.start)}")

    def open_findings_graph(self):
        if not self.saved:
            rtl_showinfo("גרף ממצאים", "אין עדיין ממצאים להצגה בגרף.")
            return
        win = tk.Toplevel(self.root)
        win.title("גרף ממצאים על פני התורה")
        win.transient(self.root)
        self.prepare_child_window(win, 760, 360)
        win.geometry("980x420")
        frame = ttk.Frame(win, padding=8)
        frame.pack(fill="both", expand=True)
        info = tk.StringVar(value="לחיצה על נקודה תעבור לממצא. המרחקים האופקיים מייצגים מיקום יחסי בתורה.")
        ttk.Label(frame, textvariable=info, anchor="e").pack(fill="x", pady=(0, 5))
        canvas = tk.Canvas(frame, bg="white", highlightthickness=1, highlightbackground="#b7b7b7")
        canvas.pack(fill="both", expand=True)
        points = self.graph_points()
        point_items = {}

        def draw(_event=None):
            canvas.delete("all")
            point_items.clear()
            width = max(1, canvas.winfo_width())
            height = max(1, canvas.winfo_height())
            left, right = 42, width - 24
            top, bottom = 34, height - 62
            axis_y = bottom
            total = max(1, len(self.model.search_text) - 1)
            canvas.create_line(left, axis_y, right, axis_y, fill="#333333", width=2)
            for i in range(6):
                x = left + (right - left) * i / 5
                pos = int(total * i / 5) + 1
                canvas.create_line(x, axis_y - 5, x, axis_y + 5, fill="#333333")
                canvas.create_text(x, axis_y + 20, text=f"{pos:,}", font=("Arial", 9), fill="#333333")
            book_starts = []
            seen_books = set()
            for verse in getattr(self.model, "verses", []):
                if verse.book and verse.book not in seen_books and "?" not in verse.book:
                    seen_books.add(verse.book)
                    book_starts.append((verse.book, verse.start))
            for name, start in book_starts:
                x = left + (right - left) * start / total
                canvas.create_line(x, top, x, axis_y, fill="#dddddd")
                canvas.create_text(x + 3, top + 7, text=name, anchor="w", font=("Arial", 9, "bold"), fill="#555555")

            sorted_points = sorted(points, key=lambda p: (p["center"], p["match"].kind, p["match"].word))
            lanes = []
            for point in sorted_points:
                x = left + (right - left) * point["center"] / total
                lane = 0
                while lane < len(lanes) and abs(x - lanes[lane]) < 12:
                    lane += 1
                if lane == len(lanes):
                    lanes.append(x)
                else:
                    lanes[lane] = x
                y = axis_y - 18 - lane * 16
                if y < top + 12:
                    y = top + 12 + (lane % 5) * 12
                radius = 6 if point["match"].kind == "primary" else 4
                item = canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                          fill=point["color"], outline="#222222", width=1)
                canvas.create_line(x, y + radius, x, axis_y - 1, fill="#cccccc")
                point_items[item] = point
            canvas.create_text(left, height - 18, text=f"סה״כ נקודות: {len(points)} | ממצאים: {len(self.saved)}",
                               anchor="w", font=("Arial", 10, "bold"), fill="#333333")

        def point_at_event(event):
            hits = canvas.find_overlapping(event.x - 4, event.y - 4, event.x + 4, event.y + 4)
            for item in reversed(hits):
                if item in point_items:
                    return point_items[item]
            return None

        def on_click(event):
            point = point_at_event(event)
            if not point:
                return
            self.current = point["saved_index"]
            self.display_current()
            self.center_match_in_view(point["match"])
            info.set(f"{point['match'].word} | דילוג {abs(point['match'].skip or 1)} | מיקום {int(point['center']) + 1:,} | {self.model.spp_at(int(point['center']))}")
            self.status.set("נפתח ממצא מתוך גרף הממצאים")

        def on_motion(event):
            point = point_at_event(event)
            if point:
                canvas.configure(cursor="hand2")
                info.set(f"{point['match'].word} | {point['match'].kind} | דילוג {abs(point['match'].skip or 1)} | מיקום {int(point['center']) + 1:,}")
            else:
                canvas.configure(cursor="")

        canvas.bind("<Configure>", draw)
        canvas.bind("<Button-1>", on_click)
        canvas.bind("<Motion>", on_motion)
        draw()

    def next_result(self):
        if self.saved:
            self.current = (self.current + 1) % len(self.saved)
            self.result_selection_highlight = True
            self.display_current()
            if getattr(self, "results_mode", "") == "ciphers":
                self.select_current_cipher_row(focus_results=False)
            self.status.set(f"ממצא {self.current + 1} מתוך {len(self.saved)}")
        else:
            self.status.set("אין ממצאים לדפדוף")

    def prev_result(self):
        if self.saved:
            self.current = (self.current - 1) % len(self.saved)
            self.result_selection_highlight = True
            self.display_current()
            if getattr(self, "results_mode", "") == "ciphers":
                self.select_current_cipher_row(focus_results=False)
            self.status.set(f"ממצא {self.current + 1} מתוך {len(self.saved)}")
        else:
            self.status.set("אין ממצאים לדפדוף")

    def select_current_cipher_row(self, focus_results: bool = True):
        if not hasattr(self, "results") or getattr(self, "results_mode", "") != "ciphers":
            return
        if not (0 <= int(getattr(self, "current", 0)) < len(getattr(self, "saved", []) or [])):
            return
        target_pm = self.saved[self.current][0]
        for idx, (label, match) in enumerate(getattr(self, "result_rows", []) or []):
            if label == "צופן" and match is not None and self.same_result_match_identity(match, target_pm):
                self.updating_result_selection = True
                try:
                    self.results.selection_clear(0, "end")
                    self.results.selection_set(idx)
                    self.results.activate(idx)
                    self.results.see(idx)
                finally:
                    self.updating_result_selection = False
                if focus_results:
                    self.results.focus_set()
                return

    def select_result(self, event):
        if getattr(self, "updating_result_selection", False):
            return
        sel = self.results.curselection()
        if not sel:
            return
        idx = sel[0]
        if not (0 <= idx < len(self.result_rows)):
            return
        label, match = self.result_rows[idx]
        if self.results_mode == "ciphers" and label == "צופן" and match is not None:
            new_current = self.cipher_index_for_result_match(match, idx)
            if new_current is not None and 0 <= new_current < len(self.saved):
                self.current = new_current
                self.result_selection_highlight = True
                self.display_current()
                self.results.focus_set()
                self.status.set(f"צופן {self.current + 1} מוצג; הראשית נשארת במרכז")
        elif self.results_mode == "details" and match is not None:
            self.results.focus_set()
            self.status.set(f"{match.word} נבחר; דאבל קליק ממרכז אליו")

    def selectable_result_indices(self) -> List[int]:
        indices = []
        for idx, (label, match) in enumerate(self.result_rows):
            if self.results_mode == "ciphers" and label == "צופן" and match is not None:
                indices.append(idx)
            elif self.results_mode == "details" and match is not None:
                indices.append(idx)
        return indices

    def move_result_selection(self, delta: int):
        selectable = self.selectable_result_indices()
        if not selectable:
            return "break"
        sel = self.results.curselection()
        current_idx = sel[0] if sel else selectable[0]
        if current_idx in selectable:
            pos = selectable.index(current_idx)
        else:
            pos = 0
            for i, idx in enumerate(selectable):
                if idx >= current_idx:
                    pos = i
                    break
        next_pos = max(0, min(len(selectable) - 1, pos + int(delta)))
        idx = selectable[next_pos]
        self.results.selection_clear(0, "end")
        self.results.selection_set(idx)
        self.results.activate(idx)
        self.results.see(idx)
        self.results.focus_set()
        self.select_result(None)
        return "break"

    def on_results_mouse_wheel(self, event):
        if getattr(event, "num", None) == 4:
            delta = -1
        elif getattr(event, "num", None) == 5:
            delta = 1
        else:
            delta = -1 if event.delta > 0 else 1
        return self.move_result_selection(delta)

    def result_index_at_pointer_tip(self, event) -> Optional[int]:
        if hasattr(self.results, "identify_row_index"):
            idx = self.results.identify_row_index(int(getattr(event, "y", 0) or 0))
            if idx is not None and 0 <= idx < len(self.result_rows):
                return idx
        y = int(getattr(event, "y", 0) or 0)
        size = int(self.results.size())
        for idx in range(size):
            bbox = self.results.bbox(idx)
            if not bbox:
                continue
            _x, row_y, _w, row_h = bbox
            if row_y <= y < row_y + row_h:
                return idx if 0 <= idx < len(self.result_rows) else None
        return None

    def left_click_result(self, event):
        idx = self.result_index_at_pointer_tip(event)
        if idx is None:
            return None
        if 0 <= idx < len(self.result_rows):
            self.results.selection_clear(0, "end")
            self.results.selection_set(idx)
            self.results.activate(idx)
            _label, match = self.result_rows[idx]
            if self.results_mode == "ciphers":
                sort_key = self.result_sort_key_at_event(idx, event)
                if sort_key:
                    self.sort_current_cipher_table_by(sort_key)
                    return "break"
                if _label == "צופן" and match is not None:
                    cipher_idx = self.cipher_index_for_result_match(match, idx)
                    if cipher_idx is None:
                        return "break"
                    self.current = cipher_idx
                    self.result_selection_highlight = True
                    self.display_current()
                    self.results.focus_set()
                    self.status.set(f"צופן {self.current + 1} במרכז הראשית; דאבל קליק פותח פירוט")
            elif self.results_mode == "details" and match is not None:
                self.canvas.canvas.focus_set()
                self.status.set(f"{match.word} נבחר; דאבל קליק ממרכז אליו")
        return "break"

    def result_sort_key_at_event(self, idx: int, event) -> Optional[str]:
        if self.results_mode != "ciphers":
            return None
        if not (0 <= idx < len(self.result_rows)):
            return None
        label, _match = self.result_rows[idx]
        if label != "כותרת":
            return None
        try:
            row_text = self.results.get(idx)
        except tk.TclError:
            return None
        if "|" not in row_text:
            return None
        raw_parts = row_text.split("|")
        x = int(getattr(event, "x", 0) or 0)
        font = tkfont.Font(font=self.results.cget("font"))
        cursor = 0
        for index, raw_part in enumerate(raw_parts):
            part = raw_part.strip()
            part_width = max(1, font.measure(raw_part))
            separator_width = font.measure("|") if index < len(raw_parts) - 1 else 0
            if cursor <= x <= cursor + part_width + separator_width:
                if part == "משניות":
                    return "secondary"
                if part == "דילוג":
                    return "skip"
                if part == "איכות":
                    return "quality"
                if part == "ראשית":
                    return "primary"
                if part == "שם":
                    return "primary"
                return None
            cursor += part_width + separator_width
        return None

    def cipher_index_for_result_match(self, match: Match, row_idx: int) -> Optional[int]:
        guessed = row_idx - 1
        if 0 <= guessed < len(self.saved) and self.saved[guessed][0] is match:
            return guessed
        for idx, (pm, _local) in enumerate(self.saved):
            if pm is match:
                return idx
            if (
                pm.word == match.word
                and pm.start == match.start
                and pm.skip == match.skip
                and pm.kind == match.kind
            ):
                return idx
        return None

    def open_selected_result(self, event=None):
        idx = None
        if event is not None:
            idx = self.result_index_at_pointer_tip(event)
            if idx is None:
                return "break"
            self.results.selection_clear(0, "end")
            self.results.selection_set(idx)
            self.results.activate(idx)
        else:
            sel = self.results.curselection()
            idx = sel[0] if sel else None
        if idx is not None and 0 <= idx < len(self.result_rows):
            _label, match = self.result_rows[idx]
            if self.results_mode == "ciphers":
                if _label != "צופן" or match is None:
                    return "break"
                cipher_idx = self.cipher_index_for_result_match(match, idx)
                if cipher_idx is None:
                    return "break"
                self.current = cipher_idx
                self.results_mode = "details"
                self.result_selection_highlight = True
                self.display_current()
                pm, _local = self.saved[self.current]
                self.fit_results_table_to_rows(len(self.result_rows), minimum=260)
                self.center_match_in_view(pm)
                self.canvas.canvas.focus_set()
                self.status.set(f"צופן {self.current + 1} נפתח במרכז; פירוט המילים המסומנות פתוח")
                return "break"
            elif match is not None:
                self.center_match_in_view(match)
                self.canvas.canvas.focus_set()
                self.status.set(f"{match.word} נפתח במרכז")
        return "break"

    def linear_start_for_match(self, match: Match) -> int:
        cols = max(1, self.canvas.fitted_linear_cols())
        rows = max(1, self.canvas.fitted_linear_rows())
        positions = match.calc_positions()
        center_pos = int(sum(positions) / len(positions)) if positions else match.start
        return center_pos - (rows // 2) * cols - cols // 2

    def ensure_match_visible_grid(self, match: Match, allow_reanchor: bool = False):
        current = self.current_display_match
        if allow_reanchor and abs(match.skip or 1) > 1 and match is not current:
            self.current_display_match = match
            self.set_live_skip_display(match.skip)
            self.canvas.view_col_offset = 0
            self.canvas.build_skip_grid(match)
            if self.saved and 0 <= self.current < len(self.saved):
                _pm, local = self.saved[self.current]
                self.canvas.set_matches(local)
            return
        if any(p in self.canvas.pos_to_cell for p in match.calc_positions()):
            return
        if allow_reanchor and match.kind in ("text", "primary") and abs(match.skip or 1) == 1:
            self.canvas.build_linear(self.linear_start_for_match(match))
            if self.saved and 0 <= self.current < len(self.saved):
                _pm, local = self.saved[self.current]
                self.canvas.set_matches(local)
        elif current and current.kind != "text":
            self.canvas.build_skip_grid(current)
            if self.saved and 0 <= self.current < len(self.saved):
                _pm, local = self.saved[self.current]
                self.canvas.set_matches(local)

    def result_context_menu(self, event):
        idx = self.result_index_at_pointer_tip(event)
        if idx is None or not (0 <= idx < len(self.result_rows)):
            return "break"
        self.results.selection_clear(0, "end")
        self.results.selection_set(idx)
        self.results.activate(idx)
        _label, match = self.result_rows[idx]
        if self.results_mode == "ciphers" or match is None:
            return "break"
        self.show_match_context_menu(self.results, event.x_root, event.y_root, match)
        return "break"

    def match_context_menu(self, event, match: Match, source: str = "generic"):
        self.show_match_context_menu(event.widget, event.x_root, event.y_root, match, source=source)
        return "break"

    def unique_matches_for_context(self, matches: List[Match]) -> List[Match]:
        unique = []
        seen = set()
        for match in matches:
            key = (canonical_hebrew(match.word), tuple(match.calc_positions()), match.kind)
            if key in seen:
                continue
            seen.add(key)
            unique.append(match)
        return unique

    def context_scope_label(self, title: str, match: Match) -> str:
        return f"{title}: {match.word} | דילוג {abs(match.skip or 1)}"

    def make_single_letter_match(self, pos: int) -> Match:
        letter = self.model.search_text[pos] if 0 <= pos < len(self.model.search_text) else ""
        return Match(letter, pos, 1, "manual", color=stable_word_color(letter), positions=[pos])

    def torah_word_match_if_fully_marked(self, pos: int, matches: List[Match]) -> Optional[Match]:
        word_positions = self.canvas.word_positions_at(pos) if hasattr(self.canvas, "word_positions_at") else []
        if not word_positions:
            return None
        word_set = set(word_positions)
        marked_positions = set()
        for match in matches:
            marked_positions.update(match.calc_positions())
        if not word_set <= marked_positions:
            return None
        word = "".join(self.model.search_text[p] for p in word_positions if 0 <= p < len(self.model.search_text))
        if not word:
            return None
        return Match(word, word_positions[0], 1, "text", color=stable_word_color(word), positions=word_positions[:])

    def add_scope_actions_menu(self, parent_menu: tk.Menu, scope_label: str, match: Match, source: str = "canvas"):
        scope_menu = tk.Menu(parent_menu, tearoff=0)
        self.add_direct_match_actions(scope_menu, match, source=source)
        parent_menu.add_cascade(label=scope_label, menu=scope_menu)

    def add_direct_match_actions(self, menu: tk.Menu, match: Match, source: str = "generic"):
        label = f"{match.word} | דילוג {abs(match.skip or 1)}"
        menu.add_command(label=f"שינוי צבע: {label}", command=lambda m=match: self.change_result_match_color(m))
        menu.add_command(label=f"שינוי צבע לכל אלה בצופן: {match.word}", command=lambda m=match: self.change_all_matching_color_in_current_saved(m))
        menu.add_command(label=f"להשאיר רק את זה מהמילים הזהות לו: {match.word}", command=lambda m=match: self.keep_only_this_matching_in_current_saved(m))
        menu.add_command(label=f"הסרת כל הקווים מממצאי המילה: {match.word}", command=lambda m=match: self.remove_all_top_connectors_for_match_word(m))
        menu.add_command(label=f"הסרה: {label}", command=lambda m=match: self.remove_result_match(m))
        menu.add_command(label=f"הסרה של כל אלה מהצופן: {match.word}", command=lambda m=match: self.remove_all_matching_from_current_saved(m))
        menu.add_command(label=f"הסרה גם מקובץ הסריקה: {match.word}", command=lambda m=match: self.remove_match_and_delete_word(m))
        move_menu = tk.Menu(menu, tearoff=0)
        for category, file_name in WORD_CATEGORY_FILES.items():
            move_menu.add_command(label=category, command=lambda m=match, c=category, f=file_name: self.move_match_word_to_category_file(m, c, f))
        menu.add_cascade(label="העברה לקובץ אחר", menu=move_menu)

    def remove_all_top_connectors_for_match_word(self, match: Match):
        removed = self.canvas.remove_top_connectors_for_word(match.word)
        self.update_context_top_lines_button()
        if removed:
            self.status.set(f"הוסרו {removed} קווים מממצאי המילה {match.word}")
        else:
            self.status.set(f"אין קווים להסרה מממצאי המילה {match.word}")

    def clear_all_top_connectors_in_cipher(self):
        removed = self.canvas.clear_top_connectors()
        self.update_context_top_lines_button()
        if removed:
            self.status.set(f"הוסרו {removed} קווים מהצופן")
        else:
            self.status.set("אין קווים להסרה בצופן הנוכחי")

    def context_scopes_for_match(self, match: Match) -> List[Tuple[str, Match]]:
        scopes: List[Tuple[str, Match]] = [(self.context_scope_label("רצף האותיות המסומן", match), match)]
        positions = match.calc_positions()
        first_pos = positions[0] if positions else match.start
        torah_word_match = self.torah_word_match_if_fully_marked(first_pos, [match])
        if torah_word_match is not None:
            scopes.append((self.context_scope_label("המילה בתורה", torah_word_match), torah_word_match))
        if 0 <= first_pos < len(self.model.search_text):
            letter_match = self.make_single_letter_match(first_pos)
            if letter_match.word:
                scopes.append((self.context_scope_label("אות אחת", letter_match), letter_match))
        return scopes

    def add_context_line_actions(self, menu: tk.Menu, widget, match: Match, source: str):
        match = self.resolve_current_match_reference(match)
        label = f"{match.word} | דילוג {abs(match.skip or 1)}"
        if source == "top":
            action = "הסרת קו לתצוגה" if self.canvas.top_connector_exists_for_match(match) else "סימון קו לתצוגה"
            menu.add_command(label=f"{action}: {label}", command=lambda w=widget, m=match: self.canvas.add_top_connector_to_match(w, m))
        else:
            framed_match = self.canvas.builtin_frame_visible_for_overlapping_match(match)
            target = framed_match or match
            if self.canvas.match_line_exists(target):
                menu.add_command(label=f"הסר מסגרת מאותיות הממצא: {target.word} | דילוג {abs(target.skip or 1)}", command=lambda m=target: self.canvas.remove_line_for_match(m))
            else:
                menu.add_command(label=f"הוסף מסגרת לאותיות הממצא: {label}", command=lambda m=target: self.canvas.add_line_for_match(m))

    def show_canvas_letter_context_menu(self, widget, x_root: int, y_root: int, pos: int, matches: List[Match]):
        menu = tk.Menu(widget, tearoff=0)
        unique = self.unique_matches_for_context(matches)
        for match in unique:
            self.add_scope_actions_menu(menu, self.context_scope_label("רצף האותיות המסומן", match), match, source="canvas")
        torah_word_match = self.torah_word_match_if_fully_marked(pos, unique)
        if torah_word_match is not None:
            self.add_scope_actions_menu(menu, self.context_scope_label("המילה בתורה", torah_word_match), torah_word_match, source="canvas")
        letter_match = self.make_single_letter_match(pos)
        if letter_match.word:
            self.add_scope_actions_menu(menu, self.context_scope_label("אות אחת", letter_match), letter_match, source="canvas")
        if unique:
            menu.add_separator()
            for match in unique:
                self.add_context_line_actions(menu, widget, match, "canvas")
        if menu.index("end") is not None:
            menu.tk_popup(x_root, y_root)

    def show_match_context_menu(self, widget, x_root: int, y_root: int, match: Match, source: str = "generic"):
        menu = tk.Menu(widget, tearoff=0)
        self.add_direct_match_actions(menu, match, source=source)
        menu.add_separator()
        self.add_context_line_actions(menu, widget, match, source)
        menu.tk_popup(x_root, y_root)

    def center_match_in_view(self, match: Match):
        self.root.update_idletasks()
        self.ensure_match_visible_grid(match, allow_reanchor=True)
        self.root.update_idletasks()
        positions = [p for p in match.calc_positions() if p in self.canvas.pos_to_cell]
        if positions:
            cells = [self.canvas.pos_to_cell[p] for p in positions]
            avg_row = sum(r for r, _c in cells) / len(cells)
            avg_col = sum(c for _r, c in cells) / len(cells)
            start_col, end_col = self.canvas.visible_col_bounds()
            visible_cols = max(1, end_col - start_col)
            content_w = self.canvas.spp_w + max(
                (self.canvas.row_visual_width(row, start_col, end_col) for row in self.canvas.grid),
                default=visible_cols * self.canvas.visual_cell_width(),
            )
            visible_col = max(0, avg_col - start_col)
            x = self.canvas.draw_x_offset + content_w - self.canvas.spp_w - (visible_col + 0.5) * self.canvas.visual_cell_width()
            y = avg_row * self.canvas.cell_h
            region = self.canvas.canvas.cget("scrollregion").split()
            if len(region) == 4:
                total_w = max(1, float(region[2]))
                total_h = max(1, float(region[3]))
                view_w = max(1, self.canvas.canvas.winfo_width())
                view_h = max(1, self.canvas.canvas.winfo_height())
                max_x = max(1, total_w - view_w)
                max_y = max(1, total_h - view_h)
                target_x = x - view_w / 2
                target_y = y - view_h / 2
                self.canvas.canvas.xview_moveto(max(0.0, min(1.0, target_x / max_x)))
                self.canvas.canvas.yview_moveto(max(0.0, min(1.0, target_y / max_y)))
        self.status.set(f"מעבר לממצא: {match.word} | דילוג {abs(match.skip or 1)}")

    def change_result_match_color(self, match: Match):
        match = self.resolve_current_match_reference(match)
        initial = match.color or ("#ff3b30" if match.kind == "primary" else stable_word_color(match.word))
        color = colorchooser.askcolor(color=initial, title=f"צבע עבור {match.word}")[1]
        if not color:
            return
        self.push_app_undo_state(f"שינוי צבע {match.word}")
        match.color = color
        if not self.saved:
            self.canvas.set_matches([match])
            return
        pm, local = self.saved[self.current]
        if match is pm or self.same_result_match_identity(pm, match):
            pm.color = color
            for local_match in local:
                if local_match.kind == "primary" and canonical_hebrew(local_match.word) == canonical_hebrew(pm.word):
                    local_match.color = color
        else:
            updated = False
            for local_match in local:
                if local_match is match or self.same_result_match_identity(local_match, match):
                    local_match.color = color
                    updated = True
            if not updated and match not in local:
                local.append(match)
                self.saved[self.current] = (pm, local)
        for manual in getattr(self.canvas, "manual_marks", []):
            if self.same_result_match_identity(manual, match):
                manual.color = color
        for item in getattr(self.canvas, "top_connector_lines", []):
            item_match = item.get("match") if isinstance(item, dict) else None
            if item_match is not None and self.same_result_match_identity(item_match, match):
                item_match.color = color
        self.canvas.set_matches(local)
        self.populate_current_result_table()
        self.update_context_header()
        self.status.set(f"שונה צבע: {match.word}")

    def change_all_matching_color_in_current_saved(self, match: Match):
        if not self.saved:
            return
        match = self.resolve_current_match_reference(match)
        initial = match.color or ("#ff3b30" if match.kind == "primary" else stable_word_color(match.word))
        color = colorchooser.askcolor(color=initial, title=f"צבע לכל המופעים של {match.word}")[1]
        if not color:
            return
        self.push_app_undo_state(f"שינוי צבע לכל {match.word}")
        target_word = canonical_hebrew(match.word)
        target_positions = set(match.calc_positions())
        pm, local = self.saved[self.current]
        changed = 0
        if target_word and canonical_hebrew(pm.word) == target_word:
            pm.color = color
            changed += 1
        for item in local:
            same_word = target_word and canonical_hebrew(item.word) == target_word
            same_positions = target_positions and set(item.calc_positions()) == target_positions
            if same_word or same_positions:
                item.color = color
                changed += 1
        for manual in getattr(self.canvas, "manual_marks", []):
            same_word = target_word and canonical_hebrew(manual.word) == target_word
            same_positions = target_positions and set(manual.calc_positions()) == target_positions
            if same_word or same_positions:
                manual.color = color
                changed += 1
        for item in getattr(self.canvas, "top_connector_lines", []):
            item_match = item.get("match") if isinstance(item, dict) else None
            if item_match is None:
                continue
            same_word = target_word and canonical_hebrew(item_match.word) == target_word
            same_positions = target_positions and set(item_match.calc_positions()) == target_positions
            if same_word or same_positions:
                item_match.color = color
        self.canvas.set_matches(local)
        if self.results_mode == "details":
            self.populate_current_result_table()
        else:
            self.populate_cipher_list()
        self.update_context_header()
        self.status.set(f"שונה צבע ל-{changed} מופעים של {match.word}" if changed else f"לא נמצאו מופעים של {match.word} לצביעה")

    def remove_result_match(self, match: Match):
        if not self.saved:
            return
        match = self.resolve_current_match_reference(match)
        self.push_app_undo_state(f"הסרת {match.word}")
        pm, local = self.saved[self.current]
        if match is pm:
            local = [m for m in local if not (m.kind == "primary" and m.word == pm.word and m.start == pm.start and m.skip == pm.skip)]
            self.saved[self.current] = (pm, local)
        else:
            removed = False
            for item in list(local):
                if item is match or self.same_result_match_identity(item, match):
                    local.remove(item)
                    removed = True
                    break
            if removed:
                self.saved[self.current] = (pm, local)
            elif self.same_result_match_identity(pm, match):
                self.saved[self.current] = (pm, local)
                removed = True
            else:
                self.status.set(f"לא נמצא סימון להסרה עבור {match.word}")
                return
        self.canvas.set_matches(local)
        self.populate_current_result_table()
        self.update_context_header()
        self.status.set("הוסר סימון")

    def remove_all_matching_from_current_saved(self, match: Match):
        if not self.saved:
            return
        match = self.resolve_current_match_reference(match)
        self.push_app_undo_state(f"הסרת כל {match.word}")
        target_word = canonical_hebrew(match.word)
        target_positions = set(match.calc_positions())
        pm, local = self.saved[self.current]
        kept = []
        removed = 0
        for item in local:
            same_word = target_word and canonical_hebrew(item.word) == target_word
            same_positions = target_positions and set(item.calc_positions()) == target_positions
            if same_word or same_positions:
                removed += 1
                continue
            kept.append(item)
        self.saved[self.current] = (pm, kept)
        self.canvas.set_matches(kept)
        self.populate_current_result_table()
        self.update_context_header()
        self.status.set(f"הוסרו {removed} מופעים של {match.word} מהצופן" if removed else f"לא נמצאו מופעים נוספים של {match.word} להסרה")

    def keep_only_this_matching_in_current_saved(self, match: Match):
        if not self.saved:
            return
        match = self.resolve_current_match_reference(match)
        target_word = canonical_hebrew(match.word)
        if not target_word:
            return
        self.push_app_undo_state(f"השארת מופע יחיד של {match.word}")
        target_positions = tuple(match.calc_positions())
        pm, local = self.saved[self.current]
        kept = []
        removed = 0
        kept_target = False
        for item in local:
            if canonical_hebrew(item.word) != target_word:
                kept.append(item)
                continue
            same_positions = tuple(item.calc_positions()) == target_positions
            if same_positions and not kept_target:
                kept.append(item)
                kept_target = True
                continue
            removed += 1
        if not kept_target and canonical_hebrew(pm.word) == target_word and tuple(pm.calc_positions()) == target_positions:
            kept_target = True
        self.saved[self.current] = (pm, kept)
        self.canvas.set_matches(kept)
        self.populate_current_result_table()
        self.update_context_header()
        if removed:
            self.status.set(f"נשאר מופע אחד של {match.word}; הוסרו {removed} סימונים זהים")
        else:
            self.status.set(f"לא נמצאו סימונים נוספים של {match.word} להסרה")

    def remove_result_word_marks_on_screen(self, match: Match):
        if not self.saved:
            return
        match = self.resolve_current_match_reference(match)
        self.push_app_undo_state(f"הסרת {match.word} מהמסך")
        target_word = canonical_hebrew(match.word)
        if not target_word:
            return
        visible = self.canvas.visible_positions() if hasattr(self, "canvas") else set()
        pm, local = self.saved[self.current]
        kept = []
        removed = 0
        for item in local:
            is_primary_anchor = (
                item.kind == "primary"
                and item.word == pm.word
                and item.start == pm.start
                and item.skip == pm.skip
            )
            if is_primary_anchor:
                kept.append(item)
                continue
            same_word = canonical_hebrew(item.word) == target_word
            positions = set(item.calc_positions())
            on_screen = not visible or bool(positions & visible)
            if same_word and on_screen:
                removed += 1
                continue
            kept.append(item)
        self.saved[self.current] = (pm, kept)
        self.canvas.set_matches(kept)
        self.populate_current_result_table()
        self.update_context_header()
        if removed:
            self.status.set(f"הוסרו {removed} סימונים של {match.word} מהמסך")
        else:
            self.status.set(f"לא נמצאו סימונים נוספים של {match.word} להסרה במסך")

    def clear_result_marks(self, idx: int):
        if not (0 <= idx < len(self.saved)):
            return
        self.push_app_undo_state("ניקוי סימוני צופן")
        pm, _local = self.saved[idx]
        self.saved[idx] = (pm, [])
        if idx == self.current:
            self.canvas.set_matches([])
            self.populate_current_result_table()
        self.status.set("נוקו סימונים")

    def remove_match_from_current_saved(self, match: Match):
        if not self.saved:
            return
        match = self.resolve_current_match_reference(match)
        self.push_app_undo_state(f"הסרת {match.word}")
        pm, local = self.saved[self.current]
        for item in list(local):
            if item is match or self.same_result_match_identity(item, match):
                local.remove(item)
                self.saved[self.current] = (pm, local)
                self.canvas.set_matches(local)
                self.populate_current_result_table()
                self.update_context_header()
                return
        if self.same_result_match_identity(pm, match):
            self.canvas.set_matches(local)
            self.populate_current_result_table()
            self.update_context_header()

    def remove_match_and_delete_word(self, match: Match):
        self.remove_result_match(match)
        self.delete_word_from_scan_file(match.word)

    def scan_current_screen(self):
        if self.stop_running_then(self.scan_current_screen, "סריקת מסך"):
            return
        if not self.saved:
            rtl_showinfo("סריקה", "אין ממצא נוכחי")
            return
        words, source = self.load_scan_words()
        if not words:
            rtl_showinfo("סריקה", "לא נמצא קובץ מילים לסריקה ואין מילים משניות לסריקה")
            return
        self.clear_status_lock()
        current_index = self.current
        grid_snapshot = self.visible_grid_snapshot()
        self.status.set(f"סורק מסך לפי {source}...")
        self.progress.configure(value=0)
        self.engine.begin_search()
        self.scan_stop = False
        self.update_search_button_state()
        self.scan_thread = threading.Thread(
            target=self._scan_worker,
            args=(current_index, grid_snapshot, words, source, None, "scan"),
            daemon=True,
        )
        self.scan_thread.start()

    def scan_current_secondaries(self):
        if self.stop_running_then(self.scan_current_secondaries, "סריקת משניות במסך"):
            return
        if not self.saved:
            rtl_showinfo("סריקת משניות", "אין ממצא נוכחי")
            return
        words = [w for w in self.secondary_words() if len(w) >= 2]
        if not words:
            rtl_showinfo("סריקת משניות", "אין מילים בשדה משניות")
            return
        self.clear_status_lock()
        current_index = self.current
        grid_snapshot = self.dense_current_primary_grid_snapshot()
        self.status.set(f"סורק את המשניות בחלון הרחב ביותר של הצופן: {len(words)} מילים...")
        self.progress.configure(value=0)
        self.engine.begin_search()
        self.scan_stop = False
        self.update_search_button_state()
        self.scan_thread = threading.Thread(
            target=self._scan_worker,
            args=(current_index, grid_snapshot, list(dict.fromkeys(words)), "המשניות", None, "secondary"),
            daemon=True,
        )
        self.scan_thread.start()

    def scan_current_dates(self):
        if self.stop_running_then(self.scan_current_dates, "סריקת תאריכים"):
            return
        if not self.saved:
            rtl_showinfo("תאריכים", "אין ממצא נוכחי")
            return
        date_words = self.load_date_words()
        if not date_words:
            rtl_showinfo("תאריכים", "לא נמצא קובץ תאריכים לסריקה")
            return
        self.clear_status_lock()
        date_words = dict(date_words)
        date_words["include_av"] = bool(self.opt_include_av_dates.get()) if hasattr(self, "opt_include_av_dates") else False
        current_index = self.current
        date_grids = self.date_scan_grids()
        date_labels = ", ".join(label for label, _grid in date_grids)
        self.status.set(f"סורק תאריכים רק בדילוגים: {date_labels}")
        self.progress.configure(value=0)
        self.engine.begin_search()
        self.scan_stop = False
        self.update_search_button_state()
        self.scan_thread = threading.Thread(
            target=self._scan_worker,
            args=(current_index, date_grids, [], "תאריכים", date_words, "date"),
            daemon=True,
        )
        self.scan_thread.start()

    def scan_stacked_words(self):
        if self.stop_running_then(self.scan_stacked_words, "חיפוש עמודות"):
            return
        self.prepare_search_start("stacked")
        primary_terms = self.primary_terms()
        secondary_terms = self.secondary_words()
        if len(primary_terms) != 1 or not secondary_terms:
            rtl_showinfo(
                "עמודות",
                "חיפוש עמודות צריך בדיוק ביטוי אחד בשדה ראשית ולפחות ביטוי אחד בשדה משניות.\n\n"
                "אם ברצונך לבדוק אותו ביטוי שחוזר על עצמו, השתמש בכפתור חוזרות."
            )
            self.status.set("עמודות: הכנס ראשית אחת ולפחות משנית אחת")
            return
        words = [primary_terms[0]] + secondary_terms
        self.clear_status_lock()
        self.status.set("עמודות: מחפש מילים בטקסט ומסדר טבלת דילוג...")
        self.progress.configure(value=0)
        self.engine.begin_search()
        self.search_thread = threading.Thread(
            target=self._stacked_columns_worker,
            args=(list(dict.fromkeys(words)),),
            daemon=True,
        )
        self.search_thread.start()

    def _stacked_columns_worker(self, words: List[str]):
        try:
            found_by_word = {}
            for idx, word in enumerate(words, 1):
                if self.engine.should_stop():
                    break
                self.set_progress(idx, max(1, len(words)), "עמודות: מחפש מילים בטקסט")
                found_by_word[word] = self.engine.find_text(word)[:80]

            saved = []
            seen = set()
            primary_word = words[0]
            for secondary_word in words[1:]:
                for primary_hit in found_by_word.get(primary_word, []):
                    for secondary_hit in found_by_word.get(secondary_word, []):
                        if self.engine.should_stop() or len(saved) >= MAX_SCAN_RESULTS:
                            break
                        gap = secondary_hit.start - primary_hit.start
                        if gap == 0:
                            continue
                        key = (primary_word, secondary_word, primary_hit.start, secondary_hit.start)
                        if key in seen:
                            continue
                        seen.add(key)
                        label = f"{primary_hit.word}/{secondary_hit.word}"
                        anchor = Match(label, primary_hit.start, gap, "primary", positions=[primary_hit.start, secondary_hit.start])
                        primary_mark = Match(primary_hit.word, primary_hit.start, 1, "stacked", positions=list(range(primary_hit.start, primary_hit.start + len(primary_hit.word))))
                        secondary_mark = Match(secondary_hit.word, secondary_hit.start, 1, "stacked", positions=list(range(secondary_hit.start, secondary_hit.start + len(secondary_hit.word))))
                        saved.append((anchor, [anchor, primary_mark, secondary_mark]))
                    if len(saved) >= MAX_SCAN_RESULTS:
                        break
                if len(saved) >= MAX_SCAN_RESULTS:
                    break

            self.root.after(0, lambda: self.show_matches(saved))
            if saved:
                self.root.after(0, lambda: self.status.set(f"עמודות: נמצאו {len(saved)} סידורי מילים אחת מתחת לשנייה"))
            else:
                self.root.after(0, lambda: self.lock_status_until_next_search("עמודות: לא נמצאו זוגות מילים מתאימים"))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("עמודות", str(e)))
        finally:
            self.root.after(0, self.mark_search_finished)

    def _scan_worker(
        self,
        current_index: int,
        grid_snapshot: object,
        words: List[str],
        source: str,
        date_words: Optional[dict],
        words_kind: str = "scan",
    ):
        try:
            self.set_status("סריקת מסך: בונה מסלולים...")
            should_stop = lambda: self.scan_stop or self.engine.should_stop()
            found = []
            scan_grids = grid_snapshot if words_kind == "date" else [("", grid_snapshot)]
            if words:
                if words_kind == "secondary":
                    total_words = max(1, len(words))
                    for word_index, word in enumerate(words, 1):
                        if should_stop():
                            break
                        self.set_status(f"סריקת משניות במסך: {word_index}/{total_words} {word}")
                        found.extend(self.canvas.screen_word_paths(
                            [word],
                            MAX_SCAN_RESULTS,
                            grid_snapshot,
                            should_stop,
                            self.progress_for(f"סריקת מסך: {word}"),
                        ))
                else:
                    found.extend(self.canvas.screen_word_paths(
                        words,
                        MAX_SCAN_RESULTS,
                        grid_snapshot,
                        should_stop,
                        self.progress_for("סריקת מסך"),
                    ))
                if words_kind != "scan":
                    for match in found:
                        match.kind = words_kind
            if not should_stop() and date_words:
                for label, date_grid in scan_grids:
                    if should_stop():
                        break
                    self.set_status(f"סריקת תאריכים: יום וחודש בדילוג {label}")
                    found.extend(self.day_month_date_matches(date_words, date_grid, should_stop, label))

            if not should_stop() and date_words and current_index < len(self.saved):
                self.set_status("סריקת תאריכים: שנים עבריות בארבעת הדילוגים...")
                year_full = date_words.get("years_full", [])
                year_short = date_words.get("years_short", [])
                year_hits = []
                for label, date_grid in scan_grids:
                    if should_stop():
                        break
                    hits = self.canvas.screen_word_paths(
                        year_full,
                        MAX_SCAN_RESULTS,
                        date_grid,
                        should_stop,
                        self.progress_for(f"סריקת תאריכים: שנים בדילוג {label}"),
                    )
                    if not hits and not should_stop():
                        hits = self.canvas.screen_word_paths(
                            year_short,
                            MAX_SCAN_RESULTS,
                            date_grid,
                            should_stop,
                            self.progress_for(f"סריקת תאריכים: שנים בלי אלפים בדילוג {label}"),
                        )
                    year_hits.extend(hits)
                for match in year_hits:
                    match.kind = "date"
                    match.color = "#c2185b"
                found.extend(year_hits)

            self.root.after(0, lambda: self.finish_screen_scan(current_index, found, source))
        except Exception as e:
            self.root.after(0, lambda: rtl_showerror("סריקה", str(e)))

    def finish_screen_scan(self, current_index: int, found: List[Match], source: str):
        if current_index >= len(self.saved):
            self.status.set("הסריקה הסתיימה, אבל הממצא כבר השתנה")
            return
        old_current = self.current
        self.current = current_index
        added_count = self.merge_matches_into_current(found)
        self.current = old_current
        if current_index == self.current:
            self.display_current()
        if self.scan_stop or self.engine.stop_reason:
            reason = self.engine.stop_reason or "סריקת המסך נעצרה ידנית"
            self.status.set(f"{reason} | נוספו {added_count} ממצאים לפי {source}")
        else:
            if added_count:
                self.status.set(f"סריקת מסך: נוספו {added_count} ממצאים לפי {source}")
            else:
                self.lock_status_until_next_search(f"סריקת מסך: לא נמצאו ממצאים חדשים לפי {source}")


if __name__ == "__main__":
    try:
        set_windows_app_id()
        root = tk.Tk()
        root.withdraw()
        apply_window_icon(root)
        app = App(root)
        root.deiconify()
        root.lift()
        root.mainloop()
    except Exception as e:
        try:
            rtl_showerror(
                "גל עיני - שגיאה בפתיחה",
                "לא הצלחתי לפתוח את התוכנה.\n\n"
                "ודא שכל קבצי התוכנה חולצו לאותה תיקייה ושמותקן Python 3.\n\n"
                f"שגיאה:\n{e}"
            )
        except Exception:
            raise


