גל עיני V124 - חבילה ידידותית למייל
====================================

הקובץ v124.py נשלח בשם:
v124.py.txt

אחרי חילוץ ה-ZIP צריך לשנות את שמו בחזרה ל:
v124.py

לאחר מכן מפעילים כך:
python v124.py

החבילה אינה כוללת קובץ BAT, כדי שמיילים לא יסמנו אותה כחשודה.

קבצי חובה בתיקייה:
- v124.py
- torah_clean.txt
- book_01_genesis_source.txt
- book_02_exodus_source.txt
- book_03_leviticus_source.txt
- book_04_numbers_source.txt
- book_05_deuteronomy_source.txt
- scan_words.txt
- date_words.json

הערה:
אם Windows מסתיר סיומות קבצים, צריך להפעיל בסייר הקבצים:
View / תצוגה -> File name extensions / סיומות שמות קבצים
ואז לשנות את v124.py.txt ל-v124.py.
