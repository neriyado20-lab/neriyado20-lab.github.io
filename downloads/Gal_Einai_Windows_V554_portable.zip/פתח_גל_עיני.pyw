# -*- coding: utf-8 -*-
import os
import runpy
import sys
base = os.path.dirname(os.path.abspath(__file__))
os.chdir(base)
if base not in sys.path:
    sys.path.insert(0, base)
runpy.run_path(os.path.join(base, "GalEinai.pyw"), run_name="__main__")
