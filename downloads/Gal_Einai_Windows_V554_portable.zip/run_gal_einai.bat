@echo off
cd /d "%~dp0"
py -3 GalEinai.pyw
if errorlevel 1 pythonw GalEinai.pyw

