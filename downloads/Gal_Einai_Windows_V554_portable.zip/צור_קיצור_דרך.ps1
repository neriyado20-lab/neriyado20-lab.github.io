$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$ws = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('DesktopDirectory')
$startMenu = Join-Path ([Environment]::GetFolderPath('Programs')) 'Gal Einai'
New-Item -ItemType Directory -Path $startMenu -Force | Out-Null
$pythonw = (Get-Command pythonw.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source)
if (-not $pythonw) { $pythonw = (Get-Command py.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source) }
if (-not $pythonw) { throw 'Python לא נמצא במחשב.' }
$launcher = Join-Path $base 'פתח_גל_עיני.pyw'
$icon = Join-Path $base 'gal_einai_icon.ico'
foreach ($target in @((Join-Path $desktop 'גל עיני.lnk'), (Join-Path $startMenu 'גל עיני.lnk'))) {
  $s = $ws.CreateShortcut($target)
  $s.TargetPath = $pythonw
  $s.Arguments = '"' + $launcher + '"'
  $s.WorkingDirectory = $base
  $s.Description = 'גל עיני - תוכנה לחיפוש צפנים בתורה'
  if (Test-Path -LiteralPath $icon) { $s.IconLocation = $icon }
  $s.Save()
}
Write-Host 'נוצר קיצור דרך בשם גל עיני בשולחן העבודה ובתפריט התחל.'
