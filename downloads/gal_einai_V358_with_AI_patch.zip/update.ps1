﻿$ErrorActionPreference = 'Stop'
$target = Join-Path $env:LOCALAPPDATA 'GalEinai\with_AI'
if (!(Test-Path -LiteralPath $target)) {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show('לא נמצאה התקנה קיימת של גל עיני ב-' + $target + '. למשתמש חדש יש להפעיל setup.exe.', 'גל עיני')
    exit 1
}
$backup = Join-Path $target ('backup-before-V358-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backup | Out-Null
foreach ($name in @('v340.py','open_gal_einai.pyw','installed_version.txt')) {
    $old = Join-Path $target $name
    if (Test-Path -LiteralPath $old) { Copy-Item -LiteralPath $old -Destination $backup -Force }
}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'v340.py') -Destination (Join-Path $target 'v340.py') -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'open_gal_einai.pyw') -Destination (Join-Path $target 'open_gal_einai.pyw') -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'installed_version.txt') -Destination (Join-Path $target 'installed_version.txt') -Force
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show('העדכון ל-V358 הותקן בהצלחה.', 'גל עיני')
