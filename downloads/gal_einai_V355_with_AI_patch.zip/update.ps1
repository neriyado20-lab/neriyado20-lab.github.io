﻿$ErrorActionPreference = 'Stop'
$source = Split-Path -Parent $MyInvocation.MyCommand.Path
$installDir = Join-Path $env:LOCALAPPDATA 'GalEinai\with_AI'
$shell = New-Object -ComObject WScript.Shell
if (-not (Test-Path -LiteralPath $installDir)) {
  $shell.Popup('לא נמצאה התקנה קיימת של גל עיני עם AI. יש להפעיל קודם את קובץ ההתקנה המלא.', 0, 'גל עיני - עדכון', 48) | Out-Null
  exit 1
}
$backup = Join-Path $installDir ('backup_before_V355_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($name in @('v340.py','open_gal_einai.pyw','installed_version.txt')) {
  $target = Join-Path $installDir $name
  if (Test-Path -LiteralPath $target) { Copy-Item -LiteralPath $target -Destination (Join-Path $backup $name) -Force }
  Copy-Item -LiteralPath (Join-Path $source $name) -Destination $target -Force
}
$shell.Popup('העדכון הושלם. הוחלף רק קוד התוכנה, בלי להעתיק מחדש את הקבצים הגדולים.', 0, 'גל עיני - עדכון', 64) | Out-Null
