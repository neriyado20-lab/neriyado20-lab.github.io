@powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"
