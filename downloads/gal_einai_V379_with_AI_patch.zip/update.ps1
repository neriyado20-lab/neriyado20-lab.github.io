﻿$ErrorActionPreference="Stop"; Copy-Item -LiteralPath (Join-Path $PSScriptRoot "*") -Destination (Split-Path -Parent $PSScriptRoot) -Force
