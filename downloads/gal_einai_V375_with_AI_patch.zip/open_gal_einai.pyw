# -*- coding: utf-8 -*-
import os
import traceback
import tkinter as tk
from tkinter import messagebox


def main():
    base = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base)
    try:
        import v340

        v340.set_windows_app_id()
        root = tk.Tk()
        root.withdraw()
        v340.apply_window_icon(root)
        v340.App(root)
        root.deiconify()
        root.lift()
        root.mainloop()
    except Exception as exc:
        try:
            messagebox.showerror(
                "גל עיני - שגיאה בפתיחה",
                "לא הצלחתי לפתוח את גל עיני.\n\n"
                "ודא שכל קבצי התוכנה חולצו לאותה תיקייה ושמותקן Python 3.\n\n"
                f"שגיאה:\n{exc}\n\n{traceback.format_exc(limit=6)}",
            )
        except Exception:
            raise


if __name__ == "__main__":
    main()
