﻿$ErrorActionPreference = "Stop"
Write-Host "העדכון הותקן. אפשר לפתוח מחדש את גל עיני."
