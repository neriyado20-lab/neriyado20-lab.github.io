@echo off`r`npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"`r`npause`r`n
