"""Keep existing Gal Einai taskbar shortcuts on the newest opened release."""
import os
import subprocess
import sys
from pathlib import Path

SCRIPT = r'''
$ErrorActionPreference = 'Stop'
$newPath=$env:GE_SHORTCUT_EXE
$newVersion=[int]$env:GE_SHORTCUT_VERSION
$folder=Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
$shell=New-Object -ComObject WScript.Shell
Get-ChildItem -LiteralPath $folder -Filter '*.lnk' | ForEach-Object {
    $link=$shell.CreateShortcut($_.FullName)
    if ([IO.Path]::GetFileName($link.TargetPath) -match '^GalEinai_V(\d+)\.exe$') {
        if ([int]$Matches[1] -le $newVersion -and $link.TargetPath -ne $newPath) {
            $backup=$_.FullName+'.gal-einai-backup'
            if (!(Test-Path -LiteralPath $backup)) { Copy-Item -LiteralPath $_.FullName -Destination $backup }
            $link.TargetPath=$newPath
            $link.WorkingDirectory=[IO.Path]::GetDirectoryName($newPath)
            $link.IconLocation=$newPath+',0'
            $link.Description='Gal Einai - latest installed version'
            $link.Save()
        }
    }
}
'''

def register_current_release():
    if not getattr(sys, 'frozen', False):
        return
    import re
    exe = Path(sys.executable).resolve()
    match = re.fullmatch(r'GalEinai_V(\d+)\.exe', exe.name, re.I)
    if not match:
        return
    env=os.environ.copy()
    env.update(GE_SHORTCUT_EXE=str(exe), GE_SHORTCUT_VERSION=match.group(1))
    powershell=Path(os.environ.get('SystemRoot',r'C:\Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
    subprocess.run([str(powershell),'-NoProfile','-NonInteractive','-Command',SCRIPT],
                   env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                   creationflags=subprocess.CREATE_NO_WINDOW,timeout=20,check=True)
