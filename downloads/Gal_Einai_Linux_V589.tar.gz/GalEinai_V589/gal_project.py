"""Compressed search snapshots and atomic, bounded file I/O."""
import gzip
import json
import os
import queue
import tempfile
import threading
from pathlib import Path

MAX_PROJECT_BYTES = 256 * 1024 * 1024

def encode_project(data):
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    if len(raw) > MAX_PROJECT_BYTES:
        raise ValueError('החיפוש גדול ממגבלת קובץ הפרויקט (256 MB).')
    return gzip.compress(raw, compresslevel=6, mtime=0)

def read_project(path):
    with open(path, 'rb') as stream:
        compressed = stream.read(2) == b'\x1f\x8b'
    with (gzip.open if compressed else open)(path, 'rb') as stream:
        raw = stream.read(MAX_PROJECT_BYTES + 1)
    if len(raw) > MAX_PROJECT_BYTES:
        raise ValueError('קובץ הפרויקט גדול מדי לפתיחה (256 MB לפני דחיסה).')
    data = json.loads(raw.decode('utf-8-sig'))
    if not isinstance(data, dict) or not isinstance(data.get('saved', []), list):
        raise ValueError('קובץ הפרויקט אינו במבנה תקין.')
    return data

def write_project_bytes(path, payload):
    destination = Path(path)
    fd, temporary = tempfile.mkstemp(prefix='.gal-project-', dir=destination.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary): os.unlink(temporary)

def format_size(size):
    if size < 1024: return f'{size:,} bytes'
    if size < 1024 * 1024: return f'{size / 1024:,.1f} KB'
    return f'{size / (1024 * 1024):,.2f} MB'

def full_search_data(app):
    data = app.project_to_dict()
    data.update(app.app_state_snapshot())
    data['view'] = data.pop('canvas', {})
    data['save_scope'] = 'full_search'
    data['cipher_sort_key'] = app.cipher_sort_key
    data['cipher_sort_reverse'] = app.cipher_sort_reverse
    return data

def save_full_search(app, dialogs, showinfo, showerror):
    if getattr(app, 'full_search_save_busy', False):
        app.status.set('שמירת החיפוש כבר מתבצעת...')
        return
    pending = app.take_live_cipher_buffer()
    if pending: app.publish_live_cipher_rows(pending)
    if not app.saved:
        showinfo('שמירת חיפוש שלם', 'אין עדיין צפנים לשמירה.')
        return
    data = full_search_data(app)
    count = len(data['saved'])
    app.full_search_save_busy = True
    app.status.set(f'מכין לשמירה {count:,} צפנים ומחשב את נפח הקובץ...')
    completed = queue.Queue()
    def prepare():
        try: completed.put((encode_project(data), None))
        except Exception as error: completed.put((None, str(error)))
    def check_prepared():
        if completed.empty():
            app.root.after(100, check_prepared)
            return
        payload, error = completed.get()
        if error:
            app.full_search_save_busy = False
            showerror('שמירת חיפוש שלם', error)
            return
        volume = format_size(len(payload))
        showinfo('נפח החיפוש לשמירה', f'מספר צפנים: {count:,}\nנפח הקובץ הדחוס: {volume}\n\nיישמרו התוצאות שנמצאו עד תחילת השמירה, הגדרות החיפוש והצופן הנבחר.\nטקסט התורה אינו משוכפל בקובץ. חיפוש פעיל לא ימשיך אוטומטית לאחר פתיחתו.')
        path = dialogs.asksaveasfilename(title=f'שמור חיפוש שלם — {count:,} צפנים — {volume}', defaultextension='.gal_einai.json.gz', filetypes=[('חיפוש שלם דחוס', '*.gal_einai.json.gz')])
        if not path:
            app.full_search_save_busy = False
            app.status.set('שמירת החיפוש בוטלה')
            return
        def write():
            try:
                write_project_bytes(path, payload)
                completed.put((True, None))
            except Exception as error: completed.put((False, str(error)))
        def check_written():
            if completed.empty():
                app.root.after(100, check_written)
                return
            ok, error = completed.get()
            app.full_search_save_busy = False
            if not ok: showerror('שמירת חיפוש שלם', error)
            else: app.status.set(f'נשמר חיפוש שלם: {count:,} צפנים | {volume} | {os.path.basename(path)}')
        threading.Thread(target=write, daemon=True).start()
        app.root.after(100, check_written)
    threading.Thread(target=prepare, daemon=True).start()
    app.root.after(100, check_prepared)

def restore_view(app, data, match_from_dict):
    if data.get('save_scope') != 'full_search' or not app.saved:
        return
    view = data.get('view', {})
    canvas = app.canvas
    bounds = {'font_size':(7,100), 'cell_w':(7,200), 'cell_h':(7,200),
              'view_cols_extra':(-500,500), 'view_rows_extra':(-500,500), 'view_col_offset':(-304805,304805),
              'linear_start':(0,304804), 'skip_view_anchor':(0,304804)}
    for name,(low,high) in bounds.items():
        if name in view and view[name] is not None:
            setattr(canvas,name,max(low,min(high,int(view[name]))))
    if view.get('view_mode') == 'linear':
        canvas.build_linear(canvas.linear_start)
    else:
        canvas.build_skip_grid(app.current_display_match,view_anchor=canvas.skip_view_anchor)
    canvas.lock_to_primary_anchor = False
    canvas.selected_positions = [int(p) for p in view.get('selected_positions',[]) if isinstance(p,int) and 0<=p<304805]
    canvas.top_connector_lines = [{'x': item.get('x',0), 'match':match_from_dict(item['match'])}
                                  for item in view.get('top_connector_lines',[]) if isinstance(item,dict) and isinstance(item.get('match'),dict)]
    canvas.hidden_match_frames = {tuple(raw[:4]) + (tuple(raw[4]),) for raw in view.get('hidden_match_frames',[])
                                  if isinstance(raw,list) and len(raw)==5 and isinstance(raw[4],list)}
    canvas.set_matches(app.saved[app.current][1])
    app.cipher_sort_key = data.get('cipher_sort_key') if data.get('cipher_sort_key') in ('quality','secondary','screen','skip') else 'quality'
    app.cipher_sort_reverse = bool(data.get('cipher_sort_reverse',True))
    app.results_mode = 'details' if data.get('results_mode') == 'details' else 'ciphers'
    if app.results_mode == 'details': app.populate_current_result_table()
    else: app.populate_cipher_list()
