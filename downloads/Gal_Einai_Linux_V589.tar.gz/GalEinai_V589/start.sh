#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
export LOCALAPPDATA="${XDG_DATA_HOME:-$HOME/.local/share}"
if ! python3 -c 'import tkinter' 2>/dev/null; then
  echo 'Python 3 and Tk are required. Ubuntu/Debian: sudo apt install python3 python3-tk'
  exit 1
fi
exec python3 GalEinai.pyw
