"""Per-user JSON storage, with read-only migration from older installations."""
import json
import os
from pathlib import Path
import tempfile


def checked_name(name):
    if name not in ("gal_einai_settings.json", "gal_einai_search_state.json"):
        raise ValueError("Unsupported settings filename")
    return name


def user_data_dir():
    base = os.environ.get("LOCALAPPDATA")
    return (Path(base) if base else Path.home() / "AppData" / "Local") / "GalEinai" / "data"


def read_user_json(name, legacy_dirs=()):
    # Callers supply fixed filenames, never imported project paths.
    target = user_data_dir() / checked_name(name)
    candidates = [target] if target.exists() else [Path(folder) / name for folder in legacy_dirs]
    for candidate in candidates:
        try:
            with candidate.open(encoding="utf-8-sig") as stream:
                value = json.load(stream)
            if isinstance(value, dict):
                return value
        except (OSError, ValueError):
            continue
    return {}


def write_user_json(name, value):
    name = checked_name(name)
    folder = user_data_dir()
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / name
    # A failed write leaves the previous complete JSON file intact.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=folder,
                                         prefix=name + ".", suffix=".tmp", delete=False) as stream:
            temporary = stream.name
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
        temporary = None
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except OSError:
                pass
