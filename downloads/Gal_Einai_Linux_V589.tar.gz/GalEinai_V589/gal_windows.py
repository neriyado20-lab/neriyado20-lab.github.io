"""Place application dialogs near their opening pointer, inside its monitor."""
import ctypes
import os
import tkinter as tk
from ctypes import wintypes


def fit_near_pointer(pointer, size, work_area, gap=8):
    px, py = pointer
    left, top, right, bottom = work_area
    width = min(max(1, size[0]), right - left)
    height = min(max(1, size[1]), bottom - top)
    x = px + gap if px + gap + width <= right else px - gap - width
    y = py + gap if py + gap + height <= bottom else py - gap - height
    return max(left, min(x, right-width)), max(top, min(y, bottom-height)), width, height


def windows_api():
    api = ctypes.windll.user32
    api.MonitorFromPoint.argtypes = [wintypes.POINT, wintypes.DWORD]
    api.MonitorFromPoint.restype = wintypes.HANDLE
    api.GetMonitorInfoW.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
    api.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    api.GetAncestor.restype = wintypes.HWND
    api.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    api.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int,
                                ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    return api


def work_area_at(win, pointer):
    if os.name == 'nt':
        class MonitorInfo(ctypes.Structure):
            _fields_ = [('cbSize', wintypes.DWORD), ('rcMonitor', wintypes.RECT),
                        ('rcWork', wintypes.RECT), ('dwFlags', wintypes.DWORD)]
        api = windows_api()
        info = MonitorInfo()
        info.cbSize = ctypes.sizeof(info)
        monitor = api.MonitorFromPoint(wintypes.POINT(*pointer), 2)
        if api.GetMonitorInfoW(monitor, ctypes.byref(info)):
            r = info.rcWork
            return r.left, r.top, r.right, r.bottom
    return (win.winfo_vrootx(), win.winfo_vrooty(),
            win.winfo_vrootx()+win.winfo_vrootwidth(),
            win.winfo_vrooty()+win.winfo_vrootheight())


def place_near_pointer(win, pointer=None):
    if not win.winfo_exists():
        return
    pointer = pointer or getattr(win, '_opening_pointer', win.winfo_pointerxy())
    win.update_idletasks()
    area = work_area_at(win, pointer)
    if os.name == 'nt':
        api = windows_api()
        hwnd = api.GetAncestor(win.winfo_id(), 2)
        rect = wintypes.RECT()
        if hwnd and api.GetWindowRect(hwnd, ctypes.byref(rect)):
            outer_w, outer_h = rect.right-rect.left, rect.bottom-rect.top
            x, y, width, height = fit_near_pointer(pointer, (outer_w, outer_h), area)
            # Permit an oversized dialog to fit smaller work areas, including its title bar.
            if (width, height) != (outer_w, outer_h):
                client_w = max(1, width - (outer_w-win.winfo_width()))
                client_h = max(1, height - (outer_h-win.winfo_height()))
                min_w, min_h = win.minsize()
                win.minsize(min(min_w, client_w), min(min_h, client_h))
                win.geometry(f'{client_w}x{client_h}')
                win.update_idletasks()
            # Native coordinates handle monitors left of/above the primary screen.
            if api.SetWindowPos(hwnd, None, x, y, width, height, 0x0004 | 0x0010):
                return
    x, y, width, height = fit_near_pointer(pointer, (win.winfo_width(), win.winfo_height()), area)
    win.geometry(f'{width}x{height}+{x}+{y}')


def position_on_open(win):
    """Capture now; place after layout/map, once only. Never chase the pointer."""
    win._opening_pointer = win.winfo_pointerxy()
    def mapped(event):
        if event.widget is not win or getattr(win, '_pointer_placement_scheduled', False):
            return
        win._pointer_placement_scheduled = True
        def place():
            try:
                place_near_pointer(win)
            except tk.TclError:
                pass  # The user may have already closed the dialog.
        win.after(0, place)
    win.bind('<Map>', mapped, add='+')
