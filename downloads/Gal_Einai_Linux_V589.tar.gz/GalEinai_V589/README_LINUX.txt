Gal Einai V589 - Linux Python distribution
Requires Python 3.10+ and Tk, and a graphical desktop.
Ubuntu/Debian dependencies: sudo apt install python3 python3-tk
Extract the entire archive, then run: sh start.sh
No Windows EXE or Python runtime is included.
Search engine regression tests passed on Windows. Linux GUI execution has not been tested.
Known limitations: PNG/PDF screen capture and direct printing require Windows in this version.
User settings are stored separately under ~/.local/share/GalEinai/data (or XDG_DATA_HOME).
This package contains no personal search history or settings.
V589 restores table-based secondary search when All skips is unchecked.
Words+ preserves the explicitly requested signed range for newly added words.
