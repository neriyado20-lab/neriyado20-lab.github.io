"""Clipboard editing for standard fields, preserving widget validation."""
import tkinter as tk
from tkinter import ttk


def install_clipboard(root):
    tag = "GalEinaiClipboard"
    supported = (tk.Entry, ttk.Entry, tk.Text, tk.Spinbox, ttk.Spinbox, ttk.Combobox, tk.Listbox, ttk.Treeview)

    def attach(widget):
        if isinstance(widget, supported) and tag not in widget.bindtags():
            widget.bindtags((tag,) + widget.bindtags())
        for child in widget.winfo_children():
            attach(child)

    def readonly(widget):
        if isinstance(widget, (tk.Listbox, ttk.Treeview)):
            return True
        return str(widget.cget("state")) in ("disabled", "readonly")

    def perform(widget, action):
        try:
            if action in ("cut", "paste", "delete") and readonly(widget):
                return "break"
            if action == "all":
                if isinstance(widget, tk.Text):
                    widget.tag_add("sel", "1.0", "end-1c")
                elif isinstance(widget, tk.Listbox):
                    widget.selection_set(0, "end")
                elif isinstance(widget, ttk.Treeview):
                    widget.selection_set(widget.get_children())
                else:
                    widget.selection_range(0, "end")
                return "break"
            if action == "copy" and isinstance(widget, (tk.Listbox, ttk.Treeview)):
                if isinstance(widget, tk.Listbox):
                    values = [str(widget.get(i)) for i in widget.curselection()]
                else:
                    values = ["\t".join([str(widget.item(i, "text"))] + [str(v) for v in widget.item(i, "values")]).strip("\t") for i in widget.selection()]
                if values:
                    root.clipboard_clear()
                    root.clipboard_append("\n".join(values))
            elif action == "delete":
                if isinstance(widget, tk.Text):
                    widget.delete("sel.first", "sel.last")
                elif widget.selection_present():
                    widget.delete("sel.first", "sel.last")
            elif action in ("copy", "cut", "paste"):
                widget.event_generate({"copy":"<<Copy>>", "cut":"<<Cut>>", "paste":"<<Paste>>"}[action])
        except tk.TclError:
            pass
        return "break"

    def keyboard(event):
        # Windows physical key codes work with Hebrew and English layouts.
        action = {65:"all", 67:"copy", 88:"cut", 86:"paste"}.get(event.keycode)
        if action is None:
            action = {"a":"all", "c":"copy", "x":"cut", "v":"paste"}.get(event.keysym.lower())
        return perform(event.widget, action) if action else None

    def menu(event):
        widget = event.widget
        if getattr(widget, "_clipboard_original_menu", False):
            return None
        popup = tk.Menu(widget, tearoff=False)
        for label, action in (("העתק", "copy"), ("גזור", "cut"), ("הדבק", "paste"), ("מחק בחירה", "delete"), ("בחר הכול", "all")):
            popup.add_command(label=label, command=lambda a=action: perform(widget, a),
                              state="disabled" if action in ("cut", "paste", "delete") and readonly(widget) else "normal")
        if widget.bind("<Button-3>"):
            def original_menu():
                widget._clipboard_original_menu = True
                try:
                    widget.event_generate("<Button-3>", x=event.x, y=event.y, rootx=event.x_root, rooty=event.y_root)
                finally:
                    widget._clipboard_original_menu = False
            popup.add_separator()
            popup.add_command(label="אפשרויות נוספות", command=original_menu)
        try:
            popup.tk_popup(event.x_root, event.y_root)
        finally:
            popup.grab_release()
        return "break"

    root.bind_class(tag, "<Control-KeyPress>", keyboard)
    root.bind_class(tag, "<Control-Insert>", lambda e: perform(e.widget, "copy"))
    root.bind_class(tag, "<Shift-Insert>", lambda e: perform(e.widget, "paste"))
    root.bind_class(tag, "<Shift-Delete>", lambda e: perform(e.widget, "cut"))
    root.bind_class(tag, "<Button-3>", menu)
    root.bind_all("<Map>", lambda event: attach(event.widget), add="+")
    attach(root)
    return perform
