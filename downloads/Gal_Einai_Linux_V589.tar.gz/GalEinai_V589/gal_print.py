import os
import subprocess
import tempfile
import shutil
import json
import time
from pathlib import Path

# Runs in a separate Windows process; never invokes PDF file associations.
PRINT_SCRIPT = r'''
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
$image = $null
$doc = $null
try {
    $image = [System.Drawing.Image]::FromFile($env:GE_PRINT_IMAGE)
    $doc = New-Object System.Drawing.Printing.PrintDocument
    $doc.PrinterSettings.PrinterName = $env:GE_PRINT_PRINTER
    if (!$doc.PrinterSettings.IsValid) { throw 'The selected printer is unavailable.' }
    $doc.DocumentName = 'Gal Einai'
    $doc.PrintController = New-Object System.Drawing.Printing.StandardPrintController
    $doc.DefaultPageSettings.Landscape = $image.Width -gt $image.Height
    $doc.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins(40,40,40,40)
    $doc.add_PrintPage({
        param($sender, $e)
        $bounds = $e.MarginBounds
        $scale = [Math]::Min($bounds.Width / $image.Width, $bounds.Height / $image.Height)
        $w = [single]($image.Width * $scale)
        $h = [single]($image.Height * $scale)
        $x = [single]($bounds.Left + ($bounds.Width - $w) / 2 - $e.PageSettings.HardMarginX)
        $y = [single]($bounds.Top + ($bounds.Height - $h) / 2 - $e.PageSettings.HardMarginY)
        $e.Graphics.DrawImage($image, $x, $y, $w, $h)
        $border = [single]::Parse($env:GE_PRINT_BORDER, [Globalization.CultureInfo]::InvariantCulture) * 100 / 25.4
        if ($border -gt 0) {
            $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::Black, $border)
            try { $e.Graphics.DrawRectangle($pen, $x, $y, $w, $h) } finally { $pen.Dispose() }
        }
        $e.HasMorePages = $false
    })
    $doc.Print()
    exit 0
} catch {
    [IO.File]::WriteAllText($env:GE_PRINT_ERROR, $_.Exception.Message)
    exit 1
} finally {
    if ($doc) { $doc.Dispose() }
    if ($image) { $image.Dispose() }
}
'''

def available_printers():
    script = r'''Add-Type -AssemblyName System.Drawing
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$p=New-Object System.Drawing.Printing.PrinterSettings
@{printers=@([System.Drawing.Printing.PrinterSettings]::InstalledPrinters); default=$p.PrinterName} | ConvertTo-Json -Compress'''
    powershell = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
    result = subprocess.run([str(powershell), '-NoProfile', '-NonInteractive', '-Command', script],
                            capture_output=True, encoding='utf-8-sig', errors='replace',
                            timeout=20, check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    return json.loads(result.stdout)

class PrintJob:
    def __init__(self, save_image, border_mm, printer):
        if not printer.strip():
            raise ValueError('יש לבחור מדפסת לפני ההדפסה.')
        self.folder = Path(tempfile.mkdtemp(prefix='gal_einai_print_'))
        self.process = None
        self.started = time.monotonic()
        try:
            image = self.folder / 'page.png'
            save_image(str(image))
            env = os.environ.copy()
            env.update(GE_PRINT_IMAGE=str(image), GE_PRINT_BORDER=str(int(border_mm)), GE_PRINT_PRINTER=printer,
                       GE_PRINT_ERROR=str(self.folder / 'error.txt'))
            powershell = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
            self.process = subprocess.Popen(
                [str(powershell), '-NoProfile', '-STA', '-WindowStyle', 'Hidden', '-Command', PRINT_SCRIPT],
                env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
        except Exception:
            self.cleanup()
            raise

    def poll(self):
        return self.process.poll()

    def error(self):
        path = self.folder / 'error.txt'
        return path.read_text(encoding='utf-8-sig') if path.exists() else 'Windows לא הצליח להשלים את פעולת ההדפסה.'

    def cleanup(self):
        shutil.rmtree(self.folder, ignore_errors=True)

