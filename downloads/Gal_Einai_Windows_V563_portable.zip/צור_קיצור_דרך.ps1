$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$ws = New-Object -ComObject WScript.Shell
$fso = New-Object -ComObject Scripting.FileSystemObject
$desktop = [Environment]::GetFolderPath('DesktopDirectory')
$startMenu = Join-Path ([Environment]::GetFolderPath('Programs')) 'Gal Einai'
New-Item -ItemType Directory -Path $startMenu -Force | Out-Null
$launcher = Join-Path $base 'GalEinai.exe'
if (-not (Test-Path -LiteralPath $launcher)) { throw 'קובץ GalEinai.exe לא נמצא.' }
$targetPath = $fso.GetFile($launcher).ShortPath
$workingDir = $fso.GetFolder($base).ShortPath
$icon = Join-Path $base 'gal_einai_icon.ico'
$iconPath = if (Test-Path -LiteralPath $icon) { $fso.GetFile($icon).ShortPath } else { $targetPath }
foreach ($target in @((Join-Path $desktop 'Gal Einai.lnk'), (Join-Path $startMenu 'Gal Einai.lnk'))) {
  $s = $ws.CreateShortcut($target)
  $s.TargetPath = $targetPath
  $s.Arguments = ''
  $s.WorkingDirectory = $workingDir
  $s.Description = 'Gal Einai - Torah codes search'
  $s.IconLocation = $iconPath
  $s.Save()
}
Write-Host 'Created Gal Einai shortcuts on the Desktop and Start Menu.'
Write-Host 'For a clean taskbar pin: unpin the old Python icon, open Gal Einai from the new shortcut, then pin it again.'
