# -*- coding: utf-8 -*-
import ctypes
import os
import runpy
import sys

APP_USER_MODEL_ID = "NeriyaDeutsch.GalEinai"

if os.name == "nt":
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
    except Exception:
        pass

base = os.path.dirname(os.path.abspath(__file__))
os.chdir(base)
if base not in sys.path:
    sys.path.insert(0, base)
runpy.run_path(os.path.join(base, "GalEinai.pyw"), run_name="__main__")
